# Motornaya — Technical Specification

## Overview

Motornaya — это интерактивная fullstack веб-платформа для подбора моторного масла по марке, модели и модификации автомобиля. Пользователь проходит через каскадный селектор (4 шага: марка → модель → модификация → результат), получая рекомендуемые технические жидкости из базы данных.

---

## Development Environment

| Требование | Версия / Способ установки |
|---|---|
| Node.js | ≥ 20 |
| Package Manager | npm (v10+) |
| TypeScript | ~5.7 |
| Build Tool | Vite |

---

## Frontend

### Dependencies

| Package | Версия | Назначение |
|---|---|---|
| `react` | ^19.0.0 | UI-фреймворк |
| `react-dom` | ^19.0.0 | React DOM-рендеринг |
| `react-router-dom` | ^7.6.0 | Маршрутизация (BrowserRouter) |
| `tailwindcss` | ^4.0.0 | Утилитарный CSS |
| `@tailwindcss/vite` | ^4.0.0 | Плагин Vite для Tailwind |
| `gsap` | ^3.12.0 | Анимации: scroll-triggered transitions, staggered cards |
| `@gsap/react` | ^2.1.0 | React-хук useGSAP |
| `@studio-freight/lenis` | ^1.0.0 | Плавный скролл с lerp=0.1 |
| `lucide-react` | ^0.469.0 | SVG-иконки (ChevronRight, Engine, OilCanister и др.) |
| `geist` | ^1.3.0 | Шрифты Inter + JetBrains Mono |
| `@trpc/client` | ^11.0.0 | tRPC клиент для типобезопасных API-вызовов |
| `@trpc/tanstack-react-query` | ^11.0.0 | tRPC + TanStack Query интеграция |
| `@tanstack/react-query` | ^5.62.0 | Управление серверным состоянием, кэширование |
| `superjson` | ^2.2.0 | Сериализация/десериализация данных |
| `zod` | ^3.24.0 | Валидация форм и runtime-типы (shared с backend) |

---

## Backend

### Dependencies

| Package | Версия | Назначение |
|---|---|---|
| `hono` | ^4.6.0 | HTTP-сервер, middleware |
| `@hono/node-server` | ^1.13.0 | Адаптер Hono для Node.js |
| `@trpc/server` | ^11.0.0 | tRPC серверная часть |
| `@trpc/client` | ^11.0.0 | Shared tRPC internals |
| `drizzle-orm` | ^0.40.0 | ORM для MySQL |
| `mysql2` | ^3.12.0 | MySQL-драйвер |
| `dotenv` | ^16.4.0 | Загрузка переменных окружения |
| `zod` | ^3.24.0 | Валидация входных данных (input schemas) |
| `superjson` | ^2.2.0 | Сериализация ответов tRPC |
| `bcryptjs` | ^2.4.0 | Хеширование паролей (auth) |
| `jose` | ^5.9.0 | JWT: создание и верификация токенов |
| `tsx` | ^4.19.0 | Запуск TypeScript напрямую (dev, seed) |
| `typescript` | ~5.7 | Компилятор TypeScript |
| `drizzle-kit` | ^0.30.0 | CLI-инструмент Drizzle (migrations, db:push) |

### Dev Dependencies (shared)

| Package | Версия | Назначение |
|---|---|---|
| `vite` | ^6.0.0 | Сборка фронтенда |
| `@vitejs/plugin-react` | ^4.3.0 | React Fast Refresh для Vite |
| `@types/react` | ^19.0.0 | Типы React |
| `@types/react-dom` | ^19.0.0 | Типы React DOM |
| `@types/bcryptjs` | ^2.4.0 | Типы bcryptjs |
| `@types/node` | ^22.0.0 | Типы Node.js |

---

## Database

### ORM Configuration
- **Движок**: `mysql2` через `DATABASE_URL` env-переменную
- **ORM**: Drizzle ORM (relational API + raw SQL через `sql` tag)
- **Конфиг**: `drizzle.config.ts` — schema: `./db/schema.ts`, driver: `mysql2`
- **Миграции**: `db/migrations/` (meta-файлы для drizzle-kit)

### Schema

Таблицы создаются строго на основе структуры данных из queries.pdf:

#### `brands` (TObrands)
```
id          INT UNSIGNED PK
name        VARCHAR(255)          -- Название марки
```

#### `models` (TOmodels)
```
id          INT UNSIGNED PK AUTO_INCREMENT
makeId      INT UNSIGNED NOT NULL  -- FK → brands.id
modelName   VARCHAR(255)           -- Название модели
yearFrom    VARCHAR(255)           -- Начало выпуска
yearTo      VARCHAR(255)           -- Окончание выпуска
```

#### `modifications` (TOmodifications)
```
id          VARCHAR(53) PK        -- Идентификатор модификации
makeId      INT UNSIGNED           -- FK → brands.id
modelId     INT UNSIGNED           -- FK → models.id
name        VARCHAR(100)           -- Название модификации
engineCode  VARCHAR(100)           -- Код двигателя
constructionType VARCHAR(255)      -- Кузов
fuel        VARCHAR(255)           -- Тип топлива
horsePower  VARCHAR(255)           -- Мощность ЛС
startDate   VARCHAR(25)            -- Начало производства
endDate     VARCHAR(25)            -- Окончание производства
engineCapacity VARCHAR(255)        -- Объём двигателя
numberOfCylinders VARCHAR(255)     -- Количество цилиндров
valves      VARCHAR(255)           -- Клапаны
valvesTotal VARCHAR(255)           -- Всего клапанов
motorType   VARCHAR(255)           -- Тип двигателя
fullName    VARCHAR(255)           -- Полное название
brand       JSON                   -- Производитель (JSON)
model       JSON                   -- Модель (JSON)
```

#### `oils` (TOoils)
```
id          INT UNSIGNED PK AUTO_INCREMENT
makeId      INT UNSIGNED           -- FK → brands.id
modelId     INT UNSIGNED           -- FK → models.id
modificationId VARCHAR(255)        -- FK → modifications.id
catalogId   INT                    -- Техническое поле
catalogItemId INT                  -- Техническое поле
orderPosition INT                  -- Сортировка
artNumber   VARCHAR(255)           -- Артикул
originalName VARCHAR(255)          -- Оригинальное название
volume      VARCHAR(255)           -- Объём
commentName VARCHAR(255)           -- Пояснения
```

#### `parts` (TOparts)
```
id          INT UNSIGNED PK AUTO_INCREMENT
makeId      INT UNSIGNED
modelId     INT UNSIGNED
modificationId VARCHAR(255)
manufacturerId INT
manufacturerName VARCHAR(255)      -- Название производителя
itemName    VARCHAR(100)           -- Наименование запчасти
partNumber  VARCHAR(255)           -- Номер запчасти
quantity    INT                    -- Количество
comment     VARCHAR(255)           -- Комментарий
```

#### `parts_crosses` (TOpartsCrosses)
```
id          INT UNSIGNED PK AUTO_INCREMENT
manufacturerName VARCHAR(255)
partNumber  VARCHAR(255)
crossBrand  VARCHAR(100)           -- Бренд кросса
crossNumber VARCHAR(50)            -- Номер кросса
```

### Seed Data
Данные сидятся из SQL-дампа пользователя (queries.pdf → schema + INSERT). Скрипт `db/seed.ts` выполняет `npx tsx db/seed.ts` и парсит SQL-дамп, вставляя данные через Drizzle `insert().values().onDuplicateKeyUpdate()`.

---

## API Specification (tRPC Routers)

### carRouter — данные автомобилей

| Procedure | Type | Input | Output | Описание |
|---|---|---|---|---|
| `brands` | `query` | — | `Brand[]` | Список уникальных марок (SELECT DISTINCT + ORDER BY name) |
| `models` | `query` | `{ makeId: number }` | `Model[]` | Модели по makeId (yearFrom, yearTo включены) |
| `modifications` | `query` | `{ makeId: number, modelId: number }` | `Modification[]` | Модификации: name, engineCode, fuel, horsePower, startDate, endDate, engineCapacity и др. |

### oilRouter — подбор масел

| Procedure | Type | Input | Output | Описание |
|---|---|---|---|---|
| `byModification` | `query` | `{ makeId: number, modelId: number, modificationId: string }` | `Oil[]` | Технические жидкости (ORDER BY orderPosition ASC) |
| `bySeoType` | `query` | `{ seoType: string }` | `Oil[]` | Альтернативный поиск по seoType-строке |

### partsRouter — запчасти ТО

| Procedure | Type | Input | Output | Описание |
|---|---|---|---|---|
| `byModification` | `query` | `{ makeId: number, modelId: number, modificationId: string }` | `Part[]` | Список запчастей для ТО |

### Zod Schemas (shared в contracts/)
```ts
const brandSchema = z.object({ id: z.number(), name: z.string() })
const modelSchema = z.object({ id: z.number(), modelName: z.string(), yearFrom: z.string().nullable(), yearTo: z.string().nullable() })
const modificationSchema = z.object({ id: z.string(), name: z.string(), engineCode: z.string().nullable(), fuel: z.string().nullable(), horsePower: z.string().nullable(), startDate: z.string().nullable(), endDate: z.string().nullable(), engineCapacity: z.string().nullable() })
const oilSchema = z.object({ id: z.number(), originalName: z.string(), artNumber: z.string().nullable(), volume: z.string().nullable(), commentName: z.string().nullable(), orderPosition: z.number().nullable() })
```

---

## Component Inventory

### Layout
| Компонент | Source | Переиспользование | Примечание |
|---|---|---|---|
| `Header` | Custom | Единоразово | Интерфейсные статусные индикаторы (СИСТЕМА: АКТИВНА, API: ПОДКЛЮЧЕНО) |
| `Footer` | Custom | Единоразово | Копирайт, ссылки, powered by |

### Sections
| Компонент | Source | Переиспользование | Примечание |
|---|---|---|---|
| `HeroSection` | Custom | Единоразово | Viscous Text Hover headline, CTA, scroll indicator |
| `OilSelectorSection` | Custom | Единоразово | Контейнер для 4-шагового каскадного селектора |
| `TechnicalSpecsSection` | Custom | Единоразово | 2-колоночный layout: текст + Liquid Glass панель |

### UI Components (shadcn/ui + Custom)

#### Каскадный селектор (Oil Selector)
| Компонент | Source | Переиспользование | Примечание |
|---|---|---|---|
| `BrandSelector` | Custom | Единоразово | Grid карточек марок, auto-fill minmax(160px, 1fr) |
| `ModelSelector` | Custom | Единоразово | Grid карточек моделей с годами выпуска |
| `ModificationSelector` | Custom | Единоразово | Row-карточки: название + двигатель + мощность/топливо |
| `OilResult` | Custom | Единоразово | Grid OilCard компонентов |
| `OilCard` | Custom | Многократно | Карточка масла: название, объём (badge), артикул, пояснения |
| `SelectorCard` | Custom | Многократно | Базовый шаблон: бордер, hover, active/selected состояния (amber glow) |

#### Прочие UI
| Компонент | Source | Переиспользование | Примечание |
|---|---|---|---|
| `ShimmerSkeleton` | Custom | Многократно | CSS-анимация загрузки (linear-gradient с background-position анимацией) |
| `ScrollIndicator` | Custom | Единоразово | Анимированная линия + текст "Листайте вниз" |
| `ViscousText` | Custom | Единоразово | Двухслойная система: base + gooey overlay с SVG filter |
| `LiquidGlassPanel` | Custom | Единоразово | CSS-only стеклянная панель с radial-gradient highlights |

---

## Animation Implementation Table

| Animation | Library | Реализация | Сложность |
|---|---|---|---|
| Плавный скролл | `@studio-freight/lenis` | Инициализация в корне с lerp=0.1 | Low |
| Scroll-triggered fade-up секций | `gsap` + `ScrollTrigger` | Batch-инициализация: opacity 0→1, y:30→0, stagger | Low |
| Step transition (смена шагов селектора) | `gsap` | Outgoing: opacity→0 (0.3s), incoming: opacity→1, y:20→0 (0.5s) | Medium |
| Card hover effects | CSS transitions | translateY(-2px), border-color, background transitions | Low |
| Shimmer skeleton loader | CSS @keyframes | linear-gradient background-position анимация 1.5s infinite | Low |
| Scroll indicator pulse | CSS @keyframes | opacity 0.3→1.0 циклически | Low |
| Viscous Text Hover | Vanilla JS + CSS SVG filter | mousemove: opposing transforms; mouseenter/mouseleave: opacity/scale/letter-spacing transitions | **High 🔒** |
| Liquid Glass Panel | CSS only | ::before (refraction edge), ::after (caustic sweep), radial-gradient layers | Medium |
| API status dot pulse | CSS @keyframes | Green dot opacity pulse | Low |

---

## State & Logic Plan

### Каскадный селектор (4-шаговый wizard)
- **State machine**: `step: 1 | 2 | 3 | 4` (марка → модель → модификация → результат)
- **Выбор сохраняется**: `selectedBrand`, `selectedModel`, `selectedModification` — useState
- **Переходы**: Выбор на шаге N → increment step, загрузка данных для шага N+1
- **Назад**: Кнопка "← Назад к маркам/моделям" — decrement step
- **Кэширование**: tRPC queries автоматически кэшируются через TanStack Query

### Oil Selector Section — управление видимостью
- `isVisible: boolean` — контролируется ScrollTrigger (GSAP)
- При `isVisible=true` — секция монтируется в DOM (ленивая инициализация)
- Это необходимо для производительности — селектор не должен рендериться до скролла

### API Integration
- `trpc.car.brands.useQuery()` — Step 1
- `trpc.car.models.useQuery({ makeId })` — Step 2 (enabled: !!makeId)
- `trpc.car.modifications.useQuery({ makeId, modelId })` — Step 3 (enabled: !!makeId && !!modelId)
- `trpc.oil.byModification.useQuery({ makeId, modelId, modificationId })` — Step 4 (enabled: all selected)
- Каждый запрос: `isLoading` → ShimmerSkeleton, `isError` → inline error + retry button

---

## Other Key Decisions

### Отказ от Three.js / WebGL
Дизайн-документ упоминает Three.js для Mechanical Pendulum и Fluid Particle Burst, но в финальной версии дизайна эти секции отсутствуют. Оставшиеся визуальные эффекты (Viscous Text Hover, Liquid Glass) реализуются на чистом CSS + vanilla JS. **Three.js не устанавливается** — это снижает bundle size на ~150KB.

### Отказ от карточной 3D-стопки
Tilted 3D Card Stack из исходного дизайна заменён на каскадный селектор как основной UI-элемент. GSAP используется только для scroll-triggered fade-ups и step transitions — без 3D transform матриц.

### Drizzle ORM вместо Raw SQL
Все запросы к БД выполняются через Drizzle ORM query builder. Raw SQL (из queries.pdf) используется только как референс для построения Drizzle-запросов. Это обеспечивает type-safety и zero SQL-injection risk.

### Шрифты
Используется npm-пакет `geist` вместо Google Fonts CDN — это обеспечивает self-hosting шрифтов и устраняет внешнюю зависимость.
