import { useState, useEffect, useRef } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import {
  ChevronRight,
  ChevronLeft,
  Droplets,
  RefreshCw,
  AlertCircle,
  Car,
  Fuel,
  Gauge,
  Calendar,
  Settings2,
  Building2,
  Package,
} from "lucide-react";
import gsap from "gsap";

type Step = 1 | 2 | 3 | 4;
type ResultTab = "catalog" | "company";

const brandIcons: Record<string, string> = {
  Toyota: "T",
  BMW: "B",
  "Mercedes-Benz": "M",
  Audi: "A",
  Volkswagen: "V",
  Ford: "F",
  Honda: "H",
  Hyundai: "Hy",
  Nissan: "N",
  Kia: "K",
  Skoda: "Sk",
  Renault: "R",
  Peugeot: "P",
  Mazda: "Mz",
  Mitsubishi: "Mi",
  Subaru: "Su",
  Lexus: "L",
  Volvo: "Vo",
  Chevrolet: "Ch",
  Opel: "O",
};

function ShimmerSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="aspect-square rounded-lg shimmer-skeleton" />
      ))}
    </div>
  );
}

function OilCard({
  oil,
}: {
  oil: {
    id: number;
    originalName: string | null;
    artNumber: string | null;
    volume: string | null;
    commentName: string | null;
  };
}) {
  return (
    <div className="bg-[#171717] border border-[#262626] rounded-lg p-5 transition-all duration-200 hover:border-[rgba(245,158,11,0.3)] hover:-translate-y-0.5 group">
      <div className="flex items-start justify-between gap-3 mb-3">
        <h4 className="text-white font-semibold text-sm leading-snug flex-1">
          {oil.originalName || "—"}
        </h4>
        {oil.volume && (
          <span className="amber-badge flex-shrink-0">{oil.volume}</span>
        )}
      </div>
      <div className="flex flex-col gap-1">
        {oil.artNumber && (
          <span className="font-mono-tech text-xs text-[#a3a3a3]">
            {oil.artNumber}
          </span>
        )}
        {oil.commentName && (
          <span className="text-xs text-[#a3a3a3]">{oil.commentName}</span>
        )}
      </div>
    </div>
  );
}

export default function OilSelector() {
  const [step, setStep] = useState<Step>(1);
  const [selectedBrand, setSelectedBrand] = useState<number | null>(null);
  const [selectedModel, setSelectedModel] = useState<number | null>(null);
  const [selectedModification, setSelectedModification] = useState<
    number | null
  >(null);
  const [selectedModName, setSelectedModName] = useState<string>("");
  const [selectedBrandName, setSelectedBrandName] = useState<string>("");
  const [selectedModelName, setSelectedModelName] = useState<string>("");
  const [companyId, setCompanyId] = useState<number | null>(null);
  const [resultTab, setResultTab] = useState<ResultTab>("catalog");
  const contentRef = useRef<HTMLDivElement>(null);

  const { isAuthenticated } = useAuth();
  const { data: myCompanies } = trpc.company.myCompanies.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const companyProductsQuery = trpc.oil.companyProducts.useQuery(
    {
      companyId: companyId ?? 0,
      makeId: selectedBrand ?? 0,
      modelId: selectedModel ?? 0,
      modificationId: String(selectedModification ?? ""),
    },
    {
      enabled:
        companyId !== null &&
        selectedBrand !== null &&
        selectedModel !== null &&
        selectedModification !== null,
    }
  );

  const brandsQuery = trpc.car.brands.useQuery();
  const modelsQuery = trpc.car.models.useQuery(
    { makeId: selectedBrand ?? 0 },
    { enabled: selectedBrand !== null }
  );
  const modificationsQuery = trpc.car.modifications.useQuery(
    { makeId: selectedBrand ?? 0, modelId: selectedModel ?? 0 },
    { enabled: selectedBrand !== null && selectedModel !== null }
  );
  const oilsQuery = trpc.oil.byModification.useQuery(
    {
      makeId: selectedBrand ?? 0,
      modelId: selectedModel ?? 0,
      modificationId: selectedModification ?? 0,
    },
    {
      enabled:
        selectedBrand !== null &&
        selectedModel !== null &&
        selectedModification !== null,
    }
  );

  useEffect(() => {
    if (contentRef.current) {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.5, ease: "power2.out" }
      );
    }
  }, [step]);

  const handleBrandSelect = (id: number, name: string) => {
    setSelectedBrand(id);
    setSelectedBrandName(name);
    setStep(2);
  };

  const handleModelSelect = (id: number, name: string) => {
    setSelectedModel(id);
    setSelectedModelName(name);
    setStep(3);
  };

  const handleModificationSelect = (id: number, name: string) => {
    setSelectedModification(id);
    setSelectedModName(name);
    setStep(4);
  };

  const handleBack = () => {
    if (step === 4) {
      setSelectedModification(null);
      setStep(3);
    } else if (step === 3) {
      setSelectedModel(null);
      setStep(2);
    } else if (step === 2) {
      setSelectedBrand(null);
      setStep(1);
    }
  };

  const handleReset = () => {
    setSelectedBrand(null);
    setSelectedModel(null);
    setSelectedModification(null);
    setSelectedBrandName("");
    setSelectedModelName("");
    setSelectedModName("");
    setStep(1);
  };

  const breadcrumbs = [
    step >= 1 && selectedBrandName
      ? { label: selectedBrandName, step: 1 as Step }
      : null,
    step >= 2 && selectedModelName
      ? { label: selectedModelName, step: 2 as Step }
      : null,
    step >= 3 && selectedModName
      ? { label: selectedModName, step: 3 as Step }
      : null,
  ].filter(Boolean) as { label: string; step: Step }[];

  return (
    <section id="selector" className="min-h-screen bg-[#0a0a0a] px-6 py-24">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-white text-3xl md:text-4xl font-bold tracking-tight mb-3">
            {step === 1 && "Выберите марку автомобиля"}
            {step === 2 && "Выберите модель"}
            {step === 3 && "Выберите двигатель"}
            {step === 4 && "Рекомендуемые жидкости"}
          </h2>
          <p className="text-[#a3a3a3] text-sm">
            {step === 1 && "Начните с выбора производителя вашего автомобиля"}
            {step === 2 && `Модели ${selectedBrandName} — выберите нужную`}
            {step === 3 && `Двигатели ${selectedModelName} — выберите модификацию`}
            {step === 4 && "Результат подбора для выбранной конфигурации"}
          </p>
        </div>

        {/* Breadcrumbs */}
        {breadcrumbs.length > 0 && (
          <div className="flex items-center gap-2 mb-8 flex-wrap">
            <button
              onClick={handleBack}
              className="flex items-center gap-1 text-[#a3a3a3] hover:text-[#f59e0b] transition-colors text-sm"
            >
              <ChevronLeft className="w-4 h-4" />
              Назад
            </button>
            <span className="text-[#262626]">|</span>
            {breadcrumbs.map((crumb, i) => (
              <div key={i} className="flex items-center gap-2">
                {i > 0 && <ChevronRight className="w-3 h-3 text-[#525252]" />}
                <span className="font-mono-tech text-xs text-[#a3a3a3] bg-[#171717] px-2 py-1 rounded">
                  {crumb.label}
                </span>
              </div>
            ))}
            {step === 4 && (
              <>
                <span className="text-[#262626]">|</span>
                <button
                  onClick={handleReset}
                  className="flex items-center gap-1 text-[#a3a3a3] hover:text-[#f59e0b] transition-colors text-sm"
                >
                  <RefreshCw className="w-3 h-3" />
                  Новый подбор
                </button>
              </>
            )}
          </div>
        )}

        {/* Step Content */}
        <div ref={contentRef}>
          {/* Step 1: Brands */}
          {step === 1 && (
            <>
              {brandsQuery.isLoading && <ShimmerSkeleton count={10} />}
              {brandsQuery.isError && (
                <div className="text-center py-12">
                  <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-3" />
                  <p className="text-[#a3a3a3] mb-4">Ошибка загрузки марок</p>
                  <button
                    onClick={() => brandsQuery.refetch()}
                    className="text-[#f59e0b] hover:underline text-sm"
                  >
                    Повторить
                  </button>
                </div>
              )}
              {brandsQuery.data && (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                  {brandsQuery.data.map((brand) => {
                    const brandId = brand.id ?? 0;
                    const brandName = brand.name ?? "";
                    return (
                      <button
                        key={brandId}
                        onClick={() => handleBrandSelect(brandId, brandName)}
                        className="selector-card flex flex-col items-center gap-3 py-6"
                      >
                        <div className="w-10 h-10 rounded-full bg-[#0a0a0a] border border-[#262626] flex items-center justify-center">
                          <span className="text-white font-bold text-sm">
                            {brandIcons[brandName] || brandName.charAt(0)}
                          </span>
                        </div>
                        <span className="text-white text-sm capitalize">
                          {brandName}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* Step 2: Models */}
          {step === 2 && (
            <>
              {modelsQuery.isLoading && <ShimmerSkeleton count={6} />}
              {modelsQuery.isError && (
                <div className="text-center py-12">
                  <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-3" />
                  <p className="text-[#a3a3a3] mb-4">Ошибка загрузки моделей</p>
                  <button
                    onClick={() => modelsQuery.refetch()}
                    className="text-[#f59e0b] hover:underline text-sm"
                  >
                    Повторить
                  </button>
                </div>
              )}
              {modelsQuery.data && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {modelsQuery.data.map((model, idx) => {
                    const modelId = model.modelId ?? 0;
                    const modelName = model.modelName ?? "";
                    return (
                      <button
                        key={`${model.makeId}-${modelId}-${idx}`}
                        onClick={() => handleModelSelect(modelId, modelName)}
                        className="selector-card flex flex-col items-start gap-2 text-left"
                      >
                        <Car className="w-5 h-5 text-[#a3a3a3] mb-1" />
                        <span className="text-white font-medium text-sm">
                          {modelName}
                        </span>
                        <span className="font-mono-tech text-xs text-[#a3a3a3]">
                          {model.yearFrom} — {model.yearTo || "н.в."}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* Step 3: Modifications */}
          {step === 3 && (
            <>
              {modificationsQuery.isLoading && <ShimmerSkeleton count={6} />}
              {modificationsQuery.isError && (
                <div className="text-center py-12">
                  <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-3" />
                  <p className="text-[#a3a3a3] mb-4">
                    Ошибка загрузки модификаций
                  </p>
                  <button
                    onClick={() => modificationsQuery.refetch()}
                    className="text-[#f59e0b] hover:underline text-sm"
                  >
                    Повторить
                  </button>
                </div>
              )}
              {modificationsQuery.data && (
                <div className="space-y-3">
                  {modificationsQuery.data.map((mod) => {
                    const modId = mod.id ?? 0;
                    return (
                      <button
                        key={modId}
                        onClick={() => handleModificationSelect(modId, mod.name || "")}
                        className="selector-card w-full flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-left"
                      >
                        <div className="flex items-center gap-3 flex-1">
                          <Settings2 className="w-5 h-5 text-[#a3a3a3] flex-shrink-0" />
                          <div>
                            <span className="text-white font-medium text-sm block">
                              {mod.name}
                              {mod.engineCode && (
                                <span className="text-[#a3a3a3] font-normal ml-2">
                                  ({mod.engineCode})
                                </span>
                              )}
                            </span>
                            <div className="flex items-center gap-3 mt-1">
                              {mod.fuel && (
                                <span className="flex items-center gap-1 font-mono-tech text-xs text-[#a3a3a3]">
                                  <Fuel className="w-3 h-3" />
                                  {mod.fuel}
                                </span>
                              )}
                              {mod.engineCapacity && (
                                <span className="flex items-center gap-1 font-mono-tech text-xs text-[#a3a3a3]">
                                  <Gauge className="w-3 h-3" />
                                  {mod.engineCapacity} л
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 flex-shrink-0">
                          {mod.horsePower && (
                            <span className="font-mono-tech text-xs text-[#f59e0b]">
                              {mod.horsePower} л.с.
                            </span>
                          )}
                          <div className="flex items-center gap-1 text-[#525252]">
                            <Calendar className="w-3 h-3" />
                            <span className="font-mono-tech text-xs">
                              {mod.startDate?.slice(0, 4)}
                              {mod.endDate
                                ? ` — ${mod.endDate.slice(0, 4)}`
                                : " — н.в."}
                            </span>
                          </div>
                          <ChevronRight className="w-4 h-4 text-[#525252]" />
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* Step 4: Results */}
          {step === 4 && (
            <>
              {/* Company selector */}
              {isAuthenticated && myCompanies && myCompanies.length > 0 && (
                <div className="mb-6 flex items-center gap-3">
                  <Building2 className="w-4 h-4 text-[#a3a3a3]" />
                  <span className="text-[#a3a3a3] text-sm">Компания:</span>
                  <select
                    value={companyId ?? ""}
                    onChange={(e) => {
                      const val = e.target.value;
                      setCompanyId(val ? Number(val) : null);
                      setResultTab(val ? "company" : "catalog");
                    }}
                    className="bg-[#171717] border border-[#262626] rounded-lg px-3 py-1.5 text-white text-sm focus:border-[#f59e0b] focus:outline-none"
                  >
                    <option value="">— Выберите компанию —</option>
                    {myCompanies.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Tabs */}
              {companyId !== null && (
                <div className="flex gap-2 mb-6 border-b border-[#262626]">
                  <button
                    onClick={() => setResultTab("catalog")}
                    className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                      resultTab === "catalog"
                        ? "text-[#f59e0b] border-[#f59e0b]"
                        : "text-[#a3a3a3] border-transparent hover:text-white"
                    }`}
                  >
                    <Droplets className="w-4 h-4 inline mr-1.5" />
                    Каталог
                  </button>
                  <button
                    onClick={() => setResultTab("company")}
                    className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                      resultTab === "company"
                        ? "text-[#f59e0b] border-[#f59e0b]"
                        : "text-[#a3a3a3] border-transparent hover:text-white"
                    }`}
                  >
                    <Package className="w-4 h-4 inline mr-1.5" />
                    Продукты компании
                  </button>
                </div>
              )}

              {/* Loading */}
              {oilsQuery.isLoading && (
                <div className="space-y-3">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="h-24 rounded-lg shimmer-skeleton" />
                  ))}
                </div>
              )}
              {oilsQuery.isError && (
                <div className="text-center py-12">
                  <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-3" />
                  <p className="text-[#a3a3a3] mb-4">
                    Ошибка загрузки результатов
                  </p>
                  <button
                    onClick={() => oilsQuery.refetch()}
                    className="text-[#f59e0b] hover:underline text-sm"
                  >
                    Повторить
                  </button>
                </div>
              )}

              {/* Catalog tab */}
              {(resultTab === "catalog" || companyId === null) && (
                <>
                  {oilsQuery.data && oilsQuery.data.length === 0 && (
                    <div className="text-center py-16">
                      <Droplets className="w-12 h-12 text-[#525252] mx-auto mb-4" />
                      <p className="text-white text-lg mb-2">
                        Данные по выбранной модификации отсутствуют
                      </p>
                      <p className="text-[#a3a3a3] text-sm mb-6">
                        В базе данных пока нет записей для этой комбинации
                      </p>
                      <button
                        onClick={handleBack}
                        className="text-[#f59e0b] hover:underline text-sm"
                      >
                        Выбрать другую модификацию
                      </button>
                    </div>
                  )}
                  {oilsQuery.data && oilsQuery.data.length > 0 && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-2">
                          <Droplets className="w-5 h-5 text-[#f59e0b]" />
                          <span className="text-[#a3a3a3] text-sm">
                            Найдено {oilsQuery.data.length} записей в каталоге
                          </span>
                        </div>
                      </div>
                      {oilsQuery.data.map((oil) => (
                        <OilCard key={oil.id} oil={oil} />
                      ))}
                    </div>
                  )}
                </>
              )}

              {/* Company products tab */}
              {resultTab === "company" && companyId !== null && (
                <>
                  {companyProductsQuery.isLoading && (
                    <div className="space-y-3">
                      {Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="h-24 rounded-lg shimmer-skeleton" />
                      ))}
                    </div>
                  )}
                  {companyProductsQuery.isError && (
                    <div className="text-center py-12">
                      <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-3" />
                      <p className="text-[#a3a3a3] mb-4">Ошибка загрузки продуктов компании</p>
                    </div>
                  )}
                  {companyProductsQuery.data && companyProductsQuery.data.length === 0 && (
                    <div className="text-center py-16">
                      <Package className="w-12 h-12 text-[#525252] mx-auto mb-4" />
                      <p className="text-white text-lg mb-2">
                        Нет продуктов для этого автомобиля
                      </p>
                      <p className="text-[#a3a3a3] text-sm mb-6">
                        В кабинете компании привяжите продукты к этой модификации
                      </p>
                    </div>
                  )}
                  {companyProductsQuery.data && companyProductsQuery.data.length > 0 && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-2">
                          <Package className="w-5 h-5 text-[#f59e0b]" />
                          <span className="text-[#a3a3a3] text-sm">
                            {companyProductsQuery.data.length} продуктов компании
                          </span>
                        </div>
                      </div>
                      {companyProductsQuery.data.map((product) => (
                        <div
                          key={product.assignmentId}
                          className={`bg-[#171717] border rounded-lg p-5 transition-all duration-200 hover:-translate-y-0.5 ${
                            product.isRecommended === "yes"
                              ? "border-[#f59e0b]/50"
                              : "border-[#262626]"
                          }`}
                        >
                          <div className="flex items-start justify-between gap-3 mb-3">
                            <div className="flex-1">
                              <h4 className="text-white font-semibold text-sm">
                                {product.name}
                              </h4>
                              <span className="font-mono-tech text-xs text-[#f59e0b]">
                                {product.sku}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 flex-shrink-0">
                              {product.isRecommended === "yes" && (
                                <span className="amber-badge text-[10px]">
                                  Рекомендовано
                                </span>
                              )}
                              {product.price && (
                                <span className="text-white text-sm font-medium">
                                  {(product.price / 100).toFixed(0)} ₽
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {product.brand && (
                              <span className="text-xs text-[#a3a3a3] bg-[#0a0a0a] px-2 py-1 rounded">
                                {product.brand}
                              </span>
                            )}
                            {product.volume && (
                              <span className="text-xs text-[#a3a3a3] bg-[#0a0a0a] px-2 py-1 rounded">
                                {product.volume}
                              </span>
                            )}
                            {product.category && (
                              <span className="text-xs text-[#a3a3a3] bg-[#0a0a0a] px-2 py-1 rounded">
                                {product.category}
                              </span>
                            )}
                          </div>
                          {product.notes && (
                            <p className="text-[#a3a3a3] text-xs mt-2">{product.notes}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </>
          )}
        </div>
      </div>
    </section>
  );
}
