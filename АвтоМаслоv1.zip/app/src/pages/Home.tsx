import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HeroSection from "@/sections/HeroSection";
import OilSelector from "@/sections/OilSelector";
import TechnicalSpecsSection from "@/sections/TechnicalSpecsSection";

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <main>
        <HeroSection />
        <OilSelector />
        <TechnicalSpecsSection />
      </main>
      <Footer />
    </div>
  );
}
