import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { useNavigate } from "react-router";
import {
  Building2,
  Package,
  Link2,
  Users,
  BarChart3,
  Plus,
  Trash2,
  ChevronLeft,
  X,
} from "lucide-react";

type Tab = "dashboard" | "companies" | "products" | "assignments";

function StatCard({
  title,
  value,
  icon: Icon,
}: {
  title: string;
  value: number;
  icon: React.ElementType;
}) {
  return (
    <div className="bg-[#171717] border border-[#262626] rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <span className="text-[#a3a3a3] text-sm">{title}</span>
        <Icon className="w-5 h-5 text-[#f59e0b]" />
      </div>
      <span className="text-white text-3xl font-bold">
        {value.toLocaleString()}
      </span>
    </div>
  );
}

function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative bg-[#0a0a0a] border border-[#262626] rounded-lg w-full max-w-lg max-h-[80vh] overflow-auto">
        <div className="flex items-center justify-between p-4 border-b border-[#262626]">
          <h3 className="text-white font-semibold">{title}</h3>
          <button onClick={onClose} className="text-[#a3a3a3] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}

// ─── Companies Tab ───
function CompaniesTab() {
  const utils = trpc.useUtils();
  const { data: companies, isLoading } = trpc.admin.listCompanies.useQuery();
  const createCompany = trpc.admin.createCompany.useMutation({
    onSuccess: () => utils.admin.listCompanies.invalidate(),
  });
  const deleteCompany = trpc.admin.deleteCompany.useMutation({
    onSuccess: () => utils.admin.listCompanies.invalidate(),
  });

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    name: "",
    slug: "",
    contactEmail: "",
    contactPhone: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createCompany.mutate(form);
    setModalOpen(false);
    setForm({ name: "", slug: "", contactEmail: "", contactPhone: "" });
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-white text-xl font-semibold">Компании</h2>
        <button
          onClick={() => setModalOpen(true)}
          className="flex items-center gap-2 bg-[#f59e0b] text-black px-4 py-2 rounded-lg font-medium hover:bg-[#f59e0b]/90 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Добавить компанию
        </button>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 rounded-lg shimmer-skeleton" />
          ))}
        </div>
      ) : (
        <div className="bg-[#171717] border border-[#262626] rounded-lg overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#262626]">
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">
                  Название
                </th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">
                  Slug
                </th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">
                  Email
                </th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">
                  Статус
                </th>
                <th className="text-right p-4 text-[#a3a3a3] text-sm font-medium">
                  Действия
                </th>
              </tr>
            </thead>
            <tbody>
              {companies?.map((c) => (
                <tr
                  key={c.id}
                  className="border-b border-[#262626] last:border-0 hover:bg-[#1f1f1f] transition-colors"
                >
                  <td className="p-4 text-white text-sm">{c.name}</td>
                  <td className="p-4 font-mono-tech text-xs text-[#a3a3a3]">
                    {c.slug}
                  </td>
                  <td className="p-4 text-[#a3a3a3] text-sm">
                    {c.contactEmail || "—"}
                  </td>
                  <td className="p-4">
                    <span
                      className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${
                        c.isActive === "active"
                          ? "bg-green-500/10 text-green-400"
                          : c.isActive === "suspended"
                          ? "bg-yellow-500/10 text-yellow-400"
                          : "bg-[#525252]/10 text-[#a3a3a3]"
                      }`}
                    >
                      {c.isActive}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <button
                      onClick={() =>
                        c.id && deleteCompany.mutate({ id: c.id })
                      }
                      className="text-[#525252] hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Новая компания"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[#a3a3a3] text-sm mb-1">
              Название *
            </label>
            <input
              type="text"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-[#a3a3a3] text-sm mb-1">Slug *</label>
            <input
              type="text"
              required
              value={form.slug}
              onChange={(e) =>
                setForm({
                  ...form,
                  slug: e.target.value.toLowerCase().replace(/\s+/g, "-"),
                })
              }
              className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white font-mono-tech focus:border-[#f59e0b] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-[#a3a3a3] text-sm mb-1">Email</label>
            <input
              type="email"
              value={form.contactEmail}
              onChange={(e) =>
                setForm({ ...form, contactEmail: e.target.value })
              }
              className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-[#a3a3a3] text-sm mb-1">Телефон</label>
            <input
              type="tel"
              value={form.contactPhone}
              onChange={(e) =>
                setForm({ ...form, contactPhone: e.target.value })
              }
              className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none"
            />
          </div>
          <button
            type="submit"
            className="w-full bg-[#f59e0b] text-black font-medium py-2 rounded-lg hover:bg-[#f59e0b]/90 transition-colors"
          >
            Создать компанию
          </button>
        </form>
      </Modal>
    </div>
  );
}

// ─── Products Tab ───
function ProductsTab() {
  const utils = trpc.useUtils();
  const { data: allProducts, isLoading } = trpc.admin.listProducts.useQuery();
  const { data: companiesList } = trpc.admin.listCompanies.useQuery();
  const createProduct = trpc.admin.createProduct.useMutation({
    onSuccess: () => utils.admin.listProducts.invalidate(),
  });
  const deleteProduct = trpc.admin.deleteProduct.useMutation({
    onSuccess: () => utils.admin.listProducts.invalidate(),
  });

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    companyId: 0,
    name: "",
    sku: "",
    brand: "",
    category: "",
    description: "",
    price: 0,
    volume: "",
    specs: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const specsObj = form.specs
      ? Object.fromEntries(
          form.specs.split(",").map((s) => {
            const [k, v] = s.split("=");
            return [k?.trim(), v?.trim()];
          })
        )
      : undefined;
    createProduct.mutate({
      ...form,
      companyId: Number(form.companyId),
      price: form.price * 100, // convert to cents
      specs: specsObj,
    });
    setModalOpen(false);
    setForm({
      companyId: 0,
      name: "",
      sku: "",
      brand: "",
      category: "",
      description: "",
      price: 0,
      volume: "",
      specs: "",
    });
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-white text-xl font-semibold">Продукты</h2>
        <button
          onClick={() => setModalOpen(true)}
          className="flex items-center gap-2 bg-[#f59e0b] text-black px-4 py-2 rounded-lg font-medium hover:bg-[#f59e0b]/90 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Добавить продукт
        </button>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 rounded-lg shimmer-skeleton" />
          ))}
        </div>
      ) : (
        <div className="bg-[#171717] border border-[#262626] rounded-lg overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#262626]">
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">
                  SKU
                </th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">
                  Название
                </th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">
                  Бренд
                </th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">
                  Категория
                </th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">
                  Цена
                </th>
                <th className="text-right p-4 text-[#a3a3a3] text-sm font-medium">
                  Действия
                </th>
              </tr>
            </thead>
            <tbody>
              {allProducts?.map((p) => (
                <tr
                  key={p.id}
                  className="border-b border-[#262626] last:border-0 hover:bg-[#1f1f1f] transition-colors"
                >
                  <td className="p-4 font-mono-tech text-xs text-[#f59e0b]">
                    {p.sku}
                  </td>
                  <td className="p-4 text-white text-sm">{p.name}</td>
                  <td className="p-4 text-[#a3a3a3] text-sm">
                    {p.brand || "—"}
                  </td>
                  <td className="p-4 text-[#a3a3a3] text-sm">
                    {p.category || "—"}
                  </td>
                  <td className="p-4 text-white text-sm">
                    {p.price ? `${(p.price / 100).toFixed(0)} ₽` : "—"}
                  </td>
                  <td className="p-4 text-right">
                    <button
                      onClick={() =>
                        p.id && deleteProduct.mutate({ id: p.id })
                      }
                      className="text-[#525252] hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Новый продукт"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[#a3a3a3] text-sm mb-1">
              Компания *
            </label>
            <select
              required
              value={form.companyId}
              onChange={(e) =>
                setForm({ ...form, companyId: Number(e.target.value) })
              }
              className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none"
            >
              <option value="">Выберите компанию</option>
              {companiesList?.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-[#a3a3a3] text-sm mb-1">
              Название *
            </label>
            <input
              type="text"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-[#a3a3a3] text-sm mb-1">SKU *</label>
            <input
              type="text"
              required
              value={form.sku}
              onChange={(e) => setForm({ ...form, sku: e.target.value })}
              className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white font-mono-tech focus:border-[#f59e0b] focus:outline-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[#a3a3a3] text-sm mb-1">
                Бренд
              </label>
              <input
                type="text"
                value={form.brand}
                onChange={(e) => setForm({ ...form, brand: e.target.value })}
                className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[#a3a3a3] text-sm mb-1">
                Категория
              </label>
              <input
                type="text"
                value={form.category}
                onChange={(e) =>
                  setForm({ ...form, category: e.target.value })
                }
                className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[#a3a3a3] text-sm mb-1">
                Цена (₽)
              </label>
              <input
                type="number"
                value={form.price}
                onChange={(e) =>
                  setForm({ ...form, price: Number(e.target.value) })
                }
                className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-[#a3a3a3] text-sm mb-1">
                Объём
              </label>
              <input
                type="text"
                value={form.volume}
                onChange={(e) =>
                  setForm({ ...form, volume: e.target.value })
                }
                placeholder="5L"
                className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none"
              />
            </div>
          </div>
          <div>
            <label className="block text-[#a3a3a3] text-sm mb-1">Описание</label>
            <textarea
              value={form.description}
              onChange={(e) =>
                setForm({ ...form, description: e.target.value })
              }
              rows={3}
              className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-[#a3a3a3] text-sm mb-1">
              Спецификации (ключ=значение, через запятую)
            </label>
            <input
              type="text"
              value={form.specs}
              onChange={(e) => setForm({ ...form, specs: e.target.value })}
              placeholder="viscosity=5W-30, api=SN, acea=C3"
              className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white font-mono-tech text-xs focus:border-[#f59e0b] focus:outline-none"
            />
          </div>
          <button
            type="submit"
            className="w-full bg-[#f59e0b] text-black font-medium py-2 rounded-lg hover:bg-[#f59e0b]/90 transition-colors"
          >
            Создать продукт
          </button>
        </form>
      </Modal>
    </div>
  );
}

// ─── Assignments Tab ───
function AssignmentsTab() {
  const utils = trpc.useUtils();
  const { data: assignments, isLoading } =
    trpc.admin.listAssignments.useQuery();
  const { data: allProducts } = trpc.admin.listProducts.useQuery();
  const deleteAssignment = trpc.admin.deleteAssignment.useMutation({
    onSuccess: () => utils.admin.listAssignments.invalidate(),
  });

  // Group by company for display
  const grouped = assignments?.reduce(
    (acc, a) => {
      const key = a.companyId;
      if (!acc[key]) acc[key] = [];
      acc[key].push(a);
      return acc;
    },
    {} as Record<number, typeof assignments>
  );

  return (
    <div>
      <h2 className="text-white text-xl font-semibold mb-6">
        Привязки продуктов к автомобилям
      </h2>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 rounded-lg shimmer-skeleton" />
          ))}
        </div>
      ) : assignments?.length === 0 ? (
        <div className="text-center py-16 text-[#a3a3a3]">
          <Link2 className="w-12 h-12 mx-auto mb-4 text-[#525252]" />
          <p>Привязок пока нет</p>
          <p className="text-sm mt-2">
            Создавайте привязки через API или интерфейс компании
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {Object.entries(grouped || {}).map(([companyId, items]) => (
            <div
              key={companyId}
              className="bg-[#171717] border border-[#262626] rounded-lg overflow-hidden"
            >
              <div className="px-4 py-3 border-b border-[#262626] bg-[#0a0a0a]">
                <span className="text-white font-medium text-sm">
                  Компания #{companyId}
                </span>
                <span className="text-[#a3a3a3] text-xs ml-2">
                  ({items.length} привязок)
                </span>
              </div>
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#262626]">
                    <th className="text-left p-3 text-[#a3a3a3] text-xs font-medium">
                      Продукт
                    </th>
                    <th className="text-left p-3 text-[#a3a3a3] text-xs font-medium">
                      Автомобиль (makeId/modelId)
                    </th>
                    <th className="text-left p-3 text-[#a3a3a3] text-xs font-medium">
                      Модификация
                    </th>
                    <th className="text-left p-3 text-[#a3a3a3] text-xs font-medium">
                      Рекомендация
                    </th>
                    <th className="text-right p-3 text-[#a3a3a3] text-xs font-medium">
                      Действия
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((a) => {
                    const product = allProducts?.find(
                      (p) => p.id === a.productId
                    );
                    return (
                      <tr
                        key={a.id}
                        className="border-b border-[#262626] last:border-0 hover:bg-[#1f1f1f]"
                      >
                        <td className="p-3 text-white text-xs">
                          {product?.name || `Product #${a.productId}`}
                        </td>
                        <td className="p-3 font-mono-tech text-xs text-[#a3a3a3]">
                          {a.makeId}/{a.modelId}
                        </td>
                        <td className="p-3 font-mono-tech text-xs text-[#a3a3a3]">
                          {a.modificationId}
                        </td>
                        <td className="p-3">
                          {a.isRecommended === "yes" ? (
                            <span className="text-green-400 text-xs">
                              Рекомендовано
                            </span>
                          ) : (
                            <span className="text-[#525252] text-xs">—</span>
                          )}
                        </td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() =>
                              a.id &&
                              deleteAssignment.mutate({ id: a.id })
                            }
                            className="text-[#525252] hover:text-red-400 transition-colors"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Main Admin Page ───
export default function AdminPage() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");

  const { data: stats } = trpc.admin.stats.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#f59e0b] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-lg mb-2">Доступ запрещён</p>
          <p className="text-[#a3a3a3] text-sm mb-4">
            Требуется роль администратора
          </p>
          <button
            onClick={() => navigate("/")}
            className="text-[#f59e0b] hover:underline text-sm"
          >
            На главную
          </button>
        </div>
      </div>
    );
  }

  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: "dashboard", label: "Дашборд", icon: BarChart3 },
    { id: "companies", label: "Компании", icon: Building2 },
    { id: "products", label: "Продукты", icon: Package },
    { id: "assignments", label: "Привязки", icon: Link2 },
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-[#262626] bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-[#f59e0b] flex items-center justify-center">
              <BarChart3 className="w-4 h-4 text-black" />
            </div>
            <div>
              <h1 className="text-white font-semibold text-sm">
                Админ-панель
              </h1>
              <p className="text-[#525252] text-xs">Motornaya B2B</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-[#a3a3a3] text-sm">{user.name}</span>
            <span className="amber-badge text-[10px]">admin</span>
            <button
              onClick={() => navigate("/")}
              className="text-[#a3a3a3] hover:text-white text-sm"
            >
              <ChevronLeft className="w-4 h-4 inline mr-1" />
              Назад
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 flex gap-8">
        {/* Sidebar */}
        <nav className="w-48 flex-shrink-0">
          <div className="space-y-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                  activeTab === tab.id
                    ? "bg-[#f59e0b]/10 text-[#f59e0b] border border-[#f59e0b]/20"
                    : "text-[#a3a3a3] hover:bg-[#171717] hover:text-white"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </nav>

        {/* Content */}
        <main className="flex-1 min-w-0">
          {activeTab === "dashboard" && (
            <div>
              <h2 className="text-white text-xl font-semibold mb-6">
                Обзор системы
              </h2>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard
                  title="Компаний"
                  value={stats?.companies || 0}
                  icon={Building2}
                />
                <StatCard
                  title="Продуктов"
                  value={stats?.products || 0}
                  icon={Package}
                />
                <StatCard
                  title="Привязок"
                  value={stats?.assignments || 0}
                  icon={Link2}
                />
                <StatCard
                  title="Пользователей"
                  value={stats?.users || 0}
                  icon={Users}
                />
              </div>

              <div className="mt-8 bg-[#171717] border border-[#262626] rounded-lg p-6">
                <h3 className="text-white font-medium mb-4">
                  Быстрые действия
                </h3>
                <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
                  <button
                    onClick={() => setActiveTab("companies")}
                    className="selector-card text-left flex items-center gap-3"
                  >
                    <Building2 className="w-5 h-5 text-[#f59e0b]" />
                    <div>
                      <span className="text-white text-sm block">
                        Управление компаниями
                      </span>
                      <span className="text-[#525252] text-xs">
                        Создание и настройка
                      </span>
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveTab("products")}
                    className="selector-card text-left flex items-center gap-3"
                  >
                    <Package className="w-5 h-5 text-[#f59e0b]" />
                    <div>
                      <span className="text-white text-sm block">
                        Каталог продуктов
                      </span>
                      <span className="text-[#525252] text-xs">
                        Добавление SKU
                      </span>
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveTab("assignments")}
                    className="selector-card text-left flex items-center gap-3"
                  >
                    <Link2 className="w-5 h-5 text-[#f59e0b]" />
                    <div>
                      <span className="text-white text-sm block">
                        Привязки к авто
                      </span>
                      <span className="text-[#525252] text-xs">
                        Продукт → автомобиль
                      </span>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "companies" && <CompaniesTab />}
          {activeTab === "products" && <ProductsTab />}
          {activeTab === "assignments" && <AssignmentsTab />}
        </main>
      </div>
    </div>
  );
}
