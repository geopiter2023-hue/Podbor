import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { LogIn, LogOut, Shield, Building2, User } from "lucide-react";

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();

  const { data: myCompanies } = trpc.company.myCompanies.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-black/80 backdrop-blur-md border-b border-[#262626]"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[#f59e0b]" />
          <span className="font-mono-tech text-xs tracking-[0.1em] text-[#a3a3a3] uppercase">
            Motornaya
          </span>
        </div>

        <div className="flex items-center gap-4">
          {/* System Status */}
          <div className="hidden sm:flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse-dot" />
            <span className="font-mono-tech text-[11px] text-[#a3a3a3] uppercase tracking-wider">
              Система: Активна
            </span>
          </div>

          {/* Auth Buttons */}
          {isAuthenticated ? (
            <div className="flex items-center gap-3">
              {/* Admin link */}
              {user?.role === "admin" && (
                <button
                  onClick={() => navigate("/admin")}
                  className="flex items-center gap-1.5 text-[#f59e0b] hover:text-[#f59e0b]/80 transition-colors text-sm"
                >
                  <Shield className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Админ</span>
                </button>
              )}

              {/* Company links */}
              {myCompanies && myCompanies.length > 0 && (
                <div className="flex items-center gap-2">
                  {myCompanies.slice(0, 2).map((c) => (
                    <button
                      key={c.id}
                      onClick={() => navigate(`/company?id=${c.id}`)}
                      className="flex items-center gap-1.5 text-[#a3a3a3] hover:text-white transition-colors text-sm"
                    >
                      <Building2 className="w-3.5 h-3.5" />
                      <span className="hidden md:inline">{c.name}</span>
                    </button>
                  ))}
                </div>
              )}

              {/* User + Logout */}
              <div className="flex items-center gap-2 border-l border-[#262626] pl-3 ml-1">
                <User className="w-3.5 h-3.5 text-[#a3a3a3]" />
                <span className="text-[#a3a3a3] text-sm hidden md:inline">{user?.name}</span>
                <button
                  onClick={logout}
                  className="text-[#525252] hover:text-red-400 transition-colors"
                  title="Выйти"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => navigate("/login")}
              className="flex items-center gap-1.5 text-[#f59e0b] hover:text-[#f59e0b]/80 transition-colors text-sm"
            >
              <LogIn className="w-3.5 h-3.5" />
              Войти
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
