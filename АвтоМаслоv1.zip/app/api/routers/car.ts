import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { brands, models, modifications, mapping } from "@db/schema";
import { sql } from "drizzle-orm";

export const carRouter = createRouter({
  brands: publicQuery.query(async () => {
    const db = getDb();
    const result = await db
      .selectDistinct({
        id: mapping.newMakeId,
        name: brands.name,
      })
      .from(brands)
      .innerJoin(mapping, sql`${brands.id} = ${mapping.makeId}`)
      .orderBy(brands.name);
    return result.map((r) => ({
      id: Number(r.id),
      name: r.name,
    }));
  }),

  models: publicQuery
    .input(z.object({ makeId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .selectDistinct({
          modelId: mapping.newModelId,
          makeId: mapping.newMakeId,
          modelName: models.modelName,
          yearFrom: models.yearFrom,
          yearTo: models.yearTo,
        })
        .from(models)
        .innerJoin(
          mapping,
          sql`${models.modelId} = ${mapping.modelId}
          AND ${models.makeId} = ${mapping.makeId}`
        )
        .where(sql`${mapping.newMakeId} = ${input.makeId}`)
        .orderBy(models.modelName);
      return result.map((r) => ({
        modelId: Number(r.modelId),
        makeId: Number(r.makeId),
        modelName: r.modelName,
        yearFrom: r.yearFrom,
        yearTo: r.yearTo,
      }));
    }),

  modifications: publicQuery
    .input(z.object({ makeId: z.number(), modelId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .selectDistinct({
          id: mapping.newTypeId,
          name: modifications.name,
          engineCode: modifications.engineCode,
          fuel: modifications.fuel,
          horsePower: modifications.horsePower,
          startDate: modifications.startDate,
          endDate: modifications.endDate,
          engineCapacity: modifications.engineCapacity,
          constructionType: modifications.constructionType,
          motorType: modifications.motorType,
        })
        .from(modifications)
        .innerJoin(
          mapping,
          sql`${modifications.id} = ${mapping.typeId}
          AND ${modifications.makeId} = ${mapping.makeId}
          AND ${modifications.modelId} = ${mapping.modelId}`
        )
        .where(
          sql`${mapping.newMakeId} = ${input.makeId}
          AND ${mapping.newModelId} = ${input.modelId}`
        )
        .orderBy(modifications.name);
      return result.map((r) => ({
        id: Number(r.id),
        name: r.name,
        engineCode: r.engineCode,
        fuel: r.fuel,
        horsePower: r.horsePower,
        startDate: r.startDate,
        endDate: r.endDate,
        engineCapacity: r.engineCapacity,
        constructionType: r.constructionType,
        motorType: r.motorType,
      }));
    }),
});
