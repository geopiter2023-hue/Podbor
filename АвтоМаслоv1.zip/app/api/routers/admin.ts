import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { companies, companyUsers, products, productAssignments, users } from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const adminRouter = createRouter({
  // ─── Companies ───
  listCompanies: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(companies).orderBy(desc(companies.createdAt));
  }),

  createCompany: adminQuery
    .input(z.object({
      name: z.string().min(1),
      slug: z.string().min(1),
      contactEmail: z.string().optional(),
      contactPhone: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(companies).values({
        name: input.name,
        slug: input.slug,
        contactEmail: input.contactEmail || null,
        contactPhone: input.contactPhone || null,
      });
      return { success: true };
    }),

  updateCompany: adminQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      slug: z.string().optional(),
      contactEmail: z.string().optional(),
      contactPhone: z.string().optional(),
      isActive: z.enum(["active", "suspended", "archived"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(companies).set(data).where(eq(companies.id, id));
      return { success: true };
    }),

  deleteCompany: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(companies).where(eq(companies.id, input.id));
      return { success: true };
    }),

  // ─── Users ───
  listUsers: adminQuery.query(async () => {
    const db = getDb();
    return db.select({
      id: users.id,
      name: users.name,
      email: users.email,
      role: users.role,
      createdAt: users.createdAt,
    }).from(users).orderBy(desc(users.createdAt));
  }),

  // ─── Company Users ───
  listCompanyMembers: adminQuery
    .input(z.object({ companyId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const members = await db
        .select({
          id: companyUsers.id,
          role: companyUsers.role,
          userId: companyUsers.userId,
          name: users.name,
          email: users.email,
        })
        .from(companyUsers)
        .innerJoin(users, eq(companyUsers.userId, users.id))
        .where(eq(companyUsers.companyId, input.companyId));
      return members;
    }),

  addCompanyMember: adminQuery
    .input(z.object({
      companyId: z.number(),
      userId: z.number(),
      role: z.enum(["owner", "manager", "viewer"]).default("viewer"),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(companyUsers).values(input).onDuplicateKeyUpdate({
        set: { role: input.role },
      });
      return { success: true };
    }),

  // ─── Products ───
  listProducts: adminQuery
    .input(z.object({ companyId: z.number() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.companyId) {
        return db.select().from(products)
          .where(eq(products.companyId, input.companyId))
          .orderBy(desc(products.createdAt));
      }
      return db.select().from(products).orderBy(desc(products.createdAt));
    }),

  createProduct: adminQuery
    .input(z.object({
      companyId: z.number(),
      name: z.string().min(1),
      sku: z.string().min(1),
      brand: z.string().optional(),
      category: z.string().optional(),
      description: z.string().optional(),
      price: z.number().optional(),
      currency: z.string().optional(),
      volume: z.string().optional(),
      specs: z.record(z.string(), z.any()).optional(),
      imageUrl: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(products).values({
        ...input,
        brand: input.brand || null,
        category: input.category || null,
        description: input.description || null,
        price: input.price || null,
        volume: input.volume || null,
        specs: input.specs || null,
        imageUrl: input.imageUrl || null,
      });
      return { success: true };
    }),

  updateProduct: adminQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      sku: z.string().optional(),
      brand: z.string().optional(),
      category: z.string().optional(),
      description: z.string().optional(),
      price: z.number().optional(),
      volume: z.string().optional(),
      specs: z.record(z.string(), z.any()).optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(products).set(data).where(eq(products.id, id));
      return { success: true };
    }),

  deleteProduct: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(products).where(eq(products.id, input.id));
      return { success: true };
    }),

  // ─── Product Assignments ───
  listAssignments: adminQuery
    .input(z.object({ companyId: z.number() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.companyId) {
        return db.select().from(productAssignments)
          .where(eq(productAssignments.companyId, input.companyId))
          .orderBy(desc(productAssignments.createdAt));
      }
      return db.select().from(productAssignments).orderBy(desc(productAssignments.createdAt));
    }),

  createAssignment: adminQuery
    .input(z.object({
      companyId: z.number(),
      productId: z.number(),
      makeId: z.number(),
      modelId: z.number(),
      modificationId: z.string(),
      notes: z.string().optional(),
      isRecommended: z.enum(["yes", "no"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(productAssignments).values({
        ...input,
        notes: input.notes || null,
        isRecommended: input.isRecommended || "no",
      }).onDuplicateKeyUpdate({
        set: { notes: input.notes || null, isRecommended: input.isRecommended || "no" },
      });
      return { success: true };
    }),

  deleteAssignment: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(productAssignments).where(eq(productAssignments.id, input.id));
      return { success: true };
    }),

  // ─── Assign Admin Role ───
  assignAdmin: adminQuery
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(users).set({ role: "admin" }).where(eq(users.id, input.userId));
      return { success: true };
    }),

  // ─── Stats ───
  stats: adminQuery.query(async () => {
    const db = getDb();
    const [companyCount] = await db.select({ count: sql<number>`COUNT(*)` }).from(companies);
    const [productCount] = await db.select({ count: sql<number>`COUNT(*)` }).from(products);
    const [assignmentCount] = await db.select({ count: sql<number>`COUNT(*)` }).from(productAssignments);
    const [userCount] = await db.select({ count: sql<number>`COUNT(*)` }).from(users);
    return {
      companies: companyCount.count,
      products: productCount.count,
      assignments: assignmentCount.count,
      users: userCount.count,
    };
  }),
});
