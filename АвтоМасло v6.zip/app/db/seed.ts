// Seed script - imports real data from SQL dumps
// Run: npx tsx db/seed.ts
// Or import SQL files directly: mysql -u USER -p DATABASE < TObase.sql

import { drizzle } from "drizzle-orm/mysql2";
import { createConnection } from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

const DATABASE_URL =
  process.env.DATABASE_URL || "mysql://user:password@localhost:3306/oilpodbor";

async function seed() {
  console.log("🌱 Starting seed process...");
  console.log("ℹ️  For full data import, run these commands manually:");
  console.log("   mysql -u USER -p DATABASE < /tmp/Podbor/TObrands.sql");
  console.log("   mysql -u USER -p DATABASE < /tmp/Podbor/TOmodels.sql");
  console.log("   mysql -u USER -p DATABASE < /tmp/Podbor/TOmodifications.sql");
  console.log("   mysql -u USER -p DATABASE < /tmp/Podbor/TOoils.sql");
  console.log("   mysql -u USER -p DATABASE < /tmp/Podbor/TOparts.sql");
  console.log("   mysql -u USER -p DATABASE < /tmp/Podbor/TOpartsCrosses.sql");
  console.log("   mysql -u USER -p DATABASE < /tmp/Podbor/mapping.sql");

  const connection = await createConnection(DATABASE_URL);
  const [rows] = await connection.execute("SHOW TABLES LIKE 'TObrands'");

  if (Array.isArray(rows) && rows.length > 0) {
    const [countResult] = await connection.execute<any>(
      "SELECT COUNT(*) as count FROM TObrands"
    );
    const count = countResult[0]?.count ?? 0;
    console.log(`✅ Database already contains ${count} brands`);
    if (count > 0) {
      console.log("✨ Real data is already imported!");
    }
  } else {
    console.log("⚠️  Real data not found. Please import SQL dumps manually.");
  }

  await connection.end();
}

seed().catch((err) => {
  console.error("❌ Seed check failed:", err);
  process.exit(1);
});
