/**
 * Import all cars from TOmodifications into cars table
 * Run: npx tsx db/import-cars.ts
 */
import { createConnection } from "mysql2/promise";

const url = process.env.DATABASE_URL || "";

async function main() {
  const m = url.match(/mysql:\/\/([^:]+):([^@]+)@([^:]+):(\d+)\/(.+)/);
  if (!m) {
    console.error("Invalid DATABASE_URL");
    process.exit(1);
  }
  const [, user, password, host, port, database] = m;

  const conn = await createConnection({
    host,
    port: parseInt(port),
    user,
    password,
    database,
    connectTimeout: 60000,
    ssl: { rejectUnauthorized: true },
    multipleStatements: true,
  });

  console.log("Connected to database");

  // Load all brands into memory
  const [brands] = await conn.execute("SELECT id, name FROM TObrands");
  const brandMap: Record<number, string> = {};
  for (const b of brands as any[]) brandMap[b.id] = b.name;
  console.log("Loaded", (brands as any[]).length, "brands");

  // Load all models into memory
  const [models] = await conn.execute(
    "SELECT makeId, modelId, modelName, yearFrom, yearTo FROM TOmodels"
  );
  const modelMap: Record<string, any> = {};
  for (const m of models as any[]) {
    const key = m.makeId + "_" + m.modelId;
    if (!modelMap[key]) modelMap[key] = m;
  }
  console.log(
    "Loaded",
    (models as any[]).length,
    "model rows,",
    Object.keys(modelMap).length,
    "unique"
  );

  // Load existing car IDs
  const [existingCars] = await conn.execute("SELECT id FROM cars");
  const existingIds = new Set((existingCars as any[]).map((c) => c.id));
  console.log("Existing cars:", existingIds.size);

  // Build fuel mapping
  function mapFuel(fuel: string | null): number | null {
    if (!fuel) return null;
    const f = fuel.toLowerCase().trim();
    if (f === "бензин" || f === "бенезин") return 1;
    if (f === "дизель") return 2;
    if (
      f.includes("электрический") &&
      !f.includes("дизель") &&
      !f.includes("бензин")
    )
      return 4;
    if (f.includes("электр") || f.includes("гибрид")) return 3;
    if (f.includes("газ") && f.includes("бензин")) return 5;
    if (f.includes("дизель") && f.includes("электр")) return 6;
    if (f.includes("бензин") && f.includes("этанол")) return 1;
    if (f.includes("flexfuel")) return 1;
    if (f.includes("бензин")) return 1;
    if (f.includes("дизель")) return 2;
    if (f.includes("газ") || f.includes("lpg") || f.includes("cng")) return 5;
    if (f.includes("водород") || f.includes("hydrogen")) return 4;
    return null;
  }

  // Build body type mapping
  function mapBodyType(ct: string | null): number | null {
    if (!ct) return null;
    const c = ct.toLowerCase().trim();
    if (c.includes("седан")) return 1;
    if (c.includes("хэтчбек") || c.includes("хетчбек")) return 2;
    if (c.includes("универсал") || c.includes("комби") || c.includes("wagon"))
      return 3;
    if (c.includes("купе") || c.includes("купэ")) return 4;
    if (
      c.includes("вездеход") ||
      c.includes("внедорожник") ||
      c.includes("suv") ||
      c.includes("кроссовер") ||
      c.includes("crossover") ||
      c.includes("джип")
    )
      return 5;
    if (
      c.includes("кабриолет") ||
      c.includes("кабрио") ||
      c.includes("cabrio")
    )
      return 6;
    if (c.includes("пикап") || c.includes("pickup")) return 7;
    if (c.includes("минивэн") || c.includes("mpv") || c.includes("минивен"))
      return 8;
    if (c.includes("родстер") || c.includes("roadster")) return 6;
    if (c.includes("лимузин") || c.includes("limousine")) return 1;
    if (c.includes("лифтбэк") || c.includes("liftback")) return 2;
    if (c.includes("тарга") || c.includes("targa")) return 6;
    if (c.includes("шутинг") || c.includes("shooting")) return 3;
    if (c.includes("спайдер") || c.includes("spyder")) return 6;
    if (c.includes("off-road") || c.includes("offroad")) return 5;
    return null;
  }

  // Extract year from date string
  function extractYear(dateStr: string | null): number | null {
    if (!dateStr) return null;
    const match = dateStr.match(/(\d{4})/);
    return match ? parseInt(match[1]) : null;
  }

  // Get total count
  const [countResult] = await conn.execute(
    "SELECT COUNT(*) as c FROM TOmodifications"
  );
  const totalMods = (countResult as any[])[0].c;
  console.log("Total modifications to import:", totalMods);

  // Process in batches
  const batchSize = 500;
  let totalInserted = 0;
  let totalSkipped = 0;

  for (let offset = 0; offset < totalMods; offset += batchSize) {
    const limit = Math.min(batchSize, totalMods - offset);

    // Fetch batch — use template literal for LIMIT since TiDB driver
    // has issues with LIMIT ? OFFSET ? placeholders
    const [mods] = await conn.query(
      `SELECT * FROM TOmodifications ORDER BY makeId, modelId, id LIMIT ${limit} OFFSET ${offset}`
    );

    const values: any[][] = [];
    for (const mod of mods as any[]) {
      const carId = mod.makeId + "_" + mod.modelId + "_" + mod.id;

      if (existingIds.has(carId)) {
        totalSkipped++;
        continue;
      }

      const brand = brandMap[mod.makeId];
      const modelKey = mod.makeId + "_" + mod.modelId;
      const model = modelMap[modelKey];

      if (!brand || !model) {
        totalSkipped++;
        continue;
      }

      values.push([
        carId,
        null,
        null,
        brand,
        model.modelName,
        mapBodyType(mod.constructionType),
        (mod.name || "") +
          (mod.engineCode ? " (" + mod.engineCode + ")" : ""),
        extractYear(mod.startDate),
        extractYear(mod.endDate),
        mod.engineCapacity || null,
        mapFuel(mod.fuel),
        mod.engineCode || null,
        mod.fullName || null,
        mod.horsePower || null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
      ]);
    }

    if (values.length > 0) {
      const placeholders = values
        .map(() => "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        .join(",");
      const flatValues = values.flat();

      await conn.execute(
        `INSERT INTO cars (id, vehicleTypeId, steeringPositionId, make, model, bodyTypeId, modification, yearFrom, yearTo, engineCapacity, fuelTypeId, engineCode, engineName, horsePower, transmissionTypeId, transmissionGears, transmissionCode, transferCaseCode, frontDifferentialCode, rearDifferentialCode, refrigerantType) VALUES ${placeholders}`,
        flatValues
      );
      totalInserted += values.length;
    }

    console.log(
      `Progress: ${offset + (mods as any[]).length}/${totalMods}, inserted=${totalInserted}, skipped=${totalSkipped}`
    );
  }

  console.log("\n=== IMPORT COMPLETE ===");
  console.log("Total inserted:", totalInserted);
  console.log("Total skipped (duplicates/missing refs):", totalSkipped);

  const [finalCount] = await conn.execute("SELECT COUNT(*) as c FROM cars");
  console.log("Total cars in table:", (finalCount as any[])[0].c);

  // Show breakdown by make
  const [byMake] = await conn.execute(
    `SELECT make, COUNT(*) as c FROM cars GROUP BY make ORDER BY c DESC LIMIT 10`
  );
  console.log("\nTop 10 makes:");
  (byMake as any[]).forEach((r) => console.log(`  ${r.make}: ${r.c}`));

  await conn.end();
}

main().catch((e) => {
  console.error("Fatal:", e);
  process.exit(1);
});
