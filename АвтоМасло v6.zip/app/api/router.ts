import { createRouter, publicQuery } from "./middleware";
import { localAuthRouter } from "./routers/localAuth";
import { setupRouter } from "./routers/setup";
import { carRouter } from "./routers/car";
import { oilRouter } from "./routers/oil";
import { partsRouter } from "./routers/parts";
import { adminRouter } from "./routers/admin";
import { companyRouter } from "./routers/company";
import { widgetRouter } from "./routers/widget";
import { statsRouter } from "./routers/stats";
import { referenceRouter } from "./routers/reference";
import { carsRouter } from "./routers/cars";
import { liquidsRouter } from "./routers/liquids";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  localAuth: localAuthRouter,
  setup: setupRouter,
  car: carRouter,
  oil: oilRouter,
  parts: partsRouter,
  admin: adminRouter,
  company: companyRouter,
  widget: widgetRouter,
  stats: statsRouter,
  reference: referenceRouter,
  cars: carsRouter,
  liquids: liquidsRouter,
});

export type AppRouter = typeof appRouter;
