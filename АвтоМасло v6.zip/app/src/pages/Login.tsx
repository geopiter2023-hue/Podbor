import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { LogIn, User, Lock, AlertCircle } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const loginMutation = trpc.localAuth.login.useMutation({
    onSuccess: (data) => {
      localStorage.setItem("local_auth_token", data.token);
      window.location.href = "/";
    },
    onError: (err) => {
      setError(err.message || "Ошибка входа");
      setLoading(false);
    },
  });

  const registerMutation = trpc.localAuth.register.useMutation({
    onSuccess: (data) => {
      localStorage.setItem("local_auth_token", data.token);
      window.location.href = "/";
    },
    onError: (err) => {
      setError(err.message || "Ошибка регистрации");
      setLoading(false);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (isRegister) {
      registerMutation.mutate({ username, password, name: name || username });
    } else {
      loginMutation.mutate({ username, password });
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-full bg-[#f59e0b] flex items-center justify-center mx-auto mb-4">
            <LogIn className="w-6 h-6 text-black" />
          </div>
          <h1 className="text-white text-2xl font-bold">
            {isRegister ? "Регистрация" : "Вход в систему"}
          </h1>
          <p className="text-[#a3a3a3] text-sm mt-2">
            OilPodbor — подбор масла
          </p>
        </div>

        {/* Form */}
        <div className="bg-[#171717] border border-[#262626] rounded-xl p-6">
          {error && (
            <div className="mb-4 bg-red-500/10 border border-red-500/20 rounded-lg p-3 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <span className="text-red-400 text-sm">{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[#a3a3a3] text-sm mb-1.5">
                Логин
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#525252]" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  autoComplete="username"
                  className="w-full bg-black border border-[#262626] rounded-lg pl-10 pr-3 py-2.5 text-white text-sm focus:border-[#f59e0b] focus:outline-none transition-colors"
                  placeholder="Ushakov"
                />
              </div>
            </div>

            {isRegister && (
              <div>
                <label className="block text-[#a3a3a3] text-sm mb-1.5">
                  Имя
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-black border border-[#262626] rounded-lg px-3 py-2.5 text-white text-sm focus:border-[#f59e0b] focus:outline-none transition-colors"
                  placeholder="Ваше имя"
                />
              </div>
            )}

            <div>
              <label className="block text-[#a3a3a3] text-sm mb-1.5">
                Пароль
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#525252]" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  autoComplete={isRegister ? "new-password" : "current-password"}
                  className="w-full bg-black border border-[#262626] rounded-lg pl-10 pr-3 py-2.5 text-white text-sm focus:border-[#f59e0b] focus:outline-none transition-colors"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#f59e0b] text-black font-semibold py-2.5 rounded-lg hover:bg-[#f59e0b]/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
              ) : (
                <LogIn className="w-4 h-4" />
              )}
              {isRegister ? "Создать аккаунт" : "Войти"}
            </button>
          </form>

          <div className="mt-4 text-center">
            <button
              onClick={() => {
                setIsRegister(!isRegister);
                setError("");
              }}
              className="text-[#a3a3a3] text-sm hover:text-[#f59e0b] transition-colors"
            >
              {isRegister
                ? "Уже есть аккаунт? Войти"
                : "Нет аккаунта? Зарегистрироваться"}
            </button>
          </div>
        </div>

        {/* Back link */}
        <div className="mt-6 text-center">
          <button
            onClick={() => navigate("/")}
            className="text-[#525252] text-sm hover:text-[#a3a3a3] transition-colors"
          >
            ← На главную
          </button>
        </div>
      </div>
    </div>
  );
}
