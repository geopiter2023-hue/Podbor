import { useState, useCallback, useMemo } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import {
  ChevronRight, ChevronDown, Search, X, Car, Truck,
  ArrowLeft, Droplets, Settings2, Cog, Wind, CircleDot, Wrench,
  Shield, LogOut, BookOpen, ExternalLink, Download,
} from "lucide-react";

type Step = "brands" | "models" | "generations" | "result";
type VehicleTab = "car" | "truck";
type AggrTab = "engine" | "cooling" | "transmission" | "differential" | "steering" | "brakes";
type SubFilter = "all" | "no_dpf" | "no_gpf" | "with_gpf";

function getFirstLetter(name: string): string {
  return name ? name.charAt(0).toUpperCase() : "?";
}

const AGGR_TABS: { key: AggrTab; label: string; count: number; icon: any }[] = [
  { key: "engine", label: "Двигатель", count: 10, icon: Settings2 },
  { key: "cooling", label: "Система охлаждения", count: 1, icon: Wind },
  { key: "transmission", label: "АКПП", count: 2, icon: Cog },
  { key: "differential", label: "Задний дифференциал", count: 2, icon: CircleDot },
  { key: "steering", label: "Рулевое управление", count: 2, icon: Wrench },
  { key: "brakes", label: "Тормозная система", count: 1, icon: CircleDot },
];

const SUB_FILTERS: { key: SubFilter; label: string }[] = [
  { key: "all", label: "Все" },
  { key: "no_dpf", label: "Без DPF" },
  { key: "no_gpf", label: "Без GPF" },
  { key: "with_gpf", label: "С GPF" },
];

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const [vehicleTab, setVehicleTab] = useState<VehicleTab>("car");
  const [step, setStep] = useState<Step>("brands");
  const [selectedMake, setSelectedMake] = useState<string | null>(null);
  const [selectedMakeName, setSelectedMakeName] = useState("");
  const [selectedModel, setSelectedModel] = useState<string | null>(null);
  const [selectedModelName, setSelectedModelName] = useState("");
  const [selectedModelImage, setSelectedModelImage] = useState("");
  const [selectedGen, setSelectedGen] = useState<string | null>(null);
  const [selectedGenName, setSelectedGenName] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAllMakes, setShowAllMakes] = useState(false);
  const [plateNumber, setPlateNumber] = useState("");
  const [vinNumber, setVinNumber] = useState("");
  const [plateError, setPlateError] = useState("");
  const [modOpen, setModOpen] = useState(false);
  const [aggrTab, setAggrTab] = useState<AggrTab>("engine");
  const [subFilter, setSubFilter] = useState<SubFilter>("all");

  const { data: makes, isLoading: makesLoading } = trpc.car.brands.useQuery();
  const { data: models } = trpc.car.models.useQuery(
    { makeId: selectedMake ? parseInt(selectedMake) : 0 },
    { enabled: !!selectedMake && step === "models" }
  );
  const { data: mods } = trpc.car.modifications.useQuery(
    { makeId: selectedMake ? parseInt(selectedMake) : 0, modelId: selectedModel ? parseInt(selectedModel) : 0 },
    { enabled: !!selectedMake && !!selectedModel && (step === "generations" || step === "result") }
  );
  const { data: manuals } = trpc.manuals.findByCar.useQuery(
    { make: selectedMakeName, model: selectedModelName },
    { enabled: step === "result" && !!selectedMakeName && !!selectedModelName }
  );

  const { data: oils } = trpc.oil.results.useQuery(
    { makeId: selectedMake ? parseInt(selectedMake) : 0, modelId: selectedModel ? parseInt(selectedModel) : 0, modificationId: selectedGen ? parseInt(selectedGen) : 0 },
    { enabled: !!selectedMake && !!selectedModel && !!selectedGen && step === "result" }
  );

  const plateSearch = trpc.plateSearch.search.useQuery(
    { plate: plateNumber, vin: vinNumber || undefined },
    { enabled: false }
  );

  const filteredMakes = useMemo(() => {
    if (!makes) return [];
    if (!searchQuery) return makes;
    const q = searchQuery.toLowerCase();
    return makes.filter((m: any) => (m.name || "").toLowerCase().includes(q));
  }, [makes, searchQuery]);

  const displayedMakes = showAllMakes || searchQuery ? filteredMakes : filteredMakes.slice(0, 10);

  const handleSelectMake = useCallback((id: string, name: string) => {
    setSelectedMake(id);
    setSelectedMakeName(name);
    setStep("models");
    setSearchQuery("");
    setShowAllMakes(false);
  }, []);

  const handleSelectModel = useCallback((id: string, name: string, imageUrl?: string) => {
    setSelectedModel(id);
    setSelectedModelName(name);
    setSelectedModelImage(imageUrl || "");
    setStep("generations");
  }, []);

  const handleSelectGen = useCallback((id: string, name: string) => {
    setSelectedGen(id);
    setSelectedGenName(name);
    setStep("result");
    setModOpen(false);
  }, []);

  const handleBack = useCallback(() => {
    if (step === "result") { setStep("generations"); setSelectedGen(null); setSelectedGenName(""); }
    else if (step === "generations") { setStep("models"); setSelectedModel(null); setSelectedModelName(""); setSelectedModelImage(""); }
    else if (step === "models") { setStep("brands"); setSelectedMake(null); setSelectedMakeName(""); setShowAllMakes(false); }
  }, [step]);

  const handlePlateSearch = async () => {
    setPlateError("");
    const query = plateNumber || vinNumber;
    if (!query.trim()) { setPlateError("Введите марку или модель"); return; }
    try {
      const result = await plateSearch.refetch();
      if (result.data?.error && !result.data?.found) {
        setPlateError(result.data.error);
        return;
      }
      if (result.data?.found && result.data.localMatch) {
        const match = result.data.localMatch;
        if (match.brand) handleSelectMake(String(match.brand.id), match.brand.name);
      }
    } catch { setPlateError("Ошибка поиска"); }
  };

  const currentMods = mods || [];
  const selectedModData = currentMods.find((m: any) => String(m.id) === selectedGen);

  return (
    <div className="min-h-screen bg-[#f0f0f0]">
      {/* HEADER */}
      <header className="bg-[#1a1a1a] sticky top-0 z-30">
        <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="oilpodbor" className="w-8 h-8" />
            <span className="text-white text-base font-bold tracking-wider uppercase">oilpodbor</span>
            <span className="text-[#737373] text-xs hidden sm:inline">|</span>
            <span className="text-[#a3a3a3] text-xs hidden sm:inline">подбор масел и технических жидкостей</span>
          </div>
          {isAuthenticated && user?.role === "admin" ? (
            <div className="flex items-center gap-3">
              <Link to="/admin" className="text-[#d32f2f] text-sm flex items-center gap-1 hover:opacity-80 font-medium">
                <Shield className="w-4 h-4" />Админ
              </Link>
              <button onClick={logout} className="text-[#737373] text-sm flex items-center gap-1 hover:text-white transition-colors">
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <Link to="/login" className="text-[#d32f2f] text-sm flex items-center gap-1 hover:opacity-80 font-medium">
              <ArrowLeft className="w-4 h-4 rotate-180" />Войти
            </Link>
          )}
        </div>
      </header>

      <main className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 py-4 sm:py-6">
        {step === "brands" && (
          <h1 className="text-[#1a1a1a] text-xl sm:text-2xl lg:text-3xl font-bold mb-4 sm:mb-6 leading-tight">
            Подбор моторного масла и других технических жидкостей
          </h1>
        )}

        {/* Vehicle Tabs */}
        <div className="flex mb-4 sm:mb-6 bg-[#1a1a1a] rounded-lg overflow-hidden">
          <button onClick={() => setVehicleTab("car")} className={`flex-1 py-3 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${vehicleTab === "car" ? "text-[#d32f2f] border-2 border-[#d32f2f] rounded-lg" : "text-white hover:text-[#d32f2f]"}`}><Car className="w-4 h-4" />Легковой</button>
          <button onClick={() => setVehicleTab("truck")} className={`flex-1 py-3 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${vehicleTab === "truck" ? "text-[#d32f2f] border-2 border-[#d32f2f] rounded-lg" : "text-white hover:text-[#d32f2f]"}`}><Truck className="w-4 h-4" />Грузовой</button>
        </div>

        {/* Plate / VIN */}
        <div className="mb-4 sm:mb-6 space-y-2">
          <div className="flex border border-[#d4d4d4] rounded-lg overflow-hidden bg-white">
            <input type="text" value={plateNumber} onChange={(e) => setPlateNumber(e.target.value.toUpperCase())} placeholder="Поиск по марке..." className="flex-1 px-3 py-2.5 text-sm text-[#1a1a1a] placeholder:text-[#a3a3a3] focus:outline-none" />
          </div>
          <input type="text" value={vinNumber} onChange={(e) => setVinNumber(e.target.value.toUpperCase())} placeholder="Поиск по модели..." className="w-full border border-[#d4d4d4] rounded-lg px-3 py-2.5 text-sm text-[#1a1a1a] placeholder:text-[#a3a3a3] focus:outline-none focus:border-[#d32f2f] bg-white" />
          <div className="flex gap-2">
            <button onClick={() => { setPlateNumber(""); setVinNumber(""); setPlateError(""); }} className="flex-1 py-2.5 border border-[#d4d4d4] rounded-lg text-sm font-medium text-[#1a1a1a] hover:bg-gray-50 flex items-center justify-center gap-1 bg-white"><X className="w-4 h-4" />Сбросить</button>
            <button onClick={handlePlateSearch} disabled={plateSearch.isFetching} className="flex-1 py-2.5 bg-[#d32f2f] text-white rounded-lg text-sm font-medium hover:bg-[#b71c1c] flex items-center justify-center gap-1 disabled:opacity-50">
              {plateSearch.isFetching ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Search className="w-4 h-4" />}Поиск
            </button>
          </div>
          {plateError && <p className="text-red-500 text-xs font-medium">{plateError}</p>}

          {/* Local search results */}
          {plateSearch.data && plateSearch.data.found && plateSearch.data.localMatch?.brand && (
            <div className="bg-white rounded-xl p-4 border border-[#d4d4d4] space-y-3">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-[#d32f2f]" />
                <p className="text-[#1a1a1a] text-sm font-medium">Найдено: {plateSearch.data.make} {plateSearch.data.model || ""}</p>
              </div>
              <button onClick={() => { const m = plateSearch.data.localMatch; if (m?.brand) handleSelectMake(String(m.brand.id), m.brand.name); }} className="w-full py-2.5 bg-[#d32f2f] text-white rounded-lg text-sm font-medium hover:bg-[#b71c1c] transition-colors">Перейти к подбору масел</button>
            </div>
          )}
        </div>

        {/* BLACK BLOCK */}
        <div className="bg-[#1a1a1a] rounded-xl p-4 sm:p-6">
          {step === "brands" && (<><h2 className="text-white text-lg sm:text-xl font-bold mb-1">Поиск транспортного средства</h2><p className="text-[#a3a3a3] text-sm mb-4 sm:mb-6">Выберите марку, модель и поколение автомобиля для подбора технических жидкостей</p></>)}

          {/* Breadcrumb */}
          {step !== "brands" && (
            <div className="mb-4 sm:mb-6">
              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 mb-4">
                <div className="w-full sm:w-40 h-28 rounded-lg overflow-hidden bg-[#262626] border border-[#404040] flex-shrink-0 flex items-center justify-center">
                  {selectedModelImage ? <img src={selectedModelImage} alt="" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} /> : <Car className="w-12 h-12 text-[#525252]" />}
                </div>
                <div className="flex-1 grid grid-cols-2 gap-2">
                  <div className="bg-[#262626] border border-[#404040] rounded-lg p-2.5"><p className="text-[#737373] text-[10px] uppercase tracking-wider">Марка авто</p><p className="text-white text-sm font-medium truncate">{selectedMakeName}</p></div>
                  <div className="bg-[#262626] border border-[#404040] rounded-lg p-2.5"><p className="text-[#737373] text-[10px] uppercase tracking-wider">Модель авто</p><p className="text-white text-sm font-medium truncate">{selectedModelName || "—"}</p></div>
                  <div className="bg-[#262626] border border-[#404040] rounded-lg p-2.5"><p className="text-[#737373] text-[10px] uppercase tracking-wider">Поколение</p><p className="text-white text-sm font-medium truncate">{selectedGenName || "—"}</p></div>
                  <div className="bg-[#262626] border border-[#404040] rounded-lg p-2.5"><p className="text-[#737373] text-[10px] uppercase tracking-wider">Модификация</p><p className="text-white text-sm font-medium truncate">{selectedModData?.name || "—"}{selectedModData?.engineCode && ` (${selectedModData.engineCode})`}</p></div>
                </div>
                <button onClick={handleBack} className="bg-[#262626] border border-[#d32f2f] text-[#d32f2f] rounded-lg px-4 py-2 text-sm font-medium hover:bg-[#333] flex items-center justify-center gap-1 flex-shrink-0 self-start sm:self-auto"><ArrowLeft className="w-4 h-4" />Назад</button>
              </div>
              {step === "generations" && (
                <div className="relative">
                  <button onClick={() => setModOpen(!modOpen)} className="w-full bg-[#262626] border border-[#404040] rounded-lg p-3 text-left flex items-center justify-between hover:border-[#d32f2f] transition-colors">
                    <div><p className="text-[#737373] text-xs">Модификация</p><p className="text-white text-sm">{selectedModData?.name || "Выберите модификацию"}{selectedModData?.engineCode && ` (${selectedModData.engineCode})`}</p></div>
                    <ChevronDown className={`w-5 h-5 text-[#737373] transition-transform ${modOpen ? "rotate-180" : ""}`} />
                  </button>
                  {modOpen && (
                    <div className="absolute z-20 w-full mt-1 bg-[#262626] border border-[#404040] rounded-lg shadow-2xl max-h-72 overflow-auto">
                      {currentMods.map((mod: any) => (
                        <button key={mod.id} onClick={() => { setSelectedGen(String(mod.id)); setSelectedGenName(mod.name || ""); setModOpen(false); }} className={`w-full text-left px-4 py-3 text-sm hover:bg-[#333] transition-colors border-b border-[#333] last:border-0 ${String(mod.id) === selectedGen ? "bg-[#d32f2f]/10 text-[#d32f2f]" : "text-white"}`}>
                          <div className="flex items-center justify-between"><span className="font-medium">{mod.name || "—"}</span>{mod.engineCode && <span className="text-[#d32f2f] text-xs font-mono">{mod.engineCode}</span>}</div>
                          <div className="flex gap-3 mt-1 text-[11px] text-[#737373]">{mod.horsePower && <span>{mod.horsePower} л.с.</span>}{mod.fuel && <span>{mod.fuel}</span>}{mod.cylinder && <span>{mod.cylinder} цил.</span>}</div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Quick search */}
          {step === "brands" && (
            <div className="flex gap-2 mb-4 sm:mb-6">
              <div className="flex-1 relative">
                <Search className="w-4 h-4 text-[#737373] absolute left-3 top-1/2 -translate-y-1/2" />
                <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Быстрый поиск марки..." className="w-full bg-[#0a0a0a] border border-[#404040] rounded-lg pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-[#525252] focus:outline-none focus:border-[#d32f2f]" />
              </div>
              {searchQuery && <button onClick={() => setSearchQuery("")} className="px-3 bg-[#262626] border border-[#404040] rounded-lg text-[#737373] hover:text-white"><X className="w-4 h-4" /></button>}
            </div>
          )}

          {/* STEP 1: BRANDS */}
          {step === "brands" && (
            <div>
              {makesLoading ? <div className="flex justify-center py-12"><div className="w-8 h-8 border-2 border-[#d32f2f] border-t-transparent rounded-full animate-spin" /></div> : (
                <>
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 sm:gap-3">
                    {displayedMakes.map((make: any) => (
                      <button key={make.id} onClick={() => handleSelectMake(String(make.id), make.name || "")} className="bg-[#262626] border border-[#404040] rounded-xl p-3 sm:p-4 flex flex-col items-center gap-2 sm:gap-3 hover:border-[#d32f2f] hover:bg-[#2a2a2a] transition-all active:scale-[0.97] group">
                        <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-[#1a1a1a] border border-[#404040] flex items-center justify-center group-hover:border-[#d32f2f]/50 transition-colors"><span className="text-[#d32f2f] text-lg sm:text-xl font-bold">{getFirstLetter(make.name || "")}</span></div>
                        <span className="text-white text-xs sm:text-sm font-medium text-center leading-tight">{make.name}</span>
                      </button>
                    ))}
                  </div>
                  {!showAllMakes && !searchQuery && filteredMakes.length > 10 && (
                    <button onClick={() => setShowAllMakes(true)} className="w-full mt-4 py-3 border border-[#404040] rounded-lg text-sm text-[#a3a3a3] hover:border-[#d32f2f] hover:text-[#d32f2f] transition-colors">Показать все марки ({filteredMakes.length})</button>
                  )}
                </>
              )}
            </div>
          )}

          {/* STEP 2: MODELS */}
          {step === "models" && (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 sm:gap-3">
              {models?.map((model: any) => (
                <button key={model.modelId} onClick={() => handleSelectModel(String(model.modelId), model.modelName || "", model.imageUrl)} className="bg-white rounded-xl overflow-hidden hover:shadow-lg hover:scale-[1.02] transition-all active:scale-[0.98]">
                  <div className="h-20 sm:h-24 bg-white flex items-center justify-center overflow-hidden">
                    {model.imageUrl ? <img src={model.imageUrl} alt={model.modelName || ""} className="w-full h-full object-cover" loading="lazy" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} /> : <Car className="w-10 h-10 sm:w-12 sm:h-12 text-[#d4d4d4]" />}
                  </div>
                  <div className="bg-[#262626] px-2 py-2"><p className="text-white text-[11px] sm:text-xs font-medium text-center truncate">{model.modelName}</p></div>
                </button>
              ))}
              {(!models || models.length === 0) && <div className="col-span-full text-center py-12 text-[#737373] text-sm">Модели не найдены</div>}
            </div>
          )}

          {/* STEP 3: GENERATIONS */}
          {step === "generations" && (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 sm:gap-3">
              {currentMods.map((mod: any) => {
                const years = [];
                if (mod.startDate) { const m = mod.startDate.match(/(\d{4})/); if (m) years.push(m[1]); }
                if (mod.endDate) { const m = mod.endDate.match(/(\d{4})/); if (m) years.push(m[1]); }
                else if (years.length > 0) years.push("н.в.");
                const yearStr = years.join(" — ");
                return (
                  <button key={mod.id} onClick={() => handleSelectGen(String(mod.id), mod.name || "")} className="bg-white rounded-xl overflow-hidden hover:shadow-lg hover:scale-[1.02] transition-all active:scale-[0.98]">
                    <div className="h-20 sm:h-24 bg-[#f5f5f5] flex items-center justify-center"><Car className="w-10 h-10 sm:w-12 sm:h-12 text-[#d4d4d4]" /></div>
                    <div className="bg-[#262626] px-2 py-2"><p className="text-white text-[11px] sm:text-xs font-medium text-center truncate">{mod.name || "—"}</p>{yearStr && <p className="text-[#737373] text-[10px] text-center">{yearStr}</p>}</div>
                  </button>
                );
              })}
              {currentMods.length === 0 && <div className="col-span-full text-center py-12 text-[#737373] text-sm">Поколения не найдены</div>}
            </div>
          )}

          {/* STEP 4: RESULT */}
          {step === "result" && (
            <div className="space-y-4">
              <div className="bg-white rounded-xl p-4 flex items-center gap-4">
                <div className="w-16 h-16 rounded-xl bg-[#f5f5f5] flex items-center justify-center flex-shrink-0 overflow-hidden border border-[#e5e5e5]">
                  {selectedModelImage ? <img src={selectedModelImage} alt="" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} /> : <span className="text-[#d32f2f] text-2xl font-bold">{getFirstLetter(selectedMakeName)}</span>}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[#1a1a1a] font-bold text-base">{selectedMakeName} {selectedModelName}</p>
                  <p className="text-[#737373] text-sm">{selectedGenName}</p>
                  <div className="flex flex-wrap gap-x-3 gap-y-1 mt-1 text-xs text-[#525252]">
                    {selectedModData?.engineCode && <span className="text-[#d32f2f] font-mono font-medium">{selectedModData.engineCode}</span>}
                    {selectedModData?.horsePower && <span>{selectedModData.horsePower} л.с.</span>}
                    {selectedModData?.cylinder && <span>{selectedModData.cylinder} цил.</span>}
                    {selectedModData?.fuel && <span>{selectedModData.fuel}</span>}
                  </div>
                </div>
              </div>

              {/* Aggregation Tabs */}
              <div className="bg-[#262626] rounded-xl overflow-hidden">
                <div className="flex overflow-x-auto scrollbar-hide border-b border-[#404040]">
                  {AGGR_TABS.map((tab) => { const Icon = tab.icon; return (
                    <button key={tab.key} onClick={() => setAggrTab(tab.key)} className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap ${aggrTab === tab.key ? "text-[#d32f2f] border-b-2 border-[#d32f2f] bg-[#d32f2f]/10" : "text-[#a3a3a3] hover:text-white"}`}>
                      <Icon className="w-4 h-4" />{tab.label}<span className={`text-xs ml-0.5 ${aggrTab === tab.key ? "text-[#d32f2f]" : "text-[#737373]"}`}>({tab.count})</span>
                    </button>
                  ); })}
                </div>
                <div className="flex items-center gap-2 px-4 py-3 border-b border-[#404040] overflow-x-auto">
                  {SUB_FILTERS.map((f) => (
                    <button key={f.key} onClick={() => setSubFilter(f.key)} className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${subFilter === f.key ? "bg-[#d32f2f] text-white" : "bg-[#1a1a1a] text-[#a3a3a3] border border-[#404040] hover:border-[#d32f2f] hover:text-white"}`}>{f.label}</button>
                  ))}
                </div>
                <div className="p-4">
                  {oils && oils.length > 0 ? (
                    <div className="space-y-2">
                      {oils.map((oil: any, i: number) => (
                        <div key={oil.id || i} className="bg-[#1a1a1a] border border-[#404040] rounded-lg p-4 hover:border-[#d32f2f]/50 transition-colors">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1"><Droplets className="w-4 h-4 text-[#d32f2f] flex-shrink-0" /><p className="text-white text-sm font-medium truncate">{oil.originalName || oil.name || "—"}</p></div>
                              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-[#737373]">
                                {oil.artNumber && <span className="font-mono text-[#a3a3a3]">{oil.artNumber}</span>}
                                {oil.volume && <span className="text-[#d32f2f] font-medium">{oil.volume}</span>}
                                {oil.specifications && <span>{oil.specifications}</span>}
                              </div>
                              {oil.oemApproval && (
                                <div className="mt-1 flex flex-wrap gap-1">
                                  {oil.oemApproval.split(/[,;]/).map((o: string, idx: number) => (
                                    <span key={idx} className="text-[10px] bg-[#262626] text-[#a3a3a3] px-1.5 py-0.5 rounded border border-[#404040]">{o.trim()}</span>
                                  ))}
                                </div>
                              )}
                            </div>
                            <span className="text-[#525252] text-xs flex-shrink-0">#{i + 1}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-12 text-center"><Droplets className="w-10 h-10 mx-auto mb-3 text-[#525252]" /><p className="text-[#737373] text-sm">Данные не найдены для выбранного фильтра</p><p className="text-[#525252] text-xs mt-1">Попробуйте изменить агрегацию или сбросить фильтры</p></div>
                  )}
                </div>
              </div>

              {/* Owner Manuals */}
              {manuals && manuals.length > 0 && (
                <div className="bg-[#262626] rounded-xl overflow-hidden">
                  <div className="flex items-center gap-2 px-4 py-3 border-b border-[#404040]">
                    <BookOpen className="w-4 h-4 text-[#d32f2f]" />
                    <h3 className="text-white text-sm font-medium">Руководства по эксплуатации</h3>
                    <span className="text-[#737373] text-xs ml-1">({manuals.length})</span>
                  </div>
                  <div className="p-4 space-y-2">
                    {manuals.map((manual: any) => (
                      <a
                        key={manual.id}
                        href={manual.pdfUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 bg-[#1a1a1a] border border-[#404040] rounded-lg p-3 hover:border-[#d32f2f]/50 transition-colors group"
                      >
                        <div className="w-10 h-10 rounded-lg bg-[#333] flex items-center justify-center flex-shrink-0">
                          <BookOpen className="w-5 h-5 text-[#737373] group-hover:text-[#d32f2f] transition-colors" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-white text-sm font-medium truncate">{manual.title || `Руководство ${manual.make} ${manual.model}`}</p>
                          <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-[#737373]">
                            {manual.source && <span>{manual.source}</span>}
                            <span className="text-[#a3a3a3]">{manual.language === "ru" ? "Русский" : manual.language === "en" ? "English" : manual.language}</span>
                            {manual.isOfficial === "yes" && <span className="text-[#d32f2f] font-medium">Официальное</span>}
                            {manual.yearFrom && <span>{manual.yearFrom}{manual.yearTo ? `-${manual.yearTo}` : "+"}</span>}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <ExternalLink className="w-4 h-4 text-[#525252] group-hover:text-[#d32f2f] transition-colors" />
                        </div>
                      </a>
                    ))}
                  </div>
                </div>
              )}

              <button onClick={handleBack} className="w-full py-3 rounded-xl text-sm font-medium bg-[#262626] border border-[#d32f2f] text-[#d32f2f] hover:bg-[#d32f2f]/10 transition-colors"><ArrowLeft className="w-4 h-4 inline mr-2" />Назад к выбору</button>
            </div>
          )}
        </div>

        <footer className="mt-8 sm:mt-12 py-6 text-center text-[#a3a3a3] text-xs border-t border-[#d4d4d4]">
          <p className="font-medium text-[#737373]">oilpodbor — система подбора технических жидкостей</p>
          <p className="mt-1">2025 Все права защищены</p>
        </footer>
      </main>
    </div>
  );
}