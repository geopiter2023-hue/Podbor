#!/bin/bash
# ═══════════════════════════════════════════════
# Setup script for oilpodbor.ru
# ═══════════════════════════════════════════════
set -e

echo "=== oilpodbor.ru Setup ==="

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
echo "Node.js: $(node --version)"

# Check PM2
if ! command -v pm2 &> /dev/null; then
    echo "Installing PM2..."
    npm install -g pm2
fi

# Check MySQL
if ! command -v mysql &> /dev/null; then
    echo "WARNING: MySQL not found. Install: apt install mysql-server"
fi

# Create .env if not exists
if [ ! -f .env ]; then
    echo ""
    echo "Creating .env file..."
    cat > .env << 'EOF'
# Database (REQUIRED)
DATABASE_URL=mysql://USER:PASSWORD@localhost:3306/oilpodbor

# API Keys (fill in as needed)
ANTHROPIC_API_KEY=
OPENAI_API_KEY=
GROQ_API_KEY=
DEEPSEEK_API_KEY=
PERPLEXITY_API_KEY=
GEMINI_API_KEY=
MISTRAL_API_KEY=
COHERE_API_KEY=
YANDEX_API_KEY=
YANDEX_FOLDER_ID=
GIGACHAT_CLIENT_SECRET=
VSEGPT_API_KEY=

# Server
PORT=3000
APP_ID=19e2b8ff-a3c2-8f3c-8000-0000ed10de53
APP_SECRET=prQ67nXXV2WBV6R1OUMpFvMLmtV8YvoF
EOF
    echo "EDIT .env with your database credentials!"
    echo "Run: nano .env"
    exit 1
fi

# Install dependencies
echo ""
echo "Installing dependencies..."
npm install --production

# Build
echo ""
echo "Building..."
npm run build

# Start with PM2
echo ""
echo "Starting server..."
pm install -g pm2 2>/dev/null || true
pm2 delete oilpodbor 2>/dev/null || true
pm2 start dist/boot.js --name oilpodbor --env PORT=3000
pm2 save
pm2 startup 2>/dev/null || true

echo ""
echo "=== Server started! ==="
echo "Check: pm2 logs oilpodbor"
echo "Health: curl http://localhost:3000/health"
echo ""
echo "=== NGINX setup ==="
echo "Copy nginx-config.txt to /etc/nginx/sites-available/oilpodbor"
echo "sudo ln -sf /etc/nginx/sites-available/oilpodbor /etc/nginx/sites-enabled/"
echo "sudo nginx -t && sudo systemctl restart nginx"
