/**
 * VIN decoder router
 * Integration with Nomerogram API and free VIN decoders
 */

import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";

export const vinRouter = createRouter({
  // ─── Decode VIN and return car info ───
  decode: publicQuery
    .input(z.object({ vin: z.string().min(11).max(17) }))
    .query(async ({ input }) => {
      const vin = input.vin.toUpperCase().trim();

      // Try Nomerogram API first
      const nomerogramToken = process.env.NOMEROGRAM_TOKEN || "";
      if (nomerogramToken) {
        try {
          const resp = await fetch(
            `https://nomerogram.ru/api/get-car-info?vin=${vin}&token=${nomerogramToken}`,
            { signal: AbortSignal.timeout(15000) }
          );
          if (resp.ok) {
            const data = await resp.json();
            if (data?.make && data?.model) {
              return {
                success: true,
                source: "nomerogram",
                make: data.make,
                model: data.model,
                year: data.year,
                engineCode: data.engine_code || data.engineCode,
                engineVolume: data.engine_volume || data.volume,
                transmission: data.transmission,
                body: data.body_type || data.body,
                vin,
              };
            }
          }
        } catch { /* fallback */ }
      }

      // Fallback: free NHTSA VIN decoder (US cars, but works for many)
      try {
        const resp = await fetch(
          `https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVINValuesBatch/`,
          {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `format=json&data=${vin}`,
            signal: AbortSignal.timeout(15000),
          }
        );
        if (resp.ok) {
          const data = await resp.json();
          const r = data.Results?.[0];
          if (r?.Make && r?.Model) {
            return {
              success: true,
              source: "nhtsa",
              make: r.Make,
              model: r.Model,
              year: r.ModelYear ? parseInt(r.ModelYear) : undefined,
              engineCode: r.EngineCode || r.EngineModel,
              engineVolume: r.DisplacementL,
              transmission: r.TransmissionStyle,
              body: r.BodyClass,
              vin,
            };
          }
        }
      } catch { /* no result */ }

      return { success: false, error: "VIN not found in databases", vin };
    }),
});
