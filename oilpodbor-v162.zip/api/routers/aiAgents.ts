import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { aiAgents } from "@db/schema";
import { eq } from "drizzle-orm";

// Health check each AI provider
async function checkProvider(name: string, apiKey: string): Promise<{ ok: boolean; latency: number; error?: string }> {
  const start = Date.now();
  if (!apiKey) return { ok: false, latency: 0, error: "No API key" };

  try {
    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": apiKey, "anthropic-version": "2023-06-01", "Content-Type": "application/json" },
      body: JSON.stringify({ model: "claude-3-haiku-20240307", max_tokens: 10, messages: [{ role: "user", content: "hi" }] }),
      signal: AbortSignal.timeout(15000),
    });
    return { ok: resp.status !== 401, latency: Date.now() - start, error: resp.status !== 401 ? undefined : `HTTP ${resp.status}` };
  } catch (e: any) {
    return { ok: false, latency: Date.now() - start, error: e.message };
  }
}

const PROVIDER_ENDPOINTS: Record<string, (key: string) => Promise<{ ok: boolean; latency: number; error?: string }>> = {
  anthropic: async (key) => {
    const start = Date.now();
    try {
      const r = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST", headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-3-haiku-20240307", max_tokens: 10, messages: [{ role: "user", content: "hi" }] }),
        signal: AbortSignal.timeout(15000),
      });
      return { ok: r.status === 200 || r.status === 429, latency: Date.now() - start, error: r.status !== 200 ? `HTTP ${r.status}` : undefined };
    } catch (e: any) { return { ok: false, latency: Date.now() - start, error: e.message }; }
  },
  openai: async (key) => {
    const start = Date.now();
    try {
      const r = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: "gpt-3.5-turbo", max_tokens: 10, messages: [{ role: "user", content: "hi" }] }),
        signal: AbortSignal.timeout(15000),
      });
      return { ok: r.status === 200 || r.status === 429, latency: Date.now() - start, error: r.status !== 200 ? `HTTP ${r.status}` : undefined };
    } catch (e: any) { return { ok: false, latency: Date.now() - start, error: e.message }; }
  },
  perplexity: async (key) => {
    const start = Date.now();
    try {
      const r = await fetch("https://api.perplexity.ai/chat/completions", {
        method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: "llama-3.1-sonar-small-128k-online", max_tokens: 10, messages: [{ role: "user", content: "hi" }] }),
        signal: AbortSignal.timeout(15000),
      });
      return { ok: r.status === 200 || r.status === 429, latency: Date.now() - start, error: r.status !== 200 ? `HTTP ${r.status}` : undefined };
    } catch (e: any) { return { ok: false, latency: Date.now() - start, error: e.message }; }
  },
  groq: async (key) => {
    const start = Date.now();
    try {
      const r = await fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: "llama3-8b-8192", max_tokens: 10, messages: [{ role: "user", content: "hi" }] }),
        signal: AbortSignal.timeout(15000),
      });
      return { ok: r.status === 200 || r.status === 429, latency: Date.now() - start, error: r.status !== 200 ? `HTTP ${r.status}` : undefined };
    } catch (e: any) { return { ok: false, latency: Date.now() - start, error: e.message }; }
  },
  gemini: async (key) => {
    const start = Date.now();
    try {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${key}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents: [{ parts: [{ text: "hi" }] }] }),
        signal: AbortSignal.timeout(15000),
      });
      return { ok: r.status === 200 || r.status === 429, latency: Date.now() - start, error: r.status !== 200 ? `HTTP ${r.status}` : undefined };
    } catch (e: any) { return { ok: false, latency: Date.now() - start, error: e.message }; }
  },
  deepseek: async (key) => {
    const start = Date.now();
    try {
      const r = await fetch("https://api.deepseek.com/chat/completions", {
        method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: "deepseek-chat", max_tokens: 10, messages: [{ role: "user", content: "hi" }] }),
        signal: AbortSignal.timeout(15000),
      });
      return { ok: r.status === 200 || r.status === 429, latency: Date.now() - start, error: r.status !== 200 ? `HTTP ${r.status}` : undefined };
    } catch (e: any) { return { ok: false, latency: Date.now() - start, error: e.message }; }
  },
  mistral: async (key) => {
    const start = Date.now();
    try {
      const r = await fetch("https://api.mistral.ai/v1/chat/completions", {
        method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: "mistral-tiny", max_tokens: 10, messages: [{ role: "user", content: "hi" }] }),
        signal: AbortSignal.timeout(15000),
      });
      return { ok: r.status === 200 || r.status === 429, latency: Date.now() - start, error: r.status !== 200 ? `HTTP ${r.status}` : undefined };
    } catch (e: any) { return { ok: false, latency: Date.now() - start, error: e.message }; }
  },
  cohere: async (key) => {
    const start = Date.now();
    try {
      const r = await fetch("https://api.cohere.ai/v1/chat", {
        method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: "command-r", message: "hi", max_tokens: 10 }),
        signal: AbortSignal.timeout(15000),
      });
      return { ok: r.status === 200 || r.status === 429, latency: Date.now() - start, error: r.status !== 200 ? `HTTP ${r.status}` : undefined };
    } catch (e: any) { return { ok: false, latency: Date.now() - start, error: e.message }; }
  },
};

export const aiAgentsRouter = createRouter({
  // ─── List all agents ───
  list: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(aiAgents).orderBy(aiAgents.priority);
  }),

  // ─── Check all providers health ───
  check: adminQuery.query(async () => {
    const results: Record<string, { ok: boolean; latency: number; error?: string }> = {};
    
    for (const [provider, checker] of Object.entries(PROVIDER_ENDPOINTS)) {
      const key = process.env[`${provider.toUpperCase()}_API_KEY`] || process.env[`${provider}_api_key`] || "";
      if (!key) {
        results[provider] = { ok: false, latency: 0, error: "No API key in env" };
        continue;
      }
      results[provider] = await checker(key);
    }
    
    return results;
  }),

  // ─── Update agent ───
  update: adminQuery
    .input(z.object({
      id: z.number(),
      isActive: z.boolean().optional(),
      priority: z.number().optional(),
      apiKey: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const update: any = {};
      if (input.isActive !== undefined) update.isActive = input.isActive ? 1 : 0;
      if (input.priority !== undefined) update.priority = input.priority;
      if (input.apiKey !== undefined) update.apiKey = input.apiKey;
      await db.update(aiAgents).set(update).where(eq(aiAgents.id, input.id));
      return { success: true };
    }),
});
