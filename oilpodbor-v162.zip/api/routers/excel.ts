import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { carFluidSpecs } from "@db/schema";
import { eq, desc, sql, and } from "drizzle-orm";

// Parse Excel buffer and return rows
async function parseExcel(buffer: Buffer): Promise<any[]> {
  const XLSX = await import("xlsx");
  const workbook = XLSX.read(buffer, { type: "buffer" });
  const sheetName = workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];

  // Get raw data
  const rawData: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
  if (rawData.length < 4) return [];

  // Row 0 = category headers (merged)
  // Row 1 = sub-headers (объем, тип топлива, etc.)
  // Row 2 = sub-sub-headers (SAE, API, ACEA, etc.)
  // Row 3+ = data

  const rows: any[] = [];
  for (let i = 3; i < rawData.length; i++) {
    const row = rawData[i];
    if (!row || row.length < 5) continue;
    if (!row[2] && !row[3]) continue; // skip empty rows

    const make = String(row[2] || "").trim();
    const model = String(row[3] || "").trim();
    if (!make || !model) continue;

    rows.push({
      vehicleType: String(row[0] || "").trim() || null,
      steeringPosition: String(row[1] || "").trim() || null,
      make,
      model,
      body: String(row[4] || "").trim() || null,
      modification: String(row[5] || "").trim() || null,
      // Engine
      engineVolume: String(row[6] || "").trim() || null,
      fuelType: String(row[7] || "").trim() || null,
      engineCode: String(row[8] || "").trim() || null,
      engineReplaceInterval: String(row[9] || "").trim() || null,
      engineFillVolume: String(row[10] || "").trim() || null,
      // Preferred oil
      prefOilSae: String(row[11] || "").trim() || null,
      prefOilApi: String(row[12] || "").trim() || null,
      prefOilAcea: String(row[13] || "").trim() || null,
      prefOilIlsac: String(row[14] || "").trim() || null,
      prefOilOe: String(row[15] || "").trim() || null,
      // Alternative oil
      altOilViscosities: String(row[16] || "").trim() || null,
      altOilApi: String(row[17] || "").trim() || null,
      altOilAcea: String(row[18] || "").trim() || null,
      altOilIlsac: String(row[19] || "").trim() || null,
      altOilOe: String(row[20] || "").trim() || null,
      // Transmission
      transmissionType: String(row[21] || "").trim() || null,
      transmissionGears: String(row[22] || "").trim() || null,
      transmissionCode: String(row[23] || "").trim() || null,
      transmissionReplaceInterval: String(row[24] || "").trim() || null,
      transmissionFillVolume: String(row[25] || "").trim() || null,
      transmissionPrefOil: String(row[26] || "").trim() || null,
      transmissionAltOil: String(row[27] || "").trim() || null,
      // Transfer case
      transferCaseCode: String(row[28] || "").trim() || null,
      transferCaseInterval: String(row[29] || "").trim() || null,
      transferCaseFillVolume: String(row[30] || "").trim() || null,
      transferCaseOil: String(row[31] || "").trim() || null,
      // Front differential
      frontDiffCode: String(row[32] || "").trim() || null,
      frontDiffFillVolume: String(row[33] || "").trim() || null,
      frontDiffInterval: String(row[34] || "").trim() || null,
      frontDiffOil: String(row[35] || "").trim() || null,
      // Rear differential
      rearDiffCode: String(row[36] || "").trim() || null,
      rearDiffFillVolume: String(row[37] || "").trim() || null,
      rearDiffInterval: String(row[38] || "").trim() || null,
      rearDiffOil: String(row[39] || "").trim() || null,
      // Cooling
      coolantFillVolume: String(row[40] || "").trim() || null,
      coolantInterval: String(row[41] || "").trim() || null,
      coolantType: String(row[42] || "").trim() || null,
      // Brake
      brakeFluidVolume: String(row[43] || "").trim() || null,
      brakeFluidInterval: String(row[44] || "").trim() || null,
      brakeFluidType: String(row[45] || "").trim() || null,
      // Power steering
      psFluidVolume: String(row[46] || "").trim() || null,
      psFluidType: String(row[47] || "").trim() || null,
      // Suspension
      suspFluidVolume: String(row[48] || "").trim() || null,
      suspFluidType: String(row[49] || "").trim() || null,
      // AdBlue
      adblueVolume: String(row[50] || "").trim() || null,
      adblueType: String(row[51] || "").trim() || null,
      // Filters
      oilFilter: String(row[52] || "").trim() || null,
      airFilter: String(row[53] || "").trim() || null,
      cabinFilter: String(row[54] || "").trim() || null,
      fuelFilter: String(row[55] || "").trim() || null,
      transmissionFilter: String(row[56] || "").trim() || null,
      rawData: row,
    });
  }
  return rows;
}

export const excelRouter = createRouter({
  // Upload and import Excel file
  import: adminQuery
    .input(z.object({
      fileBase64: z.string(),
      batchName: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const buffer = Buffer.from(input.fileBase64, "base64");
      const rows = await parseExcel(buffer);

      if (rows.length === 0) {
        throw new Error("No data rows found in Excel file");
      }

      const batch = input.batchName || `import_${Date.now()}`;
      let inserted = 0;
      let skipped = 0;

      for (const row of rows) {
        try {
          await db.insert(carFluidSpecs).values({
            ...row,
            importBatch: batch,
          });
          inserted++;
        } catch {
          skipped++;
        }
      }

      return { inserted, skipped, total: rows.length, batch };
    }),

  // List imported records
  list: adminQuery
    .input(z.object({
      make: z.string().optional(),
      model: z.string().optional(),
      batch: z.string().optional(),
      limit: z.number().min(1).max(500).default(50),
      offset: z.number().min(0).default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const filters = input || {};
      const limit = filters.limit || 50;
      const offset = filters.offset || 0;

      let query = db.select().from(carFluidSpecs).where(eq(carFluidSpecs.isActive, "active"));

      if (filters.make) {
        query = query.where(sql`${carFluidSpecs.make} LIKE ${"%" + filters.make + "%"}`);
      }
      if (filters.model) {
        query = query.where(sql`${carFluidSpecs.model} LIKE ${"%" + filters.model + "%"}`);
      }
      if (filters.batch) {
        query = query.where(eq(carFluidSpecs.importBatch, filters.batch));
      }

      const items = await query.orderBy(desc(carFluidSpecs.id)).limit(limit).offset(offset);

      const countResult = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(carFluidSpecs)
        .where(eq(carFluidSpecs.isActive, "active"));

      return { items, total: countResult[0]?.count || 0 };
    }),

  // List import batches
  batches: adminQuery.query(async () => {
    const db = getDb();
    const result = await db
      .select({
        batch: carFluidSpecs.importBatch,
        count: sql<number>`COUNT(*)`,
        lastDate: sql<string>`MAX(${carFluidSpecs.importDate})`,
      })
      .from(carFluidSpecs)
      .groupBy(carFluidSpecs.importBatch)
      .orderBy(desc(sql`MAX(${carFluidSpecs.importDate})`));
    return result;
  }),

  // Delete a batch
  deleteBatch: adminQuery
    .input(z.object({ batch: z.string() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(carFluidSpecs).where(eq(carFluidSpecs.importBatch, input.batch));
      return { ok: true };
    }),

  // Get single record
  getById: adminQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [item] = await db.select().from(carFluidSpecs).where(eq(carFluidSpecs.id, input.id)).limit(1);
      return item || null;
    }),

  // Update record
  update: adminQuery
    .input(z.object({
      id: z.number(),
      data: z.record(z.string().nullable()),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(carFluidSpecs).set(input.data).where(eq(carFluidSpecs.id, input.id));
      return { ok: true };
    }),

  // ─── Get carFluidSpecs by make/model (for edit form) ───
  getByCar: adminQuery
    .input(z.object({
      make: z.string(),
      model: z.string(),
      modification: z.string().optional(),
    }))
    .query(async ({ input }) => {
      const db = getDb();
      let query = db
        .select()
        .from(carFluidSpecs)
        .where(
          and(
            sql`${carFluidSpecs.make} LIKE ${"%" + input.make + "%"}`,
            sql`${carFluidSpecs.model} LIKE ${"%" + input.model + "%"}`,
            eq(carFluidSpecs.isActive, "active"),
          )
        )
        .orderBy(desc(carFluidSpecs.id))
        .limit(1);

      const rows = await query;
      return rows[0] || null;
    }),

  // ─── Update or create carFluidSpecs by make/model ───
  updateByCar: adminQuery
    .input(z.object({
      make: z.string(),
      model: z.string(),
      modification: z.string().optional(),
      data: z.record(z.any()),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();

      // Find existing
      let query = db
        .select()
        .from(carFluidSpecs)
        .where(
          and(
            sql`${carFluidSpecs.make} LIKE ${"%" + input.make + "%"}`,
            sql`${carFluidSpecs.model} LIKE ${"%" + input.model + "%"}`,
            eq(carFluidSpecs.isActive, "active"),
          )
        )
        .limit(1);

      const existing = await query;

      if (existing.length > 0) {
        // Update
        await db.update(carFluidSpecs)
          .set({ ...input.data, updatedAt: new Date() })
          .where(eq(carFluidSpecs.id, existing[0].id));
        return { ok: true, id: existing[0].id, action: "updated" };
      } else {
        // Create new
        const [inserted] = await db.insert(carFluidSpecs).values({
          make: input.make,
          model: input.model,
          modification: input.modification || `${input.make} ${input.model}`,
          vehicleType: "Легковой автомобиль",
          ...input.data,
          importBatch: "manual_edit",
        }).$returningId();
        return { ok: true, id: inserted.id, action: "created" };
      }
    }),

  // ─── Get data completeness for a car ───
  completeness: adminQuery
    .input(z.object({
      make: z.string(),
      model: z.string(),
      modification: z.string().optional(),
    }))
    .query(async ({ input }) => {
      const db = getDb();

      // Find matching records
      let query = db
        .select()
        .from(carFluidSpecs)
        .where(sql`${carFluidSpecs.make} LIKE ${"%" + input.make + "%"} AND ${carFluidSpecs.model} LIKE ${"%" + input.model + "%"} AND ${carFluidSpecs.isActive} = 'active'`);

      if (input.modification) {
        query = query.where(sql`${carFluidSpecs.modification} LIKE ${"%" + input.modification + "%"}`);
      }

      const rows = await query.limit(5);
      if (rows.length === 0) {
        return {
          found: false,
          overall: 0,
          sections: [],
          totalFields: 57,
          filledFields: 0,
        };
      }

      // Use the most complete record
      const row = rows[0];

      // Define sections and their fields
      const sections = [
        {
          name: "Общие данные",
          fields: [
            { key: "make", label: "Марка", value: row.make },
            { key: "model", label: "Модель", value: row.model },
            { key: "modification", label: "Модификация", value: row.modification },
            { key: "body", label: "Кузов", value: row.body },
            { key: "vehicleType", label: "Тип ТС", value: row.vehicleType },
            { key: "steeringPosition", label: "Расположение руля", value: row.steeringPosition },
          ],
        },
        {
          name: "Двигатель",
          fields: [
            { key: "engineCode", label: "Код ДВС", value: row.engineCode },
            { key: "engineVolume", label: "Объём ДВС", value: row.engineVolume },
            { key: "fuelType", label: "Тип топлива", value: row.fuelType },
            { key: "engineFillVolume", label: "Объём масла", value: row.engineFillVolume },
            { key: "engineReplaceInterval", label: "Регламент замены", value: row.engineReplaceInterval },
          ],
        },
        {
          name: "Моторное масло (предпочтительное)",
          fields: [
            { key: "prefOilSae", label: "SAE", value: row.prefOilSae },
            { key: "prefOilApi", label: "API", value: row.prefOilApi },
            { key: "prefOilAcea", label: "ACEA", value: row.prefOilAcea },
            { key: "prefOilIlsac", label: "ILSAC", value: row.prefOilIlsac },
            { key: "prefOilOe", label: "OEM допуски", value: row.prefOilOe },
          ],
        },
        {
          name: "Моторное масло (альтернативное)",
          fields: [
            { key: "altOilViscosities", label: "Вязкости", value: row.altOilViscosities },
            { key: "altOilApi", label: "API", value: row.altOilApi },
            { key: "altOilAcea", label: "ACEA", value: row.altOilAcea },
            { key: "altOilIlsac", label: "ILSAC", value: row.altOilIlsac },
            { key: "altOilOe", label: "OEM", value: row.altOilOe },
          ],
        },
        {
          name: "КПП",
          fields: [
            { key: "transmissionType", label: "Тип КПП", value: row.transmissionType },
            { key: "transmissionGears", label: "Кол-во передач", value: row.transmissionGears },
            { key: "transmissionCode", label: "Код КПП", value: row.transmissionCode },
            { key: "transmissionFillVolume", label: "Объём масла", value: row.transmissionFillVolume },
            { key: "transmissionPrefOil", label: "Масло КПП", value: row.transmissionPrefOil },
            { key: "transmissionReplaceInterval", label: "Регламент замены", value: row.transmissionReplaceInterval },
          ],
        },
        {
          name: "Раздаточная коробка",
          fields: [
            { key: "transferCaseCode", label: "Код РКП", value: row.transferCaseCode },
            { key: "transferCaseFillVolume", label: "Объём", value: row.transferCaseFillVolume },
            { key: "transferCaseOil", label: "Масло", value: row.transferCaseOil },
            { key: "transferCaseInterval", label: "Регламент", value: row.transferCaseInterval },
          ],
        },
        {
          name: "Дифференциалы",
          fields: [
            { key: "frontDiffCode", label: "Код переднего", value: row.frontDiffCode },
            { key: "frontDiffFillVolume", label: "Объём переднего", value: row.frontDiffFillVolume },
            { key: "frontDiffOil", label: "Масло переднего", value: row.frontDiffOil },
            { key: "rearDiffCode", label: "Код заднего", value: row.rearDiffCode },
            { key: "rearDiffFillVolume", label: "Объём заднего", value: row.rearDiffFillVolume },
            { key: "rearDiffOil", label: "Масло заднего", value: row.rearDiffOil },
          ],
        },
        {
          name: "Система охлаждения",
          fields: [
            { key: "coolantFillVolume", label: "Объём антифриза", value: row.coolantFillVolume },
            { key: "coolantType", label: "Тип антифриза", value: row.coolantType },
            { key: "coolantInterval", label: "Регламент замены", value: row.coolantInterval },
          ],
        },
        {
          name: "Тормозная система",
          fields: [
            { key: "brakeFluidVolume", label: "Объём", value: row.brakeFluidVolume },
            { key: "brakeFluidType", label: "Тип", value: row.brakeFluidType },
            { key: "brakeFluidInterval", label: "Регламент", value: row.brakeFluidInterval },
          ],
        },
        {
          name: "ГУР и подвеска",
          fields: [
            { key: "psFluidVolume", label: "Объём ГУР", value: row.psFluidVolume },
            { key: "psFluidType", label: "Тип ГУР", value: row.psFluidType },
            { key: "suspFluidVolume", label: "Объём подвески", value: row.suspFluidVolume },
            { key: "suspFluidType", label: "Тип подвески", value: row.suspFluidType },
          ],
        },
        {
          name: "AdBlue",
          fields: [
            { key: "adblueVolume", label: "Объём", value: row.adblueVolume },
            { key: "adblueType", label: "Тип", value: row.adblueType },
          ],
        },
        {
          name: "Фильтры",
          fields: [
            { key: "oilFilter", label: "Масляный", value: row.oilFilter },
            { key: "airFilter", label: "Воздушный", value: row.airFilter },
            { key: "cabinFilter", label: "Салонный", value: row.cabinFilter },
            { key: "fuelFilter", label: "Топливный", value: row.fuelFilter },
            { key: "transmissionFilter", label: "АКПП", value: row.transmissionFilter },
          ],
        },
      ];

      // Calculate percentages
      let totalFields = 0;
      let filledFields = 0;

      const sectionsWithPercent = sections.map((section) => {
        const sectionTotal = section.fields.length;
        const sectionFilled = section.fields.filter((f) => f.value && String(f.value).trim() !== "" && String(f.value).trim() !== "null").length;
        totalFields += sectionTotal;
        filledFields += sectionFilled;
        return {
          ...section,
          total: sectionTotal,
          filled: sectionFilled,
          percent: Math.round((sectionFilled / sectionTotal) * 100),
        };
      });

      const overall = Math.round((filledFields / totalFields) * 100);

      return {
        found: true,
        overall,
        totalFields,
        filledFields,
        sections: sectionsWithPercent,
        recordId: row.id,
      };
    }),

  // ─── Run AI agents to fill data for specific car ───
  fillWithAI: adminQuery
    .input(z.object({
      make: z.string(),
      model: z.string(),
      modification: z.string().optional(),
      engineCode: z.string().optional(),
      year: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const { runFlexibleResearch, DEFAULT_AGENTS } = await import("../agents/flexibleResearcher");

      // Try each enabled agent until one succeeds
      // Order: Perplexity first (paid $50), then free/cheap alternatives
      const agentIds = ["perplexity", "anthropic", "groq", "deepseek", "gemini", "openai", "mistral", "cohere", "manual"];
      let lastError = "";
      let bestResult: any = null;

      for (const agentId of agentIds) {
        const agent = DEFAULT_AGENTS[agentId];
        if (!agent.enabled) continue;

        try {
          console.log(`[fillWithAI] Trying agent: ${agent.name} (${agent.provider})`);
          const result = await runFlexibleResearch({
            make: input.make,
            model: input.model,
            engineCode: input.engineCode,
            year: input.year,
            modification: input.modification,
            agentId,
          });

          if (result.filledFields && result.filledFields.length > 0) {
            bestResult = result;
            break; // Found good result, stop trying
          }

          if (result.error) lastError = result.error;
        } catch (e: any) {
          console.log(`[fillWithAI] Agent ${agentId} failed:`, e.message);
          lastError = e.message;
          continue; // Try next agent
        }
      }

      // Also run manual finder in background (don't block response)
      let manualResult: any = { skipped: true };
      try {
        const { runManualFinder } = await import("../agents/manualFinder");
        manualResult = await runManualFinder({
          make: input.make,
          model: input.model,
          year: input.year,
          modification: input.modification,
          engineCode: input.engineCode,
        });
      } catch (e: any) {
        console.log("[fillWithAI] Manual finder error:", e.message);
        manualResult = { error: e.message };
      }

      if (bestResult) {
        return {
          success: bestResult.recordId > 0,
          recordId: bestResult.recordId,
          source: bestResult.source,
          confidence: bestResult.confidence,
          tokensUsed: bestResult.tokensUsed,
          filledFields: bestResult.filledFields,
          make: input.make,
          model: input.model,
          manuals: manualResult.items?.length || manualResult.existing || 0,
        };
      }

      // All agents failed — but we still return manual results if any
      if (manualResult.items && manualResult.items.length > 0) {
        return {
          success: false,
          recordId: 0,
          source: "manual-only",
          confidence: "low",
          tokensUsed: { input: 0, output: 0 },
          filledFields: [] as string[],
          make: input.make,
          model: input.model,
          manuals: manualResult.items.length,
        };
      }

      // All agents failed
      throw new Error(lastError || "Все агенты вернули пустой ответ. Проверьте API ключи в Настройках.");
    }),

  // Export all to Excel
  export: adminQuery
    .input(z.object({
      batch: z.string().optional(),
      make: z.string().optional(),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();

      // Build combined where conditions
      const conditions = [eq(carFluidSpecs.isActive, "active")];
      if (input?.batch) {
        conditions.push(eq(carFluidSpecs.importBatch, input.batch));
      }
      if (input?.make) {
        conditions.push(sql`${carFluidSpecs.make} LIKE ${"%" + input.make + "%"}`);
      }

      const items = await db
        .select()
        .from(carFluidSpecs)
        .where(and(...conditions))
        .orderBy(carFluidSpecs.make, carFluidSpecs.model);

      const XLSX = await import("xlsx");

      // Create worksheet data
      const wsData: any[][] = [];

      // Header row 1 - categories
      wsData.push([
        "Тип транспортного средства", "Расположение руля", "Марка", "Модель", "Кузов", "Модификация",
        "Двигатель", "", "", "", "",
        "Предпочтительное моторное масло", "", "", "", "",
        "Альтернативное моторное масло", "", "", "", "",
        "КПП", "", "", "", "", "", "",
        "Раздаточная коробка передач", "", "", "",
        "Передний дифференциал", "", "", "",
        "Задний дифференциал", "", "", "",
        "Система охлаждения", "", "",
        "Тормозная система", "", "",
        "ГУР", "",
        "Подвеска", "",
        "Система AdBlue", "",
        "Фильтры", "", "", "", ""
      ]);

      // Header row 2
      wsData.push([
        "", "", "", "", "", "",
        "объем ДВС", "тип топлива", "код ДВС", "Регламент замены", "Объем заправки",
        "SAE", "API", "ACEA", "ILSAC", "OE",
        "SAE", "API", "ACEA", "ILSAC", "OE",
        "Тип КПП", "количество передач", "код КПП", "Регламент замены", "Объем заправки", "Предпочтительное", "Альтернативное",
        "Код РКП", "Регламент замены", "Объем заправки", "Масло",
        "Код", "Объем заправки", "Регламент замены", "Масло",
        "Код", "Объем заправки", "Регламент замены", "Масло",
        "Объем заправки", "Регламент замены", "Охлаждающая жидкость",
        "Объем заправки", "Регламент замены", "Тормозная жидкость",
        "Объем заправки", "Жидкость ГУРа",
        "Объем заправки", "Жидкость",
        "Объем заправки", "Жидкость AdBlue",
        "Масляный", "Воздушный", "Салонный", "Топливный", "АКПП"
      ]);

      // Data rows
      for (const item of items) {
        wsData.push([
          item.vehicleType || "", item.steeringPosition || "", item.make, item.model,
          item.body || "", item.modification || "",
          item.engineVolume || "", item.fuelType || "", item.engineCode || "",
          item.engineReplaceInterval || "", item.engineFillVolume || "",
          item.prefOilSae || "", item.prefOilApi || "", item.prefOilAcea || "",
          item.prefOilIlsac || "", item.prefOilOe || "",
          item.altOilViscosities || "", item.altOilApi || "", item.altOilAcea || "",
          item.altOilIlsac || "", item.altOilOe || "",
          item.transmissionType || "", item.transmissionGears || "", item.transmissionCode || "",
          item.transmissionReplaceInterval || "", item.transmissionFillVolume || "",
          item.transmissionPrefOil || "", item.transmissionAltOil || "",
          item.transferCaseCode || "", item.transferCaseInterval || "", item.transferCaseFillVolume || "",
          item.transferCaseOil || "",
          item.frontDiffCode || "", item.frontDiffFillVolume || "", item.frontDiffInterval || "",
          item.frontDiffOil || "",
          item.rearDiffCode || "", item.rearDiffFillVolume || "", item.rearDiffInterval || "",
          item.rearDiffOil || "",
          item.coolantFillVolume || "", item.coolantInterval || "", item.coolantType || "",
          item.brakeFluidVolume || "", item.brakeFluidInterval || "", item.brakeFluidType || "",
          item.psFluidVolume || "", item.psFluidType || "",
          item.suspFluidVolume || "", item.suspFluidType || "",
          item.adblueVolume || "", item.adblueType || "",
          item.oilFilter || "", item.airFilter || "", item.cabinFilter || "",
          item.fuelFilter || "", item.transmissionFilter || "",
        ]);
      }

      const ws = XLSX.utils.aoa_to_sheet(wsData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Подборщик");

      const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
      return { data: buf.toString("base64"), filename: `oilpodbor_export_${Date.now()}.xlsx`, count: items.length };
    }),

  // ─── List available AI agents ───
  agents: adminQuery.query(async () => {
    const { DEFAULT_AGENTS } = await import("../agents/flexibleResearcher");
    return Object.entries(DEFAULT_AGENTS).map(([id, config]) => ({
      id,
      name: config.name,
      provider: config.provider,
      model: config.model,
      enabled: config.enabled,
    }));
  }),

  // ─── Stats for dashboard ───
  stats: adminQuery.query(async () => {
    const db = getDb();

    // Total carFluidSpecs records
    const [totalRecords] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(carFluidSpecs)
      .where(eq(carFluidSpecs.isActive, "active"));

    // Average fill percentage across all records
    const fields = [
      "prefOilSae", "prefOilApi", "prefOilAcea", "prefOilOe",
      "altOilViscosities", "altOilApi", "altOilAcea", "altOilOe",
      "transmissionType", "transmissionPrefOil", "transmissionAltOil",
      "transferCaseCode", "transferCaseOil",
      "frontDiffCode", "frontDiffOil", "rearDiffCode", "rearDiffOil",
      "coolantType", "coolantFillVolume",
      "brakeFluidType", "brakeFluidVolume",
      "psFluidType", "suspFluidType",
      "adblueVolume",
      "oilFilter", "airFilter", "cabinFilter", "fuelFilter", "transmissionFilter",
      "engineFillVolume",
    ];

    // Count filled fields per record (sample of 1000 for speed)
    const sample = await db
      .select()
      .from(carFluidSpecs)
      .where(eq(carFluidSpecs.isActive, "active"))
      .limit(1000);

    let totalFilled = 0;
    let totalPossible = 0;
    const filledCars: string[] = [];

    for (const row of sample) {
      let carFilled = 0;
      for (const f of fields) {
        totalPossible++;
        const val = (row as any)[f];
        if (val && String(val).trim() !== "" && String(val).trim() !== "0") {
          totalFilled++;
          carFilled++;
        }
      }
      // Count as "filled" if at least 1 field has data
      if (carFilled > 0) {
        filledCars.push(`${row.make} ${row.model}`);
      }
    }

    // Also count cars that have a record in carFluidSpecs at all (any data)
    const allCarNames = sample
      .filter((r) => r.make && r.model)
      .map((r) => `${r.make} ${r.model}`);
    const uniqueFilledCars = [...new Set([...filledCars, ...allCarNames])];

    const avgFillPercent = totalPossible > 0 ? Math.round((totalFilled / totalPossible) * 100) : 0;

    return {
      totalRecords: totalRecords?.count || 0,
      avgFillPercent,
      filledCarsCount: uniqueFilledCars.length,
      sampleSize: sample.length,
      recentCars: filledCars.slice(0, 10),
    };
  }),

  // ─── Get fluid specs for multiple makes ───
  getMany: adminQuery
    .input(z.object({ makes: z.array(z.string()) }))
    .query(async ({ input }) => {
      if (!input.makes.length) return [];
      const db = getDb();
      const uniqueMakes = [...new Set(input.makes.map((m) => m.toLowerCase()))];
      if (uniqueMakes.length === 0) return [];
      // Build OR condition for all makes
      const conditions = uniqueMakes.map((m) => sql`LOWER(${carFluidSpecs.make}) = ${m}`);
      const combined = conditions.reduce((acc, cond) => sql`${acc} OR ${cond}`);
      return db.select().from(carFluidSpecs).where(sql`(${combined})`).limit(500);
    }),
});
