import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { brands, models, modifications, cars as carsTable } from "@db/schema";
import { eq, asc, sql, count, like, or } from "drizzle-orm";

export const carRouter = createRouter({
  // ─── Get all brands (cached for 5 minutes) ───
  brands: publicQuery.query(async () => {
    try {
      const { getOrSet } = await import("../lib/cache");
      return getOrSet("brands", async () => {
        const db = getDb();
        const result = await db
          .select({ id: brands.id, name: brands.name })
          .from(brands)
          .orderBy(asc(brands.name));
        return result.map((r) => ({ id: Number(r.id), name: r.name }));
      }, 300000); // 5 min cache
    } catch (e: any) {
      console.error("[car.brands] ERROR:", e.message);
      return [];
    }
  }),

  // ─── Get cars list from modifications (with brand/model names) ───
  list: publicQuery
    .input(z.object({
      limit: z.number().default(50),
      offset: z.number().default(0),
      search: z.string().optional(),
    }).optional())
    .query(async ({ input }) => {
      try {
        const db = getDb();
        const limit = input?.limit || 50;
        const offset = input?.offset || 0;
        const search = input?.search || "";

        // Build base WHERE clause
        let whereSql = sql`1=1`;
        if (search) {
          const term = `%${search}%`;
          whereSql = sql`(${like(sql`b.name`, term)} OR ${like(sql`m.name`, term)} OR ${like(sql`mo.name`, term)})`;
        }

        // Count
        const [countResult] = await db.execute(
          sql`SELECT COUNT(*) as c FROM TOmodifications mo JOIN TOmodels m ON mo.modelId = m.id JOIN TObrands b ON m.brandId = b.id WHERE ${whereSql}`
        );
        const total = Number((countResult as any)?.c || 0);

        // Data with JOIN
        const result = await db.execute(
          sql`SELECT 
            mo.id as id, b.name as make, m.name as model, mo.name as modification,
            mo.yearFrom, mo.yearTo, mo.horsePower, mo.engineCapacity,
            mo.transmissionTypeId, mo.transmissionGears, mo.body
          FROM TOmodifications mo
          JOIN TOmodels m ON mo.modelId = m.id
          JOIN TObrands b ON m.brandId = b.id
          WHERE ${whereSql}
          ORDER BY b.name, m.name, mo.name
          LIMIT ${limit} OFFSET ${offset}`
        );

        return { cars: result as any[], total };
      } catch (e: any) {
        console.error("[car.list] ERROR:", e.message);
        return { cars: [], total: 0 };
      }
    }),

  // ─── Get models for a brand with imageUrl ───
  models: publicQuery
    .input(z.object({ makeId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      let result = await db
        .select({
          modelId: models.modelId,
          makeId: models.makeId,
          modelName: models.modelName,
          yearFrom: models.yearFrom,
          yearTo: models.yearTo,
          imageUrl: models.imageUrl,
        })
        .from(models)
        .where(eq(models.makeId, input.makeId))
        .orderBy(asc(models.modelName));

      // Fallback: if no results, search models by brand name
      if (result.length === 0) {
        const brand = await db
          .select()
          .from(brands)
          .where(eq(brands.id, input.makeId))
          .limit(1);
        if (brand.length > 0) {
          result = await db
            .select({
              modelId: models.modelId,
              makeId: models.makeId,
              modelName: models.modelName,
              yearFrom: models.yearFrom,
              yearTo: models.yearTo,
              imageUrl: models.imageUrl,
            })
            .from(models)
            .where(sql`LOWER(${models.modelName}) LIKE LOWER(${'%' + brand[0].name + '%'})`)
            .orderBy(asc(models.modelName));
        }
      }

      return result.map((r) => ({
        modelId: Number(r.modelId),
        makeId: Number(r.makeId),
        modelName: r.modelName,
        yearFrom: r.yearFrom,
        yearTo: r.yearTo,
        imageUrl: r.imageUrl,
      }));
    }),

  // ─── Get modifications directly from TOmodifications ───
  modifications: publicQuery
    .input(z.object({ makeId: z.number(), modelId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select({
          id: modifications.id,
          name: modifications.name,
          engineCode: modifications.engineCode,
          fuel: modifications.fuel,
          horsePower: modifications.horsePower,
          startDate: modifications.startDate,
          endDate: modifications.endDate,
          engineCapacity: modifications.engineCapacity,
          constructionType: modifications.constructionType,
          motorType: modifications.motorType,
        })
        .from(modifications)
        .where(eq(modifications.makeId, input.makeId))
        .orderBy(asc(modifications.modelId), asc(modifications.name));
      return result.map((r) => ({
        id: Number(r.id),
        name: r.name,
        engineCode: r.engineCode,
        fuel: r.fuel,
        horsePower: r.horsePower,
        startDate: r.startDate,
        endDate: r.endDate,
        engineCapacity: r.engineCapacity,
        constructionType: r.constructionType,
        motorType: r.motorType,
      }));
    }),
});
