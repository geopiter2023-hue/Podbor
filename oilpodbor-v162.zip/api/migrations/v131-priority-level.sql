-- v131: Add priorityLevel to products
ALTER TABLE products ADD COLUMN IF NOT EXISTS priorityLevel INT DEFAULT 2;

-- Set LUKOIL GENESIS as level 1 (recommended)
UPDATE products SET priorityLevel = 1 WHERE name LIKE '%GENESIS ARMORTECH%' OR name LIKE '%GENESIS CLARITECH%';

-- Set SHELL, CASTROL, MOBIL as level 1 (premium recommended)
UPDATE products SET priorityLevel = 1 WHERE brand IN ('SHELL', 'CASTROL', 'MOBIL') AND category = 'motor-oil';

-- Set filters as level 2 (alternative)
UPDATE products SET priorityLevel = 2 WHERE category = 'filter';

-- Set transmission/coolant as level 3 (additional)
UPDATE products SET priorityLevel = 3 WHERE category = 'transmission' AND name LIKE '%DOT 4%';

-- Verify
SELECT priorityLevel, COUNT(*) FROM products GROUP BY priorityLevel;
