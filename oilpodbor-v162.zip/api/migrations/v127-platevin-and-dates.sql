-- v127: Plate-VIN Registry + Agent Dates
-- Run: mysql -u root -p oilpodbor < v127-platevin-and-dates.sql

-- ─── 1. Add date columns to carFluidSpecs ───
ALTER TABLE carFluidSpecs
  ADD COLUMN IF NOT EXISTS lastCheckedAt TIMESTAMP NULL AFTER isActive,
  ADD COLUMN IF NOT EXISTS lastFilledAt TIMESTAMP NULL AFTER lastCheckedAt,
  ADD COLUMN IF NOT EXISTS checkedBy VARCHAR(255) NULL AFTER lastFilledAt,
  ADD COLUMN IF NOT EXISTS filledBy VARCHAR(100) NULL AFTER checkedBy;

-- ─── 2. Add date columns to aiAgentResults ───
ALTER TABLE aiAgentResults
  ADD COLUMN IF NOT EXISTS checkedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER errorMessage,
  ADD COLUMN IF NOT EXISTS filledAt TIMESTAMP NULL AFTER checkedAt;

-- ─── 3. Create plateVinRegistry table ───
CREATE TABLE IF NOT EXISTS plateVinRegistry (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plateNumber VARCHAR(20) NOT NULL,
  vin VARCHAR(50),
  make VARCHAR(255) NOT NULL,
  model VARCHAR(255) NOT NULL,
  year INT,
  engineCode VARCHAR(100),
  engineCapacity VARCHAR(50),
  transmission VARCHAR(100),
  fuel VARCHAR(50),
  source VARCHAR(50) DEFAULT 'manual' NOT NULL,
  sourceDetail TEXT,
  isVerified ENUM('yes','no','pending') DEFAULT 'no' NOT NULL,
  verifiedBy INT,
  verifiedAt TIMESTAMP NULL,
  lastCheckedAt TIMESTAMP NULL,
  lastFilledAt TIMESTAMP NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  notes TEXT,
  INDEX idx_plate (plateNumber),
  INDEX idx_vin (vin),
  INDEX idx_car (make, model),
  INDEX idx_verified (isVerified)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── 4. Create index on aiAgentResults.checkedAt ───
CREATE INDEX IF NOT EXISTS idx_ai_checked ON aiAgentResults(checkedAt);

-- ─── 5. Sample data ───
INSERT IGNORE INTO plateVinRegistry (plateNumber, vin, make, model, year, source, isVerified, notes)
VALUES
  ('А001АА 77', 'XW7BT61Z9CM000000', 'Toyota', 'Camry', 2020, 'manual', 'yes', 'Тестовая запись'),
  ('В002ВВ 99', 'Z94CT41DBMR000001', 'Kia', 'Rio', 2019, 'nomerogram', 'pending', 'Ожидает проверки');
