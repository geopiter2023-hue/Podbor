-- v134: Fix all missing columns + plateVinRegistry
-- Run: mysql -u root -p oilpodbor < v134-fix-all.sql

-- 1. Add date columns to cars table
ALTER TABLE cars
  ADD COLUMN IF NOT EXISTS lastCheckedAt TIMESTAMP NULL AFTER isActive,
  ADD COLUMN IF NOT EXISTS lastFilledAt TIMESTAMP NULL AFTER lastCheckedAt,
  ADD COLUMN IF NOT EXISTS checkedBy VARCHAR(255) NULL AFTER lastFilledAt,
  ADD COLUMN IF NOT EXISTS filledBy VARCHAR(100) NULL AFTER checkedBy;

-- 2. Add date columns to carFluidSpecs table
ALTER TABLE carFluidSpecs
  ADD COLUMN IF NOT EXISTS lastCheckedAt TIMESTAMP NULL AFTER isActive,
  ADD COLUMN IF NOT EXISTS lastFilledAt TIMESTAMP NULL AFTER lastCheckedAt,
  ADD COLUMN IF NOT EXISTS checkedBy VARCHAR(255) NULL AFTER lastFilledAt,
  ADD COLUMN IF NOT EXISTS filledBy VARCHAR(100) NULL AFTER checkedBy;

-- 3. Add priorityLevel to products
ALTER TABLE products
  ADD COLUMN IF NOT EXISTS priorityLevel INT DEFAULT 2 AFTER compatibleBrands;

-- 4. Create plateVinRegistry table
CREATE TABLE IF NOT EXISTS plateVinRegistry (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plateNumber VARCHAR(20) NOT NULL,
  vin VARCHAR(50),
  make VARCHAR(255) NOT NULL,
  model VARCHAR(255) NOT NULL,
  year INT,
  engineCode VARCHAR(100),
  engineCapacity VARCHAR(50),
  transmission VARCHAR(100),
  fuel VARCHAR(50),
  source VARCHAR(50) DEFAULT 'manual' NOT NULL,
  sourceDetail TEXT,
  isVerified ENUM('yes','no','pending') DEFAULT 'no' NOT NULL,
  verifiedBy INT,
  verifiedAt TIMESTAMP NULL,
  lastCheckedAt TIMESTAMP NULL,
  lastFilledAt TIMESTAMP NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  notes TEXT,
  INDEX idx_plate (plateNumber),
  INDEX idx_vin (vin),
  INDEX idx_car (make, model),
  INDEX idx_verified (isVerified)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Create aiAgentResults table
CREATE TABLE IF NOT EXISTS aiAgentResults (
  id INT AUTO_INCREMENT PRIMARY KEY,
  make VARCHAR(255) NOT NULL,
  model VARCHAR(255) NOT NULL,
  generation VARCHAR(500),
  modification VARCHAR(500),
  engineCode VARCHAR(100),
  agentName VARCHAR(100) NOT NULL,
  agentProvider VARCHAR(50) NOT NULL,
  filledFields JSON,
  filledCount INT DEFAULT 0,
  rawResponse TEXT,
  parsedJson JSON,
  tokensInput INT DEFAULT 0,
  tokensOutput INT DEFAULT 0,
  tokensTotal INT DEFAULT 0,
  status ENUM('success','error','empty') DEFAULT 'success' NOT NULL,
  errorMessage TEXT,
  checkedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  filledAt TIMESTAMP NULL,
  durationMs INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  INDEX idx_car (make, model),
  INDEX idx_agent (agentProvider),
  INDEX idx_created (createdAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Set sample priorities
UPDATE products SET priorityLevel = 1 WHERE brand IN ('SHELL', 'CASTROL', 'MOBIL') AND category = 'motor-oil';
UPDATE products SET priorityLevel = 1 WHERE name LIKE '%GENESIS%' AND category = 'motor-oil';
UPDATE products SET priorityLevel = 3 WHERE category = 'transmission' AND name LIKE '%DOT 4%';
