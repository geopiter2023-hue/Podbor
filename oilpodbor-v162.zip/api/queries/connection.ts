import { drizzle } from "drizzle-orm/mysql2";
import * as schema from "@db/schema";
import * as relations from "@db/relations";

const fullSchema = { ...schema, ...relations };

let instance: ReturnType<typeof drizzle<typeof fullSchema>>;
let dbError: string | null = null;

function getDatabaseUrl(): string {
  // Direct env var — most reliable for ESM
  return process.env.DATABASE_URL || "";
}

let warnedOnce = false;

export function getDb() {
  if (!instance) {
    const dbUrl = getDatabaseUrl();
    if (!dbUrl) {
      if (!warnedOnce) {
        warnedOnce = true;
        console.error("[DB] DATABASE_URL not set — check .env file");
      }
      // Return mock that throws on actual queries
      return createMockDb();
    }
    try {
      instance = drizzle(dbUrl, {
        mode: "planetscale",
        schema: fullSchema,
      });
      console.log("[DB] Connected successfully");
    } catch (e: any) {
      dbError = e.message;
      console.error("[DB] Failed to connect:", e.message);
      return createMockDb();
    }
  }
  return instance;
}

// Mock DB — chainable proxy that returns empty results for Drizzle queries
function createMockDb(): any {
  const chainable = new Proxy({} as any, {
    get(t, prop) {
      // Return a chainable function for Drizzle methods
      return (...args: any[]) => chainable;
    },
  });
  // Make it awaitable — resolves to empty array
  chainable.then = (onFulfilled: any) => Promise.resolve([]).then(onFulfilled);
  chainable.catch = (onRejected: any) => Promise.resolve([]).catch(onRejected);
  chainable[Symbol.for("nodejs.util.promisify.custom")] = async () => [];
  return chainable;
}

export function getDbStatus() {
  return { connected: !!instance, error: dbError };
}
