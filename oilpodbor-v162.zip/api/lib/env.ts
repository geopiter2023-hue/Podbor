import { getDb } from "../queries/connection";
import { systemSettings } from "@db/schema";
import { eq } from "drizzle-orm";

function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    console.warn(`[ENV] Missing: ${name}`);
    return "";
  }
  return value;
}

// Base env from process.env
const baseEnv = {
  appId: required("APP_ID"),
  appSecret: required("APP_SECRET"),
  isProduction: process.env.NODE_ENV === "production",
  databaseUrl: required("DATABASE_URL"),
  kimiAuthUrl: required("KIMI_AUTH_URL"),
  kimiOpenUrl: required("KIMI_OPEN_URL"),
  ownerUnionId: process.env.OWNER_UNION_ID ?? "",
  // Legacy: will be overridden by DB settings
  nomerogramToken: process.env.NOMEROGRAM_TOKEN ?? "",
  anthropicApiKey: process.env.ANTHROPIC_API_KEY ?? "",
  openaiApiKey: process.env.OPENAI_API_KEY ?? "",
};

// Cache for DB settings
let dbSettingsCache: Record<string, string> | null = null;
let cacheTimestamp = 0;
const CACHE_TTL_MS = 30000; // 30 seconds

/**
 * Load settings from database into cache
 */
async function loadDbSettings(): Promise<Record<string, string>> {
  const now = Date.now();
  if (dbSettingsCache && now - cacheTimestamp < CACHE_TTL_MS && Object.keys(dbSettingsCache).length > 0) {
    return dbSettingsCache;
  }

  try {
    const db = getDb();
    const rows = await db.select().from(systemSettings);
    dbSettingsCache = {};
    for (const row of rows) {
      if (row.value) dbSettingsCache[row.key] = row.value;
    }
    cacheTimestamp = now;
  } catch {
    // If DB not available, use empty cache
    dbSettingsCache = {};
  }

  return dbSettingsCache ?? {};
}

/**
 * Get a setting value: DB takes priority over env
 */
export async function getSetting(key: string): Promise<string | null> {
  // Force fresh load for API keys (skip cache)
  if (key.includes("api_key") || key.includes("token")) {
    dbSettingsCache = null; // invalidate cache
  }
  const dbSettings = await loadDbSettings();
  // DB value takes priority
  if (dbSettings[key] && dbSettings[key].trim() !== "") {
    return dbSettings[key].trim(); // trim whitespace/newlines
  }
  // Fallback to env
  const envMap: Record<string, string | undefined> = {
    nomerogram_token: baseEnv.nomerogramToken,
    anthropic_api_key: baseEnv.anthropicApiKey,
    openai_api_key: baseEnv.openaiApiKey,
    yandex_api_key: process.env.YANDEX_API_KEY || "",
    yandex_folder_id: process.env.YANDEX_FOLDER_ID || "",
    gigachat_client_id: process.env.GIGACHAT_CLIENT_ID || "",
    gigachat_client_secret: process.env.GIGACHAT_CLIENT_SECRET || "",
    vsegpt_api_key: process.env.VSEGPT_API_KEY || "",
  };
  return envMap[key] || null;
}

/**
 * Get all active settings merged (DB + env)
 */
export async function getAllSettings(): Promise<Record<string, string>> {
  const dbSettings = await loadDbSettings();
  return {
    nomerogram_token: baseEnv.nomerogramToken,
    anthropic_api_key: baseEnv.anthropicApiKey,
    openai_api_key: baseEnv.openaiApiKey,
    yandex_api_key: process.env.YANDEX_API_KEY || "",
    yandex_folder_id: process.env.YANDEX_FOLDER_ID || "",
    gigachat_client_id: process.env.GIGACHAT_CLIENT_ID || "",
    gigachat_client_secret: process.env.GIGACHAT_CLIENT_SECRET || "",
    vsegpt_api_key: process.env.VSEGPT_API_KEY || "",
    ...dbSettings, // DB overrides env
  };
}

// Sync env export for backward compatibility
export const env = {
  ...baseEnv,
  // These will be updated from DB at runtime
  get nomerogramToken() { return dbSettingsCache?.nomerogram_token || baseEnv.nomerogramToken; },
  get anthropicApiKey() { return dbSettingsCache?.anthropic_api_key || baseEnv.anthropicApiKey; },
  get openaiApiKey() { return dbSettingsCache?.openai_api_key || baseEnv.openaiApiKey; },
};

// Lazy init: don't load at import time to avoid crash if DB not ready
// Settings will be loaded on first getSetting() call
