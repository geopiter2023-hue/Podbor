/**
 * Simple in-memory cache for API responses
 * Reduces DB load for frequently accessed reference data
 */

interface CacheEntry<T> {
  data: T;
  expiresAt: number;
}

const store = new Map<string, CacheEntry<any>>();

/**
 * Get cached value or compute it
 */
export async function getOrSet<T>(
  key: string,
  factory: () => Promise<T>,
  ttlMs: number = 60000 // default 1 minute
): Promise<T> {
  const now = Date.now();
  const cached = store.get(key);

  if (cached && cached.expiresAt > now) {
    return cached.data;
  }

  const data = await factory();
  store.set(key, { data, expiresAt: now + ttlMs });
  return data;
}

/**
 * Get cached value if exists
 */
export function get<T>(key: string): T | undefined {
  const cached = store.get(key);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.data;
  }
  return undefined;
}

/**
 * Set cache value
 */
export function set<T>(key: string, data: T, ttlMs: number = 60000): void {
  store.set(key, { data, expiresAt: Date.now() + ttlMs });
}

/**
 * Invalidate cache key
 */
export function invalidate(key: string): void {
  store.delete(key);
}

/**
 * Invalidate by pattern
 */
export function invalidatePattern(pattern: string): void {
  for (const key of store.keys()) {
    if (key.includes(pattern)) store.delete(key);
  }
}

/**
 * Clear all cache
 */
export function clear(): void {
  store.clear();
}

/**
 * Get cache stats
 */
export function stats(): { keys: number; entries: string[] } {
  return {
    keys: store.size,
    entries: Array.from(store.keys()),
  };
}
