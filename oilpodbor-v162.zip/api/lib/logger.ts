/**
 * Simple file logger
 * Logs to both console and file
 */

import fs from "fs";
import path from "path";

const LOG_DIR = process.cwd();
const LOG_FILE = path.join(LOG_DIR, "server.log");

// Ensure log file exists
function ensureLogFile() {
  try {
    if (!fs.existsSync(LOG_FILE)) {
      fs.writeFileSync(LOG_FILE, "", { flag: "a" });
    }
  } catch { /* ignore */ }
}

function timestamp(): string {
  return new Date().toISOString().replace("T", " ").slice(0, 19);
}

function write(level: string, msg: string) {
  const line = `[${timestamp()}] [${level}] ${msg}\n`;
  console.log(line.trim());
  try {
    ensureLogFile();
    fs.appendFileSync(LOG_FILE, line, { flag: "a" });
  } catch { /* ignore file errors */ }
}

export const logger = {
  info: (msg: string) => write("INFO", msg),
  warn: (msg: string) => write("WARN", msg),
  error: (msg: string) => write("ERROR", msg),
  debug: (msg: string) => {
    if (process.env.DEBUG) write("DEBUG", msg);
  },
};
