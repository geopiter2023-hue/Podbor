/**
 * Simple in-memory rate limiter
 * Protects API from abuse
 */

interface RateLimitEntry {
  count: number;
  resetAt: number;
}

const requests = new Map<string, RateLimitEntry>();

const DEFAULT_WINDOW_MS = 60000; // 1 minute
const DEFAULT_MAX = 100; // 100 requests per minute

/**
 * Check if request is allowed
 */
export function checkRateLimit(
  identifier: string,
  maxRequests: number = DEFAULT_MAX,
  windowMs: number = DEFAULT_WINDOW_MS
): { allowed: boolean; remaining: number; resetAt: number } {
  const now = Date.now();
  const entry = requests.get(identifier);

  if (!entry || entry.resetAt < now) {
    // New window
    const resetAt = now + windowMs;
    requests.set(identifier, { count: 1, resetAt });
    return { allowed: true, remaining: maxRequests - 1, resetAt };
  }

  if (entry.count >= maxRequests) {
    return { allowed: false, remaining: 0, resetAt: entry.resetAt };
  }

  entry.count++;
  return { allowed: true, remaining: maxRequests - entry.count, resetAt: entry.resetAt };
}

/**
 * Clean up expired entries (call periodically)
 */
export function cleanup(): void {
  const now = Date.now();
  for (const [key, entry] of requests) {
    if (entry.resetAt < now) requests.delete(key);
  }
}

// Auto-cleanup every 5 minutes
setInterval(cleanup, 300000);
