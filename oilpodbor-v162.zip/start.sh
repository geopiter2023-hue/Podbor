#!/bin/bash
# Start script for oilpodbor.ru

echo "=== oilpodbor.ru server starter ==="
echo "Checking environment..."

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js not found. Install: https://nodejs.org"
    exit 1
fi
echo "Node.js version: $(node --version)"

# Check .env
if [ ! -f .env ]; then
    echo ""
    echo "WARNING: .env file not found!"
    echo "Creating .env template..."
    cat > .env << 'EOF'
DATABASE_URL=mysql://USER:PASSWORD@localhost:3306/oilpodbor
APP_ID=your-app-id
APP_SECRET=your-app-secret
PORT=3000
EOF
    echo "EDIT .env file with your database credentials!"
    echo "Then run: ./start.sh"
    exit 1
fi

# Check dist exists
if [ ! -f dist/boot.js ]; then
    echo "ERROR: dist/boot.js not found. Run: npm run build"
    exit 1
fi

# Start server
echo ""
echo "Starting server..."
export NODE_ENV=production
node dist/boot.js
