import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Hash, Plus, Search, Check, X, Loader2, Phone, Calendar } from "lucide-react";

export default function PlateVinView() {
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ plateNumber: "", vin: "", make: "", model: "", year: "", engineCode: "" });

  const { data: stats } = trpc.plateVin.stats.useQuery();
  const { data: list, isLoading } = trpc.plateVin.list.useQuery(
    search ? { search, limit: 50 } : { limit: 50 }
  );
  const upsert = trpc.plateVin.upsert.useMutation({
    onSuccess: () => { utils.plateVin.list.invalidate(); utils.plateVin.stats.invalidate(); setShowForm(false); setForm({ plateNumber: "", vin: "", make: "", model: "", year: "", engineCode: "" }); },
  });
  const verify = trpc.plateVin.verify.useMutation({
    onSuccess: () => utils.plateVin.list.invalidate(),
  });
  const remove = trpc.plateVin.delete.useMutation({
    onSuccess: () => { utils.plateVin.list.invalidate(); utils.plateVin.stats.invalidate(); },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-gray-800 text-xl font-semibold flex items-center gap-2">
          <Hash className="w-5 h-5 text-[#d32f2f]" />
          Реестр номеров
        </h2>
        <button onClick={() => setShowForm(!showForm)} className="bg-[#d32f2f] hover:bg-[#b71c1c] text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors">
          <Plus className="w-4 h-4" /> Добавить
        </button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-5 gap-3">
          {[
            { label: "Всего", value: stats.total, color: "bg-gray-50" },
            { label: "Проверено", value: stats.verified, color: "bg-green-50" },
            { label: "Ожидает", value: stats.pending, color: "bg-amber-50" },
            { label: "С VIN", value: stats.withVin, color: "bg-blue-50" },
            { label: "За 7 дней", value: stats.recent, color: "bg-purple-50" },
          ].map((s) => (
            <div key={s.label} className={`${s.color} rounded-lg p-3 text-center border border-gray-200`}>
              <p className="text-xl font-bold text-gray-800">{s.value}</p>
              <p className="text-xs text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Поиск по номеру, VIN, марке..."
          className="w-full border border-gray-300 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:border-[#d32f2f] focus:ring-1 focus:ring-[#d32f2f] focus:outline-none"
        />
      </div>

      {/* Add form */}
      {showForm && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Новая запись</h3>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "Госномер *", key: "plateNumber", placeholder: "А001АА 77" },
              { label: "VIN", key: "vin", placeholder: "XW7BT61Z9CM000000" },
              { label: "Марка *", key: "make", placeholder: "Toyota" },
              { label: "Модель *", key: "model", placeholder: "Camry" },
              { label: "Год", key: "year", placeholder: "2020" },
              { label: "Код двигателя", key: "engineCode", placeholder: "2GR-FE" },
            ].map((f) => (
              <div key={f.key}>
                <label className="block text-gray-500 text-xs mb-1">{f.label}</label>
                <input
                  type="text"
                  value={(form as any)[f.key]}
                  onChange={(e) => setForm((prev) => ({ ...prev, [f.key]: e.target.value }))}
                  placeholder={f.placeholder}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:border-[#d32f2f] focus:outline-none"
                />
              </div>
            ))}
          </div>
          <div className="flex gap-2 mt-3">
            <button
              onClick={() => upsert.mutate({ ...form, year: form.year ? parseInt(form.year) : undefined })}
              disabled={!form.plateNumber || !form.make || !form.model}
              className="bg-[#d32f2f] text-white px-4 py-2 rounded-lg text-sm font-medium disabled:opacity-50"
            >
              Сохранить
            </button>
            <button onClick={() => setShowForm(false)} className="border border-gray-300 text-gray-600 px-4 py-2 rounded-lg text-sm">Отмена</button>
          </div>
        </div>
      )}

      {/* Table */}
      {isLoading ? (
        <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-[#d32f2f]" /></div>
      ) : (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="border-b border-gray-200">
                <th className="text-left p-3 text-gray-500 text-xs font-medium">Госномер</th>
                <th className="text-left p-3 text-gray-500 text-xs font-medium">VIN</th>
                <th className="text-left p-3 text-gray-500 text-xs font-medium">Автомобиль</th>
                <th className="text-left p-3 text-gray-500 text-xs font-medium">Статус</th>
                <th className="text-left p-3 text-gray-500 text-xs font-medium">Проверен</th>
                <th className="text-left p-3 text-gray-500 text-xs font-medium w-20">Действия</th>
              </tr>
            </thead>
            <tbody>
              {list?.items?.map((item: any) => (
                <tr key={item.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                  <td className="p-3 font-mono font-bold text-gray-800">{item.plateNumber}</td>
                  <td className="p-3 font-mono text-xs text-gray-500">{item.vin || "—"}</td>
                  <td className="p-3">
                    <p className="font-medium text-gray-800">{item.make} {item.model}</p>
                    {item.year && <p className="text-xs text-gray-400">{item.year} {item.engineCode}</p>}
                  </td>
                  <td className="p-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                      item.isVerified === "yes" ? "bg-green-100 text-green-700" :
                      item.isVerified === "pending" ? "bg-amber-100 text-amber-700" :
                      "bg-gray-100 text-gray-500"
                    }`}>
                      {item.isVerified === "yes" ? "Проверен" : item.isVerified === "pending" ? "Ожидание" : "Новый"}
                    </span>
                  </td>
                  <td className="p-3 text-xs text-gray-400">
                    {item.verifiedAt ? new Date(item.verifiedAt).toLocaleDateString("ru-RU") : "—"}
                  </td>
                  <td className="p-3">
                    <div className="flex gap-1">
                      {item.isVerified !== "yes" && (
                        <button onClick={() => verify.mutate({ id: item.id })} className="p-1.5 text-green-500 hover:bg-green-50 rounded" title="Верифицировать">
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button onClick={() => { if (confirm("Удалить?")) remove.mutate({ id: item.id }); }} className="p-1.5 text-red-400 hover:bg-red-50 rounded" title="Удалить">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
