import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Layers, Star, ChevronUp, ChevronDown, Check } from "lucide-react";

export default function ProductPriorityManager() {
  const utils = trpc.useUtils();
  const { data: productsData, isLoading } = trpc.products.list.useQuery({ limit: 100 });
  const setPriority = trpc.products.setPriority.useMutation({
    onSuccess: () => utils.products.list.invalidate(),
  });

  const [selectedCategory, setSelectedCategory] = useState("");

  const filtered = selectedCategory
    ? productsData?.items?.filter((p: any) => p.category === selectedCategory)
    : productsData?.items;

  // Group by priority
  const level1 = filtered?.filter((p: any) => p.priorityLevel === 1) || [];
  const level2 = filtered?.filter((p: any) => p.priorityLevel === 2 || !p.priorityLevel) || [];
  const level3 = filtered?.filter((p: any) => p.priorityLevel === 3) || [];

  const categories = [...new Set(productsData?.items?.map((p: any) => p.category).filter(Boolean))];

  const handleSetPriority = (id: number, level: number) => {
    setPriority.mutate({ id, priorityLevel: level });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-6 h-6 border-2 border-[#d32f2f] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-gray-800 text-xl font-semibold flex items-center gap-2">
          <Layers className="w-5 h-5 text-[#d32f2f]" />
          Уровни товаров
        </h2>
        <div className="flex gap-2">
          <span className="text-xs px-2 py-1 bg-amber-50 text-amber-700 rounded-full border border-amber-200">
            1 уровень — Рекомендуемое
          </span>
          <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-full border border-gray-200">
            2 уровень — Альтернатива
          </span>
          <span className="text-xs px-2 py-1 bg-blue-50 text-blue-600 rounded-full border border-blue-200">
            3 уровень — Дополнительно
          </span>
        </div>
      </div>

      {/* Category filter */}
      <div className="flex gap-2 flex-wrap">
        <button
          onClick={() => setSelectedCategory("")}
          className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${!selectedCategory ? "bg-[#d32f2f] text-white border-[#d32f2f]" : "bg-white text-gray-600 border-gray-200 hover:border-[#d32f2f]"}`}
        >
          Все
        </button>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${selectedCategory === cat ? "bg-[#d32f2f] text-white border-[#d32f2f]" : "bg-white text-gray-600 border-gray-200 hover:border-[#d32f2f]"}`}
          >
            {cat === "motor-oil" ? "Моторные масла" : cat === "filter" ? "Фильтры" : cat === "transmission" ? "Трансмиссия" : cat}
          </button>
        ))}
      </div>

      {/* Level 1 */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-3 bg-amber-50 border-b border-amber-200 flex items-center gap-2">
          <Star className="w-4 h-4 text-amber-600" />
          <h3 className="text-sm font-semibold text-amber-800">1 уровень — Рекомендуемое (первым показывается)</h3>
          <span className="ml-auto text-xs text-amber-600 bg-amber-100 px-2 py-0.5 rounded-full">{level1.length}</span>
        </div>
        {level1.length === 0 ? (
          <div className="p-6 text-center text-gray-400 text-sm">Нет товаров 1 уровня</div>
        ) : (
          <div className="divide-y divide-gray-100">
            {level1.map((p: any) => (
              <ProductRow key={p.id} product={p} onSetPriority={handleSetPriority} currentLevel={1} />
            ))}
          </div>
        )}
      </div>

      {/* Level 2 */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-3 bg-gray-50 border-b border-gray-200 flex items-center gap-2">
          <Layers className="w-4 h-4 text-gray-500" />
          <h3 className="text-sm font-semibold text-gray-700">2 уровень — Альтернатива</h3>
          <span className="ml-auto text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">{level2.length}</span>
        </div>
        {level2.length === 0 ? (
          <div className="p-6 text-center text-gray-400 text-sm">Нет товаров 2 уровня</div>
        ) : (
          <div className="divide-y divide-gray-100">
            {level2.map((p: any) => (
              <ProductRow key={p.id} product={p} onSetPriority={handleSetPriority} currentLevel={2} />
            ))}
          </div>
        )}
      </div>

      {/* Level 3 */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-3 bg-blue-50 border-b border-blue-200 flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-500" />
          <h3 className="text-sm font-semibold text-blue-700">3 уровень — Дополнительно</h3>
          <span className="ml-auto text-xs text-blue-500 bg-blue-100 px-2 py-0.5 rounded-full">{level3.length}</span>
        </div>
        {level3.length === 0 ? (
          <div className="p-6 text-center text-gray-400 text-sm">Нет товаров 3 уровня</div>
        ) : (
          <div className="divide-y divide-gray-100">
            {level3.map((p: any) => (
              <ProductRow key={p.id} product={p} onSetPriority={handleSetPriority} currentLevel={3} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ProductRow({ product, onSetPriority, currentLevel }: { product: any; onSetPriority: (id: number, level: number) => void; currentLevel: number }) {
  const price = product.price ? (product.price / 100).toLocaleString("ru-RU") + " ₽" : "";
  const specs = product.specs ? (typeof product.specs === "string" ? JSON.parse(product.specs) : product.specs) : {};

  return (
    <div className="p-3 flex items-center gap-3 hover:bg-gray-50 transition-colors">
      <img src={product.imageUrl || "/placeholder.jpg"} alt="" className="w-12 h-12 object-cover rounded-lg bg-gray-100 flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-gray-800 truncate">{product.name}</p>
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <span>{product.brand}</span>
          {specs.viscosity && <span>· {specs.viscosity}</span>}
          {specs.api && <span>· {specs.api}</span>}
          <span>· {price}</span>
        </div>
      </div>
      <div className="flex items-center gap-1 flex-shrink-0">
        {[1, 2, 3].map((level) => (
          <button
            key={level}
            onClick={() => onSetPriority(product.id, level)}
            className={`w-8 h-8 rounded-lg text-xs font-bold transition-colors flex items-center justify-center ${
              currentLevel === level
                ? level === 1
                  ? "bg-amber-500 text-white"
                  : level === 2
                    ? "bg-gray-500 text-white"
                    : "bg-blue-500 text-white"
                : "bg-gray-100 text-gray-400 hover:bg-gray-200"
            }`}
            title={`Уровень ${level}`}
          >
            {currentLevel === level ? <Check className="w-3.5 h-3.5" /> : level}
          </button>
        ))}
      </div>
    </div>
  );
}
