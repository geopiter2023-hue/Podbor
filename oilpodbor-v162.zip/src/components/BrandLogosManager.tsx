import { useState, useRef } from "react";
import { trpc } from "@/providers/trpc";
import { Image, RefreshCw, Trash2, Search, Zap, Upload, ExternalLink } from "lucide-react";

export default function BrandLogosManager() {
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [aiRunning, setAiRunning] = useState(false);

  const { data: brands, isLoading } = trpc.brandLogos.adminList.useQuery();
  const { data: stats } = trpc.brandLogos.stats.useQuery();

  const runAI = trpc.brandLogos.runAI.useMutation({
    onSuccess: () => {
      utils.brandLogos.adminList.invalidate();
      utils.brandLogos.stats.invalidate();
      setAiRunning(false);
    },
    onError: () => setAiRunning(false),
  });

  const saveLogo = trpc.brandLogos.save.useMutation({
    onSuccess: () => {
      utils.brandLogos.adminList.invalidate();
      utils.brandLogos.stats.invalidate();
    },
  });

  const clearLogo = trpc.brandLogos.clear.useMutation({
    onSuccess: () => {
      utils.brandLogos.adminList.invalidate();
      utils.brandLogos.stats.invalidate();
    },
  });

  const uploadLogo = trpc.brandLogos.upload.useMutation({
    onSuccess: () => {
      utils.brandLogos.adminList.invalidate();
      utils.brandLogos.stats.invalidate();
    },
  });

  const handleFileUpload = (brandName: string, file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      const fileType = file.name.split(".").pop() || "png";
      uploadLogo.mutate({ brandName, base64Data: base64, fileType });
    };
    reader.readAsDataURL(file);
  };

  const filtered = brands?.filter((b) =>
    !search || b.brandName?.toLowerCase().includes(search.toLowerCase())
  ) || [];

  const withoutLogos = filtered.filter((b) => !b.hasLogo);
  const withLogos = filtered.filter((b) => b.hasLogo);

  const handleRunAI = () => {
    setAiRunning(true);
    const names = withoutLogos.map((b) => b.brandName).filter(Boolean) as string[];
    if (names.length > 0) {
      runAI.mutate({ brandNames: names });
    }
  };

  const handleManualUrl = (brandName: string, url: string) => {
    if (url.trim()) {
      saveLogo.mutate({ brandName, logoUrl: url.trim(), source: "manual" });
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Логотипы марок</h2>
          <p className="text-sm text-gray-500 mt-0.5">
            {stats?.withLogos || 0} из {stats?.totalBrands || 0} марок имеют логотип ({stats?.percent || 0}%)
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleRunAI}
            disabled={aiRunning || withoutLogos.length === 0}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 text-sm font-medium transition-colors"
          >
            {aiRunning ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Zap className="w-4 h-4" />
            )}
            {aiRunning ? "Поиск..." : `Найти ИИ (${withoutLogos.length})`}
          </button>
        </div>
      </div>

      {/* Progress bar */}
      <div className="bg-gray-100 rounded-full h-2.5 overflow-hidden">
        <div
          className="bg-purple-500 h-full rounded-full transition-all duration-500"
          style={{ width: `${stats?.percent || 0}%` }}
        />
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Поиск марки..."
          className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
        />
      </div>

      {/* Without logos */}
      {withoutLogos.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-gray-500 mb-2 uppercase tracking-wide">
            Без логотипа ({withoutLogos.length})
          </h3>
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 p-3">
              {withoutLogos.map((b) => (
                <div key={b.brandName} className="flex items-center gap-3 p-3 border border-gray-100 rounded-lg bg-gray-50">
                  <div className="w-12 h-12 rounded-lg bg-gray-200 flex items-center justify-center flex-shrink-0">
                    <span className="text-gray-400 text-lg font-bold">
                      {b.brandName?.charAt(0) || "?"}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{b.brandName}</p>
                    <div className="flex gap-1 mt-1">
                      <input
                        type="text"
                        placeholder="URL логотипа..."
                        className="flex-1 min-w-0 px-2 py-1 text-xs border border-gray-200 rounded focus:ring-1 focus:ring-purple-500"
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            handleManualUrl(b.brandName || "", (e.target as HTMLInputElement).value);
                            (e.target as HTMLInputElement).value = "";
                          }
                        }}
                      />
                      <label className="cursor-pointer p-1 rounded bg-gray-100 hover:bg-gray-200 text-gray-500" title="Загрузить файл">
                        <Upload className="w-3.5 h-3.5" />
                        <input
                          type="file"
                          accept=".png,.jpg,.jpeg,.svg,.webp"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file && b.brandName) handleFileUpload(b.brandName, file);
                          }}
                        />
                      </label>
                      <button
                        onClick={() => b.brandName && runAI.mutate({ brandNames: [b.brandName] })}
                        disabled={aiRunning}
                        className="p-1 rounded bg-purple-50 hover:bg-purple-100 text-purple-500 disabled:opacity-30"
                        title="Найти ИИ"
                      >
                        <Zap className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* With logos */}
      {withLogos.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-gray-500 mb-2 uppercase tracking-wide">
            С логотипом ({withLogos.length})
          </h3>
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3 p-3">
              {withLogos.map((b) => (
                <div key={b.brandName} className="group relative flex flex-col items-center p-3 border border-gray-100 rounded-lg hover:border-purple-200 hover:bg-purple-50 transition-all">
                  <div className="w-16 h-16 flex items-center justify-center mb-2">
                    {b.logoUrl ? (
                      <img
                        src={b.logoUrl}
                        alt={b.brandName || ""}
                        className="max-w-full max-h-full object-contain"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = "none";
                        }}
                      />
                    ) : (
                      <Image className="w-8 h-8 text-gray-300" />
                    )}
                  </div>
                  <p className="text-xs font-medium text-gray-700 text-center truncate w-full">
                    {b.brandName}
                  </p>
                  {b.source && (
                    <span className="text-[10px] text-gray-400 mt-0.5 flex items-center gap-0.5">
                      {b.source}
                      {b.logoUrl?.startsWith("http") && (
                        <a href={b.logoUrl} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()}>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      )}
                    </span>
                  )}
                  <button
                    onClick={() => b.brandName && clearLogo.mutate({ brandName: b.brandName })}
                    className="absolute top-1 right-1 p-1 rounded-full bg-red-50 text-red-400 opacity-0 group-hover:opacity-100 hover:bg-red-100 transition-all"
                    title="Удалить логотип"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {isLoading && (
        <div className="text-center py-8 text-gray-400">Загрузка...</div>
      )}
    </div>
  );
}
