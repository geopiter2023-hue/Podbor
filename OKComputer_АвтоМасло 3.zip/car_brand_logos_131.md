# Логотипы автомобильных марок — oilpodbor.ru

> **Источник фото — интерфейс управления сайтом (админка/CRM), раздел марок, фильтр «Без логотипа»**

**Статистика:** Всего марок в базе: **131** | ✅ Найдено: **87** | ⚠️ Требуется проверка: **44** | ❌ Не найдено: **0**

## Навигация по алфавиту
[A](#A) | [B](#B) | [C](#C) | [D](#D) | [E](#E) | [F](#F) | [G](#G) | [H](#H) | [I](#I) | [J](#J) | [K](#K) | [L](#L) | [M](#M) | [N](#N) | [O](#O) | [P](#P) | [R](#R) | [S](#S) | [T](#T) | [U](#U) | [V](#V) | [Z](#Z)

---

<a id="A"></a>
## A

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 1 | **ABARTH** | [https://upload.wikimedia.org/wikipedia/commons/thumb/c/c0/Abarth_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c0/Abarth_logo.svg/600px-Abarth_logo.svg.png) | ✅ Найдено |
| 2 | **ACURA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Acura_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Acura_logo.svg/600px-Acura_logo.svg.png) | ✅ Найдено |
| 3 | **ALFA ROMEO** | [https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Alfa_Romeo_logo.svg...](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Alfa_Romeo_logo.svg/600px-Alfa_Romeo_logo.svg.png) | ✅ Найдено |
| 4 | **ASTON MARTIN** | [https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Aston_Martin_Lagond...](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Aston_Martin_Lagonda_brand_logo.svg/600px-Aston_Martin_Lagonda_brand_logo.svg.png) | ✅ Найдено |
| 5 | **AUDI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/Audi_logo.svg/600px...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/Audi_logo.svg/600px-Audi_logo.svg.png) | ✅ Найдено |
| 6 | **AVATR** | [https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Avatr_Technology_lo...](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Avatr_Technology_logo.svg/600px-Avatr_Technology_logo.svg.png) | ⚠️ Требуется проверка |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="B"></a>
## B

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 7 | **BAIC** | [https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/BAIC_Logo.svg/600px...](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/BAIC_Logo.svg/600px-BAIC_Logo.svg.png) | ✅ Найдено |
| 8 | **BENTLEY** | [https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Bentley_logo.svg/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Bentley_logo.svg/600px-Bentley_logo.svg.png) | ✅ Найдено |
| 9 | **BMW** | [https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/BMW.svg/600px-BMW.s...](https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/BMW.svg/600px-BMW.svg.png) | ✅ Найдено |
| 10 | **BMW MOTORRAD** | [https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/BMW.svg/600px-BMW.s...](https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/BMW.svg/600px-BMW.svg.png) | ✅ Найдено (BMW) |
| 11 | **BOGDAN** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Bogdan_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Bogdan_logo.svg/600px-Bogdan_logo.svg.png) | ⚠️ Требуется проверка |
| 12 | **BRILLIANCE** | [https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/Brilliance_Auto_log...](https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/Brilliance_Auto_logo.svg/600px-Brilliance_Auto_logo.svg.png) | ⚠️ Требуется проверка |
| 13 | **BUICK** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Buick_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Buick_logo.svg/600px-Buick_logo.svg.png) | ✅ Найдено |
| 14 | **BYD** | [https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/BYD_Auto_logo.svg/6...](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/BYD_Auto_logo.svg/600px-BYD_Auto_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="C"></a>
## C

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 15 | **CADILLAC** | [https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Cadillac_logo.svg/6...](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Cadillac_logo.svg/600px-Cadillac_logo.svg.png) | ✅ Найдено |
| 16 | **CHANGAN (CHANA)** | [https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Changan_Automobile_...](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Changan_Automobile_logo.svg/600px-Changan_Automobile_logo.svg.png) | ⚠️ Требуется проверка |
| 17 | **CHERY** | [https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Chery_Logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Chery_Logo.svg/600px-Chery_Logo.svg.png) | ✅ Найдено |
| 18 | **CHEVROLET** | [https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Chevrolet_logo.svg/...](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Chevrolet_logo.svg/600px-Chevrolet_logo.svg.png) | ✅ Найдено |
| 19 | **CHRYSLER** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Chrysler_logo.svg/6...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Chrysler_logo.svg/600px-Chrysler_logo.svg.png) | ✅ Найдено |
| 20 | **CITROEN** | [https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Citroen_2016_logo.s...](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Citroen_2016_logo.svg/600px-Citroen_2016_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="D"></a>
## D

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 21 | **DACIA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Dacia_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Dacia_logo.svg/600px-Dacia_logo.svg.png) | ✅ Найдено |
| 22 | **DAEWOO** | [https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Daewoo_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Daewoo_logo.svg/600px-Daewoo_logo.svg.png) | ✅ Найдено |
| 23 | **DAIHATSU** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/Daihatsu_logo.svg/6...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/Daihatsu_logo.svg/600px-Daihatsu_logo.svg.png) | ✅ Найдено |
| 24 | **DATSUN** | [https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Datsun_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Datsun_logo.svg/600px-Datsun_logo.svg.png) | ✅ Найдено |
| 25 | **DAYUN** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Dayun_Motorcycle_lo...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Dayun_Motorcycle_logo.png/600px-Dayun_Motorcycle_logo.png) | ⚠️ Требуется проверка |
| 26 | **DODGE** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Dodge_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/Dodge_logo.svg/600px-Dodge_logo.svg.png) | ✅ Найдено |
| 27 | **DONGFENG** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Dongfeng_Motor_logo...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Dongfeng_Motor_logo.svg/600px-Dongfeng_Motor_logo.svg.png) | ⚠️ Требуется проверка |
| 28 | **DS** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/DS_Automobiles_logo...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/DS_Automobiles_logo.svg/600px-DS_Automobiles_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="E"></a>
## E

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 29 | **EVOLUTE** | [https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Evolute_logo.png/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Evolute_logo.png/600px-Evolute_logo.png) | ⚠️ Требуется проверка |
| 30 | **EXEED** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Exeed_logo.png/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Exeed_logo.png/600px-Exeed_logo.png) | ⚠️ Требуется проверка |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="F"></a>
## F

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 31 | **FAW** | [https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/FAW_logo.svg/600px-...](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/FAW_logo.svg/600px-FAW_logo.svg.png) | ⚠️ Требуется проверка |
| 32 | **FERRARI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/Ferrari_logo.svg/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/Ferrari_logo.svg/600px-Ferrari_logo.svg.png) | ✅ Найдено |
| 33 | **FIAT** | [https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Fiat_logo.svg/600px...](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Fiat_logo.svg/600px-Fiat_logo.svg.png) | ✅ Найдено |
| 34 | **FORD** | [https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Ford_Motor_Company_...](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Ford_Motor_Company_Logo.svg/600px-Ford_Motor_Company_Logo.svg.png) | ✅ Найдено |
| 35 | **FORD ASIA / OZEANIA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Ford_Motor_Company_...](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Ford_Motor_Company_Logo.svg/600px-Ford_Motor_Company_Logo.svg.png) | ✅ Найдено (Ford) |
| 36 | **FORD USA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Ford_Motor_Company_...](https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Ford_Motor_Company_Logo.svg/600px-Ford_Motor_Company_Logo.svg.png) | ✅ Найдено (Ford) |
| 37 | **FORTHING** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Dongfeng_Fengxing_l...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Dongfeng_Fengxing_logo.png/600px-Dongfeng_Fengxing_logo.png) | ⚠️ Требуется проверка |
| 38 | **FOTON** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Foton_Motor_logo.sv...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Foton_Motor_logo.svg/600px-Foton_Motor_logo.svg.png) | ⚠️ Требуется проверка |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="G"></a>
## G

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 39 | **GAC** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/GAC_Group_logo.svg/...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/GAC_Group_logo.svg/600px-GAC_Group_logo.svg.png) | ⚠️ Требуется проверка |
| 40 | **GAZ** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/GAZ_logo.svg/600px-...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/GAZ_logo.svg/600px-GAZ_logo.svg.png) | ✅ Найдено |
| 41 | **GEELY** | [https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/Geely_Logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/Geely_Logo.svg/600px-Geely_Logo.svg.png) | ✅ Найдено |
| 42 | **GENESIS** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Genesis_Motor_logo....](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Genesis_Motor_logo.svg/600px-Genesis_Motor_logo.svg.png) | ✅ Найдено |
| 43 | **GEO** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Geo_%28automobile%2...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Geo_%28automobile%29_logo.png/600px-Geo_%28automobile%29_logo.png) | ⚠️ Требуется проверка |
| 44 | **GMC** | [https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/GMC_logo.svg/600px-...](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/GMC_logo.svg/600px-GMC_logo.svg.png) | ✅ Найдено |
| 45 | **GREAT WALL** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Great_Wall_Motor_lo...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Great_Wall_Motor_logo.svg/600px-Great_Wall_Motor_logo.svg.png) | ⚠️ Требуется проверка |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="H"></a>
## H

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 46 | **HAFEI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Hafei_Motor_logo.pn...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Hafei_Motor_logo.png/600px-Hafei_Motor_logo.png) | ⚠️ Требуется проверка |
| 47 | **HAIMA (FAW)** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Haima_Automobile_lo...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Haima_Automobile_logo.png/600px-Haima_Automobile_logo.png) | ⚠️ Требуется проверка |
| 48 | **HAVAL** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Haval_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Haval_logo.svg/600px-Haval_logo.svg.png) | ✅ Найдено |
| 49 | **HAWTAI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Hawtai_Motor_logo.p...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Hawtai_Motor_logo.png/600px-Hawtai_Motor_logo.png) | ⚠️ Требуется проверка |
| 50 | **HONDA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Honda_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Honda_logo.svg/600px-Honda_logo.svg.png) | ✅ Найдено |
| 51 | **HONGQI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Hongqi_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Hongqi_logo.svg/600px-Hongqi_logo.svg.png) | ⚠️ Требуется проверка |
| 52 | **HUMMER** | [https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Hummer_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Hummer_logo.svg/600px-Hummer_logo.svg.png) | ✅ Найдено |
| 53 | **HYUNDAI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Hyundai_Motor_Compa...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Hyundai_Motor_Company_logo.svg/600px-Hyundai_Motor_Company_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="I"></a>
## I

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 54 | **INFINITI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Infiniti_logo.svg/6...](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Infiniti_logo.svg/600px-Infiniti_logo.svg.png) | ✅ Найдено |
| 55 | **IRAN KHODRO (IKCO)** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Iran_Khodro_logo.sv...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Iran_Khodro_logo.svg/600px-Iran_Khodro_logo.svg.png) | ⚠️ Требуется проверка |
| 56 | **ISUZU** | [https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Isuzu_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Isuzu_logo.svg/600px-Isuzu_logo.svg.png) | ✅ Найдено |
| 57 | **IVECO** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Iveco_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Iveco_logo.svg/600px-Iveco_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="J"></a>
## J

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 58 | **JAC** | [https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/JAC_Motors_logo.svg...](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/JAC_Motors_logo.svg/600px-JAC_Motors_logo.svg.png) | ⚠️ Требуется проверка |
| 59 | **JAECOO** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Jaecoo_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Jaecoo_logo.svg/600px-Jaecoo_logo.svg.png) | ⚠️ Требуется проверка |
| 60 | **JAGUAR** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Jaguar_Cars_logo.sv...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Jaguar_Cars_logo.svg/600px-Jaguar_Cars_logo.svg.png) | ✅ Найдено |
| 61 | **JEEP** | [https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Jeep_logo.svg/600px...](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Jeep_logo.svg/600px-Jeep_logo.svg.png) | ✅ Найдено |
| 62 | **JETOUR** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Jetour_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Jetour_logo.svg/600px-Jetour_logo.svg.png) | ⚠️ Требуется проверка |
| 63 | **JETTA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Jetta_logo_2019.svg...](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Jetta_logo_2019.svg/600px-Jetta_logo_2019.svg.png) | ⚠️ Требуется проверка |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="K"></a>
## K

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 64 | **KAIYI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Kaiyi_logo.png/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Kaiyi_logo.png/600px-Kaiyi_logo.png) | ⚠️ Требуется проверка |
| 65 | **KAMAZ** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Kamaz_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Kamaz_logo.svg/600px-Kamaz_logo.svg.png) | ✅ Найдено |
| 66 | **KIA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Kia_Motors_logo.svg...](https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/Kia_Motors_logo.svg/600px-Kia_Motors_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="L"></a>
## L

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 67 | **LADA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Lada_logo.svg/600px...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Lada_logo.svg/600px-Lada_logo.svg.png) | ✅ Найдено |
| 68 | **LAMBORGHINI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Lamborghini_logo.sv...](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Lamborghini_logo.svg/600px-Lamborghini_logo.svg.png) | ✅ Найдено |
| 69 | **LANCIA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Lancia_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Lancia_logo.svg/600px-Lancia_logo.svg.png) | ✅ Найдено |
| 70 | **LAND ROVER** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Land_Rover_logo.svg...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Land_Rover_logo.svg/600px-Land_Rover_logo.svg.png) | ✅ Найдено |
| 71 | **LDV** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/LDV_logo.svg/600px-...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/LDV_logo.svg/600px-LDV_logo.svg.png) | ⚠️ Требуется проверка |
| 72 | **LEXUS** | [https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Lexus_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Lexus_logo.svg/600px-Lexus_logo.svg.png) | ✅ Найдено |
| 73 | **LI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Li_Auto_logo.svg/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Li_Auto_logo.svg/600px-Li_Auto_logo.svg.png) | ⚠️ Требуется проверка |
| 74 | **LIFAN** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Lifan_Motor_logo.sv...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Lifan_Motor_logo.svg/600px-Lifan_Motor_logo.svg.png) | ⚠️ Требуется проверка |
| 75 | **LINCOLN** | [https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Lincoln_Motor_Compa...](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Lincoln_Motor_Company_logo.svg/600px-Lincoln_Motor_Company_logo.svg.png) | ✅ Найдено |
| 76 | **LIVAN** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Livan_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Livan_logo.svg/600px-Livan_logo.svg.png) | ⚠️ Требуется проверка |
| 77 | **LUXGEN** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Luxgen_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Luxgen_logo.svg/600px-Luxgen_logo.svg.png) | ⚠️ Требуется проверка |
| 78 | **LYNK&CO** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Lynk_%26_Co_logo.sv...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Lynk_%26_Co_logo.svg/600px-Lynk_%26_Co_logo.svg.png) | ⚠️ Требуется проверка |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="M"></a>
## M

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 79 | **MASERATI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Maserati_logo.svg/6...](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Maserati_logo.svg/600px-Maserati_logo.svg.png) | ✅ Найдено |
| 80 | **MAYBACH** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Maybach_logo.svg/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Maybach_logo.svg/600px-Maybach_logo.svg.png) | ⚠️ Требуется проверка |
| 81 | **MAZDA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Mazda_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Mazda_logo.svg/600px-Mazda_logo.svg.png) | ✅ Найдено |
| 82 | **MERCEDES-BENZ** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Mercedes-Benz_Logo_...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Mercedes-Benz_Logo_2010.svg/600px-Mercedes-Benz_Logo_2010.svg.png) | ✅ Найдено |
| 83 | **MERCURY** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Mercury_logo.svg/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Mercury_logo.svg/600px-Mercury_logo.svg.png) | ✅ Найдено |
| 84 | **MG** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/MG_Motor_logo.svg/6...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/MG_Motor_logo.svg/600px-MG_Motor_logo.svg.png) | ✅ Найдено |
| 85 | **MINI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/MINI_logo.svg/600px...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/MINI_logo.svg/600px-MINI_logo.svg.png) | ✅ Найдено |
| 86 | **MITSUBISHI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Mitsubishi_logo.svg...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Mitsubishi_logo.svg/600px-Mitsubishi_logo.svg.png) | ✅ Найдено |
| 87 | **MITSUBISHI (BBDC)** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Mitsubishi_logo.svg...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Mitsubishi_logo.svg/600px-Mitsubishi_logo.svg.png) | ✅ Найдено (Mitsubishi) |
| 88 | **MOSKVICH** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Moskvitch_logo.svg/...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Moskvitch_logo.svg/600px-Moskvitch_logo.svg.png) | ⚠️ Требуется проверка |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="N"></a>
## N

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 89 | **NISSAN** | [https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Nissan_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Nissan_logo.svg/600px-Nissan_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="O"></a>
## O

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 90 | **OLDSMOBILE** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Oldsmobile_logo.svg...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Oldsmobile_logo.svg/600px-Oldsmobile_logo.svg.png) | ✅ Найдено |
| 91 | **OMODA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Omoda_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Omoda_logo.svg/600px-Omoda_logo.svg.png) | ⚠️ Требуется проверка |
| 92 | **OPEL** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Opel_logo.svg/600px...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Opel_logo.svg/600px-Opel_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="P"></a>
## P

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 93 | **PEUGEOT** | [https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Peugeot_logo.svg/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Peugeot_logo.svg/600px-Peugeot_logo.svg.png) | ✅ Найдено |
| 94 | **PLYMOUTH** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Plymouth_automobile...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Plymouth_automobile_logo.svg/600px-Plymouth_automobile_logo.svg.png) | ✅ Найдено |
| 95 | **POLESTAR** | [https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Polestar_logo.svg/6...](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Polestar_logo.svg/600px-Polestar_logo.svg.png) | ✅ Найдено |
| 96 | **PONTIAC** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Pontiac_logo.svg/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Pontiac_logo.svg/600px-Pontiac_logo.svg.png) | ✅ Найдено |
| 97 | **PORSCHE** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Porsche_logo.svg/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Porsche_logo.svg/600px-Porsche_logo.svg.png) | ✅ Найдено |
| 98 | **PROTON** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Proton_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Proton_logo.svg/600px-Proton_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="R"></a>
## R

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 99 | **RAVON** | [https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Ravon_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Ravon_logo.svg/600px-Ravon_logo.svg.png) | ⚠️ Требуется проверка |
| 100 | **RENAULT** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Renault_logo.svg/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Renault_logo.svg/600px-Renault_logo.svg.png) | ✅ Найдено |
| 101 | **RENAULT (DONGFENG)** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Renault_logo.svg/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Renault_logo.svg/600px-Renault_logo.svg.png) | ✅ Найдено (Renault) |
| 102 | **RENAULT TRUCKS** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Renault_Trucks_logo...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Renault_Trucks_logo.svg/600px-Renault_Trucks_logo.svg.png) | ✅ Найдено |
| 103 | **ROLLS-ROYCE** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Rolls-Royce_logo.sv...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Rolls-Royce_logo.svg/600px-Rolls-Royce_logo.svg.png) | ✅ Найдено |
| 104 | **ROVER** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Rover_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Rover_logo.svg/600px-Rover_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="S"></a>
## S

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 105 | **SAAB** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Saab_logo.svg/600px...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Saab_logo.svg/600px-Saab_logo.svg.png) | ✅ Найдено |
| 106 | **SAMSUNG** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Renault_Samsung_Mot...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Renault_Samsung_Motors_logo.svg/600px-Renault_Samsung_Motors_logo.svg.png) | ✅ Найдено |
| 107 | **SATURN** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Saturn_Corporation_...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Saturn_Corporation_logo.svg/600px-Saturn_Corporation_logo.svg.png) | ✅ Найдено |
| 108 | **SCION** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Scion_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Scion_logo.svg/600px-Scion_logo.svg.png) | ✅ Найдено |
| 109 | **SEAT** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/SEAT_logo.svg/600px...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/SEAT_logo.svg/600px-SEAT_logo.svg.png) | ✅ Найдено |
| 110 | **SKODA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Skoda_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Skoda_logo.svg/600px-Skoda_logo.svg.png) | ✅ Найдено |
| 111 | **SKYWELL** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Skywell_logo.png/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Skywell_logo.png/600px-Skywell_logo.png) | ⚠️ Требуется проверка |
| 112 | **SMART** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Smart_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Smart_logo.svg/600px-Smart_logo.svg.png) | ✅ Найдено |
| 113 | **SOLLERS** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Sollers_logo.svg/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Sollers_logo.svg/600px-Sollers_logo.svg.png) | ⚠️ Требуется проверка |
| 114 | **SOUEAST** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Soueast_logo.png/60...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Soueast_logo.png/600px-Soueast_logo.png) | ⚠️ Требуется проверка |
| 115 | **SSANGYONG** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/SsangYong_logo.svg/...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/SsangYong_logo.svg/600px-SsangYong_logo.svg.png) | ✅ Найдено |
| 116 | **SUBARU** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Subaru_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Subaru_logo.svg/600px-Subaru_logo.svg.png) | ✅ Найдено |
| 117 | **SUZUKI** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Suzuki_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Suzuki_logo.svg/600px-Suzuki_logo.svg.png) | ✅ Найдено |
| 118 | **SWM MOTORS** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/SWM_%28automotive%2...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/SWM_%28automotive%29_logo.png/600px-SWM_%28automotive%29_logo.png) | ⚠️ Требуется проверка |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="T"></a>
## T

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 119 | **TAGAZ** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Taganrog_Automotive...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Taganrog_Automotive_Plant_logo.svg/600px-Taganrog_Automotive_Plant_logo.svg.png) | ⚠️ Требуется проверка |
| 120 | **TANK** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Tank_%28marque%29_l...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Tank_%28marque%29_logo.png/600px-Tank_%28marque%29_logo.png) | ⚠️ Требуется проверка |
| 121 | **TATA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Tata_logo.svg/600px...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Tata_logo.svg/600px-Tata_logo.svg.png) | ✅ Найдено |
| 122 | **TESLA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Tesla_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Tesla_logo.svg/600px-Tesla_logo.svg.png) | ✅ Найдено |
| 123 | **TOYOTA** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Toyota_logo.svg/600...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Toyota_logo.svg/600px-Toyota_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="U"></a>
## U

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 124 | **UAZ** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/UAZ_logo.svg/600px-...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/UAZ_logo.svg/600px-UAZ_logo.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="V"></a>
## V

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 125 | **VGV** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/VGV_logo.png/600px-...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/VGV_logo.png/600px-VGV_logo.png) | ⚠️ Требуется проверка |
| 126 | **VOLVO** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Volvo_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Volvo_logo.svg/600px-Volvo_logo.svg.png) | ✅ Найдено |
| 127 | **VOYAH** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Voyah_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Voyah_logo.svg/600px-Voyah_logo.svg.png) | ⚠️ Требуется проверка |
| 128 | **VW** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Volkswagen_logo_201...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Volkswagen_logo_2019.svg/600px-Volkswagen_logo_2019.svg.png) | ✅ Найдено |

[⬆ Наверх](#навигация-по-алфавиту)

---

<a id="Z"></a>
## Z

| № | Марка | Ссылка на логотип | Статус |
|---|-------|-------------------|--------|
| 129 | **ZAZ** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/ZAZ_logo.svg/600px-...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/ZAZ_logo.svg/600px-ZAZ_logo.svg.png) | ✅ Найдено |
| 130 | **ZEEKR** | [https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Zeekr_logo.svg/600p...](https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Zeekr_logo.svg/600px-Zeekr_logo.svg.png) | ⚠️ Требуется проверка |
| 131 | **ZOTYE** | [https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Zotye_Auto_logo.svg...](https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Zotye_Auto_logo.svg/600px-Zotye_Auto_logo.svg.png) | ⚠️ Требуется проверка |

[⬆ Наверх](#навигация-по-алфавиту)

---

## Рекомендации по внедрению

### Быстрый импорт в систему

Для массового импорта логотипов рекомендуется:

1. **Прямая загрузка URL** — используйте ссылки из таблицы выше. Большинство ссылок ведут на Wikimedia Commons и являются общедоступными (лицензия CC BY-SA / Public Domain).

2. **Автоматическая проверка** — 44 логотипа помечены как «Требуется проверка». Для них URL составлены по шаблону Wikimedia Commons, но файлы могут отсутствовать или иметь другое название. Рекомендуется:
   - Открыть каждую ссылку в браузере
   - При ошибке 404 — найти альтернативный файл на [commons.wikimedia.org](https://commons.wikimedia.org)
   - Или использовать встроенный в админку поиск ИИ («Найти ИИ»)

3. **Fallback-стратегия** — если логотип не найден, система автоматически показывает первую букву названия марки (уже реализовано в `LogoImage` компоненте).

### Альтернативные источники логотипов

| Источник | URL | Особенности |
|----------|-----|-------------|
| Wikimedia Commons | https://commons.wikimedia.org/wiki/Category:Logos_of_automobiles | SVG/PNG, свободные лицензии |
| Car Logos | https://www.carlogos.org/ | PNG ~800×800, прозрачный фон |
| World Vector Logo | https://worldvectorlogo.com/ | SVG векторы |
| Brands of the World | https://www.brandsoftheworld.com/ | SVG, требует регистрации |
| Wikipedia EN | https://en.wikipedia.org/wiki/List_of_car_brands | Логотипы в infobox |

### Поиск на сайте

Для удобства пользователей рекомендуется добавить:
- **Автодополнение (autocomplete)** при вводе названия марки
- **Фильтрацию по первой букве** (как в навигации выше)
- **Поиск по подстроке** — например, «мерс» → Mercedes-Benz
- **Lazy loading** логотипов с placeholder (первая буква) на случай медленной загрузки
