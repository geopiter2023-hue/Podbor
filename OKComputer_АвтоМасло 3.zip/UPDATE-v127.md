# Oilpodbor.ru — Обновление до v127

## Что нового в v127

### 1. Реестр номеров (Plate-VIN Registry)
- Таблица `plateVinRegistry` — связка госномер + VIN + модель авто
- API: поиск по номеру, по VIN, CRUD операции
- Статус верификации: проверен / не проверен / в ожидании
- Источник: Nomerogram API или ручной ввод

### 2. Даты проверок агентами
- `carFluidSpecs.lastCheckedAt` — когда агенты проверяли
- `carFluidSpecs.lastFilledAt` — когда данные заполнены
- `carFluidSpecs.checkedBy` — JSON массив имён агентов
- `carFluidSpecs.filledBy` — кто заполнил данные
- `aiAgentResults.checkedAt / filledAt` — даты в таблице агентов

### 3. Исправления агентов
- Anthropic: модель claude-3-haiku-20240307 (рабочая)
- Yandex: maxTokens число вместо строки
- Groq: llama-3.1-8b-instant (актуальная модель)
- Gemini: fallback на 4 модели + retry при rate limit

---

## Шаги обновления на сервере

### Шаг 1: Создай бэкап
```bash
# Зайди на сервер по SSH
ssh user@oilpodbor.ru

# Бэкап базы
mysqldump -u root -p oilpodbor > /root/backup_v126.sql

# Бэкап текущего приложения
cd /var/www
cp -r oilpodbor oilpodbor_backup_v126
```

### Шаг 2: Примени SQL миграцию
```bash
mysql -u root -p oilpodbor < /var/www/oilpodbor/api/migrations/v127-platevin-and-dates.sql
```

Если таблица `users` старая (ошибка входа), также выполни:
```bash
mysql -u root -p oilpodbor < /var/www/oilpodbor/api/migrations/fix-users.sql
```

### Шаг 3: Загрузи новый код
```bash
cd /var/www/oilpodbor

# Останови текущий сервер
pm2 stop oilpodbor

# Удали старый dist
rm -rf dist node_modules

# Распакуй новый архив
unzip -o /path/to/app-v127.zip -d /tmp/
cp -r /tmp/app/* /var/www/oilpodbor/

# Установи зависимости
npm install

# Собери
npm run build
```

### Шаг 4: Запусти
```bash
pm2 start ecosystem.config.cjs --env production
# или
pm2 restart oilpodbor

# Проверь статус
pm2 logs oilpodbor --lines 20
```

### Шаг 5: Проверь
- Главная страница: https://oilpodbor.ru
- Вход в админку: https://oilpodbor.ru/#/login
- Пользователь: `admin` / `admin123`
- Реестр номеров: Админ → Данные → Реестр номеров

---

## Файлы миграций
| Файл | Назначение |
|------|------------|
| `api/migrations/v127-platevin-and-dates.sql` | Новые таблицы + даты |
| `api/migrations/fix-users.sql` | Фикс таблицы users (если вход не работает) |
