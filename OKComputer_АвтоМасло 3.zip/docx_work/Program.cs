using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

string outputFile = args.Length > 0 ? args[0] : "/mnt/agents/output/oilpodbor_system_description.docx";
if (File.Exists(outputFile)) File.Delete(outputFile);

using var doc = WordprocessingDocument.Create(outputFile, WordprocessingDocumentType.Document);
var mainPart = doc.AddMainDocumentPart();
mainPart.Document = new Document(new Body());
var body = mainPart.Document.Body!;

// Add document defaults for Cyrillic
var stylePart = mainPart.AddNewPart<StyleDefinitionsPart>();
stylePart.Styles = new Styles(
    new DocDefaults(
        new RunPropertiesDefault(
            new RunPropertiesBaseStyle(
                new RunFonts { Ascii = "Times New Roman", HighAnsi = "Times New Roman", EastAsia = "Times New Roman", ComplexScript = "Times New Roman" },
                new FontSize { Val = "24" },
                new FontSizeComplexScript { Val = "24" },
                new Languages { Val = "ru-RU", EastAsia = "ru-RU", Bidi = "ru-RU" }
            )
        ),
        new ParagraphPropertiesDefault(
            new ParagraphPropertiesBaseStyle(
                new SpacingBetweenLines { After = "160", Line = "360", LineRule = LineSpacingRuleValues.Auto }
            )
        )
    )
);

string primary = "1B5E20";
string secondary = "2E7D32";
string accent = "43A047";
string dark = "212121";
string gray = "616161";
string lightGray = "F5F5F5";

RunFonts CyrillicFont() => new RunFonts { Ascii = "Times New Roman", HighAnsi = "Times New Roman", EastAsia = "Times New Roman", ComplexScript = "Times New Roman" };
Languages RuLang() => new Languages { Val = "ru-RU", EastAsia = "ru-RU", Bidi = "ru-RU" };

var RP = (string color, string size, bool bold) => new RunProperties(
    new Color { Val = color }, new FontSize { Val = size }, new Bold { Val = new OnOffValue(bold) },
    CyrillicFont(), RuLang()
);

var PP = (string before, string after, string align) => new ParagraphProperties(
    new SpacingBetweenLines { Before = before, After = after },
    new Justification { Val = align switch { "center" => JustificationValues.Center, "right" => JustificationValues.Right, _ => JustificationValues.Both } }
);

void H1(string text) => body.Append(new Paragraph(
    new ParagraphProperties(new SpacingBetweenLines { Before = "400", After = "200" },
    new ParagraphBorders(new BottomBorder { Val = BorderValues.Single, Size = 12, Color = primary }), new KeepNext()),
    new Run(RP(primary, "36", true), new Text(text))
));

void H2(string text) => body.Append(new Paragraph(
    new ParagraphProperties(new SpacingBetweenLines { Before = "300", After = "120" }, new KeepNext()),
    new Run(RP(secondary, "28", true), new Text(text))
));

void H3(string text) => body.Append(new Paragraph(
    new ParagraphProperties(new SpacingBetweenLines { Before = "200", After = "80" }, new KeepNext()),
    new Run(RP(accent, "24", true), new Text(text))
));

void P(string text) => body.Append(new Paragraph(PP("120", "80", "both"), new Run(RP(dark, "22", false), new Text(text))));
void B(string text) => body.Append(new Paragraph(new ParagraphProperties(new SpacingBetweenLines { Before = "40", After = "40" }, new Indentation { Left = "720" }), new Run(RP(dark, "22", false), new Text("\u2022 " + text))));

void CODE(string text) => body.Append(new Paragraph(
    new ParagraphProperties(new SpacingBetweenLines { Before = "40", After = "40" }, new Shading { Val = ShadingPatternValues.Clear, Fill = lightGray }, new Indentation { Left = "360", Right = "360" }),
    new Run(new RunProperties(new FontSize { Val = "18" }, new RunFonts { Ascii = "Consolas", HighAnsi = "Consolas" }, new Color { Val = "37474F" }), new Text(text))
));

void T(string[] headers, string[][] rows) {
    var table = new Table();
    table.Append(new TableProperties(
        new TableBorders(new TopBorder { Val = BorderValues.Single, Size = 8, Color = primary },
            new BottomBorder { Val = BorderValues.Single, Size = 8, Color = primary },
            new InsideHorizontalBorder { Val = BorderValues.Single, Size = 4, Color = "BDBDBD" },
            new InsideVerticalBorder { Val = BorderValues.Single, Size = 4, Color = "BDBDBD" }),
        new TableWidth { Width = "5000", Type = TableWidthUnitValues.Pct }
    ));
    var grid = new TableGrid();
    foreach (var _ in headers) grid.Append(new GridColumn());
    table.Append(grid);
    var hr = new TableRow();
    foreach (var h in headers) hr.Append(new TableCell(new TableCellProperties(new Shading { Val = ShadingPatternValues.Clear, Fill = primary }), new Paragraph(PP("60", "60", "center"), new Run(RP("FFFFFF", "20", true), new Text(h)))));
    table.Append(hr);
    foreach (var row in rows) {
        var dr = new TableRow();
        for (int i = 0; i < row.Length; i++)
            dr.Append(new TableCell(new TableCellProperties(i % 2 == 0 ? null : new Shading { Val = ShadingPatternValues.Clear, Fill = "FAFAFA" }), new Paragraph(PP("40", "40", "left"), new Run(RP(dark, "20", false), new Text(row[i])))));
        table.Append(dr);
    }
    body.Append(table);
    body.Append(new Paragraph(PP("60", "60", "both")));
}

// COVER
body.Append(new Paragraph(new ParagraphProperties(new SpacingBetweenLines { Before = "2000" }), new Run(new RunProperties(new FontSize { Val = "72" }, new Bold(), new Color { Val = primary }, CyrillicFont()), new Text("OILPODBOR"))));
body.Append(new Paragraph(new ParagraphProperties(new SpacingBetweenLines { Before = "400", After = "600" }), new Run(new RunProperties(new FontSize { Val = "48" }, new Color { Val = secondary }, CyrillicFont()), new Text("oilpodbor.ru"))));
body.Append(new Paragraph(new ParagraphProperties(new ParagraphBorders(new BottomBorder { Val = BorderValues.Single, Size = 18, Color = primary })), new Run(new RunProperties(new FontSize { Val = "32" }, new Color { Val = dark }, CyrillicFont()), new Text("Техническая документация системы"))));
body.Append(new Paragraph(new ParagraphProperties(new SpacingBetweenLines { Before = "600" }), new Run(new RunProperties(new FontSize { Val = "28" }, new Bold(), new Color { Val = dark }, CyrillicFont()), new Text("Описание системы подбора масел и технических жидкостей по автомобилю"))));
body.Append(new Paragraph(new ParagraphProperties(new SpacingBetweenLines { Before = "1200" }), new Run(new RunProperties(new FontSize { Val = "24" }, new Color { Val = gray }, CyrillicFont()), new Text("Версия: v90 (актуальная)"))));
body.Append(new Paragraph(new Run(new RunProperties(new FontSize { Val = "24" }, new Color { Val = gray }, CyrillicFont()), new Text("Дата создания: 31.05.2026"))));
body.Append(new Paragraph(new ParagraphProperties(new SpacingBetweenLines { Before = "2400" }), new Run(new RunProperties(new FontSize { Val = "22" }, new Color { Val = gray }, CyrillicFont()), new Text("Системный архитектор: Максим (AI-ассистент)"))));
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// TOC
H1("СОДЕРЖАНИЕ");
string[] toc = { "1. Введение и назначение системы", "2. Архитектура и технический стек", "3. База данных: структура и связи", "4. Публичный виджет подбора масел", "5. Административная панель (CRM)", "6. ИИ-агенты: 8 провайдеров", "7. Расширенный редактор автомобилей", "8. Маркетплейс продуктов", "9. Импорт и экспорт данных", "10. API и интеграции", "11. Примеры использования", "12. Развертывание и администрирование" };
foreach (var item in toc) body.Append(new Paragraph(new ParagraphProperties(new SpacingBetweenLines { Before = "100", After = "60" }), new Run(RP(dark, "24", false), new Text(item))));
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 1. INTRO
H1("1. ВВЕДЕНИЕ И НАЗНАЧЕНИЕ СИСТЕМЫ");
P("Система OILPODBOR (oilpodbor.ru) представляет собой профессиональную платформу для подбора моторных масел и технических жидкостей по автомобилю. Аналог: rolfoil.ru.");
H2("1.1. Основные функции");
B("Подбор масла по марке, модели, поколению автомобиля"); B("Подбор по госномеру или VIN (через nomerogram API)"); B("Автоматическое заполнение технических характеристик 8 ИИ-агентами"); B("Маркетплейс с ассортиментом продуктов ЛУКОЙЛ (855 позиций)"); B("Админ-панель с полным управлением данными"); B("Импорт/экспорт Excel с автоувеличением качества данных"); B("Виджет для установки на любой сайт");
H2("1.2. Целевая аудитория");
B("Автосервисы и технические центры"); B("Интернет-магазины автозапчастей и масел"); B("Конечные пользователи (владельцы автомобилей)");
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 2. ARCHITECTURE
H1("2. АРХИТЕКТУРА И ТЕХНИЧЕСКИЙ СТЕК");
H2("2.1. Full-stack архитектура");
T(new[] { "Компонент", "Технология", "Описание" }, new[] { new[] { "Frontend", "React 19 + TypeScript", "Современный UI с shadcn/ui компонентами" }, new[] { "Styling", "Tailwind CSS", "Утилитарный CSS-фреймворк" }, new[] { "Маршрутизация", "HashRouter", "Для статического хостинга" }, new[] { "API", "tRPC + Hono", "Типизированный API с процедурным подходом" }, new[] { "ORM", "Drizzle ORM", "Безопасный типизированный доступ к БД" }, new[] { "Сервер", "Hono.js", "Быстрый минималистичный бэкенд" }, new[] { "База данных", "MySQL 8.0", "Локальная или облачная БД" }, new[] { "Авторизация", "JWT + localStorage", "Вход по логину и паролю" }, new[] { "PWA", "Service Worker", "Установка на домашний экран" } });
H2("2.2. Схема взаимодействия");
CODE("[Пользователь] --> [React Frontend] --> [tRPC/Hono API] --> [MySQL БД]");
CODE("                                     --> [ИИ-агенты] --> [8 API провайдеров]");
CODE("                                     --> [Nomerogram API] --> [БД ГАИ]");
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 3. DATABASE
H1("3. БАЗА ДАННЫХ: СТРУКТУРА И СВЯЗИ");
H2("3.1. Основные таблицы");
T(new[] { "Таблица", "Записей", "Описание" }, new[] { new[] { "brands", "131", "Марки автомобилей (BMW, Audi, Toyota...)" }, new[] { "models", "5 459", "Модели с фото и годами выпуска" }, new[] { "modifications", "23 768", "Модификации с двигателями" }, new[] { "cars", "23 768", "Агрегированный каталог автомобилей" }, new[] { "carFluidSpecs", "~300", "Заполненные ИИ-технические данные" }, new[] { "oils", "27 630", "Каталог масел и жидкостей" }, new[] { "products", "855", "Товары маркетплейса (ЛУКОЙЛ)" }, new[] { "aiLogs", "~500", "Логи ИИ-запросов для дебага" }, new[] { "systemSettings", "30+", "Настройки системы и API-ключи" } });
H2("3.2. Структура carFluidSpecs (57 полей)");
P("Таблица хранит все технические данные по каждому автомобилю, заполняемые ИИ-агентами:");
T(new[] { "Группа", "Поле", "Описание", "Пример" }, new[] { new[] { "Двигатель", "prefOilSae", "Вязкость масла SAE", "5W-30" }, new[] { "Двигатель", "prefOilApi", "Стандарт API", "SN Plus" }, new[] { "Двигатель", "prefOilAcea", "Стандарт ACEA", "C3" }, new[] { "Двигатель", "prefOilOe", "OEM-допуск", "VW 502.00" }, new[] { "Двигатель", "altOilViscosities", "Альтернативные вязкости", "0W-30, 5W-40" }, new[] { "Двигатель", "engineOilVolume", "Объем масла, л", "4.5" }, new[] { "КПП", "transmissionType", "Тип коробки передач", "AT, MT, CVT" }, new[] { "КПП", "transmissionPrefOil", "Рекомендуемое масло КПП", "ATF WS" }, new[] { "Охлаждение", "coolantType", "Тип антифриза", "G12+" }, new[] { "Тормоза", "brakeFluidType", "Тип тормозной жидкости", "DOT 4" }, new[] { "Фильтры", "oilFilter", "Артикул масляного фильтра", "OC 1056" }, new[] { "Фильтры", "airFilter", "Артикул воздушного фильтра", "C 30 005" }, new[] { "Фильтры", "cabinFilter", "Артикул салонного фильтра", "CU 22 000" }, new[] { "Дифференциалы", "frontDiffOil", "Масло переднего дифференциала", "75W-90" }, new[] { "Дифференциалы", "rearDiffOil", "Масло заднего дифференциала", "75W-140" } });
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 4. PUBLIC WIDGET
H1("4. ПУБЛИЧНЫЙ ВИДЖЕТ ПОДБОРА МАСЕЛ");
H2("4.1. Клиентский путь (3 сценария)");
H3("Сценарий 1: Подбор по автомобилю");
P("Пользователь последовательно выбирает:");
B("Марка (131 вариант: BMW, Audi, LADA...)"); B("Модель (5 459 моделей с фото)"); B("Поколение (модификация с кодом двигателя)"); B("Результат: карточка с рекомендациями");
H3("Сценарий 2: Подбор по госномеру");
CODE("Ввод: А000АА 777 --> [Nomerogram API] --> Марка/Модель/Год");
P("Алгоритм: госномер --> API nomerogram --> данные ГАИ --> локальный поиск в БД");
H3("Сценарий 3: Подбор по VIN");
CODE("Ввод: XTA21090000000000 --> [Nomerogram API] --> Полные данные");
P("VIN дает точную идентификацию: марка, модель, двигатель, год, комплектация.");
H2("4.2. Карточка результата");
P("После выбора автомобиля отображается:");
B("Основные параметры: марка, модель, год, двигатель"); B("Рекомендации по маслу: SAE, API, ACEA, OEM-допуск"); B("Другие жидкости: КПП, антифриз, тормозная жидкость"); B("Фильтры: масляный, воздушный, салонный"); B("Кнопка 'Перейти к товарам' --> маркетплейс");
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 5. ADMIN
H1("5. АДМИНИСТРАТИВНАЯ ПАНЕЛЬ (CRM)");
H2("5.1. Структура меню");
T(new[] { "Раздел", "Описание", "Доступ" }, new[] { new[] { "Главная", "Статистика, быстрые действия", "Админ" }, new[] { "ИИ-агенты", "Управление агентами, запуск, прогресс", "Админ" }, new[] { "Автомобили", "Список 23 768 авто с фильтрами", "Админ" }, new[] { "Маркетплейс", "Управление товарами (855 ЛУКОЙЛ)", "Админ" }, new[] { "Справочники", "Категории, агрегаты, типы", "Админ" }, new[] { "Настройки", "API-ключи, цвет, featured makes", "Админ" }, new[] { "Жидкости", "Список 27 630 масел/жидкостей", "Админ" } });
H2("5.2. Панель ИИ-агентов");
P("Центральный раздел для массового заполнения данных:");
B("Выбор годов выпуска: 7 диапазонов (1990-2025)"); B("Multi-select марок: 131 марка с чекбоксами"); B("Multi-select моделей: все модели выбранной марки"); B("Живой прогресс: сколько готово/в работе/ошибок"); B("Таблица результатов: SAE, API, КПП, Фильтры, Токены");
H2("5.3. Настройки и API-ключи");
T(new[] { "Ключ", "Провайдер", "Статус" }, new[] { new[] { "anthropic_api_key", "Anthropic Claude", "Основной ИИ" }, new[] { "openai_api_key", "OpenAI GPT-3.5", "Резервный" }, new[] { "perplexity_api_key", "Perplexity Sonar", "$50 кредитов" }, new[] { "groq_api_key", "Groq Llama", "Бесплатный" }, new[] { "deepseek_api_key", "DeepSeek", "Дешевый" }, new[] { "gemini_api_key", "Google Gemini", "Бесплатный" }, new[] { "mistral_api_key", "Mistral AI", "Европейский" }, new[] { "cohere_api_key", "Cohere", "Резерв" }, new[] { "nomerogram_token", "Nomerogram", "Поиск по номеру/VIN" } });
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 6. AI AGENTS
H1("6. ИИ-АГЕНТЫ: 8 ПРОВАЙДЕРОВ");
H2("6.1. Архитектура ИИ-двигателя");
P("Система использует гибкий подход: запускается один агент, но внутри него проходит цепочка fallback из 8 провайдеров. Если первый не ответил --> переходим ко второму и т.д.");
H2("6.2. Цепочка приоритетов");
T(new[] { "#", "Провайдер", "Модель", "Цена", "Приоритет" }, new[] { new[] { "1", "Perplexity", "sonar", "$0.003/запрос", "Высокий (с интернетом)" }, new[] { "2", "Anthropic Claude", "claude-3-haiku", "$0.25/1000", "Основной" }, new[] { "3", "Groq", "llama3-8b", "Бесплатно", "Быстрый" }, new[] { "4", "DeepSeek", "deepseek-chat", "Дешево", "Китайский" }, new[] { "5", "Google Gemini", "gemini-1.5-flash", "Бесплатно", "Google" }, new[] { "6", "OpenAI", "gpt-3.5-turbo", "$0.50/1000", "Резерв" }, new[] { "7", "Mistral AI", "mistral-tiny", "Европа", "Резерв" }, new[] { "8", "Cohere", "command-r", "Резерв", "Резерв" } });
H2("6.3. Промпт для агента");
CODE("Задача: Найти технические данные для {make} {model} {двигатель}");
CODE("Формат ответа: JSON с полями:");
CODE("  engine: { oilVolume, oilSae, oilApi, oilAcea, oilOem }");
CODE("  transmission: { type, code, oilVolume, oilSpec }");
CODE("  cooling: { coolantVolume, coolantType }");
CODE("  brakes: { fluidVolume, fluidType }");
CODE("  differentials: { front: {volume, oil}, rear: {volume, oil} }");
CODE("  filters: { oil, air, cabin, fuel }");
H2("6.4. Процесс обработки");
P("При массовом запуске на 101 авто (например, HYUNDAI):");
B("1. Система создает очередь из 101 авто"); B("2. Каждое авто отправляется в ИИ с промптом"); B("3. Ответ парсится из JSON в поле БД"); B("4. Прогресс обновляется в реальном времени"); B("5. При падении агента --> автопереход к следующему провайдеру");
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 7. EDITOR
H1("7. РАСШИРЕННЫЙ РЕДАКТОР АВТОМОБИЛЕЙ");
H2("7.1. Редактирование отдельного авто");
P("При клике на автомобиль в списке открывается форма с 57 полями, сгруппированными по разделам:");
T(new[] { "Раздел", "Количество полей", "Примеры" }, new[] { new[] { "Основные данные", "4", "Марка, Модель, Год, Активность" }, new[] { "Двигатель и масло", "7", "SAE, API, ACEA, OEM, Вязкости, Объем" }, new[] { "Коробка передач", "5", "Тип КПП, Масло, Объем, Трансфер" }, new[] { "Охлаждение", "4", "Тип антифриза, Объем, Интервал замены" }, new[] { "Тормозная система", "3", "Тип жидкости, Объем" }, new[] { "ГУР и другие", "4", "Масло ГУР, Объем" }, new[] { "Фильтры", "6", "Масляный, воздушный, салонный, топливный" }, new[] { "Дифференциалы", "6", "Передний/задний: масло, объем" }, new[] { "Технические данные", "12", "VIN-коды, производитель, страна" } });
H2("7.2. Batch-заполнение ИИ");
P("Возможность запустить ИИ на группу автомобилей с настройками:");
B("Выбор марки/моделей/годов"); B("Задержка между запросами: 1-5 секунд"); B("Автоматическое продолжение при ошибках"); B("Живой прогресс: сколько авто обработано");
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 8. MARKETPLACE
H1("8. МАРКЕТПЛЕЙС ПРОДУКТОВ");
H2("8.1. Ассортимент");
P("В систему загружено 855 товаров ЛУКОЙЛ из Excel-файла 'Загрузка Финал для B2B.xlsx':");
T(new[] { "Категория", "Количество", "Примеры" }, new[] { new[] { "Моторные масла", "350+", "ЛУКОЙЛ GENESIS, ЛУКОЙЛ LUXE" }, new[] { "Трансмиссионные масла", "200+", "ЛУКОЙЛ ATF, ЛУКОЙЛ GEAR" }, new[] { "Гидравлические масла", "80+", "ЛУКОЙЛ ГЕЙЗЕР" }, new[] { "Пластичные смазки", "120+", "ЛУКОЙЛ ПОЛИФЛЕКС, ЛУКОЙЛ Литол" }, new[] { "Спец. назначения", "100+", "Промывочные, затирки" } });
H2("8.2. Карточка товара (Ozon-style)");
P("Каждый товар отображается с:");
B("Фото продукта (placeholder)"); B("Цена в RUB (из поля price)"); B("Бейджи: 'В наличии', 'B2C/B2B'"); B("Характеристики: SAE, API, ACEA, объем фасовки"); B("Доставка: 'Завтра'");
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 9. IMPORT/EXPORT
H1("9. ИМПОРТ И ЭКСПОРТ ДАННЫХ");
H2("9.1. Импорт из Excel");
P("Поддерживается загрузка данных из Excel-файлов:");
B("Загрузка автомобилей: марка, модель, год, двигатель"); B("Загрузка масел: название, SAE, API, ACEA, цена"); B("Загрузка товаров: полный ассортимент с характеристиками");
H2("9.2. Экспорт в Excel");
P("Возможность выгрузить все заполненные данные:");
B("Выгрузка всех 57 полей carFluidSpecs"); B("Фильтр по статусу заполнения"); B("Формат совместимый с входным импортом");
H2("9.3. Импорт 855 товаров ЛУКОЙЛ");
P("Скрипт обрабатывает Excel и создает SQL-INSERTы:");
CODE("python scripts/import_products.py 'Загрузка Финал для B2B.xlsx'");
CODE("# Или напрямую в MySQL:");
CODE("mysql -u root -p oilpodbor < import_lukoil_products.sql");
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 10. API
H1("10. API И ИНТЕГРАЦИИ");
H2("10.1. Типы запросов (tRPC)");
T(new[] { "Router", "Метод", "Описание" }, new[] { new[] { "car", "brands", "Список 131 марки" }, new[] { "car", "models", "Модели по makeId" }, new[] { "car", "modifications", "Модификации по модели" }, new[] { "oil", "search", "Поиск масел по параметрам" }, new[] { "agents", "missingData", "Авто без заполненных данных" }, new[] { "agents", "run", "Запуск ИИ-агента" }, new[] { "products", "list", "Список товаров маркетплейса" }, new[] { "plateSearch", "search", "Поиск по госномеру/VIN" }, new[] { "settings", "publicList", "Публичные настройки" } });
H2("10.2. Внешние интеграции");
T(new[] { "Сервис", "Тип", "Описание" }, new[] { new[] { "Nomerogram", "API", "Поиск по госномеру и VIN" }, new[] { "Anthropic Claude", "ИИ", "Основной ИИ-провайдер" }, new[] { "Perplexity", "ИИ", "ИИ с доступом к интернету" }, new[] { "OpenAI", "ИИ", "Резервный GPT-провайдер" }, new[] { "Groq/Gemini", "ИИ", "Бесплатные провайдеры" } });
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 11. EXAMPLES
H1("11. ПРИМЕРЫ ИСПОЛЬЗОВАНИЯ");
H2("Пример 1: Подбор масла для Audi A6");
P("Сценарий: пользователь выбрал Audi --> A6 --> III sedan (4F2)");
CODE("ИИ-ответ:");
CODE("  oilSae: '5W-30'");
CODE("  oilApi: 'SN'");
CODE("  oilAcea: 'C3'");
CODE("  oilOem: 'VW 502.00 / 505.00'");
CODE("  oilVolume: '4.6 л'");
CODE("  transmission: 'ATF - ЛУКОЙЛ ATF SYNTH VI'");
P("Результат в маркетплейсе: Audi A6 --> Рекомендуемые товары --> ЛУКОЙЛ GENESIS 5W-30");
H2("Пример 2: Массовое заполнение (101 HYUNDAI)");
P("Сценарий: админ выбрал все модели HYUNDAI (101 шт.) и запустил ИИ:");
B("1. Выбрана марка: HYUNDAI (101 модель)"); B("2. Запущена обработка с задержкой 2 секунды"); B("3. Первая партия: 10 авто обработано за 20 секунд"); B("4. Offset увеличен, следующая партия загружается"); B("5. Все 101 авто обработаны за ~15 минут"); B("6. Проверка в 'Проверка данных ИИ' --> все поля заполнены");
H2("Пример 3: Поиск по госномеру");
CODE("Ввод: О007ОО 77");
CODE("Ответ: LADA Vesta, 2021, 1.6L, 106 лс");
CODE("Рекомендация: ЛУКОЙЛ LUXE 5W-40, API SN/CF");
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));

// 12. DEPLOYMENT
H1("12. РАЗВЕРТЫВАНИЕ И АДМИНИСТРИРОВАНИЕ");
H2("12.1. Требования к серверу");
T(new[] { "Компонент", "Минимальные", "Рекомендуемые" }, new[] { new[] { "OS", "Ubuntu 20.04+", "Ubuntu 22.04 LTS" }, new[] { "Node.js", "18+", "20 LTS" }, new[] { "MySQL", "8.0", "8.0+" }, new[] { "RAM", "2 GB", "4 GB" }, new[] { "Диск", "10 GB", "50 GB SSD" }, new[] { "PM2", "Необходим", "Для процесс менеджмента" } });
H2("12.2. Процесс развертывания");
CODE("# 1. Остановка сервиса");
CODE("pm2 stop oilpodbor");
CODE("# 2. Распаковка новой версии");
CODE("unzip -o oilpodbor-v90.zip -d /var/www/oilpodbor");
CODE("# 3. Установка зависимостей");
CODE("cd /var/www/oilpodbor && npm install");
CODE("# 4. Сборка проекта");
CODE("npm run build");
CODE("# 5. Запуск сервиса");
CODE("pm2 start oilpodbor");
CODE("# 6. Импорт товаров (если нужно)");
CODE("mysql -u root -p oilpodbor < import_lukoil_products.sql");
H2("12.3. Переменные окружения (.env)");
CODE("DATABASE_URL=mysql://user:pass@localhost:3306/oilpodbor");
CODE("JWT_SECRET=ваш-секретный-ключ-jwt");
CODE("ADMIN_EMAIL=admin@oilpodbor.ru");
CODE("ADMIN_PASSWORD_HASH=$2a$10$...");
CODE("PORT=3000");

// CONCLUSION
body.Append(new Paragraph(new Run(new Break { Type = BreakValues.Page })));
H1("ЗАКЛЮЧЕНИЕ");
P("Система OILPODBOR представляет собой полноценное решение для подбора технических жидкостей по автомобилю. Ключевые достижения версии v90:");
B("23 768 автомобилей в каталоге с 131 маркой");
B("8 ИИ-провайдеров с гибкой цепочкой fallback");
B("57 полей технических характеристик на каждый авто");
B("855 товаров ЛУКОЙЛ в маркетплейсе");
B("Поддержка поиска по госномеру и VIN");
B("Полноценный импорт/экспорт Excel");
B("Админ-панель с реальным временем прогресса");
P("Система готова к промышленной эксплуатации и дальнейшему масштабированию.");

var sectionProps = new SectionProperties(
    new PageSize { Width = 11906, Height = 16838 },
    new PageMargin { Top = 1440, Right = 1440, Bottom = 1440, Left = 1440, Header = 720, Footer = 720 }
);
body.Append(sectionProps);
doc.Save();
Console.WriteLine($"Document saved: {outputFile}");
