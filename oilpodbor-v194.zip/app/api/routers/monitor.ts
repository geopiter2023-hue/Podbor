import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { systemSettings } from "@db/schema";
import { eq } from "drizzle-orm";
import { logger } from "../lib/logger";

let lastHealthCheck: { ok: boolean; time: Date; error?: string } = { ok: true, time: new Date() };

// Get setting from DB
async function getSetting(key: string): Promise<string | undefined> {
  try {
    const db = getDb();
    const rows = await db.select({ value: systemSettings.value }).from(systemSettings).where(eq(systemSettings.key, key)).limit(1);
    return rows[0]?.value || undefined;
  } catch {
    return undefined;
  }
}

// Send Telegram alert
async function sendTelegramAlert(message: string) {
  const botToken = await getSetting("telegram_bot_token");
  const chatId = await getSetting("telegram_chat_id");
  if (!botToken || !chatId) {
    logger.warn("[Telegram] Bot token or chat ID not configured. Set in Admin -> Settings.");
    return;
  }

  try {
    const resp = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "HTML",
      }),
      signal: AbortSignal.timeout(10000),
    });
    if (!resp.ok) {
      logger.error(`[Telegram] API error: ${resp.status}`);
    }
  } catch (e: any) {
    logger.error(`[Telegram] Failed to send: ${e.message}`);
  }
}

export const monitorRouter = createRouter({
  // Health check endpoint
  health: publicQuery
    .query(async () => {
      const checks: Record<string, { ok: boolean; error?: string }> = {};
      let allOk = true;

      // Check DB
      try {
        const { getDbStatus } = await import("../queries/connection");
        const status = getDbStatus();
        checks.db = { ok: status.connected };
        if (!status.connected) allOk = false;
      } catch (e: any) {
        checks.db = { ok: false, error: e.message };
        allOk = false;
      }

      const result = { ok: allOk, checks, time: new Date().toISOString() };

      // Send alert if state changed from OK to ERROR
      if (!allOk && lastHealthCheck.ok) {
        await sendTelegramAlert(
          `🚨 <b>OILPODBOR ALERT</b>\n\n` +
          `❌ Сервер недоступен!\n` +
          `Время: ${new Date().toLocaleString("ru-RU")}\n` +
          `DB: ${checks.db.ok ? "✅" : "❌"} ${checks.db.error || ""}\n\n` +
          `Проверьте: pm2 status`
        );
      }

      // Send recovery alert
      if (allOk && !lastHealthCheck.ok) {
        await sendTelegramAlert(
          `✅ <b>OILPODBOR RECOVERED</b>\n\n` +
          `Сервер снова работает!\n` +
          `Время: ${new Date().toLocaleString("ru-RU")}`
        );
      }

      lastHealthCheck = { ok: allOk, time: new Date(), error: allOk ? undefined : "Some checks failed" };
      return result;
    }),

  // Manual test alert
  testAlert: publicQuery
    .input(z.object({ message: z.string().optional() }))
    .mutation(async ({ input }) => {
      const msg = input.message || "Test alert from OILPODBOR";
      await sendTelegramAlert(`🧪 <b>Test Alert</b>\n\n${msg}\n\nTime: ${new Date().toLocaleString("ru-RU")}`);
      return { sent: true };
    }),

  // Get Telegram bot info
  botInfo: publicQuery
    .query(async () => {
      const botToken = await getSetting("telegram_bot_token");
      if (!botToken) return { configured: false };
      try {
        const resp = await fetch(`https://api.telegram.org/bot${botToken}/getMe`, {
          signal: AbortSignal.timeout(10000),
        });
        const data = await resp.json();
        return {
          configured: true,
          botName: data.result?.username || "unknown",
          botId: data.result?.id,
        };
      } catch {
        return { configured: false, error: "Invalid token" };
      }
    }),
});
