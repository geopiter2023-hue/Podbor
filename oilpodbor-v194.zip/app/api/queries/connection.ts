import { drizzle } from "drizzle-orm/mysql2";
import * as schema from "@db/schema";
import * as relations from "@db/relations";

const fullSchema = { ...schema, ...relations };

let instance: ReturnType<typeof drizzle<typeof fullSchema>> | null = null;
let dbError: string | null = null;

function getDatabaseUrl(): string {
  return process.env.DATABASE_URL || "";
}

export function getDb() {
  if (!instance) {
    const dbUrl = getDatabaseUrl();
    if (!dbUrl) {
      throw new Error("DATABASE_URL not set — check .env file");
    }
    try {
      instance = drizzle(dbUrl, {
        mode: "default",
        schema: fullSchema,
      });
      console.log("[DB] Connected successfully");
    } catch (e: any) {
      dbError = e.message;
      console.error("[DB] Failed to connect:", e.message);
      throw new Error("DB connection failed: " + e.message);
    }
  }
  return instance;
}

export function getDbStatus() {
  return { connected: !!instance, error: dbError };
}
