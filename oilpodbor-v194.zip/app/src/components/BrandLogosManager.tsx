import { useState, useRef, useMemo } from "react";
import { trpc } from "@/providers/trpc";
import {
  Image, RefreshCw, Trash2, Search, Zap, Upload, ExternalLink,
  CheckCircle2, XCircle, AlertTriangle, Filter, Eye, EyeOff,
  ChevronDown, Check, X
} from "lucide-react";

type FilterTab = "all" | "with" | "without";
type ConfirmAction = "clear" | "clearAll" | "aiAll" | "aiSingle" | null;

export default function BrandLogosManager() {
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [aiRunning, setAiRunning] = useState(false);
  const [filterTab, setFilterTab] = useState<FilterTab>("all");
  const [letterFilter, setLetterFilter] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<Record<string, string>>({});
  const [confirmAction, setConfirmAction] = useState<ConfirmAction>(null);
  const [confirmBrand, setConfirmBrand] = useState<string | null>(null);
  const [savedKeys, setSavedKeys] = useState<Set<string>>(new Set());
  const [showPreview, setShowPreview] = useState<Record<string, boolean>>({});

  const fileInputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  const { data: brands, isLoading } = trpc.brandLogos.adminList.useQuery();
  const { data: stats } = trpc.brandLogos.stats.useQuery();

  const runAI = trpc.brandLogos.runAI.useMutation({
    onSuccess: () => {
      utils.brandLogos.adminList.invalidate();
      utils.brandLogos.stats.invalidate();
      setAiRunning(false);
    },
    onError: () => setAiRunning(false),
  });

  const saveLogo = trpc.brandLogos.save.useMutation({
    onSuccess: (_, vars) => {
      utils.brandLogos.adminList.invalidate();
      utils.brandLogos.stats.invalidate();
      setSavedKeys((prev) => new Set(prev).add(vars.brandName));
      setTimeout(() => setSavedKeys((prev) => {
        const n = new Set(prev);
        n.delete(vars.brandName);
        return n;
      }), 2000);
    },
  });

  const clearLogo = trpc.brandLogos.clear.useMutation({
    onSuccess: () => {
      utils.brandLogos.adminList.invalidate();
      utils.brandLogos.stats.invalidate();
      setConfirmAction(null);
      setConfirmBrand(null);
    },
  });

  const uploadLogo = trpc.brandLogos.upload.useMutation({
    onSuccess: () => {
      utils.brandLogos.adminList.invalidate();
      utils.brandLogos.stats.invalidate();
    },
  });

  // Get unique first letters
  const alphabet = useMemo(() => {
    if (!brands) return [];
    const letters = new Set<string>();
    brands.forEach((b) => {
      if (b.brandName) letters.add(b.brandName[0].toUpperCase());
    });
    return Array.from(letters).sort();
  }, [brands]);

  // Filter brands
  const filtered = useMemo(() => {
    if (!brands) return [];
    return brands.filter((b) => {
      const matchesSearch = !search || b.brandName?.toLowerCase().includes(search.toLowerCase());
      const matchesLetter = !letterFilter || b.brandName?.toUpperCase().startsWith(letterFilter);
      const matchesTab =
        filterTab === "all" ? true :
        filterTab === "with" ? b.hasLogo :
        !b.hasLogo;
      return matchesSearch && matchesLetter && matchesTab;
    });
  }, [brands, search, letterFilter, filterTab]);

  const withoutLogos = brands?.filter((b) => !b.hasLogo) || [];
  const withLogos = brands?.filter((b) => b.hasLogo) || [];

  const handleFileUpload = (brandName: string, file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      const fileType = file.name.split(".").pop() || "png";
      uploadLogo.mutate({ brandName, base64Data: base64, fileType });
    };
    reader.readAsDataURL(file);
  };

  const handleManualUrl = (brandName: string, url: string) => {
    const trimmed = url.trim();
    if (trimmed && isValidUrl(trimmed)) {
      saveLogo.mutate({ brandName, logoUrl: trimmed, source: "manual" });
      setPreviewUrl((prev) => ({ ...prev, [brandName]: "" }));
    }
  };

  const isValidUrl = (url: string) => {
    try { new URL(url); return true; } catch { return false; }
  };

  const handleClearLogo = (brandName: string) => {
    setConfirmAction("clear");
    setConfirmBrand(brandName);
  };

  const handleClearAll = () => {
    setConfirmAction("clearAll");
  };

  const handleRunAIAll = () => {
    setConfirmAction("aiAll");
  };

  const handleRunAISingle = (brandName: string) => {
    setConfirmAction("aiSingle");
    setConfirmBrand(brandName);
  };

  const executeConfirm = () => {
    if (confirmAction === "clear" && confirmBrand) {
      clearLogo.mutate({ brandName: confirmBrand });
    } else if (confirmAction === "clearAll") {
      withLogos.forEach((b) => {
        if (b.brandName) clearLogo.mutate({ brandName: b.brandName });
      });
      setConfirmAction(null);
    } else if (confirmAction === "aiAll") {
      setAiRunning(true);
      const names = withoutLogos.map((b) => b.brandName).filter(Boolean) as string[];
      if (names.length > 0) runAI.mutate({ brandNames: names });
      setConfirmAction(null);
    } else if (confirmAction === "aiSingle" && confirmBrand) {
      setAiRunning(true);
      runAI.mutate({ brandNames: [confirmBrand] });
      setConfirmAction(null);
      setConfirmBrand(null);
    }
  };

  // Confirm dialog text
  const confirmConfig = {
    clear: {
      title: "Удалить логотип?",
      message: `Логотип для «${confirmBrand}» будет удалён. Продолжить?`,
      confirm: "Удалить",
      danger: true,
    },
    clearAll: {
      title: "Удалить ВСЕ логотипы?",
      message: `Будет удалено ${withLogos.length} логотипов. Это действие нельзя отменить.`,
      confirm: "Удалить все",
      danger: true,
    },
    aiAll: {
      title: "Найти логотипы ИИ?",
      message: `ИИ попытается найти логотипы для ${withoutLogos.length} марок. Это может занять несколько минут.`,
      confirm: "Начать поиск",
      danger: false,
    },
    aiSingle: {
      title: "Найти логотип ИИ?",
      message: `ИИ найдёт логотип для «${confirmBrand}». Продолжить?`,
      confirm: "Найти",
      danger: false,
    },
  };

  return (
    <div className="space-y-4">
      {/* Header with stats */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Логотипы марок</h2>
          <p className="text-sm text-gray-500 mt-0.5 flex items-center gap-2">
            <span className="flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
              {stats?.withLogos || 0} с логотипом
            </span>
            <span className="text-gray-300">|</span>
            <span className="flex items-center gap-1">
              <XCircle className="w-3.5 h-3.5 text-red-400" />
              {stats?.withoutLogos || 0} без
            </span>
            <span className="text-gray-300">|</span>
            <span>Всего: {stats?.totalBrands || 0}</span>
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {withLogos.length > 0 && (
            <button
              onClick={handleClearAll}
              className="flex items-center gap-1.5 px-3 py-2 border border-red-200 text-red-600 rounded-lg hover:bg-red-50 text-sm font-medium transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Очистить все
            </button>
          )}
          <button
            onClick={handleRunAIAll}
            disabled={aiRunning || withoutLogos.length === 0}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 text-sm font-medium transition-colors"
          >
            {aiRunning ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Zap className="w-4 h-4" />
            )}
            {aiRunning ? "Поиск..." : `Найти ИИ (${withoutLogos.length})`}
          </button>
        </div>
      </div>

      {/* Progress bar */}
      <div className="bg-gray-100 rounded-full h-3 overflow-hidden relative">
        <div
          className="bg-gradient-to-r from-purple-500 to-purple-400 h-full rounded-full transition-all duration-500"
          style={{ width: `${stats?.percent || 0}%` }}
        />
        <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-gray-600">
          {stats?.percent || 0}%
        </span>
      </div>

      {/* Search + Filter tabs */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Поиск марки..."
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <div className="flex rounded-lg border border-gray-200 overflow-hidden">
          {(["all", "with", "without"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilterTab(tab)}
              className={`px-3 py-2 text-xs font-medium transition-colors ${
                filterTab === tab
                  ? "bg-purple-100 text-purple-700"
                  : "bg-white text-gray-500 hover:bg-gray-50"
              }`}
            >
              {tab === "all" && "Все"}
              {tab === "with" && (
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />{withLogos.length}
                </span>
              )}
              {tab === "without" && (
                <span className="flex items-center gap-1">
                  <XCircle className="w-3 h-3" />{withoutLogos.length}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Alphabet filter */}
      <div className="flex flex-wrap gap-1">
        <button
          onClick={() => setLetterFilter(null)}
          className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
            !letterFilter ? "bg-purple-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
          }`}
        >
          Все
        </button>
        {alphabet.map((letter) => (
          <button
            key={letter}
            onClick={() => setLetterFilter(letterFilter === letter ? null : letter)}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
              letterFilter === letter ? "bg-purple-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {letter}
          </button>
        ))}
      </div>

      {/* Results count */}
      <p className="text-xs text-gray-400">
        Показано {filtered.length} из {brands?.length || 0} марок
        {filterTab === "without" && " (без логотипа)"}
        {filterTab === "with" && " (с логотипом)"}
        {letterFilter && ` — буква «${letterFilter}»`}
      </p>

      {/* Brand cards grid */}
      {isLoading ? (
        <div className="text-center py-12">
          <RefreshCw className="w-8 h-8 animate-spin text-purple-400 mx-auto" />
          <p className="text-sm text-gray-400 mt-2">Загрузка марок...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-200">
          <Filter className="w-10 h-10 text-gray-300 mx-auto mb-2" />
          <p className="text-sm text-gray-400">Нет марок по выбранным фильтрам</p>
          <button
            onClick={() => { setFilterTab("all"); setLetterFilter(null); setSearch(""); }}
            className="text-purple-600 text-xs mt-1 hover:underline"
          >
            Сбросить фильтры
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((b) => (
            <div
              key={b.brandName}
              className={`relative flex items-start gap-3 p-4 rounded-lg border transition-all ${
                b.hasLogo
                  ? "bg-white border-green-200 hover:border-green-300"
                  : "bg-gray-50 border-gray-200 hover:border-purple-300"
              }`}
            >
              {/* Logo preview */}
              <div
                className={`w-14 h-14 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden ${
                  b.hasLogo ? "bg-white border border-gray-100" : "bg-gray-200"
                }`}
              >
                {b.hasLogo && b.logoUrl ? (
                  <img
                    src={b.logoUrl}
                    alt={b.brandName || ""}
                    className="w-full h-full object-contain p-1"
                    loading="lazy"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                ) : (
                  <span className="text-gray-400 text-lg font-bold">
                    {b.brandName?.charAt(0) || "?"}
                  </span>
                )}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1.5">
                  <p className="text-sm font-semibold text-gray-900 truncate">{b.brandName}</p>
                  {b.hasLogo ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-3.5 h-3.5 text-red-300 flex-shrink-0" />
                  )}
                </div>

                {/* Status badge */}
                {b.source && (
                  <span className={`inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full mb-2 ${
                    b.source === "ai" ? "bg-purple-100 text-purple-600" :
                    b.source === "upload" ? "bg-blue-100 text-blue-600" :
                    b.source === "manual" ? "bg-green-100 text-green-600" :
                    "bg-gray-100 text-gray-500"
                  }`}>
                    {b.source === "ai" && <Zap className="w-2.5 h-2.5" />}
                    {b.source === "upload" && <Upload className="w-2.5 h-2.5" />}
                    {b.source === "manual" && <Check className="w-2.5 h-2.5" />}
                    {b.source === "ai" ? "ИИ" : b.source === "upload" ? "Загружен" : "Вручную"}
                  </span>
                )}

                {/* URL input + actions */}
                <div className="flex gap-1.5">
                  <div className="flex-1 relative">
                    <input
                      type="text"
                      defaultValue={b.logoUrl || ""}
                      placeholder="URL логотипа..."
                      className={`w-full px-2.5 py-1.5 text-xs border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors ${
                        savedKeys.has(b.brandName || "")
                          ? "border-green-300 bg-green-50 text-green-700"
                          : b.hasLogo
                          ? "border-green-200 bg-green-50/50"
                          : "border-gray-200"
                      }`}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          handleManualUrl(b.brandName || "", (e.target as HTMLInputElement).value);
                        }
                      }}
                      onChange={(e) => {
                        const val = e.target.value;
                        setPreviewUrl((prev) => ({ ...prev, [b.brandName || ""]: val }));
                      }}
                    />
                    {savedKeys.has(b.brandName || "") && (
                      <Check className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-green-500" />
                    )}
                  </div>

                  {/* Preview toggle */}
                  {previewUrl[b.brandName || ""] && (
                    <button
                      onClick={() =>
                        setShowPreview((prev) => ({
                          ...prev,
                          [b.brandName || ""]: !prev[b.brandName || ""],
                        }))
                      }
                      className="p-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-500 transition-colors"
                      title="Предпросмотр"
                    >
                      {showPreview[b.brandName || ""] ? (
                        <EyeOff className="w-3.5 h-3.5" />
                      ) : (
                        <Eye className="w-3.5 h-3.5" />
                      )}
                    </button>
                  )}

                  {/* Save button */}
                  <button
                    onClick={() => {
                      const input = document.querySelector(
                        `input[data-brand="${b.brandName}"]`
                      ) as HTMLInputElement;
                      handleManualUrl(b.brandName || "", input?.value || previewUrl[b.brandName || ""] || "");
                    }}
                    disabled={!previewUrl[b.brandName || ""] || saveLogo.isPending}
                    className="p-1.5 rounded-lg bg-green-50 hover:bg-green-100 text-green-600 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    title="Сохранить"
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>

                  {/* Upload file */}
                  <label className="cursor-pointer p-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-500 transition-colors" title="Загрузить файл">
                    <Upload className="w-3.5 h-3.5" />
                    <input
                      type="file"
                      accept=".png,.jpg,.jpeg,.svg,.webp"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file && b.brandName) handleFileUpload(b.brandName, file);
                      }}
                    />
                  </label>

                  {/* AI search */}
                  {!b.hasLogo && (
                    <button
                      onClick={() => b.brandName && handleRunAISingle(b.brandName)}
                      disabled={aiRunning}
                      className="p-1.5 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-500 disabled:opacity-30 transition-colors"
                      title="Найти ИИ"
                    >
                      <Zap className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Delete */}
                  {b.hasLogo && (
                    <button
                      onClick={() => b.brandName && handleClearLogo(b.brandName)}
                      className="p-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-400 transition-colors"
                      title="Удалить логотип"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Live preview */}
                {showPreview[b.brandName || ""] && previewUrl[b.brandName || ""] && (
                  <div className="mt-2 p-2 bg-gray-50 rounded-lg border border-gray-200">
                    <p className="text-[10px] text-gray-400 mb-1">Предпросмотр:</p>
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 bg-white rounded border border-gray-200 flex items-center justify-center">
                        <img
                          src={previewUrl[b.brandName || ""]}
                          alt="preview"
                          className="w-full h-full object-contain p-0.5"
                          onError={(e) => {
                            (e.target as HTMLImageElement).style.display = "none";
                          }}
                        />
                      </div>
                      <p className="text-[10px] text-gray-500 truncate flex-1">
                        {previewUrl[b.brandName || ""]}
                      </p>
                    </div>
                  </div>
                )}

                {/* Error message */}
                {b.aiErrorMessage && (
                  <p className="text-[10px] text-red-400 mt-1 flex items-center gap-1">
                    <AlertTriangle className="w-2.5 h-2.5" />
                    {b.aiErrorMessage}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Confirm Dialog */}
      {confirmAction && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-start gap-3 mb-4">
              <div className={`p-2 rounded-full ${
                confirmConfig[confirmAction].danger ? "bg-red-100" : "bg-purple-100"
              }`}>
                {confirmConfig[confirmAction].danger ? (
                  <AlertTriangle className={`w-5 h-5 ${
                    confirmConfig[confirmAction].danger ? "text-red-600" : "text-purple-600"
                  }`} />
                ) : (
                  <Zap className="w-5 h-5 text-purple-600" />
                )}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  {confirmConfig[confirmAction].title}
                </h3>
                <p className="text-sm text-gray-500 mt-1">
                  {confirmConfig[confirmAction].message}
                </p>
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => { setConfirmAction(null); setConfirmBrand(null); }}
                className="px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 text-sm font-medium transition-colors"
              >
                Отмена
              </button>
              <button
                onClick={executeConfirm}
                disabled={clearLogo.isPending || runAI.isPending}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  confirmConfig[confirmAction].danger
                    ? "bg-red-600 text-white hover:bg-red-700 disabled:opacity-50"
                    : "bg-purple-600 text-white hover:bg-purple-700 disabled:opacity-50"
                }`}
              >
                {clearLogo.isPending || runAI.isPending ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  confirmConfig[confirmAction].confirm
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
