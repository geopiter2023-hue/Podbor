import { useState, useRef } from "react";
import { trpc } from "@/providers/trpc";
import { Hash, Plus, Search, Check, X, Loader2, Phone, Calendar, Camera, Trash2 } from "lucide-react";

function formatPlateInput(value: string): string {
  // Remove all non-alphanumeric
  let v = value.replace(/[^a-zA-Zа-яА-Я0-9]/g, "").toUpperCase();
  // Russian letters only for plate
  const ruLetters = "АВЕКМНОРСТУХ";
  const enToRu: Record<string, string> = { A: "А", B: "В", E: "Е", K: "К", M: "М", H: "Н", O: "О", P: "Р", C: "С", T: "Т", Y: "У", X: "Х" };
  v = v.split("").map((ch) => enToRu[ch] || ch).join("");
  // Format: L DDD LL (letter-digit-digit-digit-letter-letter)
  v = v.slice(0, 6);
  return v;
}

export default function PlateVinView() {
  const utils = trpc.useUtils();
  const [plateNumber, setPlateNumber] = useState("");
  const [plateRegion, setPlateRegion] = useState("");
  const [vinNumber, setVinNumber] = useState("");
  const [search, setSearch] = useState("");
  const [ocrLoading, setOcrLoading] = useState(false);
  const [ocrResult, setOcrResult] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ plateNumber: "", vin: "", make: "", model: "", year: "", engineCode: "" });
  const fileRef = useRef<HTMLInputElement>(null);

  const fullPlate = `${plateNumber}${plateRegion ? " " + plateRegion : ""}`;

  const { data: stats } = trpc.plateVin.stats.useQuery();
  const { data: list, isLoading } = trpc.plateVin.list.useQuery(
    search ? { search, limit: 50 } : { limit: 50 }
  );

  // AI OCR mutation
  const recognizePlate = trpc.plateVin.recognize.useMutation({
    onMutate: () => setOcrLoading(true),
    onSuccess: (data) => {
      setOcrLoading(false);
      if (data?.plateNumber) {
        // Parse plate: number + region
        const parts = data.plateNumber.split(/\s+/);
        if (parts.length >= 2) {
          setPlateNumber(parts[0]);
          setPlateRegion(parts[1]);
        } else {
          setPlateNumber(data.plateNumber);
        }
        setOcrResult(`Распознано: ${data.plateNumber}`);
      } else {
        setOcrResult("Номер не распознан");
      }
    },
    onError: (err) => {
      setOcrLoading(false);
      setOcrResult(`Ошибка: ${err.message}`);
    },
  });

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      recognizePlate.mutate({ imageBase64: base64 });
    };
    reader.readAsDataURL(file);
  };

  const handleSearch = () => {
    const q = [fullPlate, vinNumber].filter(Boolean).join(" ");
    if (q) setSearch(q);
  };

  const handleReset = () => {
    setPlateNumber("");
    setPlateRegion("");
    setVinNumber("");
    setSearch("");
    setOcrResult("");
  };

  const upsert = trpc.plateVin.upsert.useMutation({
    onSuccess: () => { utils.plateVin.list.invalidate(); utils.plateVin.stats.invalidate(); setShowForm(false); setForm({ plateNumber: "", vin: "", make: "", model: "", year: "", engineCode: "" }); },
  });
  const verify = trpc.plateVin.verify.useMutation({
    onSuccess: () => utils.plateVin.list.invalidate(),
  });
  const remove = trpc.plateVin.delete.useMutation({
    onSuccess: () => { utils.plateVin.list.invalidate(); utils.plateVin.stats.invalidate(); },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-gray-800 text-xl font-semibold flex items-center gap-2">
          <Hash className="w-5 h-5 text-[#d32f2f]" />
          Реестр номеров
        </h2>
        <button onClick={() => setShowForm(!showForm)} className="bg-[#d32f2f] hover:bg-[#b71c1c] text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors">
          <Plus className="w-4 h-4" /> Добавить
        </button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-5 gap-3">
          {[
            { label: "Всего", value: stats.total, color: "bg-gray-50" },
            { label: "Проверено", value: stats.verified, color: "bg-green-50" },
            { label: "Ожидает", value: stats.pending, color: "bg-amber-50" },
            { label: "С VIN", value: stats.withVin, color: "bg-blue-50" },
            { label: "За 7 дней", value: stats.recent, color: "bg-purple-50" },
          ].map((s) => (
            <div key={s.label} className={`${s.color} rounded-lg p-3 text-center border border-gray-200`}>
              <p className="text-xl font-bold text-gray-800">{s.value}</p>
              <p className="text-xs text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* Search Form — style like screenshot */}
      <div className="bg-white rounded-lg border border-gray-200 p-4 space-y-3">
        {/* Plate row: Number + Region + Camera */}
        <div className="flex gap-2 items-stretch">
          {/* Plate number field */}
          <div className="flex-1">
            <input
              type="text"
              value={plateNumber}
              onChange={(e) => setPlateNumber(formatPlateInput(e.target.value))}
              placeholder="А 000 АА"
              maxLength={6}
              className="w-full border-2 border-gray-900 rounded-none px-3 py-2.5 text-lg font-bold tracking-widest text-gray-900 placeholder:text-gray-300 focus:border-[#d32f2f] focus:outline-none uppercase"
            />
          </div>
          {/* Region field with RUS flag */}
          <div className="w-24 relative">
            <input
              type="text"
              value={plateRegion}
              onChange={(e) => setPlateRegion(e.target.value.replace(/\D/g, "").slice(0, 3))}
              placeholder="000"
              maxLength={3}
              className="w-full border-2 border-gray-900 rounded-none px-2 py-2.5 text-lg font-bold text-gray-900 placeholder:text-gray-300 focus:border-[#d32f2f] focus:outline-none text-center"
            />
            <div className="absolute bottom-0.5 left-0 right-0 flex items-center justify-center gap-1 text-[10px] text-gray-400">
              <span>RUS</span>
              <span>🇷🇺</span>
            </div>
          </div>
          {/* Camera button */}
          <button
            onClick={() => fileRef.current?.click()}
            disabled={ocrLoading}
            className="w-14 border-2 border-gray-900 rounded-none flex items-center justify-center hover:bg-gray-50 disabled:opacity-50 transition-colors relative"
            title="Распознать номер по фото"
          >
            {ocrLoading ? (
              <Loader2 className="w-5 h-5 text-gray-600 animate-spin" />
            ) : (
              <Camera className="w-5 h-5 text-gray-600" />
            )}
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handlePhotoUpload}
            />
          </button>
        </div>

        {/* OCR result */}
        {ocrResult && (
          <p className={`text-xs ${ocrResult.includes("Распознано") ? "text-green-600" : "text-red-500"}`}>
            {ocrResult}
          </p>
        )}

        {/* VIN / Frame number */}
        <input
          type="text"
          value={vinNumber}
          onChange={(e) => setVinNumber(e.target.value.toUpperCase())}
          placeholder="Поиск по VIN / Frame номеру"
          className="w-full border-2 border-gray-900 rounded-none px-3 py-2.5 text-sm text-gray-900 placeholder:text-gray-300 focus:border-[#d32f2f] focus:outline-none"
        />

        {/* Buttons: Reset + Search */}
        <div className="flex gap-2">
          <button
            onClick={handleReset}
            className="flex-1 border-2 border-gray-900 rounded-none py-2.5 text-sm font-medium text-gray-900 hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
          >
            <X className="w-4 h-4" /> Сбросить
          </button>
          <button
            onClick={handleSearch}
            disabled={!fullPlate && !vinNumber}
            className="flex-1 bg-[#d32f2f] hover:bg-[#b71c1c] disabled:opacity-50 text-white rounded-none py-2.5 text-sm font-medium transition-colors flex items-center justify-center gap-2"
          >
            <Search className="w-4 h-4" /> Поиск
          </button>
        </div>
      </div>

      {/* Search results */}
      {search && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="p-3 border-b border-gray-200 flex items-center justify-between">
            <p className="text-sm text-gray-500">Результаты поиска: <span className="font-medium text-gray-800">{search}</span></p>
            <button onClick={() => setSearch("")} className="text-xs text-gray-400 hover:text-gray-600">Очистить</button>
          </div>
          {isLoading ? (
            <div className="p-8 text-center text-gray-400">Загрузка...</div>
          ) : list?.length === 0 ? (
            <div className="p-8 text-center text-gray-400">Ничего не найдено</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 text-gray-600">
                  <tr>
                    <th className="px-3 py-2 text-left font-medium">Номер</th>
                    <th className="px-3 py-2 text-left font-medium">VIN</th>
                    <th className="px-3 py-2 text-left font-medium">Марка/Модель</th>
                    <th className="px-3 py-2 text-center font-medium">Год</th>
                    <th className="px-3 py-2 text-center font-medium">Статус</th>
                    <th className="px-3 py-2 text-center font-medium">Действия</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {list?.map((item: any) => (
                    <tr key={item.id} className="hover:bg-gray-50">
                      <td className="px-3 py-2 font-mono font-medium">{item.plateNumber || "—"}</td>
                      <td className="px-3 py-2 font-mono text-xs text-gray-500">{item.vin || "—"}</td>
                      <td className="px-3 py-2">{item.make} {item.model}</td>
                      <td className="px-3 py-2 text-center">{item.year || "—"}</td>
                      <td className="px-3 py-2 text-center">
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-xs ${
                          item.isVerified === "yes" ? "bg-green-100 text-green-700" :
                          item.isVerified === "pending" ? "bg-amber-100 text-amber-700" :
                          "bg-gray-100 text-gray-600"
                        }`}>
                          {item.isVerified === "yes" ? "Проверено" :
                           item.isVerified === "pending" ? "Ожидает" : "Новое"}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {item.isVerified !== "yes" && (
                            <button onClick={() => verify.mutate({ id: item.id })} className="p-1 rounded hover:bg-green-50 text-green-600" title="Подтвердить">
                              <Check className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button onClick={() => remove.mutate({ id: item.id })} className="p-1 rounded hover:bg-red-50 text-red-500" title="Удалить">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Add form */}
      {showForm && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Новая запись</h3>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "Госномер *", key: "plateNumber", placeholder: "А001АА 77" },
              { label: "VIN", key: "vin", placeholder: "XW7BT61Z9CM000000" },
              { label: "Марка *", key: "make", placeholder: "Toyota" },
              { label: "Модель *", key: "model", placeholder: "Camry" },
              { label: "Год", key: "year", placeholder: "2020" },
              { label: "Код двигателя", key: "engineCode", placeholder: "2GR-FE" },
            ].map((f) => (
              <div key={f.key}>
                <label className="block text-xs text-gray-500 mb-1">{f.label}</label>
                <input
                  type="text"
                  value={(form as any)[f.key]}
                  onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                  placeholder={f.placeholder}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:border-[#d32f2f] focus:ring-1 focus:ring-[#d32f2f] focus:outline-none"
                />
              </div>
            ))}
          </div>
          <div className="flex justify-end gap-2 mt-3">
            <button onClick={() => setShowForm(false)} className="px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-600 hover:bg-gray-50">Отмена</button>
            <button
              onClick={() => {
                if (!form.plateNumber && !form.vin) { alert("Введите номер или VIN"); return; }
                if (!form.make || !form.model) { alert("Введите марку и модель"); return; }
                upsert.mutate({ ...form, source: "manual" });
              }}
              disabled={upsert.isPending}
              className="px-4 py-2 bg-[#d32f2f] text-white rounded-lg text-sm font-medium hover:bg-[#b71c1c] disabled:opacity-50 flex items-center gap-2"
            >
              {upsert.isPending && <Loader2 className="w-3 h-3 animate-spin" />} Сохранить
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
