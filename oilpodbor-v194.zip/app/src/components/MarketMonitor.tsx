import { useState, useRef } from "react";
import { trpc } from "@/providers/trpc";
import {
  Globe, Play, CheckCircle, XCircle, Loader2, Search,
  ChevronDown, ChevronUp, RefreshCw, Check, X, Car,
  Plus, Clock, ArrowRight, AlertTriangle, Filter,
  Power, Square, Activity,
} from "lucide-react";

const STATUS_STYLES: Record<string, { bg: string; text: string; label: string; icon: any }> = {
  new: { bg: "bg-blue-100", text: "text-blue-700", label: "Новый", icon: Plus },
  pending: { bg: "bg-amber-100", text: "text-amber-700", label: "На проверке", icon: Clock },
  approved: { bg: "bg-green-100", text: "text-green-700", label: "Добавлен", icon: CheckCircle },
  rejected: { bg: "bg-red-100", text: "text-red-700", label: "Отклонён", icon: XCircle },
  merged: { bg: "bg-gray-100", text: "text-gray-600", label: "В базе", icon: Check },
};

export default function MarketMonitor() {
  const utils = trpc.useUtils();
  const [statusFilter, setStatusFilter] = useState("");
  const [makeFilter, setMakeFilter] = useState("");
  const [page, setPage] = useState(0);
  const [expandedCar, setExpandedCar] = useState<number | null>(null);
  const [rejectionNotes, setRejectionNotes] = useState("");
  const [rejectingId, setRejectingId] = useState<number | null>(null);
  const pageSize = 30;

  const { data: stats, error: statsError } = trpc.market.stats.useQuery(undefined, { refetchInterval: 5000 });
  const { data: carsData, isLoading, error: listError } = trpc.market.list.useQuery({
    status: statusFilter || undefined,
    make: makeFilter || undefined,
    limit: pageSize,
    offset: page * pageSize,
  }, { refetchInterval: 5000 });
  const { data: makes, error: makesError } = trpc.market.getMakes.useQuery();
  const { data: syncHistory, error: syncError } = trpc.market.syncHistory.useQuery({ limit: 10 }, { refetchInterval: 5000 });

  const scan = trpc.market.scan.useMutation({
    onSuccess: (result) => {
      alert(result.message || "Сканирование запущено!");
      utils.market.stats.invalidate();
      utils.market.list.invalidate();
      utils.market.syncHistory.invalidate();
    },
    onError: (err) => {
      alert("Ошибка сканирования: " + err.message);
    },
  });

  // Auto-reset scan pending after 10s timeout
  const scanTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleScan = (params?: { brandLimit?: number; modelLimit?: number; deepParse?: boolean }) => {
    if (scanTimeoutRef.current) clearTimeout(scanTimeoutRef.current);
    scanTimeoutRef.current = setTimeout(() => {
      utils.market.stats.invalidate();
      utils.market.list.invalidate();
      utils.market.syncHistory.invalidate();
    }, 3000);
    scan.mutate(params || {});
  };

  const approve = trpc.market.approve.useMutation({
    onSuccess: () => {
      utils.market.list.invalidate();
      utils.market.stats.invalidate();
    },
  });

  const reject = trpc.market.reject.useMutation({
    onSuccess: () => {
      setRejectingId(null);
      setRejectionNotes("");
      utils.market.list.invalidate();
      utils.market.stats.invalidate();
    },
  });

  const startMonitoring = trpc.market.startMonitoring.useMutation({
    onSuccess: (r) => alert(r.message),
  });
  const stopMonitoring = trpc.market.stopMonitoring.useMutation({
    onSuccess: (r) => alert(r.message),
  });

  const handleApprove = (id: number) => {
    if (!confirm("Добавить этот автомобиль в основную базу?")) return;
    approve.mutate({ id });
  };

  const handleReject = (id: number) => {
    if (rejectingId === id) {
      reject.mutate({ id, notes: rejectionNotes || undefined });
    } else {
      setRejectingId(id);
      setRejectionNotes("");
    }
  };

  const totalPages = Math.ceil((carsData?.total || 0) / pageSize);

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {[
          { label: "Всего найдено", value: stats?.total || 0, color: "text-gray-800" },
          { label: "Новые", value: stats?.new || 0, color: "text-blue-600" },
          { label: "На проверке", value: stats?.pending || 0, color: "text-amber-600" },
          { label: "Добавлены", value: stats?.approved || 0, color: "text-green-600" },
          { label: "Уже в базе", value: stats?.merged || 0, color: "text-gray-500" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-lg border border-gray-200 p-4">
            <p className="text-gray-500 text-xs uppercase">{s.label}</p>
            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Controls */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-gray-800 font-semibold flex items-center gap-2">
              <Globe className="w-5 h-5 text-blue-600" />
              Мониторинг рынка — drom.ru
            </h2>
            <p className="text-gray-500 text-sm mt-1">
              Сканирует каталог drom.ru и находит автомобили, отсутствующие в базе.
              Последнее обновление: {syncHistory?.[0]?.completedAt
                ? new Date(syncHistory[0].completedAt).toLocaleString("ru-RU")
                : "никогда"}
            </p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => handleScan()}
              disabled={scan.isPending}
              className="bg-blue-600 text-white px-6 py-2.5 rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2 transition-colors"
            >
              {scan.isPending ? <><Loader2 className="w-4 h-4 animate-spin" />Сканирование...</> : <><RefreshCw className="w-4 h-4" />Сканировать drom.ru</>}
            </button>
            <button
              onClick={() => handleScan({ brandLimit: 5, modelLimit: 3, deepParse: true })}
              disabled={scan.isPending}
              className="border border-blue-300 text-blue-600 px-4 py-2.5 rounded-lg text-sm font-medium hover:bg-blue-50 disabled:opacity-50 flex items-center gap-1 transition-colors"
            >
              <Play className="w-4 h-4" />Тест (5 марок)
            </button>
            <button
              onClick={() => startMonitoring.mutate()}
              className="border border-green-300 text-green-600 px-3 py-2.5 rounded-lg text-sm font-medium hover:bg-green-50 flex items-center gap-1 transition-colors"
              title="Автозапуск каждые 6 часов"
            >
              <Power className="w-4 h-4" />Авто
            </button>
            <button
              onClick={() => stopMonitoring.mutate()}
              className="border border-red-300 text-red-600 px-3 py-2.5 rounded-lg text-sm font-medium hover:bg-red-50 flex items-center gap-1 transition-colors"
            >
              <Square className="w-4 h-4" />Стоп
            </button>
          </div>
        </div>

        {/* Last sync */}
        {syncHistory && syncHistory.length > 0 && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-xs text-gray-500 font-medium mb-2">История синхронизации:</p>
            <div className="space-y-1">
              {syncHistory.slice(0, 5).map((sync: any) => (
                <div key={sync.id} className="flex items-center gap-2 text-xs">
                  <div className={`w-2 h-2 rounded-full ${sync.status === "completed" ? "bg-green-400" : sync.status === "running" ? "bg-blue-400 animate-pulse" : "bg-red-400"}`} />
                  <span className="text-gray-600">{new Date(sync.startedAt).toLocaleString("ru-RU")}</span>
                  <span className={`font-medium ${sync.status === "completed" ? "text-green-600" : sync.status === "running" ? "text-blue-600" : "text-red-600"}`}>
                    {sync.status === "completed" ? `Найдено ${sync.carsFound}, новых ${sync.carsNew}` : sync.status === "running" ? "В процессе..." : `Ошибка: ${sync.error}`}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Filters */}
      <div className="flex gap-2 flex-wrap">
        <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(0); }}
          className="border border-gray-300 rounded-md px-3 py-2 text-sm">
          <option value="">Все статусы</option>
          <option value="new">Новые</option>
          <option value="pending">На проверке</option>
          <option value="approved">Добавлены</option>
          <option value="rejected">Отклонены</option>
          <option value="merged">Уже в базе</option>
        </select>
        <select value={makeFilter} onChange={(e) => { setMakeFilter(e.target.value); setPage(0); }}
          className="border border-gray-300 rounded-md px-3 py-2 text-sm">
          <option value="">Все марки</option>
          {makes?.map((m) => <option key={m} value={m}>{m}</option>)}
        </select>
      </div>

      {/* Cars Table */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-blue-600" /></div>
        ) : statsError || listError || syncError ? (
          <div className="text-center py-12">
            <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto mb-3" />
            <p className="text-amber-600 text-sm font-medium">Ошибка загрузки данных мониторинга</p>
            <p className="text-gray-400 text-xs mt-1">{statsError?.message || listError?.message || syncError?.message || "Проверьте соединение"}</p>
            <button onClick={() => window.location.reload()} className="text-blue-600 text-xs mt-2 hover:underline">Обновить</button>
          </div>
        ) : !carsData?.items?.length ? (
          <div className="text-center py-12">
            <Car className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-400 text-sm">Нет автомобилей для отображения</p>
            <p className="text-gray-400 text-xs mt-1">Запустите сканирование drom.ru выше</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 text-left bg-gray-50">
                  <th className="p-3 text-gray-500 text-xs font-medium w-12">#</th>
                  <th className="p-3 text-gray-500 text-xs font-medium">Марка</th>
                  <th className="p-3 text-gray-500 text-xs font-medium">Модель</th>
                  <th className="p-3 text-gray-500 text-xs font-medium">Поколение</th>
                  <th className="p-3 text-gray-500 text-xs font-medium">Годы</th>
                  <th className="p-3 text-gray-500 text-xs font-medium">Двигатель</th>
                  <th className="p-3 text-gray-500 text-xs font-medium w-20 text-center">Статус</th>
                  <th className="p-3 text-gray-500 text-xs font-medium w-24 text-center">Найден</th>
                  <th className="p-3 text-gray-500 text-xs font-medium w-32 text-center">Действия</th>
                </tr>
              </thead>
              <tbody>
                {carsData.items.map((car: any, idx: number) => {
                  const st = STATUS_STYLES[car.status] || STATUS_STYLES.new;
                  const StatusIcon = st.icon;
                  const isExpanded = expandedCar === car.id;
                  const isRejecting = rejectingId === car.id;

                  return (
                    <>
                      <tr key={car.id} className={`border-b border-gray-50 hover:bg-gray-50 ${isExpanded ? "bg-blue-50" : ""}`}>
                        <td className="p-3 text-gray-400 text-xs">{page * pageSize + idx + 1}</td>
                        <td className="p-3 text-gray-800 font-medium">{car.make}</td>
                        <td className="p-3 text-gray-700">{car.model}</td>
                        <td className="p-3 text-gray-600 text-xs max-w-32 truncate" title={car.generation}>{car.generation || "—"}</td>
                        <td className="p-3 text-gray-500 text-xs">{car.yearFrom}{car.yearTo ? `-${car.yearTo}` : "+"}</td>
                        <td className="p-3 text-gray-600 text-xs">{car.engineCode || "—"} {car.engineCapacity ? `(${car.engineCapacity})` : ""}</td>
                        <td className="p-3 text-center">
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${st.bg} ${st.text} flex items-center gap-1 justify-center`}>
                            <StatusIcon className="w-3 h-3" />{st.label}
                          </span>
                        </td>
                        <td className="p-3 text-gray-500 text-xs text-center">{new Date(car.foundAt).toLocaleDateString("ru-RU")}</td>
                        <td className="p-3 text-center">
                          <div className="flex gap-1 justify-center">
                            <button onClick={() => setExpandedCar(isExpanded ? null : car.id)} className="p-1.5 text-gray-400 hover:text-blue-600 rounded" title="Подробности">
                              {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                            </button>
                            {car.status === "new" && (
                              <>
                                <button onClick={() => handleApprove(car.id)} disabled={approve.isPending}
                                  className="p-1.5 text-green-600 hover:bg-green-50 rounded" title="Добавить в базу">
                                  <Check className="w-4 h-4" />
                                </button>
                                <button onClick={() => handleReject(car.id)}
                                  className="p-1.5 text-red-600 hover:bg-red-50 rounded" title="Отклонить">
                                  <X className="w-4 h-4" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                      {/* Expanded row */}
                      {isExpanded && (
                        <tr>
                          <td colSpan={9} className="p-4 bg-gray-50">
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                              {[
                                { label: "Марка", value: car.make },
                                { label: "Модель", value: car.model },
                                { label: "Поколение", value: car.generation || "—" },
                                { label: "Модификация", value: car.modification || "—" },
                                { label: "Годы", value: `${car.yearFrom || "?"}-${car.yearTo || "н.в."}` },
                                { label: "Код двигателя", value: car.engineCode || "—" },
                                { label: "Объём", value: car.engineCapacity || "—" },
                                { label: "Мощность", value: car.enginePower || "—" },
                                { label: "Топливо", value: car.fuel || "—" },
                                { label: "КПП", value: car.transmission || "—" },
                                { label: "Привод", value: car.drive || "—" },
                                { label: "Кузов", value: car.body || "—" },
                                { label: "Источник", value: car.source },
                                { label: "Найден", value: new Date(car.foundAt).toLocaleString("ru-RU") },
                              ].map((f) => (
                                <div key={f.label}>
                                  <span className="text-gray-400">{f.label}:</span>
                                  <p className="font-medium text-gray-700">{f.value}</p>
                                </div>
                              ))}
                            </div>

                            {/* Parsed specs from deep scan */}
                            {(() => {
                              try {
                                const raw = JSON.parse(car.rawData || "{}");
                                if (Object.keys(raw).length > 0) {
                                  // Group specs by category
                                  const engineSpecs = [
                                    { label: "Тип двигателя", key: "engineType" },
                                    { label: "Объём двигателя", key: "engineCapacity" },
                                    { label: "Мощность", key: "enginePower" },
                                    { label: "Код двигателя", key: "engineCode" },
                                    { label: "Крутящий момент", key: "torque" },
                                    { label: "Цилиндров", key: "cylinders" },
                                    { label: "Клапанов", key: "valves" },
                                    { label: "Компрессия", key: "compression" },
                                  ];
                                  const transSpecs = [
                                    { label: "КПП", key: "transmission" },
                                    { label: "Привод", key: "drive" },
                                  ];
                                  const bodySpecs = [
                                    { label: "Кузов", key: "body" },
                                    { label: "Дверей", key: "doors" },
                                    { label: "Мест", key: "seats" },
                                    { label: "Масса", key: "weight" },
                                    { label: "Клиренс", key: "groundClearance" },
                                  ];
                                  const perfSpecs = [
                                    { label: "Разгон 0-100", key: "acceleration" },
                                    { label: "Макс. скорость", key: "maxSpeed" },
                                    { label: "Расход топлива", key: "fuelConsumption" },
                                    { label: "Бак", key: "fuelTank" },
                                  ];
                                  const fluidSpecs = [
                                    { label: "Объём масла", key: "oilVolume" },
                                    { label: "Вязкость масла", key: "oilSae" },
                                    { label: "Объём антифриза", key: "coolantVolume" },
                                    { label: "Тормозная жидкость", key: "brakeFluid" },
                                    { label: "Трансмиссионное масло", key: "transmissionOil" },
                                  ];
                                  const renderGroup = (title: string, specs: any[], bgColor: string) => {
                                    const hasData = specs.some((s) => raw[s.key]);
                                    if (!hasData) return null;
                                    return (
                                      <div className="mt-3 pt-3 border-t border-gray-200">
                                        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">{title}</p>
                                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                                          {specs.map((spec) =>
                                            raw[spec.key] ? (
                                              <div key={spec.key} className={`${bgColor} rounded px-2 py-1 border`}>
                                                <span className="text-gray-400 text-[10px]">{spec.label}:</span>
                                                <p className="font-medium text-gray-800">{raw[spec.key]}</p>
                                              </div>
                                            ) : null
                                          )}
                                        </div>
                                      </div>
                                    );
                                  };
                                  return (
                                    <>
                                      {renderGroup("Двигатель", engineSpecs, "bg-amber-50/50 border-amber-100")}
                                      {renderGroup("Трансмиссия", transSpecs, "bg-teal-50/50 border-teal-100")}
                                      {renderGroup("Кузов и шасси", bodySpecs, "bg-purple-50/50 border-purple-100")}
                                      {renderGroup("Динамика", perfSpecs, "bg-green-50/50 border-green-100")}
                                      {renderGroup("Жидкости", fluidSpecs, "bg-blue-50/50 border-blue-100")}
                                      {/* Raw specs dump */}
                                      {raw.rawSpecs && Object.keys(raw.rawSpecs).length > 0 && (
                                        <div className="mt-3 pt-3 border-t border-gray-200">
                                          <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Все характеристики с drom.ru</p>
                                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1 text-[10px] max-h-48 overflow-y-auto">
                                            {Object.entries(raw.rawSpecs).map(([k, v]: [string, any]) => (
                                              <div key={k} className="flex gap-1">
                                                <span className="text-gray-400 truncate">{k}:</span>
                                                <span className="text-gray-700 font-medium truncate">{v}</span>
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      )}
                                    </>
                                  );
                                }
                              } catch { /* ignore */ }
                              return null;
                            })()}

                            {car.sourceUrl && (
                              <a href={car.sourceUrl} target="_blank" rel="noopener noreferrer"
                                className="text-blue-600 hover:underline text-xs mt-3 inline-flex items-center gap-1">
                                <Globe className="w-3 h-3" /> Открыть на drom.ru
                              </a>
                            )}
                            {car.notes && (
                              <p className="text-red-500 text-xs mt-2">{car.notes}</p>
                            )}
                          </td>
                        </tr>
                      )}
                      {/* Rejection row */}
                      {isRejecting && (
                        <tr>
                          <td colSpan={9} className="p-4 bg-red-50">
                            <div className="flex gap-2 items-center">
                              <input type="text" value={rejectionNotes} onChange={(e) => setRejectionNotes(e.target.value)}
                                placeholder="Причина отклонения..." className="flex-1 border border-red-200 rounded-md px-3 py-2 text-sm" />
                              <button onClick={() => handleReject(car.id)}
                                className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700">
                                Отклонить
                              </button>
                              <button onClick={() => setRejectingId(null)} className="border text-gray-600 px-4 py-2 rounded-lg text-sm">
                                Отмена
                              </button>
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  );
                })}
              </tbody>
            </table>

            {totalPages > 1 && (
              <div className="flex items-center justify-between p-4 border-t border-gray-200">
                <span className="text-gray-500 text-xs">Страница {page + 1} из {totalPages}</span>
                <div className="flex gap-1">
                  <button onClick={() => setPage(0)} disabled={page === 0} className="px-2 py-1 text-xs border rounded disabled:opacity-30">«</button>
                  <button onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0} className="px-2 py-1 text-xs border rounded disabled:opacity-30">‹</button>
                  <button onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1} className="px-2 py-1 text-xs border rounded disabled:opacity-30">›</button>
                  <button onClick={() => setPage(totalPages - 1)} disabled={page >= totalPages - 1} className="px-2 py-1 text-xs border rounded disabled:opacity-30">»</button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
