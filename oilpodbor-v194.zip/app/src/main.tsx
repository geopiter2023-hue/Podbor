import { createRoot } from 'react-dom/client'
import { HashRouter } from 'react-router'
import { Component, type ReactNode } from 'react'
import './index.css'
import { TRPCProvider } from "@/providers/trpc"
import App from './App.tsx'

// Global error boundary — prevents black screen on render errors
class RootErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean; error: string }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: '' };
  }
  static getDerivedStateFromError(err: Error) {
    return { hasError: true, error: err.message + '\n' + (err.stack || '') };
  }
  componentDidCatch(err: Error, info: any) {
    console.error('[RootError]', err, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: '#fff', zIndex: 99999, padding: '24px',
          fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif',
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        }}>
          <div style={{
            width: '56px', height: '56px', borderRadius: '16px',
            background: '#E31E24', display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: 'white', fontSize: '28px', fontWeight: 700, marginBottom: '20px',
          }}>!</div>
          <h2 style={{ color: '#1D1D1F', margin: '0 0 8px', fontSize: '22px', fontWeight: 700 }}>
            Ошибка загрузки страницы
          </h2>
          <p style={{ color: '#86868B', margin: '0 0 20px', fontSize: '15px', textAlign: 'center', maxWidth: '400px' }}>
            Что-то пошло не так при загрузке. Попробуйте обновить страницу или вернуться на главную.
          </p>
          <pre style={{
            background: '#F5F5F7', padding: '16px', borderRadius: '12px',
            overflow: 'auto', maxHeight: '200px', fontSize: '12px',
            color: '#666', width: '100%', maxWidth: '500px', marginBottom: '20px',
          }}>{this.state.error}</pre>
          <div style={{ display: 'flex', gap: '12px' }}>
            <button onClick={() => location.reload()} style={{
              padding: '14px 32px', background: '#E31E24', color: '#fff',
              border: 'none', borderRadius: '12px', fontSize: '15px', fontWeight: 600,
              cursor: 'pointer', fontFamily: 'inherit',
            }}>Обновить страницу</button>
            <button onClick={() => { localStorage.removeItem('local_auth_token'); location.href = '/#/'; }} style={{
              padding: '14px 32px', background: '#F5F5F7', color: '#1D1D1F',
              border: 'none', borderRadius: '12px', fontSize: '15px', fontWeight: 600,
              cursor: 'pointer', fontFamily: 'inherit',
            }}>На главную</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <HashRouter>
    <TRPCProvider>
      <RootErrorBoundary>
        <App />
      </RootErrorBoundary>
    </TRPCProvider>
  </HashRouter>,
)
