import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink } from "@trpc/client";
import { useState } from "react";
import superjson from "superjson";

// Create tRPC client instance
import { createTRPCReact } from "@trpc/react-query";
import type { AppRouter } from "../../api/router";

export const trpc = createTRPCReact<AppRouter>();

export function TRPCProvider({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            retry: 1,
            retryDelay: 1000,
            // Auth queries must refetch on mount to pick up new tokens
            refetchOnMount: true,
            refetchOnWindowFocus: true,
            staleTime: 30000, // 30s default
            gcTime: 5 * 60 * 1000, // 5min
          },
          mutations: {
            retry: 1,
            retryDelay: 1000,
          },
        },
      }),
  );

  const [trpcClient] = useState(() =>
    trpc.createClient({
      links: [
        httpBatchLink({
          url: "/api/trpc",
          transformer: superjson,
          headers() {
            const token = localStorage.getItem("local_auth_token");
            return {
              ...(token ? { "x-local-auth-token": token } : {}),
            };
          },
          fetch(input, init) {
            const url = typeof input === "string" ? input : input instanceof Request ? input.url : input.toString();
            const isHealth = url.includes("health");
            return globalThis.fetch(input, {
              ...(init ?? {}),
              credentials: "include",
              signal: AbortSignal.timeout(isHealth ? 10000 : 30000),
            });
          },
        }),
      ],
    }),
  );

  return (
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
    </trpc.Provider>
  );
}
