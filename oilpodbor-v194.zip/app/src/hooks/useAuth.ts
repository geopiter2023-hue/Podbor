import { useCallback } from "react";
import { trpc } from "@/providers/trpc";

export interface AuthUser {
  id: number;
  name: string | null;
  username: string | null;
  email: string | null;
  avatar: string | null;
  role: "user" | "admin";
}

export function useAuth() {
  const utils = trpc.useUtils();

  // me query — ALWAYS refetch on mount to pick up new token after login
  const { data: localUser, isLoading, error } = trpc.localAuth.me.useQuery(
    undefined,
    {
      retry: 1,
      retryDelay: 500,
      refetchOnWindowFocus: false,
      staleTime: 0,       // Always fresh — auth state changes
      gcTime: 0,          // Don't cache — we need live auth state
    },
  );

  const logout = useCallback(() => {
    localStorage.removeItem("local_auth_token");
    utils.invalidate();
    window.location.reload();
  }, [utils]);

  const isAuthenticated = !!localUser && !error;

  return {
    user: (localUser || null) as AuthUser | null,
    isAuthenticated,
    isLoading, // true while fetching
    logout,
  };
}
