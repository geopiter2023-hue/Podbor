// Polyfill for AbortSignal.timeout (not available in older Node.js)
if (typeof (AbortSignal as any).timeout !== "function") {
  (AbortSignal as any).timeout = function(ms: number) {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(new DOMException("Timeout", "AbortError")), ms);
    return ctrl.signal;
  };
}

import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { createOAuthCallbackHandler } from "./kimi/auth";
import { Paths } from "@contracts/constants";

const app = new Hono<{ Bindings: HttpBindings }>();

// ─── Auto-create missing tables on startup ───
(async () => {
  try {
    const mysql2 = await import("mysql2/promise");
    const pool = mysql2.createPool({
      uri: process.env.DATABASE_URL || "",
      connectionLimit: 2,
    });
    const conn = await pool.getConnection();

    // Add columns to users
    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS unionId VARCHAR(255)`);
    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS username VARCHAR(255) UNIQUE`);
    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS passwordHash VARCHAR(255)`);
    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS name VARCHAR(255)`);
    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS role ENUM('user','admin') DEFAULT 'user'`);
    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS lastSignInAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);

    // Add columns to cars
    await conn.execute(`ALTER TABLE cars ADD COLUMN IF NOT EXISTS lastCheckedAt TIMESTAMP NULL`);
    await conn.execute(`ALTER TABLE cars ADD COLUMN IF NOT EXISTS lastFilledAt TIMESTAMP NULL`);
    await conn.execute(`ALTER TABLE cars ADD COLUMN IF NOT EXISTS checkedBy VARCHAR(255) NULL`);
    await conn.execute(`ALTER TABLE cars ADD COLUMN IF NOT EXISTS filledBy VARCHAR(100) NULL`);

    // Add columns to carFluidSpecs
    await conn.execute(`ALTER TABLE carFluidSpecs ADD COLUMN IF NOT EXISTS lastCheckedAt TIMESTAMP NULL`);
    await conn.execute(`ALTER TABLE carFluidSpecs ADD COLUMN IF NOT EXISTS lastFilledAt TIMESTAMP NULL`);
    await conn.execute(`ALTER TABLE carFluidSpecs ADD COLUMN IF NOT EXISTS checkedBy VARCHAR(255) NULL`);
    await conn.execute(`ALTER TABLE carFluidSpecs ADD COLUMN IF NOT EXISTS filledBy VARCHAR(100) NULL`);

    // Add columns to products
    await conn.execute(`ALTER TABLE products ADD COLUMN IF NOT EXISTS priorityLevel INT DEFAULT 2`);

    // Create plateVinRegistry
    await conn.execute(`CREATE TABLE IF NOT EXISTS plateVinRegistry (
      id INT AUTO_INCREMENT PRIMARY KEY,
      plateNumber VARCHAR(20) NOT NULL, vin VARCHAR(50),
      make VARCHAR(255) NOT NULL, model VARCHAR(255) NOT NULL,
      year INT, engineCode VARCHAR(100), engineCapacity VARCHAR(50),
      transmission VARCHAR(100), fuel VARCHAR(50),
      source VARCHAR(50) DEFAULT 'manual' NOT NULL,
      isVerified ENUM('yes','no','pending') DEFAULT 'no' NOT NULL,
      verifiedBy INT, verifiedAt TIMESTAMP NULL,
      lastCheckedAt TIMESTAMP NULL, lastFilledAt TIMESTAMP NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
      notes TEXT,
      INDEX idx_plate (plateNumber), INDEX idx_vin (vin)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

    // Create aiAgentResults
    await conn.execute(`CREATE TABLE IF NOT EXISTS aiAgentResults (
      id INT AUTO_INCREMENT PRIMARY KEY,
      make VARCHAR(255) NOT NULL, model VARCHAR(255) NOT NULL,
      generation VARCHAR(500), modification VARCHAR(500), engineCode VARCHAR(100),
      agentName VARCHAR(100) NOT NULL, agentProvider VARCHAR(50) NOT NULL,
      filledFields JSON, filledCount INT DEFAULT 0,
      rawResponse TEXT, parsedJson JSON,
      tokensInput INT DEFAULT 0, tokensOutput INT DEFAULT 0, tokensTotal INT DEFAULT 0,
      status ENUM('success','error','empty') DEFAULT 'success' NOT NULL,
      errorMessage TEXT, checkedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      filledAt TIMESTAMP NULL, durationMs INT DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
      INDEX idx_car (make, model), INDEX idx_agent (agentProvider)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

    conn.release();
    await pool.end();
    console.log("[Boot] Database schema verified");
  } catch (e: any) {
    console.warn("[Boot] Schema check (non-critical):", e.message);
  }
})();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.get(Paths.oauthCallback, createOAuthCallbackHandler());
// Serve uploaded PDF manuals
import fs from "fs";
import path from "path";

app.use("/uploads/manuals/*", async (c) => {
  const filePath = path.join(process.cwd(), "uploads", "manuals", c.req.path.replace("/uploads/manuals/", ""));
  if (fs.existsSync(filePath)) {
    const buffer = fs.readFileSync(filePath);
    return c.body(buffer, 200, { "Content-Type": "application/pdf" });
  }
  return c.json({ error: "PDF not found" }, 404);
});

app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

// ─── Health check endpoint ───
app.get("/health", async (c) => {
  // Check DB
  let dbStatus = "unknown";
  try {
    const { getDbStatus } = await import("./queries/connection");
    const status = getDbStatus();
    dbStatus = status.connected ? "connected" : "disconnected";
  } catch {
    dbStatus = "error";
  }

  return c.json({
    status: "ok",
    version: "v115",
    time: new Date().toISOString(),
    uptime: process.uptime(),
    db: dbStatus,
  });
});

// ─── Global error handler ───
app.onError((err, c) => {
  console.error(`[Server Error] ${c.req.method} ${c.req.path}:`, err);
  return c.json({ error: "Internal server error", message: env.isProduction ? undefined : err.message }, 500);
});

// ─── Start server ───
if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);

    // Start background drom.ru monitoring
    try {
      const { startBackgroundMonitoring } = require("./agents/dromParser");
      startBackgroundMonitoring();
    } catch (e: any) {
      console.warn("[Boot] Could not start drom monitoring:", e.message);
    }
  });
} else {
  // Dev mode — just export app for Vite plugin
  console.log("[Boot] Dev mode — server handled by Vite plugin");
}
