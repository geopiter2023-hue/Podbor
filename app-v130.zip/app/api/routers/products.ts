import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { products } from "@db/schema";
import { eq, desc, sql, like, and } from "drizzle-orm";

export const productsRouter = createRouter({
  // ─── List products (public) ───
  list: publicQuery
    .input(z.object({
      category: z.string().optional(),
      brand: z.string().optional(),
      search: z.string().optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const limit = input?.limit || 50;
      const offset = input?.offset || 0;

      let conditions = [];
      if (input?.category) conditions.push(eq(products.category, input.category));
      if (input?.brand) conditions.push(eq(products.brand, input.brand));
      if (input?.search) {
        conditions.push(sql`(${products.name} LIKE ${"%" + input.search + "%"} OR ${products.brand} LIKE ${"%" + input.search + "%"})`);
      }

      const where = conditions.length > 0 ? and(...conditions) : undefined;

      const items = where
        ? await db.select().from(products).where(where).limit(limit).offset(offset)
        : await db.select().from(products).limit(limit).offset(offset);

      const countResult = where
        ? await db.select({ count: sql<number>`COUNT(*)` }).from(products).where(where)
        : await db.select({ count: sql<number>`COUNT(*)` }).from(products);

      return { items, total: countResult[0]?.count || 0 };
    }),

  // ─── Get single product ───
  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [product] = await db.select().from(products).where(eq(products.slug, input.slug)).limit(1);
      return product || null;
    }),

  // ─── Get categories ───
  categories: publicQuery.query(async () => {
    const db = getDb();
    const result = await db.selectDistinct({ category: products.category }).from(products);
    return result.map((r) => r.category).filter(Boolean);
  }),

  // ─── Get brands ───
  brands: publicQuery.query(async () => {
    const db = getDb();
    const result = await db.selectDistinct({ brand: products.brand }).from(products);
    return result.map((r) => r.brand).filter(Boolean);
  }),

  // ─── Import many products (admin) ───
  importMany: adminQuery
    .input(z.object({
      items: z.array(z.object({
        name: z.string(),
        sku: z.string().optional(),
        brand: z.string().optional(),
        category: z.string().optional(),
        subcategory: z.string().optional(),
        description: z.string().optional(),
        price: z.number().optional(),
        oldPrice: z.number().optional(),
        volume: z.string().optional(),
        specs: z.any().optional(),
        imageUrl: z.string().optional(),
        inStock: z.string().optional(),
        badges: z.any().optional(),
        externalUrl: z.string().optional(),
      })),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      let inserted = 0;
      let errors = 0;

      for (const item of input.items) {
        try {
          const slug = item.name
            ?.toLowerCase()
            .replace(/[^a-z0-9\-]+/g, "-")
            .replace(/-+/g, "-")
            .substring(0, 255) || `product-${Date.now()}`;

          await db.insert(products).values({
            name: item.name,
            slug: slug + "-" + Math.random().toString(36).substring(2, 8),
            sku: item.sku || null,
            brand: item.brand || null,
            category: item.category || null,
            subcategory: item.subcategory || null,
            description: item.description || null,
            price: item.price || null,
            oldPrice: item.oldPrice || null,
            volume: item.volume || null,
            specs: item.specs || null,
            imageUrl: item.imageUrl || null,
            inStock: item.inStock || "yes",
            badges: item.badges || null,
            externalUrl: item.externalUrl || null,
            currency: "RUB",
            discountPercent: item.oldPrice && item.price
              ? Math.round(((item.oldPrice - item.price) / item.oldPrice) * 100)
              : null,
          });
          inserted++;
        } catch {
          errors++;
        }
      }

      return { inserted, errors };
    }),

  // ─── Filters (categories + brands) ───
  filters: publicQuery.query(async () => {
    const db = getDb();
    const categories = await db.selectDistinct({ category: products.category }).from(products);
    const brands = await db.selectDistinct({ brand: products.brand }).from(products);
    return {
      categories: categories.map((r) => r.category).filter(Boolean),
      brands: brands.map((r) => r.brand).filter(Boolean),
    };
  }),

  // ─── Seed demo products (public — auto-seed on first visit) ───
  seed: publicQuery.mutation(async () => {
    const db = getDb();

    // Check if products already exist
    const existing = await db.select({ count: sql<number>`COUNT(*)` }).from(products);
    if (existing[0].count > 0) {
      return { message: "Products already exist", count: existing[0].count };
    }

    const demoProducts = [
      {
        name: "Моторное масло LUKOIL GENESIS ARMORTECH 5W-30",
        sku: "LUK-5W30-GEN-4L",
        brand: "LUKOIL",
        category: "motor-oil",
        subcategory: "Синтетическое",
        description: "Синтетическое моторное масло для бензиновых и дизельных двигателей. API SN/CF, ACEA A3/B4.",
        price: 249900,
        oldPrice: 319900,
        volume: "4 л",
        specs: JSON.stringify({ viscosity: "5W-30", api: "API SN/CF", acea: "A3/B4", volume: "4л" }),
        imageUrl: "https://lukoil.ru/produkt/img/genesis-armortech-5w30.png",
        inStock: "yes",
        badges: JSON.stringify(["Распродажа", "-22%"]),
        rating: "4.8",
        reviewsCount: 1247,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
      {
        name: "Моторное масло LUKOIL GENESIS CLARITECH 5W-40",
        sku: "LUK-5W40-CLA-4L",
        brand: "LUKOIL",
        category: "motor-oil",
        subcategory: "Синтетическое",
        description: "Синтетическое моторное масло для современных двигателей. API SN/CF, ACEA C3.",
        price: 279900,
        oldPrice: 349900,
        volume: "4 л",
        specs: JSON.stringify({ viscosity: "5W-40", api: "API SN/CF", acea: "C3", volume: "4л" }),
        imageUrl: "https://lukoil.ru/produkt/img/genesis-claritech-5w40.png",
        inStock: "yes",
        badges: JSON.stringify(["Хит"]),
        rating: "4.7",
        reviewsCount: 892,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
      {
        name: "Моторное масло LUKOIL SUPER 10W-40",
        sku: "LUK-10W40-SUP-4L",
        brand: "LUKOIL",
        category: "motor-oil",
        subcategory: "Полусинтетическое",
        description: "Полусинтетическое моторное масло. API SL/CF.",
        price: 129900,
        oldPrice: 159900,
        volume: "4 л",
        specs: JSON.stringify({ viscosity: "10W-40", api: "API SL/CF", volume: "4л" }),
        imageUrl: "https://lukoil.ru/produkt/img/super-10w40.png",
        inStock: "yes",
        badges: JSON.stringify(["0% в рассрочку"]),
        rating: "4.5",
        reviewsCount: 2103,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
      {
        name: "Моторное масло SHELL HELIX ULTRA 5W-30",
        sku: "SHL-5W30-ULT-4L",
        brand: "SHELL",
        category: "motor-oil",
        subcategory: "Синтетическое",
        description: "Полностью синтетическое моторное масло. API SN Plus, ACEA C3.",
        price: 399900,
        oldPrice: 499900,
        volume: "4 л",
        specs: JSON.stringify({ viscosity: "5W-30", api: "API SN+", acea: "C3", volume: "4л" }),
        imageUrl: "https://www.shell.ru/produkt/img/helix-ultra-5w30.png",
        inStock: "yes",
        badges: JSON.stringify(["Премиум"]),
        rating: "4.9",
        reviewsCount: 756,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
      {
        name: "Моторное масло CASTROL EDGE 5W-30",
        sku: "CST-5W30-EDG-4L",
        brand: "CASTROL",
        category: "motor-oil",
        subcategory: "Синтетическое",
        description: "Синтетическое моторное масло с технологией Titanium FST. API SN, ACEA C3.",
        price: 349900,
        oldPrice: 429900,
        volume: "4 л",
        specs: JSON.stringify({ viscosity: "5W-30", api: "API SN", acea: "C3", volume: "4л" }),
        imageUrl: "https://www.castrol.com/produkt/img/edge-5w30.png",
        inStock: "yes",
        badges: JSON.stringify(["Распродажа"]),
        rating: "4.7",
        reviewsCount: 934,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
      {
        name: "Масляный фильтр LUKOIL LF-01",
        sku: "LUK-LF01-FIL",
        brand: "LUKOIL",
        category: "filter",
        subcategory: "Масляный фильтр",
        description: "Высококачественный масляный фильтр для бензиновых двигателей.",
        price: 29900,
        oldPrice: 39900,
        volume: "1 шт",
        specs: JSON.stringify({ type: "Масляный", thread: "3/4-16 UNF" }),
        imageUrl: "https://lukoil.ru/produkt/img/filter-lf01.png",
        inStock: "yes",
        badges: JSON.stringify(["-25%"]),
        rating: "4.6",
        reviewsCount: 567,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
      {
        name: "Воздушный фильтр LUKOIL AF-02",
        sku: "LUK-AF02-FIL",
        brand: "LUKOIL",
        category: "filter",
        subcategory: "Воздушный фильтр",
        description: "Воздушный фильтр высокой степени очистки.",
        price: 24900,
        oldPrice: null,
        volume: "1 шт",
        specs: JSON.stringify({ type: "Воздушный" }),
        imageUrl: "https://lukoil.ru/produkt/img/filter-af02.png",
        inStock: "yes",
        badges: JSON.stringify([]),
        rating: "4.4",
        reviewsCount: 321,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
      {
        name: "Трансмиссионное масло LUKOIL ATF SYNTH 75W-90",
        sku: "LUK-ATF-75W90-1L",
        brand: "LUKOIL",
        category: "transmission",
        subcategory: "Трансмиссионное",
        description: "Синтетическое трансмиссионное масло для МКПП. API GL-4/GL-5.",
        price: 89900,
        oldPrice: 109900,
        volume: "1 л",
        specs: JSON.stringify({ viscosity: "75W-90", api: "GL-4/GL-5", volume: "1л" }),
        imageUrl: "https://lukoil.ru/produkt/img/atf-75w90.png",
        inStock: "yes",
        badges: JSON.stringify(["Распродажа"]),
        rating: "4.7",
        reviewsCount: 445,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
      {
        name: "Тормозная жидкость LUKOIL DOT 4",
        sku: "LUK-DOT4-0.5L",
        brand: "LUKOIL",
        category: "transmission",
        subcategory: "Тормозная жидкость",
        description: "Тормозная жидкость на основе гликолевых эфиров. DOT 4.",
        price: 34900,
        oldPrice: null,
        volume: "0.5 л",
        specs: JSON.stringify({ type: "DOT 4", volume: "0.5л" }),
        imageUrl: "https://lukoil.ru/produkt/img/dot4.png",
        inStock: "yes",
        badges: JSON.stringify([]),
        rating: "4.5",
        reviewsCount: 289,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
      {
        name: "Антифриз LUKOIL G12+ RED",
        sku: "LUK-G12-RED-5L",
        brand: "LUKOIL",
        category: "transmission",
        subcategory: "Антифриз",
        description: "Карбоксилатный антифриз красного цвета. G12+.",
        price: 59900,
        oldPrice: 74900,
        volume: "5 л",
        specs: JSON.stringify({ type: "G12+", color: "Красный", volume: "5л" }),
        imageUrl: "https://lukoil.ru/produkt/img/g12-red.png",
        inStock: "yes",
        badges: JSON.stringify(["-20%"]),
        rating: "4.6",
        reviewsCount: 678,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
      {
        name: "Салонный фильтр LUKOIL CF-03",
        sku: "LUK-CF03-FIL",
        brand: "LUKOIL",
        category: "filter",
        subcategory: "Салонный фильтр",
        description: "Угольный салонный фильтр с высокой степенью очистки.",
        price: 19900,
        oldPrice: null,
        volume: "1 шт",
        specs: JSON.stringify({ type: "Салонный", carbon: "Да" }),
        imageUrl: "https://lukoil.ru/produkt/img/filter-cf03.png",
        inStock: "yes",
        badges: JSON.stringify([]),
        rating: "4.3",
        reviewsCount: 198,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
      {
        name: "Моторное масло MOBIL 1 ESP 5W-30",
        sku: "MOB-5W30-ESP-4L",
        brand: "MOBIL",
        category: "motor-oil",
        subcategory: "Синтетическое",
        description: "Синтетическое моторное масло для дизельных двигателей. API SN, ACEA C2/C3.",
        price: 459900,
        oldPrice: 579900,
        volume: "4 л",
        specs: JSON.stringify({ viscosity: "5W-30", api: "API SN", acea: "C2/C3", volume: "4л" }),
        imageUrl: "https://www.mobil.com/produkt/img/mobil1-esp-5w30.png",
        inStock: "yes",
        badges: JSON.stringify(["Премиум", "-21%"]),
        rating: "4.8",
        reviewsCount: 523,
        deliveryText: "Завтра",
        isOriginal: "yes",
      },
    ];

    let inserted = 0;
    for (const p of demoProducts) {
      try {
        const slug = p.name.toLowerCase().replace(/[^a-z0-9\-]+/g, "-").replace(/-+/g, "-").substring(0, 200) + "-" + Math.random().toString(36).substring(2, 6);
        await db.insert(products).values({
          ...p,
          slug,
          currency: "RUB",
          discountPercent: p.oldPrice ? Math.round(((p.oldPrice - p.price) / p.oldPrice) * 100) : null,
        });
        inserted++;
      } catch (e: any) {
        console.warn("[Seed] Failed:", e.message);
      }
    }

    return { message: `Inserted ${inserted} demo products`, count: inserted };
  }),

  // ─── Delete all products (admin) ───
  clearAll: adminQuery.mutation(async () => {
    const db = getDb();
    await db.delete(products);
    return { success: true };
  }),
});
