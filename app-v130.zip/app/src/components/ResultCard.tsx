import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { FileDown, Droplets, Thermometer, Settings, Disc, Car, Bot, User, ShoppingCart, Star, Heart, Truck, Check } from "lucide-react";
import { AiAgentDetails } from "./AiAgentDetails";
import { ManualDataEntry } from "./ManualDataEntry";

interface ResultCardProps {
  car: {
    make?: string;
    model?: string;
    generation?: string;
    modification?: string;
    year?: string;
    engineCapacity?: string;
    powerHp?: string;
    fuel?: string;
    transmission?: string;
    vin?: string;
  };
  specs?: Record<string, any>;
}

const TABS = [
  { key: "engine", label: "Двигатель", icon: Droplets },
  { key: "cooling", label: "Охлаждение", icon: Thermometer },
  { key: "transmission", label: "КПП", icon: Settings },
  { key: "brakes", label: "Тормоза", icon: Disc },
  { key: "agents", label: "ИИ Агенты", icon: Bot },
  { key: "manual", label: "Ручной ввод", icon: User },
];

export default function ResultCard({ car, specs }: ResultCardProps) {
  const [activeTab, setActiveTab] = useState("engine");
  const [generating, setGenerating] = useState(false);

  const { data: matchedProducts } = trpc.matching.forCar.useQuery(
    { make: car.make || "", model: car.model || "" },
    { enabled: !!(car.make && car.model) }
  );

  // Get shop products filtered by oil specs
  const oilSae = specs?.prefOilSae || specs?.oilSae || "";
  const oilApi = specs?.prefOilApi || specs?.oilApi || "";
  const { data: shopProducts } = trpc.products.list.useQuery(
    {
      category: "motor-oil",
      search: oilSae ? `${oilSae} ${oilApi}`.trim() : undefined,
      limit: 8,
    },
    { enabled: !!(car.make && car.model) }
  );

  const generatePdf = trpc.pdf.generateLubricationCard.useMutation({
    onSuccess: (data) => {
      setGenerating(false);
      // Download PDF
      const byteCharacters = atob(data.pdfBase64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = data.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    },
    onError: () => setGenerating(false),
  });

  const handleDownload = () => {
    setGenerating(true);
    generatePdf.mutate({
      make: car.make || "",
      model: car.model || "",
      vin: car.vin,
      generation: car.generation,
      modification: car.modification,
      year: car.year,
      engineCapacity: car.engineCapacity,
      power: car.powerHp,
      fuel: car.fuel,
      transmission: car.transmission,
    });
  };

  const carInfoRows = [
    { label: "Марка", value: car.make },
    { label: "Модель", value: car.model },
    { label: "Поколение", value: car.generation },
    { label: "Модификация", value: car.modification },
    { label: "Объём ДВС", value: car.engineCapacity },
    { label: "Мощность", value: car.powerHp },
    { label: "Топливо", value: car.fuel },
    { label: "Трансмиссия", value: car.transmission },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case "engine":
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
              <span className="text-sm font-medium text-gray-700">Заправочный объём</span>
              <span className="text-sm font-bold text-[#d32f2f]">{specs?.engineOil || specs?.engineOilCapacity || "—"}</span>
            </div>
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
              <span className="text-sm font-medium text-gray-700">Уровень сложности замены</span>
              <span className="text-sm text-amber-600">★★☆☆☆</span>
            </div>
            <h4 className="text-sm font-semibold text-gray-800 mt-4 mb-2">Рекомендуемые моторные масла</h4>
            {matchedProducts?.engineOil && matchedProducts.engineOil.length > 0 ? (
              <div className="space-y-2">
                {matchedProducts.engineOil.map((p: any, i: number) => (
                  <div key={i} className="border border-gray-200 rounded-lg p-3 hover:border-[#d32f2f] transition-colors">
                    <p className="text-sm font-bold text-[#d32f2f]">{p.name}</p>
                    <p className="text-xs text-gray-500 mt-1">{p.description || `Моторное масло ${p.brand}`}</p>
                    <p className="text-xs text-gray-600 mt-1">SAE: {typeof p.specs === "string" ? JSON.parse(p.specs).sae : p.specs?.sae || "—"} | Объём: {p.volume || "—"}</p>
                    {p.price && <p className="text-sm font-bold text-gray-800 mt-1">{(p.price / 100).toLocaleString("ru-RU")} ₽</p>}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-400 italic">Продукты загружаются...</p>
            )}
          </div>
        );
      case "cooling":
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
              <span className="text-sm font-medium text-gray-700">Заправочный объём</span>
              <span className="text-sm font-bold text-[#d32f2f]">{specs?.coolantVolume || "—"}</span>
            </div>
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
              <span className="text-sm font-medium text-gray-700">Уровень сложности замены</span>
              <span className="text-sm text-amber-600">★★★☆☆</span>
            </div>
            <div className="bg-blue-50 rounded-lg p-3">
              <span className="text-sm font-medium text-blue-800">Рекомендуемый тип антифриза: </span>
              <span className="text-sm font-bold text-blue-800">{specs?.coolantType || "—"}</span>
            </div>
            {matchedProducts?.coolant && matchedProducts.coolant.length > 0 && (
              <div className="space-y-2 mt-3">
                {matchedProducts.coolant.map((p: any, i: number) => (
                  <div key={i} className="border border-gray-200 rounded-lg p-3">
                    <p className="text-sm font-bold text-[#d32f2f]">{p.name}</p>
                    <p className="text-xs text-gray-500 mt-1">Объём: {p.volume || "—"}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      case "transmission":
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
              <span className="text-sm font-medium text-gray-700">Заправочный объём</span>
              <span className="text-sm font-bold text-[#d32f2f]">{specs?.transmissionOilVolume || "—"}</span>
            </div>
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
              <span className="text-sm font-medium text-gray-700">Уровень сложности замены</span>
              <span className="text-sm text-amber-600">★★★★☆</span>
            </div>
            <div className="bg-blue-50 rounded-lg p-3">
              <span className="text-sm font-medium text-blue-800">Тип трансмиссии: </span>
              <span className="text-sm font-bold text-blue-800">{car.transmission || specs?.transmissionType || "—"}</span>
            </div>
            {matchedProducts?.transmissionOil && matchedProducts.transmissionOil.length > 0 && (
              <div className="space-y-2 mt-3">
                {matchedProducts.transmissionOil.map((p: any, i: number) => (
                  <div key={i} className="border border-gray-200 rounded-lg p-3">
                    <p className="text-sm font-bold text-[#d32f2f]">{p.name}</p>
                    <p className="text-xs text-gray-500 mt-1">Объём: {p.volume || "—"}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      case "brakes":
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
              <span className="text-sm font-medium text-gray-700">Заправочный объём</span>
              <span className="text-sm font-bold text-[#d32f2f]">{specs?.brakeFluidVolume || "—"}</span>
            </div>
            <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
              <span className="text-sm font-medium text-gray-700">Уровень сложности замены</span>
              <span className="text-sm text-amber-600">★☆☆☆☆</span>
            </div>
            <div className="bg-blue-50 rounded-lg p-3">
              <span className="text-sm font-medium text-blue-800">Рекомендуемая жидкость: </span>
              <span className="text-sm font-bold text-blue-800">{specs?.brakeFluidType || "DOT 4"}</span>
            </div>
            {matchedProducts?.brakeFluid && matchedProducts.brakeFluid.length > 0 && (
              <div className="space-y-2 mt-3">
                {matchedProducts.brakeFluid.map((p: any, i: number) => (
                  <div key={i} className="border border-gray-200 rounded-lg p-3">
                    <p className="text-sm font-bold text-[#d32f2f]">{p.name}</p>
                    <p className="text-xs text-gray-500 mt-1">Объём: {p.volume || "—"}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      case "agents":
        return (
          <div className="space-y-4">
            <AiAgentDetails make={car.make || ""} model={car.model || ""} />
          </div>
        );
      case "manual":
        return (
          <ManualDataEntry
            make={car.make || ""}
            model={car.model || ""}
            generation={car.generation}
            modification={car.modification}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
      {/* Header with car photo placeholder */}
      <div className="bg-gradient-to-r from-[#f8f8f8] to-[#f0f0f0] p-4">
        <div className="flex items-start gap-4">
          <div className="w-24 h-24 bg-gray-200 rounded-lg flex items-center justify-center flex-shrink-0">
            <Car className="w-12 h-12 text-gray-400" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-bold text-[#1a1a1a]">{car.make} {car.model}</h3>
            <p className="text-sm text-gray-500">{car.generation || ""} {car.modification || ""}</p>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 mt-2">
              {carInfoRows.filter((r) => r.value).map((row) => (
                <div key={row.label} className="flex items-center gap-1">
                  <span className="text-xs text-gray-400">{row.label}:</span>
                  <span className="text-xs font-medium text-gray-700">{row.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Download button */}
      <div className="px-4 py-3 border-b border-gray-100 bg-gray-50">
        <button
          onClick={handleDownload}
          disabled={generating}
          className="w-full bg-[#d32f2f] text-white py-2.5 rounded-lg text-sm font-medium hover:bg-[#b71c1c] disabled:opacity-50 flex items-center justify-center gap-2 transition-colors"
        >
          {generating ? (
            <span className="animate-pulse">Формирование PDF...</span>
          ) : (
            <><FileDown className="w-4 h-4" /> Скачать карту смазок</>
          )}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200 overflow-x-auto">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-1.5 px-4 py-3 text-xs font-medium whitespace-nowrap border-b-2 transition-colors ${
                activeTab === tab.key
                  ? "border-[#d32f2f] text-[#d32f2f] bg-red-50"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div className="p-4">
        {renderTabContent()}
      </div>

      {/* Shop block — recommended products */}
      {shopProducts?.items && shopProducts.items.length > 0 && (
        <div className="border-t border-gray-200 p-4 bg-gray-50">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-bold text-gray-800 flex items-center gap-2">
              <ShoppingCart className="w-4 h-4 text-[#d32f2f]" />
              Рекомендуемые товары для {car.make} {car.model}
            </h4>
            <a href="/marketplace" className="text-xs text-[#005bff] hover:underline">Все товары →</a>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {shopProducts.items.slice(0, 8).map((product: any) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ProductCard({ product }: { product: any }) {
  const [liked, setLiked] = useState(false);
  const price = product.price ? (product.price / 100).toLocaleString("ru-RU") + " ₽" : "";
  const oldPrice = product.oldPrice ? (product.oldPrice / 100).toLocaleString("ru-RU") + " ₽" : "";
  const badges: string[] = product.badges ? (typeof product.badges === "string" ? JSON.parse(product.badges) : product.badges) : [];
  const specs = product.specs ? (typeof product.specs === "string" ? JSON.parse(product.specs) : product.specs) : {};

  return (
    <div className="bg-white rounded-xl border border-gray-100 overflow-hidden hover:shadow-lg transition-shadow group">
      <div className="relative bg-gray-100 aspect-[3/4] overflow-hidden">
        <img
          src={product.imageUrl || "/placeholder.jpg"}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
          loading="lazy"
        />
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {badges.map((badge: string, i: number) => (
            <span key={i} className={`text-[10px] font-bold px-2 py-0.5 rounded ${badge.includes("Распродажа") ? "bg-[#f91155] text-white" : badge.includes("0%") ? "bg-[#00d009] text-white" : "bg-[#005bff] text-white"}`}>
              {badge}
            </span>
          ))}
        </div>
        <button onClick={() => setLiked(!liked)} className="absolute top-2 right-2 w-8 h-8 bg-white/80 rounded-full flex items-center justify-center">
          <Heart className={`w-4 h-4 ${liked ? "fill-red-500 text-red-500" : "text-gray-500"}`} />
        </button>
        {product.isOriginal === "yes" && (
          <div className="absolute bottom-2 left-2 flex items-center gap-1 bg-white/90 px-2 py-0.5 rounded-full text-[10px] text-green-700">
            <Check className="w-3 h-3" />Оригинал
          </div>
        )}
      </div>
      <div className="p-3">
        <div className="flex items-baseline gap-2 mb-1">
          <span className="text-lg font-bold text-gray-900">{price}</span>
          {oldPrice && <span className="text-sm text-gray-400 line-through">{oldPrice}</span>}
        </div>
        {product.discountPercent && <span className="text-[11px] font-medium text-[#f91155]">-{product.discountPercent}%</span>}
        <div className="flex items-center gap-1 mt-1 mb-1.5">
          <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
          <span className="text-sm font-medium text-gray-800">{product.rating || "4.5"}</span>
          <span className="text-xs text-gray-400">{product.reviewsCount || 0} отзывов</span>
        </div>
        <h3 className="text-sm text-gray-800 leading-tight line-clamp-2 mb-2">{product.name}</h3>
        {specs.viscosity && (
          <div className="flex flex-wrap gap-1 mb-2">
            <span className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{specs.viscosity}</span>
            {specs.api && <span className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{specs.api}</span>}
          </div>
        )}
        <div className="flex items-center gap-1 text-[11px] text-gray-500">
          <Truck className="w-3 h-3" />{product.deliveryText || "Завтра"}
        </div>
      </div>
    </div>
  );
}
