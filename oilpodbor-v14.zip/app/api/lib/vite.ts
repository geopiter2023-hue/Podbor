import type { Hono } from "hono";
import type { HttpBindings } from "@hono/node-server";
import { serveStatic } from "@hono/node-server/serve-static";
import fs from "fs";
import path from "path";

type App = Hono<{ Bindings: HttpBindings }>;

export function serveStaticFiles(app: App) {
  // Absolute path to dist/public (works regardless of cwd)
  const distPath = path.resolve(import.meta.dirname, "../dist/public");

  console.log("[serveStatic] distPath:", distPath);
  console.log("[serveStatic] index.html exists:", fs.existsSync(path.join(distPath, "index.html")));

  // Serve static files from absolute path
  app.use("*", serveStatic({ root: distPath }));

  // SPA fallback: return index.html for all non-API, non-asset routes
  app.notFound((c) => {
    const accept = c.req.header("accept") ?? "";
    const url = c.req.url;

    console.log("[notFound] URL:", url, "accept:", accept);

    // Don't interfere with API routes
    if (url.startsWith("/api/")) {
      return c.json({ error: "API Not Found" }, 404);
    }

    // For HTML requests or root paths, serve index.html
    if (accept.includes("text/html") || !accept) {
      const indexPath = path.join(distPath, "index.html");
      if (fs.existsSync(indexPath)) {
        const content = fs.readFileSync(indexPath, "utf-8");
        return c.html(content);
      }
      return c.json({ error: "index.html not found at " + indexPath }, 500);
    }

    return c.json({ error: "Not Found" }, 404);
  });
}
