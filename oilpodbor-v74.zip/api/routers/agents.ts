import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { aiAgents, aiTasks, cars, carFluidSpecs, aiLogs } from "@db/schema";
import { eq, desc, sql, and, like, isNull } from "drizzle-orm";
import { runResearcher } from "../agents/researcher";
import { runCarCatalogParser } from "../agents/carCatalogParser";
import { runManualFinder } from "../agents/manualFinder";

export const agentsRouter = createRouter({
  // ─── List all agents ───
  list: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(aiAgents).orderBy(aiAgents.id);
  }),

  // ─── Get agent by ID with tasks ───
  getById: adminQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [agent] = await db.select().from(aiAgents).where(eq(aiAgents.id, input.id)).limit(1);
      if (!agent) return null;
      const tasks = await db.select().from(aiTasks).where(eq(aiTasks.agentId, input.id)).orderBy(desc(aiTasks.createdAt)).limit(20);
      return { ...agent, tasks };
    }),

  // ─── Update agent settings ───
  update: adminQuery
    .input(z.object({
      id: z.number(),
      isActive: z.enum(["active", "paused", "error"]).optional(),
      schedule: z.string().optional(),
      config: z.record(z.any()).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(aiAgents).set(data).where(eq(aiAgents.id, id));
      return { success: true };
    }),

  // ─── Run specific agent by slug ───
  runBySlug: adminQuery
    .input(z.object({
      slug: z.string(),
      payload: z.record(z.any()).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();

      // Find agent
      const [agent] = await db.select().from(aiAgents).where(eq(aiAgents.slug, input.slug)).limit(1);
      if (!agent) throw new Error(`Agent "${input.slug}" not found`);

      // Create task
      const [task] = await db.insert(aiTasks).values({
        agentId: agent.id,
        status: "running",
        payload: input.payload ? JSON.stringify(input.payload) : null,
        startedAt: new Date(),
      }).$returningId();

      const payload = input.payload || {};
      let result: any = {};

      try {
        switch (agent.slug) {
          case "catalog-parser": {
            // Parse TOmodifications → cars
            const parserResult = await runCarCatalogParser({
              makeId: payload.makeId ? parseInt(payload.makeId) : undefined,
              limit: payload.limit ? parseInt(payload.limit) : 100,
            });
            result = parserResult;
            break;
          }

          case "oil-researcher": {
            if (!payload.make || !payload.model) throw new Error("make и model обязательны");
            result = await runResearcher({
              make: payload.make,
              model: payload.model,
              engineCode: payload.engineCode,
              year: payload.year ? parseInt(payload.year) : undefined,
            }, task.id);
            break;
          }

          case "transmission-researcher": {
            if (!payload.make || !payload.model) throw new Error("make и model обязательны");
            result = await runResearcher({
              make: payload.make,
              model: payload.model,
              engineCode: payload.engineCode,
              year: payload.year ? parseInt(payload.year) : undefined,
            }, task.id);
            // Mark which columns this agent fills
            result.agentType = "transmission";
            result.columns = [
              "transmissionType", "transmissionGears", "transmissionCode",
              "transmissionFillVolume", "transmissionPrefOil", "transmissionReplaceInterval",
              "transferCaseCode", "transferCaseFillVolume", "transferCaseOil",
              "frontDiffCode", "frontDiffFillVolume", "frontDiffOil",
              "rearDiffCode", "rearDiffFillVolume", "rearDiffOil",
            ];
            break;
          }

          case "fluids-researcher": {
            if (!payload.make || !payload.model) throw new Error("make и model обязательны");
            result = await runResearcher({
              make: payload.make,
              model: payload.model,
              engineCode: payload.engineCode,
              year: payload.year ? parseInt(payload.year) : undefined,
            }, task.id);
            result.agentType = "fluids";
            result.columns = [
              "coolantFillVolume", "coolantType", "coolantInterval",
              "brakeFluidVolume", "brakeFluidType", "brakeFluidInterval",
              "psFluidVolume", "psFluidType",
              "suspFluidVolume", "suspFluidType",
              "adblueVolume", "adblueType",
            ];
            break;
          }

          case "filters-researcher": {
            if (!payload.make || !payload.model) throw new Error("make и model обязательны");
            result = await runResearcher({
              make: payload.make,
              model: payload.model,
              engineCode: payload.engineCode,
              year: payload.year ? parseInt(payload.year) : undefined,
            }, task.id);
            result.agentType = "filters";
            result.columns = ["oilFilter", "airFilter", "cabinFilter", "fuelFilter", "transmissionFilter"];
            break;
          }

          case "manual-finder": {
            if (!payload.make || !payload.model) throw new Error("make и model обязательны");
            result = await runManualFinder({
              make: payload.make,
              model: payload.model,
              year: payload.year ? parseInt(payload.year) : undefined,
              generation: payload.generation,
              modification: payload.modification,
            }, taskId);
            break;
          }

          default:
            throw new Error(`Unknown agent slug: ${agent.slug}`);
        }

        // Update agent stats
        await db.update(aiAgents).set({
          lastRunAt: new Date(),
          lastRunStatus: result.success ? "success" : (result.skipped ? "success" : "error"),
          lastRunResult: JSON.stringify(result).substring(0, 500),
          runsTotal: sql`${aiAgents.runsTotal} + 1`,
          runsSuccess: result.success ? sql`${aiAgents.runsSuccess} + 1` : aiAgents.runsSuccess,
          runsError: !result.success && !result.skipped ? sql`${aiAgents.runsError} + 1` : aiAgents.runsError,
          itemsProcessed: result.inserted || result.recordId ? sql`${aiAgents.itemsProcessed} + 1` : aiAgents.itemsProcessed,
        }).where(eq(aiAgents.id, agent.id));

        // Update task
        await db.update(aiTasks).set({
          status: result.success || result.skipped ? "completed" : "failed",
          result: JSON.stringify(result).substring(0, 1000),
          completedAt: new Date(),
          itemsProcessed: result.inserted || (result.recordId ? 1 : 0),
        }).where(eq(aiTasks.id, task.id));

        return { success: true, result, taskId: task.id };

      } catch (e: any) {
        await db.update(aiTasks).set({
          status: "failed",
          errorMessage: e.message,
          completedAt: new Date(),
        }).where(eq(aiTasks.id, task.id));

        await db.update(aiAgents).set({
          lastRunStatus: "error",
          lastRunResult: e.message,
          runsError: sql`${aiAgents.runsError} + 1`,
        }).where(eq(aiAgents.id, agent.id));

        throw e;
      }
    }),

  // ─── Run researcher agent (legacy) ───
  research: adminQuery
    .input(z.object({
      make: z.string(),
      model: z.string(),
      engineCode: z.string().optional(),
      year: z.number().optional(),
      body: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      return runResearcher(input);
    }),

  // ─── Run batch research (legacy) ───
  researchBatch: adminQuery
    .input(z.object({
      make: z.string().optional(),
      model: z.string().optional(),
      limit: z.number().min(1).max(50).default(10),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      // Find cars without fluid specs
      const carsNeedingData = await db
        .selectDistinct({
          make: cars.make,
          model: cars.model,
          engineCode: cars.engineCode,
        })
        .from(cars)
        .where(
          and(
            input.make ? like(cars.make, `%${input.make}%`) : sql`1=1`,
            input.model ? like(cars.model, `%${input.model}%`) : sql`1=1`,
          )
        )
        .limit(input.limit);

      const results = [];
      for (const car of carsNeedingData) {
        if (!car.make || !car.model) continue;
        const res = await runResearcher({
          make: car.make,
          model: car.model,
          engineCode: car.engineCode || undefined,
        });
        results.push({ car: `${car.make} ${car.model}`, ...res });
      }

      return { processed: results.length, results };
    }),

  // ─── Get cars missing data (for batch processing) ───
  missingData: adminQuery
    .input(z.object({
      agentSlug: z.string(),
      make: z.string().optional(),
      limit: z.number().default(50),
      yearFrom: z.number().optional(),
      yearTo: z.number().optional(),
    }))
    .query(async ({ input }) => {
      const db = getDb();

      // Hardcoded columns per agent (works even without aiAgents table)
      const AGENT_COLUMNS: Record<string, string[]> = {
        "oil-researcher": ["prefOilSae", "prefOilApi", "prefOilAcea", "prefOilOe", "altOilViscosities"],
        "transmission-researcher": ["transmissionType", "transmissionPrefOil", "transferCaseOil", "frontDiffOil", "rearDiffOil"],
        "fluids-researcher": ["coolantType", "brakeFluidType", "psFluidType", "suspFluidType", "adblueVolume"],
        "filters-researcher": ["oilFilter", "airFilter", "cabinFilter", "fuelFilter", "transmissionFilter"],
      };

      // Try to get from aiAgents table first, fallback to hardcoded
      let columns: string[] = AGENT_COLUMNS[input.agentSlug] || [];
      try {
        const [agent] = await db.select().from(aiAgents).where(eq(aiAgents.slug, input.agentSlug)).limit(1);
        if (agent) {
          const config = typeof agent.config === "string" ? JSON.parse(agent.config) : agent.config;
          if (config?.columns?.length > 0) {
            columns = config.columns.map((c: any) => c.db || c);
          }
        }
      } catch {
        // aiAgents table doesn't exist, use hardcoded
      }

      // Get cars from catalog that don't have data in carFluidSpecs for these columns
      // Strategy: get cars from cars table, left join with carFluidSpecs, filter where data is missing
      const existingMakes = new Set<string>();
      try {
        const existing = await db
          .selectDistinct({ make: carFluidSpecs.make, model: carFluidSpecs.model })
          .from(carFluidSpecs)
          .where(eq(carFluidSpecs.isActive, "active"))
          .limit(10000);
        existing.forEach((e) => { if (e.make && e.model) existingMakes.add(`${e.make}|${e.model}`); });
      } catch {
        // carFluidSpecs might be empty
      }

      // Get ALL cars from main catalog (no limit yet!)
      let conditions: any[] = [eq(cars.isActive, "active")];
      if (input.make) {
        conditions.push(like(cars.make, `%${input.make}%`));
      }
      // Year filter: car's year range overlaps with selected range
      if (input.yearFrom !== undefined) {
        conditions.push(sql`${cars.yearTo} >= ${input.yearFrom}`);
      }
      if (input.yearTo !== undefined) {
        conditions.push(sql`${cars.yearFrom} <= ${input.yearTo}`);
      }

      const allCars = await db
        .selectDistinct({
          make: cars.make,
          model: cars.model,
          modification: cars.modification,
          engineCode: cars.engineCode,
        })
        .from(cars)
        .where(and(...conditions));

      // Filter out cars that already have data, THEN apply limit
      const toProcess = allCars
        .filter((c) => c.make && c.model && !existingMakes.has(`${c.make}|${c.model}`))
        .slice(0, input.limit);

      return toProcess;
    }),

  // ─── Create task (run generic agent) ───
  run: adminQuery
    .input(z.object({
      agentId: z.number(),
      payload: z.record(z.any()).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(aiTasks).values({
        agentId: input.agentId,
        status: "queued",
        payload: input.payload ? JSON.stringify(input.payload) : null,
      }).$returningId();
      return { taskId: result.id };
    }),

  // ─── Get tasks list ───
  tasks: adminQuery
    .input(z.object({
      agentId: z.number().optional(),
      limit: z.number().default(50),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const query = input?.agentId
        ? db.select().from(aiTasks).where(eq(aiTasks.agentId, input.agentId)).orderBy(desc(aiTasks.createdAt)).limit(input.limit)
        : db.select().from(aiTasks).orderBy(desc(aiTasks.createdAt)).limit(input?.limit || 50);
      return query;
    }),

  // ─── Get AI research logs (debug) ───
  logs: adminQuery
    .input(z.object({
      make: z.string().optional(),
      model: z.string().optional(),
      limit: z.number().default(50),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      try {
        let query = db.select().from(aiLogs).orderBy(desc(aiLogs.createdAt)).limit(input?.limit || 50);
        const conditions = [];
        if (input?.make) conditions.push(like(aiLogs.make, `%${input.make}%`));
        if (input?.model) conditions.push(like(aiLogs.model, `%${input.model}%`));
        if (conditions.length > 0) {
          query = query.where(and(...conditions)) as any;
        }
        return await query;
      } catch {
        // aiLogs table may not exist
        return [];
      }
    }),

  // ─── Run batch fill for all cars missing data ───
  fillAll: adminQuery
    .input(z.object({
      make: z.string().optional(),
      limit: z.number().min(1).max(100).default(10),
      skipExisting: z.boolean().default(true),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();

      // Get cars from catalog that don't have fluid specs yet
      const existingKeys = new Set<string>();
      if (input.skipExisting) {
        const existing = await db
          .select({ make: carFluidSpecs.make, model: carFluidSpecs.model })
          .from(carFluidSpecs)
          .where(eq(carFluidSpecs.isActive, "active"))
          .limit(10000);
        existing.forEach((e) => { if (e.make && e.model) existingKeys.add(`${e.make}|${e.model}`); });
      }

      // Get unique make+model from cars table
      let carQuery = db
        .selectDistinct({
          make: cars.make,
          model: cars.model,
          engineCode: cars.engineCode,
        })
        .from(cars)
        .where(eq(cars.isActive, "active"))
        .limit(input.limit * 2);

      if (input.make) {
        carQuery = carQuery.where(like(cars.make, `%${input.make}%`)) as any;
      }

      const allCars = await carQuery;

      // Filter out existing
      const toProcess = allCars
        .filter((c) => c.make && c.model && !existingKeys.has(`${c.make}|${c.model}`))
        .slice(0, input.limit);

      const results: any[] = [];
      for (const car of toProcess) {
        try {
          const res = await runResearcher({
            make: car.make!,
            model: car.model!,
            engineCode: car.engineCode || undefined,
          });
          results.push({ car: `${car.make} ${car.model}`, ...res });
          // Rate limit: 1.5s between requests
          await new Promise((r) => setTimeout(r, 1500));
        } catch (e: any) {
          results.push({ car: `${car.make} ${car.model}`, error: e.message });
        }
      }

      return {
        processed: results.length,
        totalInQueue: allCars.length,
        skipped: existingKeys.size,
        results,
      };
    }),

  // ─── Get stats ───
  stats: adminQuery.query(async () => {
    const db = getDb();
    const [totalAgents] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiAgents);
    const [activeAgents] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiAgents).where(eq(aiAgents.isActive, "active"));
    const [totalTasks] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiTasks);
    const [completedTasks] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiTasks).where(eq(aiTasks.status, "completed"));
    const [runningTasks] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiTasks).where(eq(aiTasks.status, "running"));
    const [failedTasks] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiTasks).where(eq(aiTasks.status, "failed"));

    return {
      agents: { total: totalAgents.count, active: activeAgents.count },
      tasks: { total: totalTasks.count, completed: completedTasks.count, running: runningTasks.count, failed: failedTasks.count },
    };
  }),
});
