/**
 * Logo Researcher — AI agent that finds car brand logos
 * Strategy: Search Wikipedia API → DuckDuckGo → fallback to placeholder
 */

import { getDb } from "../queries/connection";
import { brandLogos } from "@db/schema";
import { eq, sql } from "drizzle-orm";

interface LogoResult {
  brandName: string;
  logoUrl: string | null;
  status: "success" | "error";
  error?: string;
}

// ─── Wikipedia API — get logo from brand page ───
async function searchWikipedia(brand: string): Promise<string | null> {
  try {
    // Search for brand page
    const searchResp = await fetch(
      `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(brand + " car brand logo")}&format=json&origin=*`,
      { signal: AbortSignal.timeout(10000) }
    );
    if (!searchResp.ok) return null;
    const searchData = await searchResp.json();
    const title = searchData.query?.search?.[0]?.title;
    if (!title) return null;

    // Get page images
    const pageResp = await fetch(
      `https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(title)}&prop=pageimages&pithumbsize=300&format=json&origin=*`,
      { signal: AbortSignal.timeout(10000) }
    );
    if (!pageResp.ok) return null;
    const pageData = await pageResp.json();
    const pages = pageData.query?.pages;
    const page = pages ? Object.values(pages)[0] as any : null;
    return page?.thumbnail?.source || null;
  } catch {
    return null;
  }
}

// ─── DuckDuckGo image search via proxy ───
async function searchDuckDuckGo(brand: string): Promise<string | null> {
  try {
    // Use Wikimedia Commons directly
    const resp = await fetch(
      `https://commons.wikimedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(brand + " logo")}&srnamespace=6&format=json&origin=*`,
      { signal: AbortSignal.timeout(10000) }
    );
    if (!resp.ok) return null;
    const data = await resp.json();
    const result = data.query?.search?.[0];
    if (!result?.title) return null;

    // Get image URL
    const imgResp = await fetch(
      `https://commons.wikimedia.org/w/api.php?action=query&titles=${encodeURIComponent(result.title)}&prop=imageinfo&iiprop=url|thumburl&iiurlwidth=300&format=json&origin=*`,
      { signal: AbortSignal.timeout(10000) }
    );
    if (!imgResp.ok) return null;
    const imgData = await imgResp.json();
    const pages = imgData.query?.pages;
    const page = pages ? Object.values(pages)[0] as any : null;
    return page?.imageinfo?.[0]?.thumburl || page?.imageinfo?.[0]?.url || null;
  } catch {
    return null;
  }
}

// ─── Brand name mapping for carlogos.org ───
const BRAND_MAPPING: Record<string, string> = {
  "alfa romeo": "alfa-romeo",
  "aston martin": "aston-martin",
  "land rover": "land-rover",
  "rolls-royce": "rolls-royce",
  "mercedes-benz": "mercedes-benz",
  "mercedes": "mercedes-benz",
  "bmw": "bmw",
  "audi": "audi",
  "toyota": "toyota",
  "honda": "honda",
  "nissan": "nissan",
  "mazda": "mazda",
  "subaru": "subaru",
  "mitsubishi": "mitsubishi",
  "hyundai": "hyundai",
  "kia": "kia",
  "volkswagen": "volkswagen",
  "vw": "volkswagen",
  "ford": "ford",
  "chevrolet": "chevrolet",
  "cadillac": "cadillac",
  "jeep": "jeep",
  "dodge": "dodge",
  "chrysler": "chrysler",
  "porsche": "porsche",
  "ferrari": "ferrari",
  "lamborghini": "lamborghini",
  "bentley": "bentley",
  "jaguar": "jaguar",
  "volvo": "volvo",
  "peugeot": "peugeot",
  "renault": "renault",
  "citroen": "citroen",
  "opel": "opel",
  "fiat": "fiat",
  "lancia": "lancia",
  "maserati": "maserati",
  "bugatti": "bugatti",
  "lexus": "lexus",
  "infiniti": "infiniti",
  "acura": "acura",
  "genesis": "genesis",
  "tesla": "tesla",
  "byd": "byd",
  "geely": "geely",
  "chery": "chery",
  "great wall": "great-wall",
  "haval": "haval",
  "jac": "jac",
  "lifan": "lifan",
  "changan": "changan",
  "faw": "faw",
  "dongfeng": "dongfeng",
  "brilliance": "brilliance",
  "zotye": "zotye",
  "gaz": "gaz",
  "uaz": "uaz",
  "vaz": "lada",
  "lada": "lada",
  "moskvich": "moskvich",
  "tagaz": "tagaz",
  "ssangyong": "ssangyong",
  "daihatsu": "daihatsu",
  "isuzu": "isuzu",
  "suzuki": "suzuki",
  "scion": "scion",
  "hummer": "hummer",
  "oldsmobile": "oldsmobile",
  "pontiac": "pontiac",
  "saturn": "saturn",
  "mercury": "mercury",
  "lincoln": "lincoln",
  "buick": "buick",
  "gmc": "gmc",
  "ram": "ram",
  "smart": "smart",
  "mini": "mini",
  "skoda": "skoda",
  "seat": "seat",
  "cupra": "cupra",
  "ds": "ds",
  "alpina": "alpina",
  "ac": "ac",
  "abarth": "abarth",
  "aro": "aro",
  "wartburg": "wartburg",
  "trabant": "trabant",
  "rover": "rover",
  "mg": "mg",
  "saab": "saab",
  "scania": "scania",
  "man": "man",
  "iveco": "iveco",
  "daf": "daf",
  "tatra": "tatra",
};

// ─── Car Logo API (free CDN) ───
function getCarLogoCDN(brand: string): string | null {
  const normalized = brand.toLowerCase().trim();
  // Check mapping first
  const mapped = BRAND_MAPPING[normalized];
  if (mapped) {
    return `https://www.carlogos.org/car-logos/${mapped}-logo.png`;
  }
  // Auto-generate URL
  const slug = normalized.replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
  if (!slug) return null;
  return `https://www.carlogos.org/car-logos/${slug}-logo.png`;
}

// ─── Main researcher — simple CDN URL without verification ───
export async function runLogoResearcher(brandNames: string[]): Promise<LogoResult[]> {
  const results: LogoResult[] = [];

  for (const brand of brandNames) {
    console.log(`[LogoResearcher] Processing: ${brand}...`);

    // Method 1: Direct CDN URL (no fetch verification — let browser handle it)
    let logoUrl = getCarLogoCDN(brand);

    // Method 2: Try Wikipedia if CDN format looks wrong
    if (!logoUrl) {
      try { logoUrl = await searchWikipedia(brand); } catch { /* ignore */ }
    }

    // Method 3: Wikimedia Commons
    if (!logoUrl) {
      try { logoUrl = await searchDuckDuckGo(brand); } catch { /* ignore */ }
    }

    // Save result (even if null — we track the attempt)
    try {
      const db = getDb();
      const [existing] = await db.select().from(brandLogos)
        .where(sql`LOWER(${brandLogos.brandName}) = LOWER(${brand})`)
        .limit(1);

      if (logoUrl) {
        if (existing) {
          await db.update(brandLogos).set({
            logoUrl, source: "ai", aiFillStatus: "filled",
            filledAt: new Date(), updatedAt: new Date(),
          }).where(eq(brandLogos.id, existing.id));
        } else {
          await db.insert(brandLogos).values({
            brandName: brand, logoUrl, source: "ai",
            aiFillStatus: "filled", filledAt: new Date(),
          });
        }
        console.log(`[LogoResearcher] ✓ ${brand}: ${logoUrl}`);
        results.push({ brandName: brand, logoUrl, status: "success" });
      } else {
        // Record failed attempt
        if (!existing) {
          await db.insert(brandLogos).values({
            brandName: brand, logoUrl: null, source: "ai",
            aiFillStatus: "error", aiErrorMessage: "No logo found",
          });
        }
        console.log(`[LogoResearcher] ✗ ${brand}: not found`);
        results.push({ brandName: brand, logoUrl: null, status: "error", error: "Logo not found" });
      }
    } catch (e: any) {
      console.error(`[LogoResearcher] DB error ${brand}:`, e.message);
      results.push({ brandName: brand, logoUrl: null, status: "error", error: e.message });
    }
  }

  return results;
}
