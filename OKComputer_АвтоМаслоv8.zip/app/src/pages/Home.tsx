import { useState, useCallback, useMemo } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import {
  Home as HomeIcon, ChevronRight, Camera, X, Car, Truck, Search, ArrowLeft,
  Fuel, Cog, Calendar, Droplets,
} from "lucide-react";

type Step = "brands" | "models" | "generations" | "result";
type VehicleTab = "car" | "truck";

// ─── Car brand logos (colored SVG icons) ───
const brandLogos: Record<string, string> = {
  "AC": "🚗", "Acura": "🔴", "Alfa Romeo": "⚪", "Aston Martin": "🟢",
  "Audi": "🔘", "Bentley": "🟡", "BMW": "🔵", "Brilliance": "⚫",
  "Bugatti": "🔴", "Buick": "🔵", "BYD": "🟢", "Cadillac": "🔴",
  "Changan": "🔵", "Chery": "🔴", "Chevrolet": "🟡", "Chrysler": "🔵",
  "Citroen": "🔴", "Dacia": "🟢", "Daewoo": "🔵", "Daihatsu": "🔴",
  "Datsun": "🟡", "Dodge": "🔴", "DongFeng": "🟢", "DS": "🔴",
  "FAW": "🔵", "Ferrari": "🔴", "Fiat": "🔴", "Ford": "🔵",
  "Foton": "🟢", "GAC": "🔴", "Geely": "🔵", "Genesis": "🟡",
  "GMC": "🔴", "Great Wall": "🟢", "Hafei": "🔵", "Haima": "🔴",
  "Haval": "🟢", "Honda": "🔴", "Hummer": "🟡", "Hyundai": "🔵",
  "Infiniti": "🔴", "Iran Khodro": "🟢", "Isuzu": "🔴", "Iveco": "🔵",
  "JAC": "🔴", "Jaguar": "🟢", "Jeep": "🟢", "Kia": "🔴",
  "Lada": "🔴", "Lamborghini": "🟡", "Lancia": "🔵", "Land Rover": "🟢",
  "Lexus": "🟡", "Lifan": "🔵", "Lincoln": "🔵", "Mahindra": "🔴",
  "Maserati": "🔵", "Maybach": "🟡", "Mazda": "🔴", "McLaren": "🟡",
  "Mercedes": "🟡", "Mercedes-Benz": "🟡", "MG": "🟢", "Mini": "🔴",
  "Mitsubishi": "🔴", "Nissan": "🔴", "Opel": "🟡", "Peugeot": "🔵",
  "Porsche": "🔴", "Ravon": "🔵", "Renault": "🔴", "Rolls-Royce": "🟡",
  "Rover": "🟢", "Saab": "🔵", "Saturn": "🔴", "Scion": "🔴",
  "SEAT": "🔴", "Skoda": "🟢", "Smart": "🟡", "SsangYong": "🔴",
  "Subaru": "🔵", "Suzuki": "🔴", "Tesla": "🔴", "Toyota": "🔴",
  "UAZ": "🔴", "Volkswagen": "🔵", "Volvo": "🔴", "Vortex": "🔵",
  "ZAZ": "🔵", "ZX": "🔴",
};

function getBrandLogo(name: string): string {
  for (const key of Object.keys(brandLogos)) {
    if (name.toLowerCase().includes(key.toLowerCase())) {
      return brandLogos[key];
    }
  }
  return "🚗";
}

export default function Home() {
  const [vehicleTab, setVehicleTab] = useState<VehicleTab>("car");
  const [plateNumber, setPlateNumber] = useState("");
  const [vinNumber, setVinNumber] = useState("");
  const [step, setStep] = useState<Step>("brands");
  const [selectedMake, setSelectedMake] = useState<string | null>(null);
  const [selectedModel, setSelectedModel] = useState<string | null>(null);
  const [selectedGen, setSelectedGen] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [modificationOpen, setModificationOpen] = useState(false);
  const [showAllMakes, setShowAllMakes] = useState(false);

  // ─── Data ───
  const { data: makesData, isLoading: makesLoading } = trpc.car.brands.useQuery();
  const { data: modelsData } = trpc.car.models.useQuery(
    { makeId: selectedMake ? parseInt(selectedMake) : 0 },
    { enabled: !!selectedMake && step === "models" }
  );
  const { data: modsData } = trpc.car.modifications.useQuery(
    {
      makeId: selectedMake ? parseInt(selectedMake) : 0,
      modelId: selectedModel ? parseInt(selectedModel) : 0,
    },
    { enabled: !!selectedMake && !!selectedModel && step === "generations" }
  );
  const { data: oilsData } = trpc.oil.results.useQuery(
    {
      makeId: selectedMake ? parseInt(selectedMake) : 0,
      modelId: selectedModel ? parseInt(selectedModel) : 0,
      modificationId: selectedGen ? parseInt(selectedGen) : 0,
    },
    { enabled: !!selectedMake && !!selectedModel && !!selectedGen && step === "result" }
  );

  // ─── Breadcrumbs ───
  const breadcrumbs = useMemo(() => {
    const items = [{ label: "Главная", active: step === "brands" }];
    if (step === "models" && selectedMake) {
      const makeName = makesData?.find((m: any) => String(m.id) === selectedMake)?.name || "Марка";
      items.push({ label: makeName, active: true });
    }
    if (step === "generations" && selectedMake && selectedModel) {
      const makeName = makesData?.find((m: any) => String(m.id) === selectedMake)?.name || "Марка";
      const modelName = modelsData?.find((m: any) => String(m.modelId) === selectedModel)?.modelName || "Модель";
      items.push({ label: makeName, active: false }, { label: modelName, active: true });
    }
    if (step === "result" && selectedMake && selectedModel && selectedGen) {
      const makeName = makesData?.find((m: any) => String(m.id) === selectedMake)?.name || "Марка";
      const modelName = modelsData?.find((m: any) => String(m.modelId) === selectedModel)?.modelName || "Модель";
      const genName = modsData?.find((m: any) => String(m.id) === selectedGen)?.name || "Поколение";
      items.push(
        { label: makeName, active: false },
        { label: modelName, active: false },
        { label: genName, active: true }
      );
    }
    return items;
  }, [step, selectedMake, selectedModel, selectedGen, makesData, modelsData, modsData]);

  // ─── Filtered makes by search ───
  const filteredMakes = useMemo(() => {
    if (!makesData) return [];
    if (!searchQuery) return makesData;
    const q = searchQuery.toLowerCase();
    return makesData.filter((m: any) => (m.name || "").toLowerCase().includes(q));
  }, [makesData, searchQuery]);

  const handleSelectMake = useCallback((id: string) => {
    setSelectedMake(id);
    setStep("models");
    setSearchQuery("");
    setShowAllMakes(false);
  }, []);

  const handleSelectModel = useCallback((modelId: string) => {
    setSelectedModel(modelId);
    setStep("generations");
  }, []);

  const handleSelectGen = useCallback((genId: string) => {
    setSelectedGen(genId);
    setStep("result");
    setModificationOpen(false);
  }, []);

  const handleBack = useCallback(() => {
    if (step === "result") { setStep("generations"); setSelectedGen(null); }
    else if (step === "generations") { setStep("models"); setSelectedModel(null); }
    else if (step === "models") { setStep("brands"); setSelectedMake(null); setShowAllMakes(false); }
  }, [step]);

  const selectedMakeName = makesData?.find((m: any) => String(m.id) === selectedMake)?.name || "";
  const selectedModelName = modelsData?.find((m: any) => String(m.modelId) === selectedModel)?.modelName || "";
  const selectedGenName = modsData?.find((m: any) => String(m.id) === selectedGen)?.name || "";
  const selectedEngineCode = modsData?.find((m: any) => String(m.id) === selectedGen)?.engineCode || "";

  return (
    <div className="min-h-screen bg-gray-100">
      {/* ═══ HEADER ═══ */}
      <header className="bg-white shadow-sm sticky top-0 z-30">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-amber-500 font-bold text-lg tracking-tight">oilpodbor</span>
          </div>
          <nav className="flex items-center gap-3 text-xs">
            <Link to="/login" className="text-gray-500 hover:text-gray-800 transition-colors">Вход</Link>
            <Link to="/admin" className="text-gray-500 hover:text-gray-800 transition-colors">Админ</Link>
          </nav>
        </div>
      </header>

      {/* ═══ MAIN CONTENT ═══ */}
      <main className="max-w-2xl mx-auto px-4 py-4">
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-1 text-xs text-gray-400 mb-3 overflow-x-auto">
          <HomeIcon className="w-3 h-3 flex-shrink-0" />
          <span className="flex-shrink-0">Главная</span>
          {breadcrumbs.length > 1 && (
            <>
              <ChevronRight className="w-3 h-3 flex-shrink-0" />
              <span className="text-gray-500 whitespace-nowrap">{breadcrumbs[breadcrumbs.length - 1]?.label}</span>
            </>
          )}
        </nav>

        {/* Title */}
        <h1 className="text-gray-800 text-lg font-bold mb-4 leading-snug">
          Подбор моторного масла и других технических жидкостей
        </h1>

        {/* ═══ VEHICLE TYPE TABS ═══ */}
        <div className="flex gap-2 mb-4">
          <button
            onClick={() => setVehicleTab("car")}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
              vehicleTab === "car"
                ? "bg-amber-500 text-white shadow-md"
                : "bg-white text-gray-600 border border-gray-200 hover:border-amber-300"
            }`}
          >
            <Car className="w-4 h-4" />
            Легковой
          </button>
          <button
            onClick={() => setVehicleTab("truck")}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
              vehicleTab === "truck"
                ? "bg-amber-500 text-white shadow-md"
                : "bg-white text-gray-600 border border-gray-200 hover:border-amber-300"
            }`}
          >
            <Truck className="w-4 h-4" />
            Грузовой
          </button>
        </div>

        {/* ═══ PLATE & VIN SEARCH ═══ */}
        <div className="bg-white rounded-lg border border-gray-200 p-4 mb-4 space-y-3">
          {/* Plate number */}
          <div className="flex gap-2">
            <div className="flex-1 flex border border-gray-300 rounded-lg overflow-hidden focus-within:border-amber-500 focus-within:ring-1 focus-within:ring-amber-200">
              <input
                type="text"
                value={plateNumber}
                onChange={(e) => setPlateNumber(e.target.value.toUpperCase())}
                placeholder="A 000 AA"
                className="flex-1 px-3 py-2.5 text-sm text-gray-800 uppercase focus:outline-none"
              />
              <div className="border-l border-gray-200 flex items-center">
                <input
                  type="text"
                  value="000 RUS"
                  readOnly
                  className="w-20 px-2 py-2.5 text-xs text-gray-400 text-center focus:outline-none cursor-default"
                />
              </div>
            </div>
            <button className="p-2.5 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
              <Camera className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {/* VIN */}
          <div className="flex gap-2">
            <input
              type="text"
              value={vinNumber}
              onChange={(e) => setVinNumber(e.target.value.toUpperCase())}
              placeholder="Поиск по VIN / Frame номеру"
              className="flex-1 border border-gray-300 rounded-lg px-3 py-2.5 text-sm text-gray-800 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-200"
            />
          </div>

          {/* Buttons */}
          <div className="flex gap-2">
            <button
              onClick={() => { setPlateNumber(""); setVinNumber(""); }}
              className="flex-1 py-2.5 rounded-lg text-sm font-medium bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors"
            >
              Сбросить
            </button>
            <button className="flex-1 py-2.5 rounded-lg text-sm font-medium bg-amber-500 text-white hover:bg-amber-600 transition-colors shadow-md">
              Поиск
            </button>
          </div>
        </div>

        {/* ═══ BLACK SEARCH BLOCK ═══ */}
        <div className="bg-gray-900 rounded-lg p-4 mb-4">
          <h2 className="text-white font-bold text-base mb-1">
            {step === "brands" && "Поиск транспортного средства"}
            {step === "models" && selectedMakeName}
            {step === "generations" && `${selectedMakeName} ${selectedModelName}`}
            {step === "result" && "Результат поиска"}
          </h2>
          <p className="text-gray-400 text-xs mb-3">
            {step === "brands"
              ? "Вы можете найти необходимый продукт по марке, модели транспортного средства и коду двигателя"
              : step === "result"
              ? "Выберите модификацию для просмотра рекомендуемых продуктов"
              : "Выберите подкатегорию"
            }
          </p>

          {/* Quick search */}
          {step === "brands" && (
            <div className="relative mb-2">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Быстрый поиск"
                className="w-full bg-gray-800 border border-gray-700 rounded-lg pl-9 pr-9 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-amber-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          )}

          {/* Back button */}
          {step !== "brands" && (
            <button
              onClick={handleBack}
              className="flex items-center gap-2 text-amber-500 text-sm hover:text-amber-400 transition-colors mb-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Назад
            </button>
          )}
        </div>

        {/* ═══ STEP: BRANDS ═══ */}
        {step === "brands" && (
          <div>
            {makesLoading ? (
              <div className="flex justify-center py-12">
                <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {(showAllMakes || searchQuery ? filteredMakes : filteredMakes.slice(0, 10)).map((make: any) => (
                    <button
                      key={make.id}
                      onClick={() => handleSelectMake(String(make.id))}
                      className="bg-white rounded-lg border border-gray-200 p-4 flex items-center gap-3 hover:border-amber-400 hover:shadow-md transition-all active:scale-[0.98]"
                    >
                      <span className="text-2xl flex-shrink-0 w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center">
                        {getBrandLogo(make.name || "")}
                      </span>
                      <span className="text-gray-700 text-sm font-medium text-left leading-tight">
                        {make.name}
                      </span>
                    </button>
                  ))}
                  {filteredMakes.length === 0 && searchQuery && (
                    <div className="col-span-full text-center py-8 text-gray-400 text-sm">
                      Ничего не найдено по «{searchQuery}»
                    </div>
                  )}
                </div>

                {/* Show all button */}
                {!showAllMakes && !searchQuery && filteredMakes.length > 10 && (
                  <button
                    onClick={() => setShowAllMakes(true)}
                    className="w-full mt-4 py-3 rounded-lg text-sm font-medium bg-white border border-gray-200 text-gray-600 hover:border-amber-400 hover:text-amber-600 transition-all flex items-center justify-center gap-2"
                  >
                    <span>Показать все марки</span>
                    <span className="text-gray-400">({filteredMakes.length})</span>
                  </button>
                )}
              </>
            )}
          </div>
        )}

        {/* ═══ STEP: MODELS ═══ */}
        {step === "models" && (
          <div className="grid grid-cols-2 gap-3">
            {modelsData?.map((model: any) => (
              <button
                key={model.modelId}
                onClick={() => handleSelectModel(String(model.modelId))}
                className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:border-amber-400 hover:shadow-md transition-all active:scale-[0.98]"
              >
                <div className="bg-gray-50 h-24 flex items-center justify-center">
                  <Car className="w-10 h-10 text-gray-300" />
                </div>
                <div className="p-3">
                  <p className="text-gray-800 text-sm font-medium text-left">{model.modelName}</p>
                  <p className="text-gray-400 text-xs text-left mt-0.5">
                    {model.yearFrom || ""}{model.yearTo ? ` — ${model.yearTo}` : model.yearFrom ? " — н.в." : ""}
                  </p>
                </div>
              </button>
            ))}
            {(!modelsData || modelsData.length === 0) && (
              <div className="col-span-full text-center py-8 text-gray-400 text-sm">
                Модели не найдены
              </div>
            )}
          </div>
        )}

        {/* ═══ STEP: GENERATIONS ═══ */}
        {step === "generations" && (
          <div className="grid grid-cols-2 gap-3">
            {modsData?.map((mod: any) => {
              const years = [];
              if (mod.startDate) {
                const match = mod.startDate.match(/(\d{4})/);
                if (match) years.push(match[1]);
              }
              if (mod.endDate) {
                const match = mod.endDate.match(/(\d{4})/);
                if (match) years.push(match[1]);
              } else if (years.length > 0) {
                years.push("н.в.");
              }
              const yearStr = years.length > 0 ? years.join(" — ") : "";

              return (
                <button
                  key={mod.id}
                  onClick={() => handleSelectGen(String(mod.id))}
                  className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:border-amber-400 hover:shadow-md transition-all active:scale-[0.98]"
                >
                  <div className="bg-gray-50 h-20 flex items-center justify-center">
                    <Cog className="w-8 h-8 text-gray-300" />
                  </div>
                  <div className="p-3">
                    <p className="text-gray-800 text-sm font-medium text-left">{mod.name || "—"}</p>
                    {mod.engineCode && (
                      <p className="text-amber-600 text-xs font-mono mt-0.5 text-left">{mod.engineCode}</p>
                    )}
                    {yearStr && (
                      <p className="text-gray-400 text-xs mt-0.5 text-left flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {yearStr}
                      </p>
                    )}
                    {mod.fuel && (
                      <p className="text-gray-400 text-xs mt-0.5 text-left flex items-center gap-1">
                        <Fuel className="w-3 h-3" />
                        {mod.fuel}
                      </p>
                    )}
                  </div>
                </button>
              );
            })}
            {(!modsData || modsData.length === 0) && (
              <div className="col-span-full text-center py-8 text-gray-400 text-sm">
                Модификации не найдены
              </div>
            )}
          </div>
        )}

        {/* ═══ STEP: RESULT ═══ */}
        {step === "result" && (
          <div className="space-y-4">
            {/* Car card */}
            <div className="bg-white rounded-lg border border-gray-200 p-4 flex gap-4">
              <div className="w-16 h-16 rounded-full bg-gray-50 flex items-center justify-center flex-shrink-0">
                <span className="text-3xl">{getBrandLogo(selectedMakeName)}</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-gray-800 font-bold text-base">{selectedMakeName}</span>
                  <span className="text-gray-400">|</span>
                  <span className="text-gray-600 text-sm">{selectedModelName}</span>
                </div>

                {/* Modification dropdown */}
                <div className="relative">
                  <button
                    onClick={() => setModificationOpen(!modificationOpen)}
                    className="w-full flex items-center justify-between border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-700 hover:border-amber-400 transition-colors bg-white"
                  >
                    <span className="truncate">
                      {selectedGenName}
                      {selectedEngineCode && ` (${selectedEngineCode})`}
                    </span>
                    <ChevronRight className={`w-4 h-4 text-gray-400 flex-shrink-0 transition-transform ${modificationOpen ? "rotate-90" : ""}`} />
                  </button>

                  {modificationOpen && (
                    <div className="absolute z-20 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-auto">
                      {modsData?.map((mod: any) => (
                        <button
                          key={mod.id}
                          onClick={() => {
                            setSelectedGen(String(mod.id));
                            setModificationOpen(false);
                          }}
                          className={`w-full text-left px-3 py-2.5 text-sm hover:bg-amber-50 transition-colors ${
                            String(mod.id) === selectedGen ? "bg-amber-50 text-amber-700 font-medium" : "text-gray-700"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span>{mod.name || "—"}</span>
                            {mod.engineCode && (
                              <span className="text-amber-600 text-xs font-mono ml-2">{mod.engineCode}</span>
                            )}
                          </div>
                          {mod.horsePower && (
                            <span className="text-gray-400 text-xs">{mod.horsePower} л.с.</span>
                          )}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Oils */}
            {oilsData && oilsData.length > 0 ? (
              <div>
                <h3 className="text-gray-800 font-bold text-sm mb-3 flex items-center gap-2">
                  <Droplets className="w-4 h-4 text-amber-500" />
                  Рекомендуемые масла
                </h3>
                <div className="space-y-2">
                  {oilsData.map((oil: any, i: number) => (
                    <div
                      key={oil.id || i}
                      className="bg-white rounded-lg border border-gray-200 p-4 hover:border-amber-300 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-gray-800 text-sm font-medium">{oil.originalName || oil.name || "—"}</p>
                          <div className="flex items-center gap-3 mt-1">
                            {oil.artNumber && (
                              <span className="text-gray-400 text-xs font-mono">{oil.artNumber}</span>
                            )}
                            {oil.volume && (
                              <span className="text-amber-600 text-xs font-medium">{oil.volume}</span>
                            )}
                          </div>
                        </div>
                        <span className="text-gray-300 text-xs flex-shrink-0">#{i + 1}</span>
                      </div>
                      {oil.commentName && (
                        <p className="text-gray-500 text-xs mt-2 border-t border-gray-100 pt-2">{oil.commentName}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
                <Droplets className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                <p className="text-gray-400 text-sm">Данные по маслам не найдены</p>
              </div>
            )}

            {/* Back button */}
            <button
              onClick={handleBack}
              className="w-full py-3 rounded-lg text-sm font-medium bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Назад
            </button>
          </div>
        )}
      </main>

      {/* ═══ FOOTER ═══ */}
      <footer className="mt-8 border-t border-gray-200 bg-white">
        <div className="max-w-2xl mx-auto px-4 py-4 text-center text-gray-400 text-xs">
          oilpodbor — система подбора технических жидкостей
        </div>
      </footer>
    </div>
  );
}
