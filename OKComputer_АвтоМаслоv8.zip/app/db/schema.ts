import {
  mysqlTable,
  serial,
  varchar,
  int,
  json,
  bigint,
  index,
  uniqueIndex,
  mysqlEnum,
  text,
  timestamp,
} from "drizzle-orm/mysql-core";

// ═══════════════════════════════════════════
//  AUTH & MULTI-TENANCY
// ═══════════════════════════════════════════

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }),
  username: varchar("username", { length: 255 }).unique(),
  passwordHash: varchar("passwordHash", { length: 255 }),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
}, (table) => [
  index("users_username_idx").on(table.username),
]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Companies (multi-tenant) ───
export const companies = mysqlTable("companies", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  apiKey: varchar("apiKey", { length: 64 }).unique(),
  allowedDomains: json("allowedDomains"), // ["example.com", "shop.example.com"]
  // ─── Widget settings (configurable per company) ───
  widgetAccentColor: varchar("widgetAccentColor", { length: 20 }).default("#f59e0b"),
  widgetShowVinSearch: mysqlEnum("widgetShowVinSearch", ["yes", "no"]).default("yes").notNull(),
  widgetShowPlateSearch: mysqlEnum("widgetShowPlateSearch", ["yes", "no"]).default("yes").notNull(),
  widgetShowTruckTab: mysqlEnum("widgetShowTruckTab", ["yes", "no"]).default("yes").notNull(),
  widgetShowCarTab: mysqlEnum("widgetShowCarTab", ["yes", "no"]).default("yes").notNull(),
  widgetTitle: varchar("widgetTitle", { length: 255 }).default("Подбор моторного масла и других технических жидкостей"),
  widgetSearchTitle: varchar("widgetSearchTitle", { length: 255 }).default("Поиск транспортного средства"),
  widgetSearchDesc: varchar("widgetSearchDesc", { length: 500 }).default("Вы можете найти необходимый продукт по марке, модели транспортного средства и коду двигателя"),
  logo: varchar("logo", { length: 500 }),
  contactEmail: varchar("contactEmail", { length: 320 }),
  contactPhone: varchar("contactPhone", { length: 50 }),
  isActive: mysqlEnum("isActive", ["active", "suspended", "archived"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
}, (table) => [
  index("companies_slug_idx").on(table.slug),
  index("companies_active_idx").on(table.isActive),
  index("companies_apiKey_idx").on(table.apiKey),
]);

// ─── Search Logs (widget requests) ───
export const searchLogs = mysqlTable("searchLogs", {
  id: serial("id").primaryKey(),
  companyId: int("companyId").notNull(),
  apiKey: varchar("apiKey", { length: 64 }).notNull(),
  domain: varchar("domain", { length: 255 }),
  makeId: int("makeId"),
  modelId: int("modelId"),
  modificationId: varchar("modificationId", { length: 53 }),
  makeName: varchar("makeName", { length: 255 }),
  modelName: varchar("modelName", { length: 255 }),
  modificationName: varchar("modificationName", { length: 255 }),
  engineCode: varchar("engineCode", { length: 100 }),
  clientIp: varchar("clientIp", { length: 45 }),
  userAgent: varchar("userAgent", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("searchLogs_company_idx").on(table.companyId),
  index("searchLogs_apiKey_idx").on(table.apiKey),
  index("searchLogs_createdAt_idx").on(table.createdAt),
  index("searchLogs_domain_idx").on(table.domain),
]);

// ─── Company Users (membership) ───
export const companyUsers = mysqlTable("companyUsers", {
  id: serial("id").primaryKey(),
  companyId: int("companyId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["owner", "manager", "viewer"]).default("viewer").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("companyUsers_unique_idx").on(table.companyId, table.userId),
  index("companyUsers_company_idx").on(table.companyId),
  index("companyUsers_user_idx").on(table.userId),
]);

// ─── Products (company-specific catalog) ───
export const products = mysqlTable("products", {
  id: serial("id").primaryKey(),
  companyId: int("companyId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  sku: varchar("sku", { length: 100 }).notNull(),
  brand: varchar("brand", { length: 255 }),
  category: varchar("category", { length: 255 }),
  description: text("description"),
  price: int("price"), // cents
  currency: varchar("currency", { length: 3 }).default("RUB"),
  volume: varchar("volume", { length: 50 }),
  specs: json("specs"), // { viscosity, api, acea, oemApprovals }
  imageUrl: varchar("imageUrl", { length: 500 }),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("products_sku_company_idx").on(table.companyId, table.sku),
  index("products_company_idx").on(table.companyId),
  index("products_active_idx").on(table.isActive),
  index("products_category_idx").on(table.category),
]);

// ─── Product-to-Car Assignments ───
export const productAssignments = mysqlTable("productAssignments", {
  id: serial("id").primaryKey(),
  companyId: int("companyId").notNull(),
  productId: int("productId").notNull(),
  makeId: int("makeId").notNull(),
  modelId: int("modelId").notNull(),
  modificationId: varchar("modificationId", { length: 53 }).notNull(),
  notes: varchar("notes", { length: 500 }),
  isRecommended: mysqlEnum("isRecommended", ["yes", "no"]).default("no").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("productAssignments_unique_idx").on(table.companyId, table.productId, table.makeId, table.modelId, table.modificationId),
  index("productAssignments_company_idx").on(table.companyId),
  index("productAssignments_product_idx").on(table.productId),
  index("productAssignments_car_idx").on(table.makeId, table.modelId),
]);

// ═══════════════════════════════════════════
//  ORIGINAL CATALOG TABLES (from SQL dumps)
// ═══════════════════════════════════════════

export const mapping = mysqlTable(
  "mapping",
  {
    id: serial("id").primaryKey(),
    newMakeId: bigint("newMakeId", { mode: "number", unsigned: true }).notNull().default(0),
    newModelId: bigint("newModelId", { mode: "number", unsigned: true }).notNull().default(0),
    newTypeId: bigint("newTypeId", { mode: "number", unsigned: true }).notNull().default(0),
    seoType: varchar("seoType", { length: 512 }),
    makeId: int("makeId"),
    modelId: int("modelId"),
    typeId: varchar("typeId", { length: 53 }),
  },
  (table) => [
    index("mapping_newMakeId_idx").on(table.newMakeId),
    index("mapping_newMakeModel_idx").on(table.newMakeId, table.newModelId),
    index("mapping_newMakeModelType_idx").on(table.newMakeId, table.newModelId, table.newTypeId),
    index("mapping_seoType_idx").on(table.seoType),
    index("mapping_makeId_idx").on(table.makeId),
    index("mapping_makeModel_idx").on(table.makeId, table.modelId),
    index("mapping_makeModelType_idx").on(table.makeId, table.modelId, table.typeId),
  ]
);

export const brands = mysqlTable("TObrands", {
  id: int("id"),
  name: varchar("name", { length: 255 }),
}, (table) => [
  uniqueIndex("TObrands_id_name_idx").on(table.id, table.name),
  index("TObrands_id_idx").on(table.id),
]);

export const models = mysqlTable("TOmodels", {
  makeId: int("makeId"),
  modelId: int("modelId"),
  modelName: varchar("modelName", { length: 255 }),
  yearFrom: varchar("yearFrom", { length: 255 }),
  yearTo: varchar("yearTo", { length: 255 }),
}, (table) => [
  uniqueIndex("TOmodels_unique_idx").on(table.makeId, table.modelId, table.modelName, table.yearFrom, table.yearTo),
  index("TOmodels_makeId_idx").on(table.makeId),
  index("TOmodels_modelId_idx").on(table.modelId),
]);

export const modifications = mysqlTable("TOmodifications", {
  id: varchar("id", { length: 53 }),
  name: varchar("name", { length: 100 }),
  engineCode: varchar("engineCode", { length: 100 }),
  constructionType: varchar("constructionType", { length: 255 }),
  fuel: varchar("fuel", { length: 255 }),
  horsePower: varchar("horsePower", { length: 255 }),
  startDate: varchar("startDate", { length: 25 }),
  endDate: varchar("endDate", { length: 25 }),
  engineCapacity: varchar("engineCapacity", { length: 255 }),
  numberOfCylinders: varchar("numberOfCylinders", { length: 255 }),
  valves: varchar("valves", { length: 255 }),
  valvesTotal: varchar("valvesTotal", { length: 255 }),
  motorType: varchar("motorType", { length: 255 }),
  fullName: varchar("fullName", { length: 255 }),
  brand: json("brand"),
  model: json("model"),
  makeId: int("makeId"),
  modelId: int("modelId"),
}, (table) => [
  uniqueIndex("TOmodifications_unique_idx").on(table.id, table.name, table.engineCode, table.fullName, table.makeId, table.modelId),
  index("TOmodifications_makeModel_idx").on(table.makeId, table.modelId),
  index("TOmodifications_modelId_idx").on(table.modelId),
  index("TOmodifications_id_idx").on(table.id),
]);

export const oils = mysqlTable("TOoils", {
  id: serial("id").primaryKey(),
  makeId: int("makeId"),
  modelId: int("modelId"),
  modificationId: int("modificationId"),
  catalogId: int("catalogId"),
  catalogItemId: int("catalogItemId"),
  orderPosition: int("orderPosition"),
  artNumber: varchar("artNumber", { length: 255 }),
  originalName: varchar("originalName", { length: 255 }),
  volume: varchar("volume", { length: 255 }),
  commentName: varchar("commentName", { length: 255 }),
}, (table) => [
  index("TOoils_makeModelMod_idx").on(table.makeId, table.modelId, table.modificationId),
  index("TOoils_modelId_idx").on(table.modelId),
  index("TOoils_modificationId_idx").on(table.modificationId),
]);

export const parts = mysqlTable("TOparts", {
  id: int("id"),
  makeId: int("makeId"),
  modelId: int("modelId"),
  modificationId: varchar("modificationId", { length: 255 }),
  manufacturerId: int("manufacturerId"),
  manufacturerName: varchar("manufacturerName", { length: 255 }),
  itemName: varchar("itemName", { length: 100 }),
  partNumber: varchar("partNumber", { length: 255 }),
  quantity: int("quantity"),
  comment: varchar("comment", { length: 255 }),
}, (table) => [
  uniqueIndex("TOparts_unique_idx").on(table.makeId, table.modelId, table.modificationId, table.manufacturerId, table.partNumber, table.quantity, table.itemName),
  index("TOparts_makeModelMod_idx").on(table.makeId, table.modelId, table.modificationId),
  index("TOparts_modelId_idx").on(table.modelId),
  index("TOparts_modificationId_idx").on(table.modificationId),
  index("TOparts_itemName_idx").on(table.itemName),
]);

export const partsCrosses = mysqlTable("TOpartsCrosses", {
  id: serial("id").primaryKey(),
  manufacturerName: varchar("manufacturerName", { length: 255 }),
  partNumber: varchar("partNumber", { length: 255 }),
  crossBrand: varchar("crossBrand", { length: 100 }),
  crossNumber: varchar("crossNumber", { length: 50 }),
}, (table) => [
  index("TOpartsCrosses_mfr_idx").on(table.manufacturerName, table.partNumber),
]);

// ═══════════════════════════════════════════
//  OILPODBOR REFERENCE TABLES
// ═══════════════════════════════════════════

// ─── Vehicle Types (Легковые, Грузовые и т.д.) ───
export const vehicleTypes = mysqlTable("vehicleTypes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("vehicleTypes_active_idx").on(table.isActive),
]);

// ─── Steering Positions (Левое/Правое) ───
export const steeringPositions = mysqlTable("steeringPositions", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("steeringPositions_active_idx").on(table.isActive),
]);

// ─── Car Body Types (седан, хэтчбек, SUV и т.д.) ───
export const carBodyTypes = mysqlTable("carBodyTypes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("carBodyTypes_active_idx").on(table.isActive),
]);

// ─── Fuel Types (Бензин, Дизель, Гибрид и т.д.) ───
export const fuelTypes = mysqlTable("fuelTypes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("fuelTypes_active_idx").on(table.isActive),
]);

// ─── Transmission Types (МКПП, АКПП, Вариатор и т.д.) ───
export const transmissionTypes = mysqlTable("transmissionTypes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("transmissionTypes_active_idx").on(table.isActive),
]);

// ─── Viscosity Classes (5W-30, 5W-40 и т.д.) ───
export const viscosityClasses = mysqlTable("viscosityClasses", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("viscosityClasses_active_idx").on(table.isActive),
]);

// ─── Liquid Categories (моторное масло, антифриз, тормозная и т.д.) ───
export const liquidCategories = mysqlTable("liquidCategories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  displayName: varchar("displayName", { length: 255 }),
  parentId: int("parentId"),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("liquidCategories_parent_idx").on(table.parentId),
  index("liquidCategories_active_idx").on(table.isActive),
]);

// ─── Aggregation Trees (дерево агрегатов) ───
export const aggregationTrees = mysqlTable("aggregationTrees", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  parentId: int("parentId"),
  liquidCategoryId: int("liquidCategoryId"),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("aggregationTrees_parent_idx").on(table.parentId),
  index("aggregationTrees_category_idx").on(table.liquidCategoryId),
]);

// ═══════════════════════════════════════════
//  MAIN JOURNAL: CARS (АВТОМОБИЛИ)
// ═══════════════════════════════════════════

export const cars = mysqlTable("cars", {
  id: varchar("id", { length: 50 }).primaryKey(),
  // General
  vehicleTypeId: int("vehicleTypeId"),
  steeringPositionId: int("steeringPositionId"),
  make: varchar("make", { length: 255 }).notNull(),
  model: varchar("model", { length: 255 }).notNull(),
  bodyTypeId: int("bodyTypeId"),
  modification: varchar("modification", { length: 255 }).notNull(),
  yearFrom: int("yearFrom"),
  yearTo: int("yearTo"),
  // Engine
  engineCapacity: varchar("engineCapacity", { length: 50 }),
  fuelTypeId: int("fuelTypeId"),
  engineCode: varchar("engineCode", { length: 100 }),
  engineName: varchar("engineName", { length: 255 }),
  horsePower: varchar("horsePower", { length: 50 }),
  // Transmission
  transmissionTypeId: int("transmissionTypeId"),
  transmissionGears: varchar("transmissionGears", { length: 50 }),
  transmissionCode: varchar("transmissionCode", { length: 100 }),
  // Transfer case
  transferCaseCode: varchar("transferCaseCode", { length: 100 }),
  // Differentials
  frontDifferentialCode: varchar("frontDifferentialCode", { length: 100 }),
  rearDifferentialCode: varchar("rearDifferentialCode", { length: 100 }),
  // Air conditioning
  refrigerantType: varchar("refrigerantType", { length: 100 }),
  // Status
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
}, (table) => [
  index("cars_make_idx").on(table.make),
  index("cars_model_idx").on(table.model),
  index("cars_active_idx").on(table.isActive),
  index("cars_vehicleType_idx").on(table.vehicleTypeId),
  index("cars_fuelType_idx").on(table.fuelTypeId),
  index("cars_modification_idx").on(table.modification),
]);

// ═══════════════════════════════════════════
//  MAIN JOURNAL: LIQUIDS (ЖИДКОСТИ)
// ═══════════════════════════════════════════

export const liquids = mysqlTable("liquids", {
  id: varchar("id", { length: 50 }).primaryKey(),
  name: varchar("name", { length: 500 }).notNull(),
  // Category & priority
  categoryId: int("categoryId"),
  aggregationTreeId: int("aggregationTreeId"),
  priority: int("priority").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  // Product info
  volume: varchar("volume", { length: 50 }),
  sku: varchar("sku", { length: 100 }),
  // Viscosity
  viscosityClassId: int("viscosityClassId"),
  viscosityName: varchar("viscosityName", { length: 50 }),
  // Specs
  oilType: varchar("oilType", { length: 50 }), // синтетика / полусинт / минералка
  apiSpec: varchar("apiSpec", { length: 255 }),
  aceaSpec: varchar("aceaSpec", { length: 255 }),
  ilsacSpec: varchar("ilsacSpec", { length: 255 }),
  oemSpec: varchar("oemSpec", { length: 255 }),
  // Vehicle applicability
  applicableVehicleTypes: json("applicableVehicleTypes"),
  // Description
  description: text("description"),
  websiteUrl: varchar("websiteUrl", { length: 500 }),
  imageUrl: varchar("imageUrl", { length: 500 }),
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
}, (table) => [
  index("liquids_category_idx").on(table.categoryId),
  index("liquids_active_idx").on(table.isActive),
  index("liquids_priority_idx").on(table.priority),
  index("liquids_viscosity_idx").on(table.viscosityClassId),
]);

// ═══════════════════════════════════════════
//  CAR ↔ LIQUID ASSIGNMENTS (СВЯЗЬ)
// ═══════════════════════════════════════════

export const carLiquidAssignments = mysqlTable("carLiquidAssignments", {
  id: serial("id").primaryKey(),
  carId: varchar("carId", { length: 50 }).notNull(),
  liquidId: varchar("liquidId", { length: 50 }).notNull(),
  aggregationTreeId: int("aggregationTreeId"),
  // For the assignment — volume, interval, priority
  fillVolume: varchar("fillVolume", { length: 50 }),
  replaceInterval: varchar("replaceInterval", { length: 255 }),
  isPrimary: mysqlEnum("isPrimary", ["yes", "no"]).default("yes").notNull(),
  // Notes
  notes: varchar("notes", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("carLiquid_unique_idx").on(table.carId, table.liquidId, table.aggregationTreeId),
  index("carLiquid_car_idx").on(table.carId),
  index("carLiquid_liquid_idx").on(table.liquidId),
  index("carLiquid_tree_idx").on(table.aggregationTreeId),
]);
