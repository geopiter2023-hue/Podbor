// Polyfill for AbortSignal.timeout (not available in older Node.js)
if (typeof (AbortSignal as any).timeout !== "function") {
  (AbortSignal as any).timeout = function(ms: number) {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(new DOMException("Timeout", "AbortError")), ms);
    return ctrl.signal;
  };
}

// ─── Load .env file safely ───
try {
  const dotenv = await import("dotenv");
  dotenv.default?.config?.() || (dotenv as any).config?.();
} catch {
  // dotenv not installed, use system env vars
}

// ─── Log env status (for debugging) ───
import path from "path";
import fs from "fs";
console.log("[ENV] cwd:", process.cwd());
console.log("[ENV] .env exists:", fs.existsSync(path.join(process.cwd(), ".env")));
const dbUrl = process.env.DATABASE_URL || "";
if (dbUrl) {
  const match = dbUrl.match(/@([^/]+)/);
  console.log("[ENV] DATABASE_URL host:", match ? match[1] : "set");
} else {
  console.error("[ENV] DATABASE_URL is NOT SET!");
  console.error("[ENV] Create .env file in:", process.cwd());
  console.error("[ENV] With: DATABASE_URL=mysql://USER:PASS@HOST:PORT/DB");
}

import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { createOAuthCallbackHandler } from "./kimi/auth";
import { Paths } from "@contracts/constants";

const app = new Hono<{ Bindings: HttpBindings }>();

// ─── CORS headers ───
app.use("*", async (c, next) => {
  c.header("Access-Control-Allow-Origin", "*");
  c.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  c.header("Access-Control-Allow-Headers", "Content-Type, Authorization, x-local-auth-token");
  if (c.req.method === "OPTIONS") return c.body(null, 204);
  await next();
});

// ─── Request logging ───
app.use("*", async (c, next) => {
  const start = Date.now();
  await next();
  const ms = Date.now() - start;
  console.log(`[${c.req.method}] ${c.req.path} — ${c.res.status} (${ms}ms)`);
});

// ─── Body limit ───
app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));

// ─── OAuth callback ───
app.get(Paths.oauthCallback, createOAuthCallbackHandler());

// ─── Uploaded PDFs ───
app.use("/uploads/manuals/*", async (c) => {
  const filePath = path.join(process.cwd(), "uploads", "manuals", c.req.path.replace("/uploads/manuals/", ""));
  if (fs.existsSync(filePath)) {
    return c.body(fs.readFileSync(filePath), 200, { "Content-Type": "application/pdf" });
  }
  return c.json({ error: "PDF not found" }, 404);
});

// ─── Health check (BEFORE tRPC) ───
app.get("/health", async (c) => {
  let dbStatus = "unknown";
  try {
    const { getDbStatus } = await import("./queries/connection");
    dbStatus = getDbStatus().connected ? "connected" : "disconnected";
  } catch {
    dbStatus = "error";
  }
  return c.json({
    status: "ok",
    version: "v141",
    time: new Date().toISOString(),
    uptime: process.uptime(),
    db: dbStatus,
  });
});

// ─── tRPC API ───
app.use("/api/trpc/*", async (c) => {
  try {
    return await fetchRequestHandler({
      endpoint: "/api/trpc",
      req: c.req.raw,
      router: appRouter,
      createContext,
      onError: (opts) => {
        const { error, path } = opts;
        console.error(`[tRPC ERROR] ${path}:`, error.message);
        if (error.cause) console.error(`[tRPC CAUSE]`, error.cause);
      },
    });
  } catch (e: any) {
    console.error("[tRPC FATAL]", e.message);
    return c.json({ error: "Server error", message: e.message }, 500);
  }
});

// ─── 404 catch-all ───
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

// ─── Serve static files (index.html for SPA) ───
app.use("/*", async (c, next) => {
  await next();
  // If no route matched and it's not API, serve index.html
  if (c.res.status === 404 && !c.req.path.startsWith("/api/")) {
    try {
      const indexPath = path.join(process.cwd(), "dist", "public", "index.html");
      if (fs.existsSync(indexPath)) {
        return c.body(fs.readFileSync(indexPath), 200, { "Content-Type": "text/html" });
      }
    } catch { /* ignore */ }
  }
});

// ─── Global error handler ───
app.onError((err, c) => {
  console.error(`[Server Error] ${c.req.method} ${c.req.path}:`, err);
  return c.json({ error: "Internal server error" }, 500);
});

// ─── Auto-create missing tables on startup ───
(async () => {
  try {
    const mysql2 = await import("mysql2/promise");
    const pool = mysql2.createPool({
      uri: process.env.DATABASE_URL || "",
      connectionLimit: 2,
    });
    const conn = await pool.getConnection();

    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS unionId VARCHAR(255)`);
    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS username VARCHAR(255) UNIQUE`);
    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS passwordHash VARCHAR(255)`);
    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS name VARCHAR(255)`);
    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS role ENUM('user','admin') DEFAULT 'user'`);
    await conn.execute(`ALTER TABLE users ADD COLUMN IF NOT EXISTS lastSignInAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP`);

    await conn.execute(`ALTER TABLE cars ADD COLUMN IF NOT EXISTS lastCheckedAt TIMESTAMP NULL`);
    await conn.execute(`ALTER TABLE cars ADD COLUMN IF NOT EXISTS lastFilledAt TIMESTAMP NULL`);
    await conn.execute(`ALTER TABLE cars ADD COLUMN IF NOT EXISTS checkedBy VARCHAR(255) NULL`);
    await conn.execute(`ALTER TABLE cars ADD COLUMN IF NOT EXISTS filledBy VARCHAR(100) NULL`);

    await conn.execute(`ALTER TABLE carFluidSpecs ADD COLUMN IF NOT EXISTS lastCheckedAt TIMESTAMP NULL`);
    await conn.execute(`ALTER TABLE carFluidSpecs ADD COLUMN IF NOT EXISTS lastFilledAt TIMESTAMP NULL`);
    await conn.execute(`ALTER TABLE carFluidSpecs ADD COLUMN IF NOT EXISTS checkedBy VARCHAR(255) NULL`);
    await conn.execute(`ALTER TABLE carFluidSpecs ADD COLUMN IF NOT EXISTS filledBy VARCHAR(100) NULL`);

    await conn.execute(`ALTER TABLE products ADD COLUMN IF NOT EXISTS priorityLevel INT DEFAULT 2`);

    await conn.execute(`CREATE TABLE IF NOT EXISTS plateVinRegistry (
      id INT AUTO_INCREMENT PRIMARY KEY,
      plateNumber VARCHAR(20) NOT NULL, vin VARCHAR(50),
      make VARCHAR(255) NOT NULL, model VARCHAR(255) NOT NULL,
      year INT, engineCode VARCHAR(100), engineCapacity VARCHAR(50),
      transmission VARCHAR(100), fuel VARCHAR(50),
      source VARCHAR(50) DEFAULT 'manual' NOT NULL,
      isVerified ENUM('yes','no','pending') DEFAULT 'no' NOT NULL,
      verifiedBy INT, verifiedAt TIMESTAMP NULL,
      lastCheckedAt TIMESTAMP NULL, lastFilledAt TIMESTAMP NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
      notes TEXT,
      INDEX idx_plate (plateNumber), INDEX idx_vin (vin)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

    await conn.execute(`CREATE TABLE IF NOT EXISTS aiAgentResults (
      id INT AUTO_INCREMENT PRIMARY KEY,
      make VARCHAR(255) NOT NULL, model VARCHAR(255) NOT NULL,
      generation VARCHAR(500), modification VARCHAR(500), engineCode VARCHAR(100),
      agentName VARCHAR(100) NOT NULL, agentProvider VARCHAR(50) NOT NULL,
      filledFields JSON, filledCount INT DEFAULT 0,
      rawResponse TEXT, parsedJson JSON,
      tokensInput INT DEFAULT 0, tokensOutput INT DEFAULT 0, tokensTotal INT DEFAULT 0,
      status ENUM('success','error','empty') DEFAULT 'success' NOT NULL,
      errorMessage TEXT, checkedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      filledAt TIMESTAMP NULL, durationMs INT DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
      INDEX idx_car (make, model), INDEX idx_agent (agentProvider)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);

    conn.release();
    await pool.end();
    console.log("[Boot] Database schema OK");
  } catch (e: any) {
    console.warn("[Boot] Schema check:", e.message);
  }
})();

// ─── Start server ───
const port = parseInt(process.env.PORT || "3000");

try {
  const { serve } = await import("@hono/node-server");

  serve({ fetch: app.fetch, port }, () => {
    console.log(`[Server] Running on port ${port}`);
  });
} catch (e: any) {
  console.error("[Server] Failed to start:", e.message);
  console.error("Make sure you run: npm install");
}

export default app;
