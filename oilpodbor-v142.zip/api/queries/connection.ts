import { drizzle } from "drizzle-orm/mysql2";
import * as schema from "@db/schema";
import * as relations from "@db/relations";

const fullSchema = { ...schema, ...relations };

let instance: ReturnType<typeof drizzle<typeof fullSchema>>;
let dbError: string | null = null;

function getDatabaseUrl(): string {
  // Try direct env var first (most reliable)
  const url = process.env.DATABASE_URL || "";
  if (url) return url;
  // Fallback: try to load from env module
  try {
    const { env } = require("../lib/env");
    return env?.databaseUrl || "";
  } catch {
    return "";
  }
}

export function getDb() {
  if (!instance) {
    const dbUrl = getDatabaseUrl();
    if (!dbUrl) {
      const msg = "DATABASE_URL is not set. Check your .env file.";
      console.error("[DB] " + msg);
      throw new Error(msg);
    }
    try {
      instance = drizzle(dbUrl, {
        mode: "planetscale",
        schema: fullSchema,
      });
      console.log("[DB] Connected successfully");
    } catch (e: any) {
      dbError = e.message;
      console.error("[DB] Failed to connect:", e.message);
      throw new Error("Database connection failed: " + e.message);
    }
  }
  return instance;
}

export function getDbStatus() {
  return { connected: !!instance, error: dbError };
}
