import { useRef, useState, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Html, Text } from "@react-three/drei";
import * as THREE from "three";

// ─── Animated fluid particles ───
function FluidParticles({ path, color, speed = 1, count = 20 }) {
  const points = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(path.map((p) => new THREE.Vector3(...p)));
    return Array.from({ length: count }, (_, i) => ({
      t: i / count,
      offset: Math.random() * 0.3,
    }));
  }, [path, count]);

  const groupRef = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (!groupRef.current) return;
    groupRef.current.children.forEach((child, i) => {
      const p = points[i];
      p.t += delta * speed * 0.3;
      if (p.t > 1) p.t -= 1;
      const curve = new THREE.CatmullRomCurve3(path.map((pp) => new THREE.Vector3(...pp)));
      const pos = curve.getPointAt(p.t);
      child.position.copy(pos);
    });
  });

  return (
    <group ref={groupRef}>
      {points.map((_, i) => (
        <mesh key={i}>
          <sphereGeometry args={[0.06, 8, 8]} />
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.8} transparent opacity={0.9} />
        </mesh>
      ))}
    </group>
  );
}

// ─── Fluid tube ───
function FluidTube({ path, color }) {
  const curve = useMemo(() => {
    return new THREE.CatmullRomCurve3(path.map((p) => new THREE.Vector3(...p)));
  }, [path]);

  return (
    <mesh>
      <tubeGeometry args={[curve, 64, 0.03, 8, false]} />
      <meshStandardMaterial color={color} transparent opacity={0.4} emissive={color} emissiveIntensity={0.3} />
    </mesh>
  );
}

// ─── Car body (semi-transparent) ───
function CarBody() {
  return (
    <group>
      {/* Main body */}
      <mesh position={[0, 0.7, 0]}>
        <boxGeometry args={[4.2, 0.8, 1.8]} />
        <meshStandardMaterial color="#e8e8e8" transparent opacity={0.25} metalness={0.3} roughness={0.2} />
      </mesh>
      {/* Roof */}
      <mesh position={[0, 1.35, 0]}>
        <boxGeometry args={[2.2, 0.5, 1.6]} />
        <meshStandardMaterial color="#e8e8e8" transparent opacity={0.2} metalness={0.3} roughness={0.2} />
      </mesh>
      {/* Hood */}
      <mesh position={[1.3, 0.7, 0]}>
        <boxGeometry args={[1.6, 0.65, 1.75]} />
        <meshStandardMaterial color="#e8e8e8" transparent opacity={0.2} metalness={0.3} roughness={0.2} />
      </mesh>
      {/* Trunk */}
      <mesh position={[-1.5, 0.7, 0]}>
        <boxGeometry args={[1.2, 0.65, 1.75]} />
        <meshStandardMaterial color="#e8e8e8" transparent opacity={0.2} metalness={0.3} roughness={0.2} />
      </mesh>
      {/* Wheels */}
      {[[-1.3, 0.25, 0.9], [-1.3, 0.25, -0.9], [1.3, 0.25, 0.9], [1.3, 0.25, -0.9]].map((pos, i) => (
        <mesh key={i} position={pos as [number, number, number]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.35, 0.35, 0.2, 16]} />
          <meshStandardMaterial color="#333" metalness={0.5} roughness={0.8} />
        </mesh>
      ))}
    </group>
  );
}

// ─── Engine block ───
function Engine({ hovered, onHover }) {
  return (
    <group
      position={[1.0, 0.55, 0.2]}
      onPointerOver={(e) => { e.stopPropagation(); onHover("engine"); }}
      onPointerOut={() => onHover(null)}
    >
      <mesh>
        <boxGeometry args={[0.7, 0.5, 0.6]} />
        <meshStandardMaterial
          color={hovered === "engine" ? "#ff6b6b" : "#c0392b"}
          metalness={0.6}
          roughness={0.3}
          emissive={hovered === "engine" ? "#ff6b6b" : "#000"}
          emissiveIntensity={hovered === "engine" ? 0.3 : 0}
        />
      </mesh>
      {/* Engine label */}
      {hovered === "engine" && (
        <Html position={[0, 0.5, 0]} center>
          <div className="bg-white/95 backdrop-blur rounded-lg shadow-lg px-3 py-2 text-xs whitespace-nowrap border border-red-200">
            <p className="font-bold text-red-700">Двигатель</p>
            <p className="text-gray-600">Моторное масло 5W-30</p>
            <p className="text-gray-500">API SN / ACEA C3</p>
          </div>
        </Html>
      )}
    </group>
  );
}

// ─── Transmission ───
function Transmission({ hovered, onHover }) {
  return (
    <group
      position={[0.1, 0.45, 0.2]}
      onPointerOver={(e) => { e.stopPropagation(); onHover("transmission"); }}
      onPointerOut={() => onHover(null)}
    >
      <mesh>
        <cylinderGeometry args={[0.25, 0.25, 0.5, 16]} />
        <meshStandardMaterial
          color={hovered === "transmission" ? "#4ecdc4" : "#16a085"}
          metalness={0.5}
          roughness={0.4}
          emissive={hovered === "transmission" ? "#4ecdc4" : "#000"}
          emissiveIntensity={hovered === "transmission" ? 0.3 : 0}
        />
      </mesh>
      {hovered === "transmission" && (
        <Html position={[0, 0.5, 0]} center>
          <div className="bg-white/95 backdrop-blur rounded-lg shadow-lg px-3 py-2 text-xs whitespace-nowrap border border-teal-200">
            <p className="font-bold text-teal-700">КПП / АКПП</p>
            <p className="text-gray-600">Трансмиссионное масло 75W-90</p>
          </div>
        </Html>
      )}
    </group>
  );
}

// ─── Radiator ───
function Radiator({ hovered, onHover }) {
  return (
    <group
      position={[1.6, 0.55, 0]}
      onPointerOver={(e) => { e.stopPropagation(); onHover("radiator"); }}
      onPointerOut={() => onHover(null)}
    >
      <mesh>
        <boxGeometry args={[0.15, 0.5, 0.9]} />
        <meshStandardMaterial
          color={hovered === "radiator" ? "#74b9ff" : "#2980b9"}
          metalness={0.4}
          roughness={0.3}
          emissive={hovered === "radiator" ? "#74b9ff" : "#000"}
          emissiveIntensity={hovered === "radiator" ? 0.3 : 0}
        />
      </mesh>
      {hovered === "radiator" && (
        <Html position={[0, 0.5, 0]} center>
          <div className="bg-white/95 backdrop-blur rounded-lg shadow-lg px-3 py-2 text-xs whitespace-nowrap border border-blue-200">
            <p className="font-bold text-blue-700">Радиатор / Охлаждение</p>
            <p className="text-gray-600">Антифриз G12+ / G13</p>
          </div>
        </Html>
      )}
    </group>
  );
}

// ─── Brake system ───
function BrakeSystem({ hovered, onHover }) {
  return (
    <group
      position={[-0.8, 0.4, 0.6]}
      onPointerOver={(e) => { e.stopPropagation(); onHover("brakes"); }}
      onPointerOut={() => onHover(null)}
    >
      <mesh>
        <cylinderGeometry args={[0.12, 0.12, 0.15, 12]} />
        <meshStandardMaterial
          color={hovered === "brakes" ? "#a29bfe" : "#6c5ce7"}
          metalness={0.5}
          roughness={0.4}
          emissive={hovered === "brakes" ? "#a29bfe" : "#000"}
          emissiveIntensity={hovered === "brakes" ? 0.3 : 0}
        />
      </mesh>
      {hovered === "brakes" && (
        <Html position={[0, 0.4, 0]} center>
          <div className="bg-white/95 backdrop-blur rounded-lg shadow-lg px-3 py-2 text-xs whitespace-nowrap border border-purple-200">
            <p className="font-bold text-purple-700">Тормозная система</p>
            <p className="text-gray-600">DOT 4 / DOT 5.1</p>
          </div>
        </Html>
      )}
    </group>
  );
}

// ─── Steering (ГУР) ───
function Steering({ hovered, onHover }) {
  return (
    <group
      position={[1.2, 0.35, -0.4]}
      onPointerOver={(e) => { e.stopPropagation(); onHover("steering"); }}
      onPointerOut={() => onHover(null)}
    >
      <mesh>
        <cylinderGeometry args={[0.1, 0.1, 0.2, 12]} />
        <meshStandardMaterial
          color={hovered === "steering" ? "#fd79a8" : "#e84393"}
          metalness={0.5}
          roughness={0.4}
          emissive={hovered === "steering" ? "#fd79a8" : "#000"}
          emissiveIntensity={hovered === "steering" ? 0.3 : 0}
        />
      </mesh>
      {hovered === "steering" && (
        <Html position={[0, 0.4, 0]} center>
          <div className="bg-white/95 backdrop-blur rounded-lg shadow-lg px-3 py-2 text-xs whitespace-nowrap border border-pink-200">
            <p className="font-bold text-pink-700">ГУР / ЭГУ</p>
            <p className="text-gray-600">ATF DEXRON VI</p>
          </div>
        </Html>
      )}
    </group>
  );
}

// ─── Differential ───
function Differential({ hovered, onHover }) {
  return (
    <group
      position={[-1.0, 0.35, 0.2]}
      onPointerOver={(e) => { e.stopPropagation(); onHover("diff"); }}
      onPointerOut={() => onHover(null)}
    >
      <mesh>
        <boxGeometry args={[0.4, 0.25, 0.4]} />
        <meshStandardMaterial
          color={hovered === "diff" ? "#55efc4" : "#00b894"}
          metalness={0.5}
          roughness={0.4}
          emissive={hovered === "diff" ? "#55efc4" : "#000"}
          emissiveIntensity={hovered === "diff" ? 0.3 : 0}
        />
      </mesh>
      {hovered === "diff" && (
        <Html position={[0, 0.4, 0]} center>
          <div className="bg-white/95 backdrop-blur rounded-lg shadow-lg px-3 py-2 text-xs whitespace-nowrap border border-emerald-200">
            <p className="font-bold text-emerald-700">Дифференциал</p>
            <p className="text-gray-600">Масло 75W-90 GL-5</p>
          </div>
        </Html>
      )}
    </group>
  );
}

// ─── Main 3D Scene ───
function Scene() {
  const [hovered, setHovered] = useState<string | null>(null);

  // Fluid paths
  const engineOilPath: [number, number, number][] = [
    [1.0, 0.55, 0.2], [0.8, 0.7, 0.3], [0.5, 0.9, 0.1], [0.2, 0.7, -0.2], [0.1, 0.55, 0.2],
  ];
  const coolantPath: [number, number, number][] = [
    [1.6, 0.55, 0], [1.3, 0.8, 0.1], [1.0, 0.9, 0], [0.7, 0.8, -0.1], [0.4, 0.6, 0],
  ];
  const transOilPath: [number, number, number][] = [
    [0.1, 0.45, 0.2], [0.2, 0.6, 0.4], [0.4, 0.8, 0.2], [0.6, 0.65, 0], [0.8, 0.5, -0.2],
  ];
  const brakeFluidPath: [number, number, number][] = [
    [-0.8, 0.4, 0.6], [-0.4, 0.6, 0.5], [0, 0.8, 0.3], [0.5, 0.7, 0.1], [1.0, 0.5, 0],
  ];
  const steeringFluidPath: [number, number, number][] = [
    [1.2, 0.35, -0.4], [0.9, 0.55, -0.3], [0.5, 0.75, -0.2], [0.1, 0.65, -0.1], [-0.3, 0.45, 0],
  ];

  return (
    <>
      <ambientLight intensity={0.6} />
      <directionalLight position={[5, 5, 5]} intensity={0.8} />
      <directionalLight position={[-3, 3, -3]} intensity={0.3} color="#d32f2f" />

      <CarBody />
      <Engine hovered={hovered} onHover={setHovered} />
      <Transmission hovered={hovered} onHover={setHovered} />
      <Radiator hovered={hovered} onHover={setHovered} />
      <BrakeSystem hovered={hovered} onHover={setHovered} />
      <Steering hovered={hovered} onHover={setHovered} />
      <Differential hovered={hovered} onHover={setHovered} />

      {/* Fluid tubes */}
      <FluidTube path={engineOilPath} color="#f1c40f" />
      <FluidTube path={coolantPath} color="#3498db" />
      <FluidTube path={transOilPath} color="#1abc9c" />
      <FluidTube path={brakeFluidPath} color="#9b59b6" />
      <FluidTube path={steeringFluidPath} color="#e84393" />

      {/* Animated fluid particles */}
      <FluidParticles path={engineOilPath} color="#f1c40f" speed={1.2} count={15} />
      <FluidParticles path={coolantPath} color="#3498db" speed={0.8} count={12} />
      <FluidParticles path={transOilPath} color="#1abc9c" speed={1.0} count={10} />
      <FluidParticles path={brakeFluidPath} color="#9b59b6" speed={0.6} count={8} />
      <FluidParticles path={steeringFluidPath} color="#e84393" speed={0.9} count={10} />

      <OrbitControls
        enablePan={false}
        minDistance={3}
        maxDistance={8}
        minPolarAngle={Math.PI / 6}
        maxPolarAngle={Math.PI / 2.2}
        autoRotate
        autoRotateSpeed={0.5}
      />
    </>
  );
}

// ─── Exported component ───
export default function Car3DModel() {
  return (
    <div className="w-full h-[500px] rounded-xl overflow-hidden bg-gradient-to-b from-gray-50 to-gray-100 border border-gray-200 shadow-sm relative">
      {/* Legend */}
      <div className="absolute top-3 left-3 z-10 bg-white/90 backdrop-blur rounded-lg shadow-sm border border-gray-200 px-3 py-2 space-y-1">
        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Агрегаты</p>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-red-500" /><span className="text-[10px] text-gray-600">Двигатель — масло</span></div>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-blue-500" /><span className="text-[10px] text-gray-600">Радиатор — антифриз</span></div>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-teal-500" /><span className="text-[10px] text-gray-600">КПП — трансмиссия</span></div>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-purple-500" /><span className="text-[10px] text-gray-600">Тормоза — DOT</span></div>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-pink-500" /><span className="text-[10px] text-gray-600">ГУР — ATF</span></div>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /><span className="text-[10px] text-gray-600">Дифференциал</span></div>
      </div>
      <Canvas camera={{ position: [3, 2.5, 4], fov: 45 }}>
        <Scene />
      </Canvas>
    </div>
  );
}
