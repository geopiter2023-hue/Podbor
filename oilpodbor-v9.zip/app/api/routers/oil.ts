import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { oils } from "@db/schema";
import { eq, sql, asc } from "drizzle-orm";

export const oilRouter = createRouter({
  results: publicQuery
    .input(z.object({
      makeId: z.number(),
      modelId: z.number(),
      modificationId: z.number(),
    }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select({
          id: oils.id,
          originalName: oils.originalName,
          artNumber: oils.artNumber,
          volume: oils.volume,
          commentName: oils.commentName,
          orderPosition: oils.orderPosition,
        })
        .from(oils)
        .where(
          sql`${oils.makeId} = ${input.makeId} AND ${oils.modelId} = ${input.modelId}`
        )
        .orderBy(asc(oils.orderPosition));
    }),
});
