import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import {
  companies,
  searchLogs,
  oils,
  products,
  productAssignments,
  brands,
  models,
  modifications,
} from "@db/schema";
import { eq, and, sql, asc, desc } from "drizzle-orm";

// ─── Helpers ───

function extractDomain(referrer: string): string | null {
  try {
    const url = new URL(referrer);
    return url.hostname;
  } catch {
    return null;
  }
}

function isDomainAllowed(allowedDomains: unknown, requestDomain: string): boolean {
  if (!allowedDomains) return false;
  const domains = Array.isArray(allowedDomains) ? allowedDomains : [];
  if (domains.length === 0) return false;
  // Allow exact match or subdomain match
  return domains.some((d: string) => {
    const domain = d.toLowerCase().trim();
    const req = requestDomain.toLowerCase().trim();
    return domain === req || req.endsWith(`.${domain}`);
  });
}

function generateApiKey(): string {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let key = "mk_"; // oilpodbor key prefix
  for (let i = 0; i < 32; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return key;
}

// ─── API Key Validation Middleware (inline in procedures) ───

async function validateWidgetRequest(apiKey: string, referrerHeader: string | null) {
  const db = getDb();

  // Find company by API key
  const [company] = await db
    .select()
    .from(companies)
    .where(eq(companies.apiKey, apiKey))
    .limit(1);

  if (!company) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "Invalid API key",
    });
  }

  if (company.isActive !== "active") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Company account is suspended",
    });
  }

  // Validate domain
  const requestDomain = referrerHeader ? extractDomain(referrerHeader) : null;
  if (!requestDomain || !isDomainAllowed(company.allowedDomains, requestDomain)) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: `Domain not authorized: ${requestDomain || "unknown"}`,
    });
  }

  return { company, domain: requestDomain };
}

// ─── Log search request ───

async function logSearch(
  data: {
    companyId: number;
    apiKey: string;
    domain: string;
    makeId?: number;
    modelId?: number;
    modificationId?: string | number;
    makeName?: string | null;
    modelName?: string | null;
    modificationName?: string | null;
    engineCode?: string | null;
    clientIp?: string | null;
    userAgent?: string | null;
  }
) {
  const db = getDb();
  await db.insert(searchLogs).values({
    companyId: data.companyId,
    apiKey: data.apiKey,
    domain: data.domain,
    makeId: data.makeId || null,
    modelId: data.modelId || null,
    modificationId: data.modificationId?.toString() || null,
    makeName: data.makeName || null,
    modelName: data.modelName || null,
    modificationName: data.modificationName || null,
    engineCode: data.engineCode || null,
    clientIp: data.clientIp || null,
    userAgent: data.userAgent || null,
  });
}

// ─── Widget Router ───

export const widgetRouter = createRouter({
  // ─── Validate API key (called by widget on init) ───
  validate: publicQuery
    .input(
      z.object({
        apiKey: z.string().min(1),
      })
    )
    .query(async ({ input, ctx }) => {
      const referrer = ctx.req.headers.get("referer") || ctx.req.headers.get("origin");
      const { company, domain } = await validateWidgetRequest(input.apiKey, referrer);

      return {
        valid: true,
        company: {
          id: company.id,
          name: company.name,
          logo: company.logo,
        },
        domain,
      };
    }),

  // ─── Get brands directly from TObrands ───
  brands: publicQuery
    .input(z.object({ apiKey: z.string().min(1) }))
    .query(async ({ input, ctx }) => {
      const referrer = ctx.req.headers.get("referer") || ctx.req.headers.get("origin");
      await validateWidgetRequest(input.apiKey, referrer);

      const db = getDb();
      const result = await db
        .select({ id: brands.id, name: brands.name })
        .from(brands)
        .orderBy(asc(brands.name));

      return result.map((r) => ({ id: Number(r.id), name: r.name }));
    }),

  // ─── Get models ───
  models: publicQuery
    .input(z.object({ apiKey: z.string().min(1), makeId: z.number() }))
    .query(async ({ input, ctx }) => {
      const referrer = ctx.req.headers.get("referer") || ctx.req.headers.get("origin");
      await validateWidgetRequest(input.apiKey, referrer);

      const db = getDb();
      const result = await db
        .select({
          modelId: models.modelId,
          makeId: models.makeId,
          modelName: models.modelName,
          yearFrom: models.yearFrom,
          yearTo: models.yearTo,
        })
        .from(models)
        .where(eq(models.makeId, input.makeId))
        .orderBy(asc(models.modelName));

      return result.map((r) => ({
        modelId: Number(r.modelId),
        makeId: Number(r.makeId),
        modelName: r.modelName,
        yearFrom: r.yearFrom,
        yearTo: r.yearTo,
      }));
    }),

  // ─── Get modifications ───
  modifications: publicQuery
    .input(z.object({ apiKey: z.string().min(1), makeId: z.number(), modelId: z.number() }))
    .query(async ({ input, ctx }) => {
      const referrer = ctx.req.headers.get("referer") || ctx.req.headers.get("origin");
      await validateWidgetRequest(input.apiKey, referrer);

      const db = getDb();
      const result = await db
        .select({
          id: modifications.id,
          name: modifications.name,
          engineCode: modifications.engineCode,
          fuel: modifications.fuel,
          horsePower: modifications.horsePower,
          startDate: modifications.startDate,
          endDate: modifications.endDate,
          engineCapacity: modifications.engineCapacity,
          constructionType: modifications.constructionType,
          motorType: modifications.motorType,
        })
        .from(modifications)
        .where(eq(modifications.makeId, input.makeId))
        .orderBy(asc(modifications.modelId), asc(modifications.name));

      return result.map((r) => ({
        id: r.id,
        name: r.name,
        engineCode: r.engineCode,
        fuel: r.fuel,
        horsePower: r.horsePower,
        startDate: r.startDate,
        endDate: r.endDate,
        engineCapacity: r.engineCapacity,
        constructionType: r.constructionType,
        motorType: r.motorType,
      }));
    }),

  // ─── Get oils + company products for a specific car ───
  results: publicQuery
    .input(z.object({ apiKey: z.string().min(1), makeId: z.number(), modelId: z.number(), modificationId: z.number() }))
    .query(async ({ input, ctx }) => {
      const referrer = ctx.req.headers.get("referer") || ctx.req.headers.get("origin");
      const { company, domain } = await validateWidgetRequest(input.apiKey, referrer);

      const db = getDb();

      // Find the modification to get its string ID
      const [modInfo] = await db
        .select({ id: modifications.id })
        .from(modifications)
        .where(eq(modifications.makeId, input.makeId))
        .limit(1);

      // Get catalog oils directly by makeId + modelId
      const catalogOils = await db
        .select({
          id: oils.id,
          originalName: oils.originalName,
          artNumber: oils.artNumber,
          volume: oils.volume,
          commentName: oils.commentName,
          orderPosition: oils.orderPosition,
        })
        .from(oils)
        .where(sql`${oils.makeId} = ${input.makeId} AND ${oils.modelId} = ${input.modelId}`)
        .orderBy(asc(oils.orderPosition));

      // Get car info for logging
      const [carInfo] = await db
        .select({
          makeName: brands.name,
          modelName: models.modelName,
        })
        .from(brands)
        .leftJoin(models, eq(models.makeId, brands.id))
        .where(eq(brands.id, input.makeId))
        .limit(1);

      // Get company products
      const companyProducts = await db
        .select({
          assignmentId: productAssignments.id,
          isRecommended: productAssignments.isRecommended,
          notes: productAssignments.notes,
          id: products.id,
          name: products.name,
          sku: products.sku,
          brand: products.brand,
          category: products.category,
          price: products.price,
          volume: products.volume,
          specs: products.specs,
          imageUrl: products.imageUrl,
        })
        .from(productAssignments)
        .innerJoin(products, eq(productAssignments.productId, products.id))
        .where(
          and(
            eq(productAssignments.companyId, company.id),
            eq(productAssignments.makeId, input.makeId),
            eq(productAssignments.modelId, input.modelId)
          )
        )
        .orderBy(desc(productAssignments.isRecommended));

      // Log the search
      await logSearch({
        companyId: company.id,
        apiKey: input.apiKey,
        domain,
        makeId: input.makeId,
        modelId: input.modelId,
        modificationId: input.modificationId,
        makeName: carInfo?.makeName || null,
        modelName: carInfo?.modelName || null,
        clientIp: ctx.req.headers.get("x-forwarded-for") || ctx.req.headers.get("x-real-ip"),
        userAgent: ctx.req.headers.get("user-agent"),
      });

      return {
        catalogOils,
        companyProducts,
        carInfo: {
          make: carInfo?.makeName || "",
          model: carInfo?.modelName || "",
          modification: "",
          engineCode: "",
        },
      };
    }),
});

export { generateApiKey };
