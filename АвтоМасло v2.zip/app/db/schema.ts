import {
  mysqlTable,
  serial,
  varchar,
  int,
  json,
  bigint,
  index,
  uniqueIndex,
  mysqlEnum,
  text,
  timestamp,
} from "drizzle-orm/mysql-core";

// ═══════════════════════════════════════════
//  AUTH & MULTI-TENANCY
// ═══════════════════════════════════════════

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }),
  username: varchar("username", { length: 255 }).unique(),
  passwordHash: varchar("passwordHash", { length: 255 }),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
}, (table) => [
  index("users_username_idx").on(table.username),
]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Companies (multi-tenant) ───
export const companies = mysqlTable("companies", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  logo: varchar("logo", { length: 500 }),
  contactEmail: varchar("contactEmail", { length: 320 }),
  contactPhone: varchar("contactPhone", { length: 50 }),
  isActive: mysqlEnum("isActive", ["active", "suspended", "archived"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
}, (table) => [
  index("companies_slug_idx").on(table.slug),
  index("companies_active_idx").on(table.isActive),
]);

// ─── Company Users (membership) ───
export const companyUsers = mysqlTable("companyUsers", {
  id: serial("id").primaryKey(),
  companyId: int("companyId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["owner", "manager", "viewer"]).default("viewer").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("companyUsers_unique_idx").on(table.companyId, table.userId),
  index("companyUsers_company_idx").on(table.companyId),
  index("companyUsers_user_idx").on(table.userId),
]);

// ─── Products (company-specific catalog) ───
export const products = mysqlTable("products", {
  id: serial("id").primaryKey(),
  companyId: int("companyId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  sku: varchar("sku", { length: 100 }).notNull(),
  brand: varchar("brand", { length: 255 }),
  category: varchar("category", { length: 255 }),
  description: text("description"),
  price: int("price"), // cents
  currency: varchar("currency", { length: 3 }).default("RUB"),
  volume: varchar("volume", { length: 50 }),
  specs: json("specs"), // { viscosity, api, acea, oemApprovals }
  imageUrl: varchar("imageUrl", { length: 500 }),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("products_sku_company_idx").on(table.companyId, table.sku),
  index("products_company_idx").on(table.companyId),
  index("products_active_idx").on(table.isActive),
  index("products_category_idx").on(table.category),
]);

// ─── Product-to-Car Assignments ───
export const productAssignments = mysqlTable("productAssignments", {
  id: serial("id").primaryKey(),
  companyId: int("companyId").notNull(),
  productId: int("productId").notNull(),
  makeId: int("makeId").notNull(),
  modelId: int("modelId").notNull(),
  modificationId: varchar("modificationId", { length: 53 }).notNull(),
  notes: varchar("notes", { length: 500 }),
  isRecommended: mysqlEnum("isRecommended", ["yes", "no"]).default("no").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("productAssignments_unique_idx").on(table.companyId, table.productId, table.makeId, table.modelId, table.modificationId),
  index("productAssignments_company_idx").on(table.companyId),
  index("productAssignments_product_idx").on(table.productId),
  index("productAssignments_car_idx").on(table.makeId, table.modelId),
]);

// ═══════════════════════════════════════════
//  ORIGINAL CATALOG TABLES (from SQL dumps)
// ═══════════════════════════════════════════

export const mapping = mysqlTable(
  "mapping",
  {
    id: serial("id").primaryKey(),
    newMakeId: bigint("newMakeId", { mode: "number", unsigned: true }).notNull().default(0),
    newModelId: bigint("newModelId", { mode: "number", unsigned: true }).notNull().default(0),
    newTypeId: bigint("newTypeId", { mode: "number", unsigned: true }).notNull().default(0),
    seoType: varchar("seoType", { length: 512 }),
    makeId: int("makeId"),
    modelId: int("modelId"),
    typeId: varchar("typeId", { length: 53 }),
  },
  (table) => [
    index("mapping_newMakeId_idx").on(table.newMakeId),
    index("mapping_newMakeModel_idx").on(table.newMakeId, table.newModelId),
    index("mapping_newMakeModelType_idx").on(table.newMakeId, table.newModelId, table.newTypeId),
    index("mapping_seoType_idx").on(table.seoType),
    index("mapping_makeId_idx").on(table.makeId),
    index("mapping_makeModel_idx").on(table.makeId, table.modelId),
    index("mapping_makeModelType_idx").on(table.makeId, table.modelId, table.typeId),
  ]
);

export const brands = mysqlTable("TObrands", {
  id: int("id"),
  name: varchar("name", { length: 255 }),
}, (table) => [
  uniqueIndex("TObrands_id_name_idx").on(table.id, table.name),
  index("TObrands_id_idx").on(table.id),
]);

export const models = mysqlTable("TOmodels", {
  makeId: int("makeId"),
  modelId: int("modelId"),
  modelName: varchar("modelName", { length: 255 }),
  yearFrom: varchar("yearFrom", { length: 255 }),
  yearTo: varchar("yearTo", { length: 255 }),
}, (table) => [
  uniqueIndex("TOmodels_unique_idx").on(table.makeId, table.modelId, table.modelName, table.yearFrom, table.yearTo),
  index("TOmodels_makeId_idx").on(table.makeId),
  index("TOmodels_modelId_idx").on(table.modelId),
]);

export const modifications = mysqlTable("TOmodifications", {
  id: varchar("id", { length: 53 }),
  name: varchar("name", { length: 100 }),
  engineCode: varchar("engineCode", { length: 100 }),
  constructionType: varchar("constructionType", { length: 255 }),
  fuel: varchar("fuel", { length: 255 }),
  horsePower: varchar("horsePower", { length: 255 }),
  startDate: varchar("startDate", { length: 25 }),
  endDate: varchar("endDate", { length: 25 }),
  engineCapacity: varchar("engineCapacity", { length: 255 }),
  numberOfCylinders: varchar("numberOfCylinders", { length: 255 }),
  valves: varchar("valves", { length: 255 }),
  valvesTotal: varchar("valvesTotal", { length: 255 }),
  motorType: varchar("motorType", { length: 255 }),
  fullName: varchar("fullName", { length: 255 }),
  brand: json("brand"),
  model: json("model"),
  makeId: int("makeId"),
  modelId: int("modelId"),
}, (table) => [
  uniqueIndex("TOmodifications_unique_idx").on(table.id, table.name, table.engineCode, table.fullName, table.makeId, table.modelId),
  index("TOmodifications_makeModel_idx").on(table.makeId, table.modelId),
  index("TOmodifications_modelId_idx").on(table.modelId),
  index("TOmodifications_id_idx").on(table.id),
]);

export const oils = mysqlTable("TOoils", {
  id: serial("id").primaryKey(),
  makeId: int("makeId"),
  modelId: int("modelId"),
  modificationId: int("modificationId"),
  catalogId: int("catalogId"),
  catalogItemId: int("catalogItemId"),
  orderPosition: int("orderPosition"),
  artNumber: varchar("artNumber", { length: 255 }),
  originalName: varchar("originalName", { length: 255 }),
  volume: varchar("volume", { length: 255 }),
  commentName: varchar("commentName", { length: 255 }),
}, (table) => [
  index("TOoils_makeModelMod_idx").on(table.makeId, table.modelId, table.modificationId),
  index("TOoils_modelId_idx").on(table.modelId),
  index("TOoils_modificationId_idx").on(table.modificationId),
]);

export const parts = mysqlTable("TOparts", {
  id: int("id"),
  makeId: int("makeId"),
  modelId: int("modelId"),
  modificationId: varchar("modificationId", { length: 255 }),
  manufacturerId: int("manufacturerId"),
  manufacturerName: varchar("manufacturerName", { length: 255 }),
  itemName: varchar("itemName", { length: 100 }),
  partNumber: varchar("partNumber", { length: 255 }),
  quantity: int("quantity"),
  comment: varchar("comment", { length: 255 }),
}, (table) => [
  uniqueIndex("TOparts_unique_idx").on(table.makeId, table.modelId, table.modificationId, table.manufacturerId, table.partNumber, table.quantity, table.itemName),
  index("TOparts_makeModelMod_idx").on(table.makeId, table.modelId, table.modificationId),
  index("TOparts_modelId_idx").on(table.modelId),
  index("TOparts_modificationId_idx").on(table.modificationId),
  index("TOparts_itemName_idx").on(table.itemName),
]);

export const partsCrosses = mysqlTable("TOpartsCrosses", {
  id: serial("id").primaryKey(),
  manufacturerName: varchar("manufacturerName", { length: 255 }),
  partNumber: varchar("partNumber", { length: 255 }),
  crossBrand: varchar("crossBrand", { length: 100 }),
  crossNumber: varchar("crossNumber", { length: 50 }),
}, (table) => [
  index("TOpartsCrosses_mfr_idx").on(table.manufacturerName, table.partNumber),
]);
