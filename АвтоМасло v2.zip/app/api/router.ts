import { createRouter, publicQuery } from "./middleware";
import { localAuthRouter } from "./routers/localAuth";
import { setupRouter } from "./routers/setup";
import { carRouter } from "./routers/car";
import { oilRouter } from "./routers/oil";
import { partsRouter } from "./routers/parts";
import { adminRouter } from "./routers/admin";
import { companyRouter } from "./routers/company";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  localAuth: localAuthRouter,
  setup: setupRouter,
  car: carRouter,
  oil: oilRouter,
  parts: partsRouter,
  admin: adminRouter,
  company: companyRouter,
});

export type AppRouter = typeof appRouter;
