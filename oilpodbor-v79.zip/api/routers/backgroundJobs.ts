import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { backgroundJobs } from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { runResearcher } from "../agents/researcher";

/**
 * Background AI Fill Engine
 * Runs on server independently of client connection.
 */

export const backgroundJobsRouter = createRouter({
  // ─── Create and start a background job ───
  start: adminQuery
    .input(z.object({
      makes: z.array(z.string()).optional(),
      models: z.array(z.string()).optional(),
      yearFrom: z.number().optional(),
      yearTo: z.number().optional(),
      delaySeconds: z.number().default(2),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();

      // Count how many cars will be processed
      const makeList = input.makes || [];
      const modelList = input.models || [];
      const yearFrom = input.yearFrom;
      const yearTo = input.yearTo;

      // Create job record
      const [job] = await db.insert(backgroundJobs).values({
        type: "ai-fill",
        status: "queued",
        makes: makeList.length > 0 ? JSON.stringify(makeList) : null,
        models: modelList.length > 0 ? JSON.stringify(modelList) : null,
        yearFrom: yearFrom || null,
        yearTo: yearTo || null,
        delaySeconds: input.delaySeconds,
        totalCars: 0,
        processedCars: 0,
        shouldStop: "no",
      }).$returningId();

      const jobId = job.id;

      // Start processing in background (non-blocking)
      setTimeout(() => runBackgroundFill(jobId, makeList, modelList, yearFrom, yearTo, input.delaySeconds), 0);

      return { jobId, status: "queued" };
    }),

  // ─── Get job status ───
  status: adminQuery
    .input(z.object({ id: z.number() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.id) {
        const [job] = await db.select().from(backgroundJobs).where(eq(backgroundJobs.id, input.id)).limit(1);
        return job || null;
      }
      // Return latest 10 jobs
      return db.select().from(backgroundJobs).orderBy(desc(backgroundJobs.createdAt)).limit(10);
    }),

  // ─── Stop a running job ───
  stop: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(backgroundJobs)
        .set({ shouldStop: "yes", status: "stopped" })
        .where(eq(backgroundJobs.id, input.id));
      return { success: true };
    }),

  // ─── List all jobs ───
  list: adminQuery
    .input(z.object({ limit: z.number().default(20) }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(backgroundJobs).orderBy(desc(backgroundJobs.createdAt)).limit(input?.limit || 20);
    }),

  // ─── Delete old completed jobs ───
  cleanup: adminQuery
    .input(z.object({ days: z.number().default(7) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(backgroundJobs).where(
        sql`${backgroundJobs.status} IN ('completed', 'failed', 'stopped') AND ${backgroundJobs.createdAt} < DATE_SUB(NOW(), INTERVAL ${input.days} DAY)`
      );
      return { success: true };
    }),
});

/**
 * The actual background worker — runs independently of client
 */
async function runBackgroundFill(
  jobId: number,
  makes: string[],
  models: string[],
  yearFrom?: number,
  yearTo?: number,
  delaySeconds: number = 2,
) {
  const db = getDb();

  try {
    // Mark as running
    await db.update(backgroundJobs)
      .set({ status: "running", startedAt: new Date() })
      .where(eq(backgroundJobs.id, jobId));

    // Get cars to process — use raw SQL to handle multiple makes efficiently
    const makeCondition = makes.length > 0
      ? `LOWER(c.make) IN (${makes.map(m => `'${m.toLowerCase().replace(/'/g, "''")}'`).join(',')})`
      : '1=1';

    const yearCondition = (yearFrom !== undefined && yearTo !== undefined)
      ? `(c.yearTo >= ${yearFrom} AND c.yearFrom <= ${yearTo})`
      : '1=1';

    // Get distinct make+model combinations
    const carQuery = `
      SELECT DISTINCT c.make, c.model
      FROM cars c
      WHERE c.isActive = 'active'
        AND ${makeCondition}
        AND ${yearCondition}
      ORDER BY c.make, c.model
    `;

    const allCars = await db.execute(sql.raw(carQuery));
    const carRows = allCars[0] as any[] || [];

    // Filter by specific models if provided
    let carsToProcess = carRows;
    if (models.length > 0) {
      const modelSet = new Set(models.map(m => m.toUpperCase()));
      carsToProcess = carRows.filter((c: any) => {
        const key = `${c.make}|${c.model}`.toUpperCase();
        return modelSet.has(key);
      });
    }

    if (carsToProcess.length === 0) {
      await db.update(backgroundJobs)
        .set({ status: "completed", completedAt: new Date(), lastError: "Нет авто для обработки" })
        .where(eq(backgroundJobs.id, jobId));
      return;
    }

    // Update total count
    await db.update(backgroundJobs)
      .set({ totalCars: carsToProcess.length })
      .where(eq(backgroundJobs.id, jobId));

    // Process each car
    let processed = 0;
    let successCount = 0;
    let errorCount = 0;
    let totalTokensIn = 0;
    let totalTokensOut = 0;
    const errors: string[] = [];

    for (let i = 0; i < carsToProcess.length; i++) {
      const car = carsToProcess[i];

      // Check if should stop
      const [jobCheck] = await db.select({ shouldStop: backgroundJobs.shouldStop })
        .from(backgroundJobs)
        .where(eq(backgroundJobs.id, jobId))
        .limit(1);
      if (jobCheck?.shouldStop === "yes") {
        await db.update(backgroundJobs)
          .set({ status: "stopped", completedAt: new Date() })
          .where(eq(backgroundJobs.id, jobId));
        return;
      }

      // Update current car
      await db.update(backgroundJobs)
        .set({
          currentMake: car.make,
          currentModel: car.model,
          processedCars: processed,
        })
        .where(eq(backgroundJobs.id, jobId));

      try {
        const result = await runResearcher({
          make: car.make,
          model: car.model,
        }, undefined);

        if (result.success) {
          successCount++;
          if (result.tokensUsed) {
            totalTokensIn += result.tokensUsed.input || 0;
            totalTokensOut += result.tokensUsed.output || 0;
          }
        } else {
          errorCount++;
        }
      } catch (e: any) {
        errorCount++;
        const errMsg = e.message || "Unknown error";
        errors.push(`${car.make} ${car.model}: ${errMsg}`);
        if (errors.length > 20) errors.shift(); // Keep last 20

        await db.update(backgroundJobs)
          .set({
            lastError: errMsg,
            errorLog: errors.join("\n"),
          })
          .where(eq(backgroundJobs.id, jobId));
      }

      processed++;

      // Update progress every car
      await db.update(backgroundJobs)
        .set({
          processedCars: processed,
          successCars: successCount,
          errorCars: errorCount,
          tokensInput: totalTokensIn,
          tokensOutput: totalTokensOut,
        })
        .where(eq(backgroundJobs.id, jobId));

      // Rate limiting
      if (i < carsToProcess.length - 1) {
        await new Promise(r => setTimeout(r, delaySeconds * 1000));
      }
    }

    // Mark as completed
    await db.update(backgroundJobs)
      .set({
        status: "completed",
        completedAt: new Date(),
        processedCars: processed,
        successCars: successCount,
        errorCars: errorCount,
        tokensInput: totalTokensIn,
        tokensOutput: totalTokensOut,
        currentMake: null,
        currentModel: null,
      })
      .where(eq(backgroundJobs.id, jobId));

  } catch (e: any) {
    await db.update(backgroundJobs)
      .set({
        status: "failed",
        completedAt: new Date(),
        lastError: e.message || "Background job failed",
      })
      .where(eq(backgroundJobs.id, jobId));
  }
}
