import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { aiAgentResults, carFluidSpecs } from "@db/schema";
import { eq, and, sql, desc } from "drizzle-orm";

export const aiAgentsRouter = createRouter({
  // ─── List results for a car ───
  listByCar: adminQuery
    .input(z.object({ make: z.string(), model: z.string() }))
    .query(async ({ input }) => {
      try {
        const db = getDb();
        return await db.select().from(aiAgentResults)
        .where(and(
          sql`LOWER(${aiAgentResults.make}) = LOWER(${input.make})`,
          sql`LOWER(${aiAgentResults.model}) = LOWER(${input.model})`,
        ))
        .orderBy(desc(aiAgentResults.createdAt));
      } catch (e: any) {
        console.error("[aiAgents] listByCar error:", e.message);
        return [];
      }
    }),

  // ─── List all results (paginated) ───
  list: adminQuery
    .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }).optional())
    .query(async ({ input }) => {
      try {
        const db = getDb();
        const items = await db.select().from(aiAgentResults)
        .orderBy(desc(aiAgentResults.createdAt))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);
        const count = await db.select({ count: sql<number>`COUNT(*)` }).from(aiAgentResults);
        return { items, total: Number(count[0]?.count || 0) };
      } catch (e: any) {
        console.error("[aiAgents] list error:", e.message);
        return { items: [], total: 0 };
      }
    }),

  // ─── Get stats per agent ───
  stats: adminQuery.query(async () => {
    try {
      const db = getDb();
      const results = await db.select({
      agent: aiAgentResults.agentName,
      provider: aiAgentResults.agentProvider,
      totalRuns: sql<number>`COUNT(*)`,
      totalFields: sql<number>`SUM(${aiAgentResults.filledCount})`,
      totalTokens: sql<number>`SUM(${aiAgentResults.tokensTotal})`,
      avgTokens: sql<number>`AVG(${aiAgentResults.tokensTotal})`,
      avgDuration: sql<number>`AVG(${aiAgentResults.durationMs})`,
      successCount: sql<number>`SUM(CASE WHEN ${aiAgentResults.status} = 'success' THEN 1 ELSE 0 END)`,
      errorCount: sql<number>`SUM(CASE WHEN ${aiAgentResults.status} = 'error' THEN 1 ELSE 0 END)`,
    }).from(aiAgentResults)
      .groupBy(aiAgentResults.agentName, aiAgentResults.agentProvider)
      .orderBy(desc(sql<number>`COUNT(*)`));
      return results;
    } catch (e: any) {
      console.error("[aiAgents] stats error:", e.message);
      return [];
    }
  }),

  // ─── Clear results for a car ───
  clearByCar: adminQuery
    .input(z.object({ make: z.string(), model: z.string() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(aiAgentResults).where(and(
        sql`LOWER(${aiAgentResults.make}) = LOWER(${input.make})`,
        sql`LOWER(${aiAgentResults.model}) = LOWER(${input.model})`,
      ));
      return { success: true, message: `Данные агентов очищены для ${input.make} ${input.model}` };
    }),

  // ─── Clear all results ───
  clearAll: adminQuery.mutation(async () => {
    const db = getDb();
    await db.delete(aiAgentResults);
    return { success: true, message: "Все данные агентов очищены" };
  }),

  // ─── Save manual override (human path) ───
  saveManual: adminQuery
    .input(z.object({
      make: z.string(),
      model: z.string(),
      generation: z.string().optional(),
      modification: z.string().optional(),
      data: z.record(z.string()),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const filledFields = Object.keys(input.data).filter((k) => input.data[k] && input.data[k].trim() !== "");
      await db.insert(aiAgentResults).values({
        make: input.make,
        model: input.model,
        generation: input.generation || null,
        modification: input.modification || null,
        agentName: "Ручной ввод",
        agentProvider: "manual",
        filledFields: JSON.stringify(filledFields),
        filledCount: filledFields.length,
        rawResponse: JSON.stringify(input.data),
        parsedJson: input.data,
        tokensInput: 0,
        tokensOutput: 0,
        tokensTotal: 0,
        status: "success",
        durationMs: 0,
      });

      // Update carFluidSpecs with manual data
      const [existing] = await db.select().from(carFluidSpecs).where(
        and(
          sql`LOWER(${carFluidSpecs.make}) = LOWER(${input.make})`,
          sql`LOWER(${carFluidSpecs.model}) = LOWER(${input.model})`,
        )
      ).limit(1);

      const updateData: any = {};
      const fieldMap: Record<string, string> = {
        oilVolume: "engineFillVolume",
        oilSae: "prefOilSae",
        oilApi: "prefOilApi",
        oilAcea: "prefOilAcea",
        oilOem: "prefOilOe",
        transmissionType: "transmissionType",
        transmissionVolume: "transmissionFillVolume",
        coolantVolume: "coolantFillVolume",
        coolantType: "coolantType",
        brakeFluid: "brakeFluidType",
        frontDiffVolume: "frontDiffFillVolume",
        rearDiffVolume: "rearDiffFillVolume",
        oilFilter: "oilFilter",
        airFilter: "airFilter",
        cabinFilter: "cabinFilter",
        fuelFilter: "fuelFilter",
      };

      for (const [key, value] of Object.entries(input.data)) {
        const dbField = fieldMap[key];
        if (dbField && value) updateData[dbField] = value;
      }

      if (existing) {
        await db.update(carFluidSpecs).set(updateData).where(eq(carFluidSpecs.id, existing.id));
      } else {
        await db.insert(carFluidSpecs).values({
          make: input.make,
          model: input.model,
          ...updateData,
        });
      }

      return { success: true, filledFields: filledFields.length };
    }),
});
