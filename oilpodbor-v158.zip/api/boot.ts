// ─── 0. ESM polyfills ───
import { fileURLToPath } from "url";
import { dirname } from "path";
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// ─── 1. Load .env FIRST ───
try {
  require("dotenv").config();
} catch {
  /* dotenv not available */
}

// ─── 2. Debug env ───
const dbUrl = process.env.DATABASE_URL || "";
logger.info("cwd: " + process.cwd());
logger.info(".env exists: " + require("fs").existsSync("./.env"));
logger.info("DATABASE_URL: " + (dbUrl ? "SET" : "NOT SET!"));

if (!dbUrl) {
  logger.error("DATABASE_URL not set! Create .env file with DATABASE_URL=mysql://...");
}

// ─── 3. Polyfill ───
if (typeof (AbortSignal as any).timeout !== "function") {
  (AbortSignal as any).timeout = function(ms: number) {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), ms);
    return ctrl.signal;
  };
}

// ─── 4. Imports ───
import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import { serve } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { logger } from "./lib/logger";
import fs from "fs";
import path from "path";

const app = new Hono();
const PORT = parseInt(process.env.PORT || "3000");

// CORS
app.use("*", async (c, next) => {
  c.header("Access-Control-Allow-Origin", "*");
  c.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  c.header("Access-Control-Allow-Headers", "Content-Type, Authorization, x-local-auth-token");
  if (c.req.method === "OPTIONS") return c.body(null, 204);
  await next();
});

// Logging + rate limiting
app.use("*", async (c, next) => {
  const start = Date.now();

  // Rate limit API requests
  if (c.req.path.startsWith("/api/")) {
    const { checkRateLimit } = await import("./lib/rateLimit");
    const clientIp = c.req.header("x-forwarded-for") || "unknown";
    const limit = checkRateLimit(clientIp + ":" + c.req.path, 120, 60000);
    if (!limit.allowed) {
      return c.json({ error: "Too many requests" }, 429);
    }
  }

  await next();
  logger.info(`${c.req.method} ${c.req.path} — ${c.res.status} (${Date.now() - start}ms)`);
});

// Body limit
app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));

// Health check
app.get("/health", (c) => c.json({
  status: "ok",
  version: "v151",
  time: new Date().toISOString(),
  uptime: process.uptime(),
}));

// tRPC API
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
    onError: ({ error, path }) => console.error(`[tRPC ERR] ${path}:`, error.message),
  });
});

// Uploaded logos
app.use("/uploads/logos/*", async (c) => {
  const filePath = path.join(process.cwd(), "uploads", "logos", c.req.path.replace("/uploads/logos/", ""));
  if (fs.existsSync(filePath)) {
    const ext = path.extname(filePath).slice(1);
    const ct: Record<string, string> = {
      png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg",
      svg: "image/svg+xml", gif: "image/gif", webp: "image/webp",
    };
    return c.body(fs.readFileSync(filePath), 200, { "Content-Type": ct[ext] || "image/png" });
  }
  return c.json({ error: "Logo not found" }, 404);
});

// Static files (SPA fallback) — use __dirname for reliable path
const staticDir = path.join(__dirname, "..", "dist", "public");
app.use("/*", async (c) => {
  const url = new URL(c.req.url).pathname;
  let file = path.join(staticDir, url === "/" ? "/index.html" : url);
  if (!fs.existsSync(file)) file = path.join(staticDir, "index.html");
  try {
    const ext = path.extname(file).slice(1);
    const ct: Record<string, string> = {
      html: "text/html", js: "application/javascript", css: "text/css",
      json: "application/json", png: "image/png", jpg: "image/jpeg",
      jpeg: "image/jpeg", svg: "image/svg+xml", ico: "image/x-icon",
    };
    return c.body(fs.readFileSync(file), 200, { "Content-Type": ct[ext] || "text/plain" });
  } catch {
    return c.text("Not found", 404);
  }
});

// Global error
app.onError((err, c) => {
  console.error(`[ERR] ${c.req.method} ${c.req.path}:`, err.message);
  return c.json({ error: "Server error", msg: err.message }, 500);
});

// ─── 5. AUTO-CREATE TABLES ───
(async () => {
  try {
    const mysql2 = await import("mysql2/promise");
    const dbUrl = process.env.DATABASE_URL || "";
    if (!dbUrl) return;
    const pool = mysql2.createPool({ uri: dbUrl, connectionLimit: 2 });
    const conn = await pool.getConnection();
    await conn.execute(`CREATE TABLE IF NOT EXISTS brandLogos (
      id INT AUTO_INCREMENT PRIMARY KEY,
      brandName VARCHAR(255) NOT NULL,
      logoUrl VARCHAR(1000),
      logoSvg TEXT,
      source VARCHAR(50) DEFAULT 'manual',
      isActive ENUM('yes','no') DEFAULT 'yes' NOT NULL,
      aiFillStatus ENUM('empty','filled','error') DEFAULT 'empty' NOT NULL,
      aiErrorMessage TEXT,
      filledAt TIMESTAMP NULL,
      filledBy VARCHAR(100),
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
      UNIQUE KEY brandLogos_name_idx (brandName),
      KEY brandLogos_active_idx (isActive)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
    conn.release();
    await pool.end();
    logger.info("brandLogos table OK");
  } catch (e: any) {
    logger.warn("brandLogos table: " + e.message);
  }
})();

// ─── 6. START SERVER ───
logger.info("Starting server...");
logger.info("staticDir: " + staticDir);
logger.info("staticDir exists: " + fs.existsSync(staticDir));
serve({ fetch: app.fetch, port: PORT }, () => {
  logger.info(`Server running on port ${PORT}`);
  logger.info(`Health: http://localhost:${PORT}/health`);
  if (!fs.existsSync(staticDir)) {
    logger.warn("dist/public not found! Run: npm run build");
  }
});

export default app;
