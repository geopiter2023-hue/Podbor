/**
 * Drom.ru Catalog Parser — Advanced Version
 * - Fixes encoding (windows-1251 → UTF-8)
 - Deep parsing: dives into each car card for full specs
 * - Human-like behavior: random delays, User-Agent rotation, referrers
 * - Background scheduling via node-cron
 */

import { getDb } from "../queries/connection";
import { marketCars, marketSyncLog, carFluidSpecs } from "@db/schema";
import { eq, and, like, sql, desc } from "drizzle-orm";
import iconv from "iconv-lite";
import * as cheerio from "cheerio";

// ─── User-Agent rotation (human-like browsers) ───
const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
];

let uaIndex = 0;
function getUA() {
  uaIndex = (uaIndex + 1) % USER_AGENTS.length;
  return USER_AGENTS[uaIndex];
}

// ─── Random delay between requests (human-like) ───
function randomDelay(min = 1500, max = 4000): Promise<void> {
  const ms = Math.floor(Math.random() * (max - min) + min);
  return new Promise((r) => setTimeout(r, ms));
}

// ─── Fetch with encoding fix + human behavior ───
async function fetchHumanLike(url: string, retries = 3): Promise<string> {
  for (let i = 0; i <= retries; i++) {
    try {
      await randomDelay(800, 2500); // Always wait before request

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 25000);

      const resp = await fetch(url, {
        headers: {
          "User-Agent": getUA(),
          "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
          "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
          "Accept-Encoding": "gzip, deflate, br",
          "Referer": "https://www.drom.ru/catalog/",
          "DNT": "1",
          "Connection": "keep-alive",
          "Upgrade-Insecure-Requests": "1",
          "Sec-Fetch-Dest": "document",
          "Sec-Fetch-Mode": "navigate",
          "Sec-Fetch-Site": "same-origin",
          "Cache-Control": "max-age=0",
        },
        redirect: "follow",
        signal: controller.signal,
      });
      clearTimeout(timeout);

      if (!resp.ok) {
        if (resp.status === 429 || resp.status === 503) {
          console.warn(`[DromParser] Rate limited (429/503), waiting ${5 * (i + 1)}s...`);
          await new Promise((r) => setTimeout(r, 5000 * (i + 1)));
          continue;
        }
        if (resp.status === 403) {
          console.warn(`[DromParser] Blocked (403), rotating UA...`);
          await randomDelay(3000, 6000);
          continue;
        }
        throw new Error(`HTTP ${resp.status}`);
      }

      // Get raw buffer and decode properly
      const buffer = Buffer.from(await resp.arrayBuffer());
      let text: string;

      // Check for charset in Content-Type or meta tag
      const contentType = resp.headers.get("content-type") || "";
      if (contentType.includes("windows-1251") || contentType.includes("1251")) {
        text = iconv.decode(buffer, "windows-1251");
      } else {
        // Try decoding as UTF-8 first, check for garbled text
        text = buffer.toString("utf-8");
        // If we see replacement characters or common garbled patterns, try windows-1251
        if (text.includes("\uFFFD") || /[�ЌЋЏђ�]/g.test(text)) {
          text = iconv.decode(buffer, "windows-1251");
        }
      }

      // Double-check with cheerio meta charset
      const $meta = cheerio.load(text);
      const metaCharset = $meta('meta[charset]').attr('charset') || '';
      const metaContentType = $meta('meta[http-equiv="Content-Type"]').attr('content') || '';
      if ((metaCharset.includes("1251") || metaContentType.includes("1251")) && !contentType.includes("1251")) {
        text = iconv.decode(buffer, "windows-1251");
      }

      if (text.length < 200) {
        console.warn(`[DromParser] Response too short (${text.length}), retrying...`);
        if (i < retries) continue;
      }

      return text;
    } catch (e: any) {
      console.error(`[DromParser] Attempt ${i + 1} failed for ${url}: ${e.message}`);
      if (i === retries) throw e;
      await randomDelay(2000, 5000);
    }
  }
  throw new Error(`All retries failed for ${url}`);
}

// ─── Parse brand list ───
export async function fetchDromBrands(): Promise<Array<{ name: string; slug: string; url: string }>> {
  const html = await fetchHumanLike("https://www.drom.ru/catalog/");
  const $ = cheerio.load(html);
  const brands: Array<{ name: string; slug: string; url: string }> = [];
  const seen = new Set<string>();

  // Helper to extract slug from href
  const extractSlug = (href: string): string | null => {
    // Match: /catalog/audi/ or https://www.drom.ru/catalog/audi/
    const m = href.match(/\/catalog\/([^\/]+)\/?$/);
    return m ? m[1].toLowerCase().trim() : null;
  };

  // Method 1: Tile-based selectors (drom.ru uses these classes)
  const tileSelectors = [
    '.b-tile a', '.e-title a', '[class*="tile"] a',
    '[class*="brand"] a', '[class*="catalog"] a',
    'a[href*="/catalog/"]',
  ];
  for (const sel of tileSelectors) {
    $(sel).each((_, el) => {
      const href = $(el).attr("href") || "";
      const slug = extractSlug(href);
      const name = $(el).text().trim();
      if (slug && name.length > 1 && name.length < 50 && !seen.has(slug)) {
        // Filter out non-brand slugs
        if (!slug.match(/^(~|js|css|img|api|lcv|chinese|catalog|search)/)) {
          seen.add(slug);
          brands.push({ name, slug, url: `https://www.drom.ru/catalog/${slug}/` });
        }
      }
    });
  }

  // Method 2: JSON in page
  if (brands.length === 0) {
    const scriptMatch = html.match(/window\.__INITIAL_STATE__\s*=\s*(\{.+?\});?\s*<\/script>/s);
    if (scriptMatch) {
      try {
        const data = JSON.parse(scriptMatch[1]);
        const list = data?.catalog?.brands || data?.brands || [];
        list.forEach((b: any) => {
          const slug = (b.slug || b.code || "").toLowerCase();
          if (slug && !seen.has(slug)) {
            seen.add(slug);
            brands.push({ name: b.name || b.title || b.russianName || slug, slug, url: `https://www.drom.ru/catalog/${slug}/` });
          }
        });
      } catch (e) {
        console.error("[DromParser] JSON parse error:", (e as Error).message);
      }
    }
  }

  console.log(`[DromParser] Found ${brands.length} brands:`, brands.slice(0, 10).map((b) => b.name).join(", "));
  return brands;
}

// ─── Parse models for a brand ───
export async function fetchDromModels(brandSlug: string): Promise<Array<{ name: string; slug: string; url: string }>> {
  const html = await fetchHumanLike(`https://www.drom.ru/catalog/${brandSlug}/`);
  const $ = cheerio.load(html);
  const models: Array<{ name: string; slug: string; url: string }> = [];
  const seen = new Set<string>();

  // Helper to extract model slug from href
  const extractModelSlug = (href: string): string | null => {
    const re = new RegExp(`/catalog/${brandSlug}/([^/]+)/?$`);
    const m = href.match(re);
    return m ? m[1] : null;
  };

  // Method 1: Tile-based selectors
  const selectors = [
    `.b-tile a`, `.e-title a`, `[class*="tile"] a`,
    `a[href*="/catalog/${brandSlug}/"]`,
  ];
  for (const sel of selectors) {
    $(sel).each((_, el) => {
      const href = $(el).attr("href") || "";
      const slug = extractModelSlug(href);
      const name = $(el).text().trim();
      if (slug && name.length > 1 && name.length < 60 && !seen.has(slug)) {
        seen.add(slug);
        models.push({ name, slug, url: `https://www.drom.ru/catalog/${brandSlug}/${slug}/` });
      }
    });
  }

  console.log(`[DromParser] ${brandSlug}: found ${models.length} models`);
  return models;
}

// ─── Parse generations ───
export async function fetchDromGenerations(brandSlug: string, modelSlug: string): Promise<Array<{ name: string; years: string; url: string }>> {
  const html = await fetchHumanLike(`https://www.drom.ru/catalog/${brandSlug}/${modelSlug}/`);
  const $ = cheerio.load(html);
  const generations: Array<{ name: string; years: string; url: string }> = [];

  $('a[href*="/catalog/"]').each((_, el) => {
    const href = $(el).attr("href") || "";
    const match = href.match(new RegExp(`/catalog/${brandSlug}/${modelSlug}/([^/]+)/?$`));
    if (match) {
      const name = $(el).find("b, strong, .e-title").first().text().trim() || $(el).text().trim();
      const yearMatch = $(el).text().match(/(\d{4}[\s–-]+\d{4}?)/);
      const years = yearMatch ? yearMatch[1] : "";
      if (name.length > 1) {
        generations.push({ name, years, url: `https://www.drom.ru${href}` });
      }
    }
  });

  if (generations.length === 0) {
    const titleMatch = html.match(/<title>([^<]+)<\/title>/);
    if (titleMatch) {
      const title = titleMatch[1].replace(/каталог|— Дром/gi, "").trim();
      generations.push({ name: title, years: "", url: `https://www.drom.ru/catalog/${brandSlug}/${modelSlug}/` });
    }
  }

  return generations;
}

// ─── DEEP PARSING: dive into car card for full specs ───
export async function fetchDromCarSpecs(url: string): Promise<{
  engineType?: string;
  engineCapacity?: string;
  enginePower?: string;
  fuel?: string;
  transmission?: string;
  drive?: string;
  body?: string;
  yearFrom?: number;
  yearTo?: number;
  engineCode?: string;
  oilVolume?: string;
  oilSae?: string;
  coolantVolume?: string;
  brakeFluid?: string;
  transmissionOil?: string;
}> {
  const html = await fetchHumanLike(url);
  const $ = cheerio.load(html);
  const specs: any = {};

  // Parse spec tables
  $("table tr, .b-table tr, .techspec__row, .css-1dk枯萎hn tr").each((_, el) => {
    const tds = $(el).find("td, th, .techspec__name, .techspec__value, .css-xhdvva");
    if (tds.length >= 2) {
      const label = $(tds[0]).text().trim().toLowerCase();
      const value = $(tds[1]).text().trim();

      if (label.includes("объем") && label.includes("двиг")) specs.engineCapacity = value;
      else if (label.includes("мощност")) specs.enginePower = value;
      else if (label.includes("тип") && label.includes("двиг")) specs.engineType = value;
      else if (label.includes("топлив")) specs.fuel = value;
      else if (label.includes("короб")) specs.transmission = value;
      else if (label.includes("привод")) specs.drive = value;
      else if (label.includes("кузов")) specs.body = value;
      else if (label.includes("год") && label.includes("нач")) specs.yearFrom = parseInt(value) || undefined;
      else if (label.includes("год") && label.includes("кон")) specs.yearTo = parseInt(value) || undefined;
      else if (label.includes("объем") && label.includes("масл")) specs.oilVolume = value;
      else if (label.includes("вязкост") || label.includes("sae")) specs.oilSae = value;
      else if (label.includes("охлаждающ")) specs.coolantVolume = value;
      else if (label.includes("тормозн")) specs.brakeFluid = value;
      else if (label.includes("трансмисс") && label.includes("масл")) specs.transmissionOil = value;
    }
  });

  // Parse engine code from title or headings
  const title = $("title").text();
  const engineMatch = title.match(/(\d{3,}[A-Z]{0,3})/);
  if (engineMatch) specs.engineCode = engineMatch[1];

  // Parse year range from title or page
  const yearMatch = $("h1, .e-title, .css-1hdvva").first().text().match(/(\d{4})[\s–-]+(\d{4}?)/);
  if (yearMatch) {
    specs.yearFrom = parseInt(yearMatch[1]) || specs.yearFrom;
    specs.yearTo = parseInt(yearMatch[2]) || specs.yearTo;
  }

  return specs;
}

// ─── Full scan with deep parsing ───
export async function scanDromCatalog(options: {
  brandLimit?: number;
  modelLimit?: number;
  deepParse?: boolean;
  syncId?: number;
  onProgress?: (msg: string) => void;
} = {}) {
  const db = getDb();
  const startTime = Date.now();
  const brandLimit = options.brandLimit || 0;
  const modelLimit = options.modelLimit || 0;
  const deepParse = options.deepParse !== false; // default true

  let syncId = options.syncId || 0;
  if (!syncId) {
    const [syncLog] = await db.insert(marketSyncLog).values({
      source: "drom.ru",
      status: "running",
    }).$returningId();
    syncId = syncLog.id;
  }

  try {
    options.onProgress?.("Получаем список марок с drom.ru...");
    let brands: Awaited<ReturnType<typeof fetchDromBrands>> = [];
    try {
      brands = await fetchDromBrands();
    } catch (e: any) {
      options.onProgress?.(`Ошибка получения марок: ${e.message}`);
      await db.update(marketSyncLog).set({ status: "failed", error: e.message, completedAt: new Date() }).where(eq(marketSyncLog.id, syncId));
      return { syncId, totalFound: 0, totalNew: 0, duration: 0 };
    }

    if (brands.length === 0) {
      options.onProgress?.("Марки не найдены — возможно, drom.ru заблокировал доступ.");
      await db.update(marketSyncLog).set({ status: "completed", carsFound: 0, carsNew: 0, completedAt: new Date() }).where(eq(marketSyncLog.id, syncId));
      return { syncId, totalFound: 0, totalNew: 0, duration: 0 };
    }

    options.onProgress?.(`Найдено ${brands.length} марок`);

    let totalFound = 0;
    let totalNew = 0;
    const scannedBrands = brandLimit > 0 ? brands.slice(0, brandLimit) : brands;

    for (let bi = 0; bi < scannedBrands.length; bi++) {
      const brand = scannedBrands[bi];
      options.onProgress?.(`[${bi + 1}/${scannedBrands.length}] ${brand.name} — получаем модели...`);

      try {
        const models = await fetchDromModels(brand.slug);
        const scannedModels = modelLimit > 0 ? models.slice(0, modelLimit) : models;
        options.onProgress?.(`  ${models.length} моделей, парсим...`);

        for (const model of scannedModels) {
          try {
            // Check if already scanned recently
            const existing = await db
              .select()
              .from(marketCars)
              .where(and(
                eq(marketCars.source, "drom.ru"),
                sql`LOWER(${marketCars.make}) = LOWER(${brand.name})`,
                sql`LOWER(${marketCars.model}) = LOWER(${model.name})`,
              ))
              .limit(1);

            let fullSpecs: any = {};
            if (deepParse) {
              try {
                fullSpecs = await fetchDromCarSpecs(model.url);
                await randomDelay(500, 1500);
              } catch (e: any) {
                console.warn(`[DromParser] Deep parse failed for ${model.url}: ${e.message}`);
              }
            }

            const yearFrom = fullSpecs.yearFrom;
            const yearTo = fullSpecs.yearTo;

            if (existing.length === 0) {
              await db.insert(marketCars).values({
                source: "drom.ru",
                sourceUrl: model.url,
                make: brand.name,
                model: model.name,
                yearFrom,
                yearTo,
                engineCode: fullSpecs.engineCode,
                engineCapacity: fullSpecs.engineCapacity,
                enginePower: fullSpecs.enginePower,
                fuel: fullSpecs.fuel,
                transmission: fullSpecs.transmission,
                body: fullSpecs.body,
                status: "new",
                rawData: JSON.stringify(fullSpecs),
              });
              totalNew++;
            } else {
              // Update existing with new data
              await db.update(marketCars)
                .set({
                  yearFrom,
                  yearTo,
                  engineCode: fullSpecs.engineCode || existing[0].engineCode,
                  engineCapacity: fullSpecs.engineCapacity || existing[0].engineCapacity,
                  enginePower: fullSpecs.enginePower || existing[0].enginePower,
                  fuel: fullSpecs.fuel || existing[0].fuel,
                  transmission: fullSpecs.transmission || existing[0].transmission,
                  body: fullSpecs.body || existing[0].body,
                  rawData: JSON.stringify(fullSpecs),
                  status: "updated",
                })
                .where(eq(marketCars.id, existing[0].id));
            }

            totalFound++;
            await randomDelay(300, 1000);
          } catch (e: any) {
            options.onProgress?.(`  Ошибка модели ${model.name}: ${e.message}`);
          }
        }
      } catch (e: any) {
        options.onProgress?.(`Ошибка марки ${brand.name}: ${e.message}`);
      }

      await randomDelay(1000, 3000); // Delay between brands
    }

    await db.update(marketSyncLog)
      .set({ status: "completed", carsFound: totalFound, carsNew: totalNew, completedAt: new Date() })
      .where(eq(marketSyncLog.id, syncId));

    const duration = Math.round((Date.now() - startTime) / 1000);
    options.onProgress?.(`Готово! Найдено ${totalFound}, новых ${totalNew} за ${duration}с`);
    return { syncId, totalFound, totalNew, duration };

  } catch (e: any) {
    await db.update(marketSyncLog).set({ status: "failed", error: e.message, completedAt: new Date() }).where(eq(marketSyncLog.id, syncId));
    throw e;
  }
}

// ─── Stats ───
export async function getMarketStats() {
  const db = getDb();
  const statuses = ["new", "pending", "approved", "rejected", "updated", "merged"];
  const result: Record<string, number> = {};
  for (const s of statuses) {
    const r = await db.select({ count: sql<number>`COUNT(*)` }).from(marketCars).where(eq(marketCars.status, s as any));
    result[s] = Number(r[0]?.count || 0);
  }
  const total = await db.select({ count: sql<number>`COUNT(*)` }).from(marketCars);
  result.total = Number(total[0]?.count || 0);
  return result;
}

// ─── Approve → add to cars DB ───
export async function approveMarketCar(marketCarId: number, userId?: number) {
  const db = getDb();

  const [mc] = await db.select().from(marketCars).where(eq(marketCars.id, marketCarId)).limit(1);
  if (!mc) throw new Error("Market car not found");

  // Parse rawData
  let specs: any = {};
  try { specs = JSON.parse(mc.rawData || "{}"); } catch { /* ignore */ }

  // Insert or update carFluidSpecs
  const [existing] = await db
    .select()
    .from(carFluidSpecs)
    .where(and(
      sql`LOWER(${carFluidSpecs.make}) = LOWER(${mc.make})`,
      sql`LOWER(${carFluidSpecs.model}) = LOWER(${mc.model})`,
    ))
    .limit(1);

  if (existing) {
    await db.update(carFluidSpecs).set({
      engineCode: specs.engineCode || mc.engineCode || existing.engineCode,
      engineFillVolume: specs.oilVolume || existing.engineFillVolume,
      prefOilSae: specs.oilSae || existing.prefOilSae,
      coolantFillVolume: specs.coolantVolume || existing.coolantFillVolume,
      brakeFluidType: specs.brakeFluid || existing.brakeFluidType,
      transmissionType: mc.transmission || specs.transmission || existing.transmissionType,
      body: mc.body || specs.body || existing.body,
      fuel: mc.fuel || specs.fuel || existing.fuel,
      updatedAt: new Date(),
    }).where(eq(carFluidSpecs.id, existing.id));
  } else {
    await db.insert(carFluidSpecs).values({
      make: mc.make,
      model: mc.model,
      vehicleType: "Легковой автомобиль",
      engineCode: specs.engineCode || mc.engineCode,
      engineFillVolume: specs.oilVolume,
      prefOilSae: specs.oilSae,
      coolantFillVolume: specs.coolantVolume,
      brakeFluidType: specs.brakeFluid,
      transmissionType: mc.transmission || specs.transmission,
      body: mc.body || specs.body,
      fuel: mc.fuel || specs.fuel,
    });
  }

  await db.update(marketCars)
    .set({ status: "approved", reviewedBy: userId, reviewedAt: new Date() })
    .where(eq(marketCars.id, marketCarId));

  return { ok: true };
}

// ─── Background scheduler (runs every 6 hours) ───
let cronJob: any = null;

export function startBackgroundMonitoring() {
  if (cronJob) return; // Already running

  const { schedule } = require("node-cron");
  // Run every 6 hours at minute 0
  cronJob = schedule("0 */6 * * *", async () => {
    console.log("[DromMonitor] Starting scheduled scan at", new Date().toISOString());
    try {
      const db = getDb();
      // Check if a scan is already running
      const running = await db.select().from(marketSyncLog)
        .where(and(eq(marketSyncLog.source, "drom.ru"), eq(marketSyncLog.status, "running" as any)))
        .limit(1);

      if (running.length > 0) {
        console.log("[DromMonitor] Scan already running, skipping");
        return;
      }

      await scanDromCatalog({
        brandLimit: 0, // all brands
        modelLimit: 0, // all models
        deepParse: true,
        onProgress: (msg) => console.log(`[DromMonitor] ${msg}`),
      });
    } catch (e: any) {
      console.error("[DromMonitor] Scheduled scan failed:", e.message);
    }
  });

  console.log("[DromMonitor] Background monitoring started (every 6 hours)");
}

export function stopBackgroundMonitoring() {
  if (cronJob) {
    cronJob.stop();
    cronJob = null;
    console.log("[DromMonitor] Background monitoring stopped");
  }
}
