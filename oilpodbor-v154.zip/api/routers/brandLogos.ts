import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { brandLogos, brands } from "@db/schema";
import { eq, sql, asc, desc, like, and } from "drizzle-orm";

export const brandLogosRouter = createRouter({
  // ─── List all brand logos (public — for homepage) ───
  list: publicQuery.query(async () => {
    try {
      const db = getDb();
      // Get all brands with their logos (left join simulation)
      const allBrands = await db.select().from(brands).orderBy(asc(brands.name));
      const logos = await db.select().from(brandLogos).where(eq(brandLogos.isActive, "yes"));
      const logoMap = new Map();
      for (const l of logos) {
        logoMap.set(l.brandName.toLowerCase(), l);
      }
      return allBrands.map((b) => {
        const logo = logoMap.get(b.name?.toLowerCase() || "");
        return {
          id: b.id,
          name: b.name,
          logoUrl: logo?.logoUrl || null,
          logoSvg: logo?.logoSvg || null,
          hasLogo: !!logo?.logoUrl || !!logo?.logoSvg,
        };
      });
    } catch (e: any) {
      console.error("[brandLogos.list] ERROR:", e.message);
      return [];
    }
  }),

  // ─── Get single brand logo ───
  getByName: publicQuery
    .input(z.object({ name: z.string() }))
    .query(async ({ input }) => {
      try {
        const db = getDb();
        const [logo] = await db.select().from(brandLogos)
          .where(sql`LOWER(${brandLogos.brandName}) = LOWER(${input.name})`)
          .limit(1);
        return logo || null;
      } catch {
        return null;
      }
    }),

  // ─── Admin: list all with status ───
  adminList: adminQuery.query(async () => {
    try {
      const db = getDb();
      const allBrands = await db.select().from(brands).orderBy(asc(brands.name));
      const logos = await db.select().from(brandLogos);
      const logoMap = new Map();
      for (const l of logos) {
        logoMap.set(l.brandName.toLowerCase(), l);
      }
      return allBrands.map((b) => {
        const logo = logoMap.get(b.name?.toLowerCase() || "");
        return {
          brandId: b.id,
          brandName: b.name,
          logoUrl: logo?.logoUrl || null,
          logoSvg: logo?.logoSvg || null,
          source: logo?.source || null,
          aiFillStatus: logo?.aiFillStatus || "empty",
          aiErrorMessage: logo?.aiErrorMessage || null,
          filledAt: logo?.filledAt || null,
          isActive: logo?.isActive || "yes",
        };
      });
    } catch (e: any) {
      console.error("[brandLogos.adminList] ERROR:", e.message);
      return [];
    }
  }),

  // ─── Save/update logo ───
  save: adminQuery
    .input(z.object({
      brandName: z.string(),
      logoUrl: z.string().optional(),
      logoSvg: z.string().optional(),
      source: z.string().default("manual"),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [existing] = await db.select().from(brandLogos)
        .where(sql`LOWER(${brandLogos.brandName}) = LOWER(${input.brandName})`)
        .limit(1);

      if (existing) {
        await db.update(brandLogos).set({
          logoUrl: input.logoUrl || existing.logoUrl,
          logoSvg: input.logoSvg || existing.logoSvg,
          source: input.source,
          updatedAt: new Date(),
        }).where(eq(brandLogos.id, existing.id));
      } else {
        await db.insert(brandLogos).values({
          brandName: input.brandName,
          logoUrl: input.logoUrl || null,
          logoSvg: input.logoSvg || null,
          source: input.source,
          aiFillStatus: input.source === "ai" ? "filled" : "empty",
        });
      }
      return { success: true };
    }),

  // ─── Bulk save logos ───
  saveMany: adminQuery
    .input(z.array(z.object({
      brandName: z.string(),
      logoUrl: z.string(),
      source: z.string().default("ai"),
    })))
    .mutation(async ({ input }) => {
      const db = getDb();
      let saved = 0;
      for (const item of input) {
        try {
          const [existing] = await db.select().from(brandLogos)
            .where(sql`LOWER(${brandLogos.brandName}) = LOWER(${item.brandName})`)
            .limit(1);
          if (existing) {
            await db.update(brandLogos).set({
              logoUrl: item.logoUrl,
              source: item.source,
              aiFillStatus: "filled",
              filledAt: new Date(),
              updatedAt: new Date(),
            }).where(eq(brandLogos.id, existing.id));
          } else {
            await db.insert(brandLogos).values({
              brandName: item.brandName,
              logoUrl: item.logoUrl,
              source: item.source,
              aiFillStatus: "filled",
              filledAt: new Date(),
            });
          }
          saved++;
        } catch (e: any) {
          console.warn(`[saveMany] ${item.brandName}:`, e.message);
        }
      }
      return { success: true, saved };
    }),

  // ─── Run AI to fill missing logos ───
  runAI: adminQuery
    .input(z.object({
      brandNames: z.array(z.string()).optional(),
    }).optional())
    .mutation(async ({ input }) => {
      const { runLogoResearcher } = await import("../agents/logoResearcher");
      const db = getDb();

      // Get brands without logos
      let brandsToProcess: string[] = [];
      if (input?.brandNames && input.brandNames.length > 0) {
        brandsToProcess = input.brandNames;
      } else {
        const allBrands = await db.select().from(brands).orderBy(asc(brands.name));
        const logos = await db.select().from(brandLogos)
          .where(sql`${brandLogos.logoUrl} IS NOT NULL OR ${brandLogos.logoSvg} IS NOT NULL`);
        const logoSet = new Set(logos.map((l) => l.brandName.toLowerCase()));
        brandsToProcess = allBrands
          .filter((b) => !logoSet.has(b.name?.toLowerCase() || ""))
          .map((b) => b.name)
          .filter(Boolean) as string[];
      }

      if (brandsToProcess.length === 0) {
        return { success: true, message: "Все марки уже имеют логотипы", processed: 0 };
      }

      const results = await runLogoResearcher(brandsToProcess);
      return { success: true, processed: brandsToProcess.length, results };
    }),

  // ─── Clear logo ───
  clear: adminQuery
    .input(z.object({ brandName: z.string() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(brandLogos)
        .where(sql`LOWER(${brandLogos.brandName}) = LOWER(${input.brandName})`);
      return { success: true };
    }),

  // ─── Stats ───
  stats: adminQuery.query(async () => {
    try {
      const db = getDb();
      const allBrands = await db.select().from(brands);
      const logos = await db.select().from(brandLogos)
        .where(sql`${brandLogos.logoUrl} IS NOT NULL OR ${brandLogos.logoSvg} IS NOT NULL`);
      return {
        totalBrands: allBrands.length,
        withLogos: logos.length,
        withoutLogos: allBrands.length - logos.length,
        percent: allBrands.length > 0 ? Math.round((logos.length / allBrands.length) * 100) : 0,
      };
    } catch {
      return { totalBrands: 0, withLogos: 0, withoutLogos: 0, percent: 0 };
    }
  }),
});
