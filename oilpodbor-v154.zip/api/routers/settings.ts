import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { systemSettings } from "@db/schema";
import { eq, sql } from "drizzle-orm";

// Default settings to seed
export const DEFAULT_SETTINGS = [
  // API Keys — only what actually works for oil selection
  {
    key: "anthropic_api_key",
    value: "",
    label: "Ключ API Anthropic Claude — ОСНОВНОЙ AI",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Главный ключ для ИИ-агентов. Ищет масла, жидкости, фильтры, руководства. Получить: console.anthropic.com (~$0.25 за 1000 авто)",
  },
  {
    key: "openai_api_key",
    value: "",
    label: "Ключ API OpenAI — РЕЗЕРВНЫЙ AI",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Резервный ключ если Claude недоступен. Получить: platform.openai.com (~$0.50 за 1000 авто)",
  },
  {
    key: "perplexity_api_key",
    value: "",
    label: "Ключ API Perplexity — ПОИСКОВЫЙ AI",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Поисковый AI с доступом к интернету. Хорош для технических данных. Получить: perplexity.ai/settings/api",
  },
  {
    key: "gemini_api_key",
    value: "",
    label: "Ключ API Google Gemini — БЕСПЛАТНЫЙ AI",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Бесплатный tier до 60 запросов/мин. Получить: aistudio.google.com/app/apikey",
  },
  {
    key: "groq_api_key",
    value: "",
    label: "Ключ API Groq — СВЕРХБЫСТРЫЙ AI",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Сверхбыстрый AI (LLaMA, Mixtral). 500 токенов/сек! Получить: console.groq.com (бесплатный tier)",
  },
  {
    key: "deepseek_api_key",
    value: "",
    label: "Ключ API DeepSeek — ДЕШЁВЫЙ AI",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Дешёвый китайский AI. ~$0.10 за 1000 авто! Получить: platform.deepseek.com/api_keys",
  },
  {
    key: "mistral_api_key",
    value: "",
    label: "Ключ API Mistral AI — ЕВРОПЕЙСКИЙ AI",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Европейский AI (Mistral Large). Получить: console.mistral.ai (бесплатный tier)",
  },
  {
    key: "cohere_api_key",
    value: "",
    label: "Ключ API Cohere — АЛЬТЕРНАТИВНЫЙ AI",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Command R+ модель для сложных задач. Получить: dashboard.cohere.com (бесплатный trial)",
  },
  // ─── Russian AI providers (work without VPN from Russia) ───
  {
    key: "yandex_api_key",
    value: "",
    label: "Yandex GPT API Key — РОССИЙСКИЙ AI",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Работает из России без VPN. Получить: yandex.cloud/ru/docs/foundation-models/ -> создать сервисный аккаунт -> API ключ",
  },
  {
    key: "yandex_folder_id",
    value: "",
    label: "Yandex Folder ID",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "ID каталога Yandex Cloud. Находится в консоли Yandex Cloud (b1g...)",
  },
  {
    key: "gigachat_client_secret",
    value: "",
    label: "GigaChat Authorization Key — СБЕР AI",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Работает из России без VPN. Получить: developers.sber.ru/studio -> проект -> Настройки проекта -> Authorization key (НЕ Client Secret!)",
  },
  {
    key: "vsegpt_api_key",
    value: "",
    label: "VseGPT API Key — АГРЕГАТОР AI",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Работает из России. Агрегатор: GigaChat, Yandex, Llama, Mistral. Получить: vsegpt.ru -> API -> Создать ключ",
  },
  {
    key: "nomerogram_token",
    value: "",
    label: "Токен API Номерограм — ПОИСК ПО НОМЕРУ",
    category: "api_keys",
    isSecret: "yes" as const,
    description: "Поиск авто по гос. номеру: фото, пробег, цена, регион. Получить: api-cloud.ru",
  },
  {
    key: "imagin_customer_name",
    value: "",
    label: "Imagin Studio Customer Name — ФОТО АВТО",
    category: "api_keys",
    isSecret: "no" as const,
    description: "Имя клиента в Imagin Studio (не API ключ!). Изображения загружаются ПРЯМО с CDN. Получить: imagin.studio -> Регистрация -> Customer Name",
  },
  // Widget Settings
  {
    key: "widget_title",
    value: "oilpodbor — подбор масел",
    label: "Заголовок виджета",
    category: "widget",
    isSecret: "no" as const,
    description: "Отображается в шапке виджета",
  },
  {
    key: "widget_primary_color",
    value: "#d32f2f",
    label: "Основной цвет виджета",
    category: "widget",
    isSecret: "no" as const,
    description: "Цвет кнопок, акцентов, прогресс-баров. Используйте палитру ниже.",
  },
  {
    key: "widget_company_name",
    value: "oilpodbor",
    label: "Название компании",
    category: "widget",
    isSecret: "no" as const,
    description: "Имя компании в виджете",
  },
  // System
  {
    key: "site_title",
    value: "oilpodbor — подбор масел и технических жидкостей",
    label: "Заголовок сайта",
    category: "system",
    isSecret: "no" as const,
    description: "HTML <title> сайта",
  },
  // Featured makes
  {
    key: "featured_makes",
    value: '["BMW","Mercedes-Benz","Audi","Toyota","Volkswagen","Hyundai","Kia","LADA","Skoda"]',
    label: "9 избранных марок на главной",
    category: "widget",
    isSecret: "no" as const,
    description: "JSON массив из 9 марок. Меняйте порядок и названия для главного экрана.",
  },
];

// Predefined color palette
export const COLOR_PALETTE = [
  { name: "Красный", hex: "#d32f2f" },
  { name: "Синий", hex: "#1976d2" },
  { name: "Зелёный", hex: "#388e3c" },
  { name: "Оранжевый", hex: "#f57c00" },
  { name: "Фиолетовый", hex: "#7b1fa2" },
  { name: "Чёрный", hex: "#212121" },
  { name: "Бирюзовый", hex: "#00838f" },
  { name: "Розовый", hex: "#c2185b" },
];

// Helper: get setting value
export async function getSetting(key: string): Promise<string | null> {
  const db = getDb();
  const [row] = await db.select().from(systemSettings).where(eq(systemSettings.key, key)).limit(1);
  return row?.value || null;
}

// Helper: get all settings as object
export async function getAllSettings(): Promise<Record<string, string>> {
  const db = getDb();
  const rows = await db.select().from(systemSettings);
  const result: Record<string, string> = {};
  for (const row of rows) {
    if (row.value) result[row.key] = row.value;
  }
  return result;
}

export const settingsRouter = createRouter({
  // ─── List public settings (no auth required) ───
  publicList: publicQuery.query(async () => {
    try {
      const db = getDb();
      const rows = await db
        .select()
        .from(systemSettings)
        .where(eq(systemSettings.isSecret, "no"))
        .orderBy(systemSettings.category, systemSettings.key);
      return rows;
    } catch (e: any) {
      console.error("[settings.publicList] ERROR:", e.message);
      // Return defaults if DB error
      return DEFAULT_SETTINGS.filter((s) => s.isSecret === "no").map((s) => ({
        id: 0,
        key: s.key,
        value: s.value,
        label: s.label,
        category: s.category,
        isSecret: s.isSecret,
        description: s.description,
        updatedBy: null,
        updatedAt: null,
      }));
    }
  }),

  // ─── List all settings (admin only) ───
  list: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db.select().from(systemSettings).orderBy(systemSettings.category, systemSettings.key);
    return rows; // Return full values — masking is done on UI level
  }),

  // ─── Get single setting (admin, full value) ───
  get: adminQuery
    .input(z.object({ key: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [row] = await db.select().from(systemSettings).where(eq(systemSettings.key, input.key)).limit(1);
      return row || null;
    }),

  // ─── Update setting ───
  set: adminQuery
    .input(z.object({
      key: z.string(),
      value: z.string(),
      updatedBy: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userName = ctx.user?.name || "admin";

      const [existing] = await db.select().from(systemSettings).where(eq(systemSettings.key, input.key)).limit(1);

      if (existing) {
        await db.update(systemSettings).set({
          value: input.value,
          updatedBy: userName,
        }).where(eq(systemSettings.key, input.key));
      } else {
        await db.insert(systemSettings).values({
          key: input.key,
          value: input.value,
          updatedBy: userName,
        });
      }

      return { ok: true };
    }),

  // ─── Update multiple settings ───
  setMany: adminQuery
    .input(z.object({
      settings: z.array(z.object({ key: z.string(), value: z.string() })),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userName = ctx.user?.name || "admin";

      for (const s of input.settings) {
        const [existing] = await db.select().from(systemSettings).where(eq(systemSettings.key, s.key)).limit(1);
        if (existing) {
          await db.update(systemSettings).set({ value: s.value, updatedBy: userName }).where(eq(systemSettings.key, s.key));
        } else {
          await db.insert(systemSettings).values({ key: s.key, value: s.value, updatedBy: userName });
        }
      }

      return { ok: true, count: input.settings.length };
    }),

  // ─── Delete setting ───
  delete: adminQuery
    .input(z.object({ key: z.string() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(systemSettings).where(eq(systemSettings.key, input.key));
      return { ok: true };
    }),

  // ─── Seed default settings ───
  seed: adminQuery.mutation(async () => {
    const db = getDb();
    let inserted = 0;
    let updated = 0;

    for (const s of DEFAULT_SETTINGS) {
      const [existing] = await db.select().from(systemSettings).where(eq(systemSettings.key, s.key)).limit(1);
      if (existing) {
        // Update metadata even if key exists
        await db.update(systemSettings).set({
          label: s.label,
          description: s.description,
          category: s.category,
          isSecret: s.isSecret,
        }).where(eq(systemSettings.key, s.key));
        updated++;
      } else {
        await db.insert(systemSettings).values(s);
        inserted++;
      }
    }

    return { inserted, updated, total: DEFAULT_SETTINGS.length };
  }),

  // ─── Check AI API status ───
  checkAI: adminQuery.query(async () => {
    const apiKey = await getSetting("anthropic_api_key");
    const openaiKey = await getSetting("openai_api_key");

    const result: any = {
      anthropic: {
        configured: !!(apiKey && apiKey.length > 10),
        keyLength: apiKey ? apiKey.length : 0,
        keyPrefix: apiKey ? `${apiKey.substring(0, 12)}...` : "none",
        testResult: null,
      },
      openai: {
        configured: !!(openaiKey && openaiKey.length > 10),
        keyLength: openaiKey ? openaiKey.length : 0,
      },
    };

    // Test Anthropic
    if (apiKey && apiKey.length > 10) {
      try {
        const resp = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": apiKey,
            "anthropic-version": "2023-06-01",
          },
          body: JSON.stringify({
            model: "claude-3-haiku-20240307",
            max_tokens: 50,
            messages: [{ role: "user", content: "Say OK" }],
          }),
        });
        if (resp.ok) {
          const data = await resp.json();
          result.anthropic.testResult = "success";
          result.anthropic.model = data.model;
          result.anthropic.response = data.content?.[0]?.text?.substring(0, 50);
        } else {
          const err = await resp.text();
          result.anthropic.testResult = "failed";
          result.anthropic.error = `${resp.status}: ${err.substring(0, 200)}`;
        }
      } catch (e: any) {
        result.anthropic.testResult = "error";
        result.anthropic.error = e.message;
      }
    }

    return result;
  }),

  // ─── Stats ───
  stats: adminQuery.query(async () => {
    const db = getDb();
    const [total] = await db.select({ count: sql<number>`COUNT(*)` }).from(systemSettings);
    const [filled] = await db.select({ count: sql<number>`COUNT(*)` }).from(systemSettings).where(sql`${systemSettings.value} IS NOT NULL AND ${systemSettings.value} != ''`);
    const [secrets] = await db.select({ count: sql<number>`COUNT(*)` }).from(systemSettings).where(eq(systemSettings.isSecret, "yes"));

    // By category
    const byCategory = await db
      .select({ category: systemSettings.category, count: sql<number>`COUNT(*)` })
      .from(systemSettings)
      .groupBy(systemSettings.category);

    return { total: total.count, filled: filled.count, secrets: secrets.count, byCategory };
  }),
});
