/**
 * Logo Researcher — AI agent that finds car brand logos
 * Strategy: Search Wikipedia API → DuckDuckGo → fallback to placeholder
 */

import { getDb } from "../queries/connection";
import { brandLogos } from "@db/schema";
import { eq, sql } from "drizzle-orm";

interface LogoResult {
  brandName: string;
  logoUrl: string | null;
  status: "success" | "error";
  error?: string;
}

// ─── Wikipedia API — get logo from brand page ───
async function searchWikipedia(brand: string): Promise<string | null> {
  try {
    // Search for brand page
    const searchResp = await fetch(
      `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(brand + " car brand logo")}&format=json&origin=*`,
      { signal: AbortSignal.timeout(10000) }
    );
    if (!searchResp.ok) return null;
    const searchData = await searchResp.json();
    const title = searchData.query?.search?.[0]?.title;
    if (!title) return null;

    // Get page images
    const pageResp = await fetch(
      `https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(title)}&prop=pageimages&pithumbsize=300&format=json&origin=*`,
      { signal: AbortSignal.timeout(10000) }
    );
    if (!pageResp.ok) return null;
    const pageData = await pageResp.json();
    const pages = pageData.query?.pages;
    const page = pages ? Object.values(pages)[0] as any : null;
    return page?.thumbnail?.source || null;
  } catch {
    return null;
  }
}

// ─── DuckDuckGo image search via proxy ───
async function searchDuckDuckGo(brand: string): Promise<string | null> {
  try {
    // Use Wikimedia Commons directly
    const resp = await fetch(
      `https://commons.wikimedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(brand + " logo")}&srnamespace=6&format=json&origin=*`,
      { signal: AbortSignal.timeout(10000) }
    );
    if (!resp.ok) return null;
    const data = await resp.json();
    const result = data.query?.search?.[0];
    if (!result?.title) return null;

    // Get image URL
    const imgResp = await fetch(
      `https://commons.wikimedia.org/w/api.php?action=query&titles=${encodeURIComponent(result.title)}&prop=imageinfo&iiprop=url|thumburl&iiurlwidth=300&format=json&origin=*`,
      { signal: AbortSignal.timeout(10000) }
    );
    if (!imgResp.ok) return null;
    const imgData = await imgResp.json();
    const pages = imgData.query?.pages;
    const page = pages ? Object.values(pages)[0] as any : null;
    return page?.imageinfo?.[0]?.thumburl || page?.imageinfo?.[0]?.url || null;
  } catch {
    return null;
  }
}

// ─── Car Logo API (free CDN) ───
function getCarLogoCDN(brand: string): string | null {
  // Try known free car logo CDNs
  const normalized = brand.toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-]/g, "")
    .replace(/^-|-$/g, "");

  if (!normalized) return null;

  // CarLogos.org style
  return `https://www.carlogos.org/car-logos/${normalized}-logo.png`;
}

// ─── Main researcher ───
export async function runLogoResearcher(brandNames: string[]): Promise<LogoResult[]> {
  const results: LogoResult[] = [];

  for (const brand of brandNames) {
    console.log(`[LogoResearcher] Processing: ${brand}...`);
    let logoUrl: string | null = null;

    // Method 1: Car Logo CDN
    try {
      logoUrl = getCarLogoCDN(brand);
      if (logoUrl) {
        // Verify URL is accessible
        const head = await fetch(logoUrl, { method: "HEAD", signal: AbortSignal.timeout(5000) });
        if (!head.ok || (head.headers.get("content-length") === "0")) {
          logoUrl = null;
        }
      }
    } catch { logoUrl = null; }

    // Method 2: Wikipedia
    if (!logoUrl) {
      try { logoUrl = await searchWikipedia(brand); } catch { /* ignore */ }
    }

    // Method 3: Wikimedia Commons
    if (!logoUrl) {
      try { logoUrl = await searchDuckDuckGo(brand); } catch { /* ignore */ }
    }

    // Save result
    if (logoUrl) {
      try {
        const db = getDb();
        const [existing] = await db.select().from(brandLogos)
          .where(sql`LOWER(${brandLogos.brandName}) = LOWER(${brand})`)
          .limit(1);

        if (existing) {
          await db.update(brandLogos).set({
            logoUrl,
            source: "ai",
            aiFillStatus: "filled",
            filledAt: new Date(),
            updatedAt: new Date(),
          }).where(eq(brandLogos.id, existing.id));
        } else {
          await db.insert(brandLogos).values({
            brandName: brand,
            logoUrl,
            source: "ai",
            aiFillStatus: "filled",
            filledAt: new Date(),
          });
        }
        console.log(`[LogoResearcher] ✓ ${brand}: ${logoUrl.substring(0, 80)}...`);
        results.push({ brandName: brand, logoUrl, status: "success" });
      } catch (e: any) {
        console.error(`[LogoResearcher] Save error ${brand}:`, e.message);
        results.push({ brandName: brand, logoUrl, status: "error", error: e.message });
      }
    } else {
      console.log(`[LogoResearcher] ✗ ${brand}: not found`);
      results.push({ brandName: brand, logoUrl: null, status: "error", error: "Logo not found" });
    }

    // Rate limiting — small delay between requests
    await new Promise((r) => setTimeout(r, 500));
  }

  return results;
}
