/**
 * Flexible AI Researcher — Multi-provider with retry & fallback
 * Strategy: 3 retries per provider → fallback models → VseGPT as universal fallback
 */

import { getDb } from "../queries/connection";
import { carFluidSpecs, aiLogs, systemSettings, aiAgentResults } from "@db/schema";
import { eq, like, and, desc, sql } from "drizzle-orm";
import { getSetting } from "../lib/env";
// Note: use safeGetSetting() wrapper below for all API calls

export interface AgentConfig {
  name: string;
  provider: string;
  model: string;
  prompt: string;
  enabled: boolean;
}

const BASE_PROMPT = `Car: {make} {model} {engine}. Return ONLY JSON:
{"engine":{"oilVolume":"X","oilSae":"5W-30","oilApi":"SN","oilAcea":"C3","oilOem":"","replaceInterval":""},"transmission":{"type":"","code":"","oilVolume":"","oilSpec":"","replaceInterval":""},"cooling":{"coolantVolume":"","coolantType":"","replaceInterval":""},"brakes":{"fluidVolume":"","fluidType":"","replaceInterval":""},"differentials":{"front":{"volume":"","oil":""},"rear":{"volume":"","oil":""}},"filters":{"oil":"","air":"","cabin":"","fuel":""}}
All values as strings. oilVolume/coolantVolume in liters.`;

export const DEFAULT_AGENTS: Record<string, AgentConfig> = {
  perplexity:    { name: "Perplexity ($50)",       provider: "perplexity", model: "sonar",                        prompt: BASE_PROMPT, enabled: true },
  anthropic:     { name: "Anthropic Claude",         provider: "anthropic",  model: "claude-3-haiku-20240307",      prompt: BASE_PROMPT, enabled: true },
  openai:        { name: "OpenAI GPT",               provider: "openai",     model: "gpt-3.5-turbo",                prompt: BASE_PROMPT, enabled: true },
  gemini:        { name: "Google Gemini",            provider: "gemini",     model: "gemini-2.0-flash-lite",        prompt: BASE_PROMPT, enabled: true },
  groq:          { name: "Groq",                     provider: "groq",       model: "llama-3.1-8b-instant",         prompt: BASE_PROMPT, enabled: true },
  deepseek:      { name: "DeepSeek",                 provider: "deepseek",   model: "deepseek-chat",                prompt: BASE_PROMPT, enabled: true },
  mistral:       { name: "Mistral AI",               provider: "mistral",    model: "mistral-tiny",                 prompt: BASE_PROMPT, enabled: true },
  cohere:        { name: "Cohere",                   provider: "cohere",     model: "command-r",                    prompt: BASE_PROMPT, enabled: true },
  yandex:        { name: "Yandex GPT",               provider: "yandex",     model: "yandexgpt-lite",               prompt: BASE_PROMPT, enabled: true },
  gigachat:      { name: "GigaChat (Сбер)",          provider: "gigachat",   model: "GigaChat",                     prompt: BASE_PROMPT, enabled: true },
  vsegpt:        { name: "VseGPT.ru",                provider: "vsegpt",     model: "openai/gigachat",              prompt: BASE_PROMPT, enabled: true },
};

// ─── Retry with exponential backoff ───
async function withRetry<T>(fn: () => Promise<T>, label: string, maxRetries = 3): Promise<T> {
  let lastError: any;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (e: any) {
      lastError = e;
      const delay = Math.min(1000 * Math.pow(2, i), 8000);
      console.warn(`[FlexibleResearch] ${label} attempt ${i + 1}/${maxRetries} failed: ${e.message}. Retrying in ${delay}ms...`);
      await new Promise((r) => setTimeout(r, delay));
    }
  }
  throw lastError;
}

// ─── Universal fetch wrapper with timeout & headers ───
async function safeFetch(url: string, init: RequestInit, timeoutMs = 25000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const resp = await fetch(url, { ...init, signal: controller.signal });
    return resp;
  } finally {
    clearTimeout(timer);
  }
}

// ─── Anthropic with fallback models ───
async function callAnthropic(prompt: string, _model: string) {
  const apiKey = await safeGetSetting("anthropic_api_key");
  if (!apiKey) throw new Error("No key");
  const models = ["claude-3-haiku-20240307", "claude-3-5-haiku-20241022"];
  let lastErr = "";
  for (const m of models) {
    try {
      const resp = await safeFetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model: m, max_tokens: 2000, messages: [{ role: "user", content: prompt + "\n\nReturn ONLY JSON." }] }),
      });
      if (!resp.ok) { lastErr = `Anthropic ${m}: ${resp.status}`; continue; }
      const data = await resp.json();
      return { text: data.content?.[0]?.text || "", tokens: { input: data.usage?.input_tokens || 0, output: data.usage?.output_tokens || 0 }, source: "anthropic" };
    } catch (e: any) { lastErr = e.message; }
  }
  throw new Error(lastErr);
}

// ─── OpenAI / Groq / DeepSeek / Mistral (OpenAI-compatible) ───
async function callOpenAICompatible(url: string, apiKey: string, prompt: string, model: string, extraHeaders?: Record<string, string>) {
  const resp = await safeFetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}`, ...extraHeaders },
    body: JSON.stringify({ model, messages: [{ role: "user", content: prompt + "\n\nReturn ONLY JSON. No markdown." }], temperature: 0.1, max_tokens: 1500 }),
  });
  if (!resp.ok) throw new Error(`${resp.status}: ${(await resp.text()).substring(0, 200)}`);
  const data = await resp.json();
  return { text: data.choices?.[0]?.message?.content || "", tokens: { input: data.usage?.prompt_tokens || 0, output: data.usage?.completion_tokens || 0 } };
}

// ─── Groq with fallback models ───
async function callGroq(prompt: string, _model: string) {
  const apiKey = await safeGetSetting("groq_api_key");
  if (!apiKey) throw new Error("No key");
  const models = ["llama-3.1-8b-instant", "llama3-8b-8192", "mixtral-8x7b-32768", "gemma2-9b-it"];
  let lastErr = "";
  for (const m of models) {
    try {
      const result = await callOpenAICompatible("https://api.groq.com/openai/v1/chat/completions", apiKey, prompt, m);
      return { ...result, source: "groq" };
    } catch (e: any) { lastErr = `Groq ${m}: ${e.message}`; }
  }
  throw new Error(lastErr);
}

// ─── DeepSeek ───
async function callDeepSeek(prompt: string, model: string) {
  const apiKey = await safeGetSetting("deepseek_api_key");
  if (!apiKey) throw new Error("No key");
  const result = await callOpenAICompatible("https://api.deepseek.com/v1/chat/completions", apiKey, prompt, model || "deepseek-chat");
  return { ...result, source: "deepseek" };
}

// ─── OpenAI ───
async function callOpenAI(prompt: string, model: string) {
  const apiKey = await safeGetSetting("openai_api_key");
  if (!apiKey) throw new Error("No key");
  const result = await callOpenAICompatible("https://api.openai.com/v1/chat/completions", apiKey, prompt, model || "gpt-3.5-turbo");
  return { ...result, source: "openai" };
}

// ─── Mistral ───
async function callMistral(prompt: string, model: string) {
  const apiKey = await safeGetSetting("mistral_api_key");
  if (!apiKey) throw new Error("No key");
  const result = await callOpenAICompatible("https://api.mistral.ai/v1/chat/completions", apiKey, prompt, model || "mistral-tiny");
  return { ...result, source: "mistral" };
}

// ─── Cohere ───
async function callCohere(prompt: string, _model: string) {
  const apiKey = await safeGetSetting("cohere_api_key");
  if (!apiKey) throw new Error("No key");
  const resp = await safeFetch("https://api.cohere.ai/v1/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
    body: JSON.stringify({ message: prompt + "\n\nReturn ONLY JSON.", model: "command-r", temperature: 0.1 }),
  });
  if (!resp.ok) throw new Error(`Cohere ${resp.status}: ${(await resp.text()).substring(0, 200)}`);
  const data = await resp.json();
  return { text: data.text || "", tokens: { input: 0, output: 0 }, source: "cohere" };
}

// ─── Perplexity ───
async function callPerplexity(prompt: string, model: string) {
  const apiKey = await safeGetSetting("perplexity_api_key");
  if (!apiKey) throw new Error("No key");
  const result = await callOpenAICompatible("https://api.perplexity.ai/chat/completions", apiKey, prompt, model || "sonar");
  return { ...result, source: "perplexity" };
}

// ─── Gemini with fallback models ───
async function callGemini(prompt: string, _model: string) {
  const apiKey = await safeGetSetting("gemini_api_key");
  if (!apiKey) throw new Error("No key");
  const models = ["gemini-2.0-flash-lite", "gemini-1.5-flash", "gemini-1.5-flash-8b"];
  let lastErr = "";
  for (const m of models) {
    try {
      const resp = await safeFetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${apiKey}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: prompt + "\n\nReturn ONLY JSON." }] }], generationConfig: { temperature: 0.1, maxOutputTokens: 1500 } }),
      });
      if (resp.status === 429) { lastErr = `Gemini ${m}: 429 rate limit`; await new Promise((r) => setTimeout(r, 2000)); continue; }
      if (!resp.ok) { lastErr = `Gemini ${m}: ${resp.status}`; continue; }
      const data = await resp.json();
      return { text: data.candidates?.[0]?.content?.parts?.[0]?.text || "", tokens: { input: data.usageMetadata?.promptTokenCount || 0, output: data.usageMetadata?.candidatesTokenCount || 0 }, source: "gemini" };
    } catch (e: any) { lastErr = e.message; }
  }
  throw new Error(lastErr);
}

// ─── Yandex GPT ───
async function callYandex(prompt: string, model: string) {
  const apiKey = await safeGetSetting("yandex_api_key");
  const folderId = await safeGetSetting("yandex_folder_id");
  if (!apiKey) throw new Error("No key");
  if (!folderId) throw new Error("No folder ID");
  const modelUri = `gpt://${folderId}/${model || "yandexgpt-lite"}`;
  const resp = await safeFetch("https://llm.api.cloud.yandex.net/foundationModels/v1/completion", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Api-Key ${apiKey}`, "x-folder-id": folderId },
    body: JSON.stringify({ modelUri, completionOptions: { stream: false, temperature: 0.1, maxTokens: 2000 }, messages: [{ role: "user", text: prompt + "\n\nReturn ONLY JSON." }] }),
  });
  if (!resp.ok) throw new Error(`Yandex ${resp.status}: ${(await resp.text()).substring(0, 300)}`);
  const data = await resp.json();
  return { text: data.result?.alternatives?.[0]?.message?.text || "", tokens: { input: 0, output: 0 }, source: "yandex" };
}

// ─── GigaChat via axios (bypasses Sber SSL) ───
async function callGigaChat(prompt: string, model: string) {
  const vsegptKey = await getSetting("vsegpt_api_key");
  if (vsegptKey) {
    try { return await callVseGPT(prompt, "openai/gigachat", vsegptKey); } catch { /* fallback */ }
  }
  const clientSecret = await safeGetSetting("gigachat_client_secret");
  if (!clientSecret) throw new Error("No key");
  try {
    const { default: axios } = await import("axios");
    const https = await import("https");
    const agent = new https.Agent({ rejectUnauthorized: false });
    const tokenResp = await axios.post("https://ngw.devices.sberbank.ru:9443/api/v2/oauth", "scope=GIGACHAT_API_PERS", { headers: { "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json", "RqUID": crypto.randomUUID(), "Authorization": `Bearer ${clientSecret}` }, httpsAgent: agent, timeout: 15000 });
    const accessToken = tokenResp.data.access_token;
    const resp = await axios.post("https://gigachat.devices.sberbank.ru/api/v1/chat/completions", { model: model || "GigaChat", messages: [{ role: "user", content: prompt + "\n\nReturn ONLY JSON." }], temperature: 0.1 }, { headers: { "Content-Type": "application/json", "Authorization": `Bearer ${accessToken}` }, httpsAgent: agent, timeout: 30000 });
    return { text: resp.data.choices?.[0]?.message?.content || "", tokens: { input: resp.data.usage?.prompt_tokens || 0, output: resp.data.usage?.completion_tokens || 0 }, source: "gigachat" };
  } catch (e: any) { throw new Error(`GigaChat: ${e.message}`); }
}

// ─── VseGPT with multi-model fallback ───
async function callVseGPT(prompt: string, model: string, externalKey?: string) {
  const apiKey = externalKey || await safeGetSetting("vsegpt_api_key");
  if (!apiKey) throw new Error("No key");
  const modelsToTry = [model || "", "openai/gigachat", "meta-llama/llama-3.1-70b-instruct", "qwen/qwen-2.5-72b-instruct"].filter(Boolean);
  let lastErr = "";
  for (const m of modelsToTry) {
    try {
      const resp = await safeFetch("https://api.vsegpt.ru/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
        body: JSON.stringify({ model: m, messages: [{ role: "user", content: prompt + "\n\nReturn ONLY JSON." }], temperature: 0.1, max_tokens: 1500 }),
      });
      if (!resp.ok) { lastErr = `VseGPT(${m}) ${resp.status}`; continue; }
      const data = await resp.json();
      return { text: data.choices?.[0]?.message?.content || "", tokens: { input: data.usage?.prompt_tokens || 0, output: data.usage?.completion_tokens || 0 }, source: "vsegpt" };
    } catch (e: any) { lastErr = e.message; }
  }
  throw new Error(lastErr);
}

// ─── Safe getSetting with fallback ───
async function safeGetSetting(key: string): Promise<string | null> {
  try {
    return await getSetting(key);
  } catch (e: any) {
    console.warn(`[safeGetSetting] ${key}: ${e.message}`);
    return null;
  }
}

// ─── Dispatcher — only reliable providers ───
const DISPATCHER: Record<string, (prompt: string, model: string) => Promise<{ text: string; tokens: { input: number; output: number }; source: string }>> = {
  perplexity: (p, m) => withRetry(() => callPerplexity(p, m), "Perplexity"),
  anthropic:  (p, m) => withRetry(() => callAnthropic(p, m), "Anthropic", 2),
  openai:     (p, m) => withRetry(() => callOpenAI(p, m), "OpenAI"),
  gemini:     (p, m) => withRetry(() => callGemini(p, m), "Gemini", 2),
  groq:       (p, m) => withRetry(() => callGroq(p, m), "Groq", 2),
  deepseek:   (p, m) => withRetry(() => callDeepSeek(p, m), "DeepSeek"),
  mistral:    (p, m) => withRetry(() => callMistral(p, m), "Mistral"),
  cohere:     (p, m) => withRetry(() => callCohere(p, m), "Cohere"),
  vsegpt:     (p, m) => withRetry(() => callVseGPT(p, m), "VseGPT"),
};

// ─── Normalize string values for comparison ───
export function normalizeValue(val: string | null | undefined): string {
  if (!val) return "";
  return val.toString().toLowerCase().replace(/\s+/g, " ").replace(/[^a-z0-9\-.,/ ]/g, "").trim();
}

// ─── Check if two values match (fuzzy) ───
export function valuesMatch(a: string | null, b: string | null): boolean {
  const na = normalizeValue(a);
  const nb = normalizeValue(b);
  if (na === nb) return true;
  if (!na || !nb) return false;
  // Token match: "5W-30" matches "5w30" and "5W30"
  const tokensA = na.split(/[\s,/]+/).filter(Boolean);
  const tokensB = nb.split(/[\s,/]+/).filter(Boolean);
  const common = tokensA.filter((t) => tokensB.includes(t));
  return common.length > 0 && common.length >= Math.min(tokensA.length, tokensB.length) * 0.5;
}

// ─── Parse JSON from AI response ───
function parseJson(text: string): any {
  const cleaned = text.replace(/```json\s*|```\s*$/gi, "").trim();
  try { return JSON.parse(cleaned); } catch { /* try with regex */ }
  const match = cleaned.match(/\{[\s\S]*\}/);
  if (match) try { return JSON.parse(match[0]); } catch { /* ignore */ }
  return null;
}

// ─── Main researcher ───
export async function runResearcher(v: { make: string; model: string; year?: number; engineCode?: string; modification?: string; generation?: string }, agentKeys?: string[]) {
  const db = getDb();
  const startTime = Date.now();
  const keysToRun = agentKeys && agentKeys.length > 0 ? agentKeys : Object.keys(DEFAULT_AGENTS);
  const prompt = BASE_PROMPT.replace("{make}", v.make).replace("{model}", v.model).replace("{engine}", v.engineCode ? `(${v.engineCode})` : "");

  // Priority: most reliable first
  const priorityOrder = ["perplexity", "anthropic", "deepseek", "groq", "gemini", "openai", "mistral", "cohere", "vsegpt"];
  const sortedKeys = [...keysToRun].sort((a, b) => {
    const ia = priorityOrder.indexOf(a); const ib = priorityOrder.indexOf(b);
    return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
  });

  const results: any[] = [];

  for (const key of sortedKeys) {
    const agentConfig = DEFAULT_AGENTS[key];
    if (!agentConfig) continue;

    const agentStart = Date.now();
    try {
      console.log(`[FlexibleResearch] Starting ${agentConfig.name} (${agentConfig.provider})...`);
      const dispatcher = DISPATCHER[agentConfig.provider];
      if (!dispatcher) { console.warn(`[FlexibleResearch] No dispatcher for ${agentConfig.provider}`); continue; }

      const result = await dispatcher(prompt, agentConfig.model);
      const aiText = result.text;
      const duration = Date.now() - agentStart;

      const parsed = parseJson(aiText);
      let filledFields: string[] = [];

      if (parsed) {
        const flatten = (obj: any, prefix = ""): string[] => {
          const fields: string[] = [];
          for (const [k, val] of Object.entries(obj)) {
            if (val && typeof val === "object" && !Array.isArray(val)) { fields.push(...flatten(val, prefix ? `${prefix}.${k}` : k)); }
            else if (val && typeof val === "string" && val.trim() !== "" && val !== "N/A" && val !== "—") { fields.push(prefix ? `${prefix}.${k}` : k); }
          }
          return fields;
        };
        filledFields = flatten(parsed);
      }

      // Save to aiAgentResults
      try {
        await db.insert(aiAgentResults).values({
          make: v.make, model: v.model, generation: v.generation || null, modification: v.modification || null, engineCode: v.engineCode || null,
          agentName: agentConfig.name, agentProvider: agentConfig.provider,
          filledFields: JSON.stringify(filledFields), filledCount: filledFields.length,
          rawResponse: aiText.substring(0, 5000), parsedJson: parsed,
          tokensInput: result.tokens.input, tokensOutput: result.tokens.output, tokensTotal: result.tokens.input + result.tokens.output,
          status: filledFields.length > 0 ? "success" : "empty", durationMs: duration,
        });
      } catch (e: any) { console.warn("[FlexibleResearch] Save error:", e.message); }

      results.push({ agent: key, name: agentConfig.name, provider: agentConfig.provider, filledFields, filledCount: filledFields.length, tokens: result.tokens, duration, status: filledFields.length > 0 ? "success" : "empty" });
      console.log(`[FlexibleResearch] ${agentConfig.name}: ${filledFields.length} fields in ${duration}ms`);

    } catch (e: any) {
      const duration = Date.now() - agentStart;
      console.error(`[FlexibleResearch] ${agentConfig.name} FAILED: ${e.message}`);

      try {
        await db.insert(aiAgentResults).values({
          make: v.make, model: v.model, generation: v.generation || null, modification: v.modification || null, engineCode: v.engineCode || null,
          agentName: agentConfig.name, agentProvider: agentConfig.provider,
          filledFields: JSON.stringify([]), filledCount: 0, status: "error", errorMessage: e.message.substring(0, 500), durationMs: duration,
        });
      } catch { /* ignore */ }

      results.push({ agent: key, name: agentConfig.name, provider: agentConfig.provider, filledFields: [], filledCount: 0, duration, status: "error", error: e.message });
    }
  }

  return { results, totalTime: Date.now() - startTime };
}

// ─── Apply best result to carFluidSpecs ───
export async function applyBestResult(v: { make: string; model: string }) {
  const db = getDb();
  try {
    const [best] = await db.select().from(aiAgentResults)
    .where(and(eq(aiAgentResults.make, v.make), eq(aiAgentResults.model, v.model)))
    .orderBy(desc(aiAgentResults.filledCount))
    .limit(1);

  if (!best || best.filledCount === 0) return { applied: false };

  let parsed: any = null;
  try { parsed = typeof best.parsedJson === "string" ? JSON.parse(best.parsedJson) : best.parsedJson; } catch { /* ignore */ }
  if (!parsed) return { applied: false };

  const updateData: any = {};
  if (parsed.engine?.oilVolume) updateData.engineFillVolume = parsed.engine.oilVolume;
  if (parsed.engine?.oilSae) updateData.prefOilSae = parsed.engine.oilSae;
  if (parsed.engine?.oilApi) updateData.prefOilApi = parsed.engine.oilApi;
  if (parsed.cooling?.coolantVolume) updateData.coolantFillVolume = parsed.cooling.coolantVolume;
  if (parsed.cooling?.coolantType) updateData.coolantType = parsed.cooling.coolantType;
  if (parsed.brakes?.fluidType) updateData.brakeFluidType = parsed.brakes.fluidType;
  if (parsed.transmission?.type) updateData.transmissionType = parsed.transmission.type;

  const [existing] = await db.select().from(carFluidSpecs).where(and(eq(carFluidSpecs.make, v.make), eq(carFluidSpecs.model, v.model))).limit(1);

  if (existing) {
    await db.update(carFluidSpecs).set({ ...updateData, lastFilledAt: new Date(), filledBy: best.agentName }).where(eq(carFluidSpecs.id, existing.id));
  } else {
    await db.insert(carFluidSpecs).values({ make: v.make, model: v.model, ...updateData, lastFilledAt: new Date(), filledBy: best.agentName });
  }

    return { applied: true, agent: best.agentName, fields: best.filledCount };
  } catch (e: any) {
    console.warn("[FlexibleResearch] applyBestResult error:", e.message);
    return { applied: false };
  }
}
