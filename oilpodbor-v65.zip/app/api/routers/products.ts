import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { products } from "@db/schema";
import { eq, desc, sql, and, like, inArray } from "drizzle-orm";

export const productsRouter = createRouter({
  // ─── List products (public) ───
  list: publicQuery
    .input(z.object({
      category: z.string().optional(),
      brand: z.string().optional(),
      search: z.string().optional(),
      minPrice: z.number().optional(),
      maxPrice: z.number().optional(),
      sae: z.string().optional(),
      api: z.string().optional(),
      sort: z.enum(["popular", "price_asc", "price_desc", "rating", "new"]).default("popular"),
      limit: z.number().default(20),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [eq(products.isActive, "active")];

      if (input?.category) conditions.push(eq(products.category, input.category));
      if (input?.brand) conditions.push(eq(products.brand, input.brand));
      if (input?.search) {
        conditions.push(sql`${products.name} LIKE ${"%" + input.search + "%"}`);
      }
      if (input?.minPrice) conditions.push(sql`${products.price} >= ${input.minPrice}`);
      if (input?.maxPrice) conditions.push(sql`${products.price} <= ${input.maxPrice}`);
      if (input?.sae) {
        conditions.push(sql`${products.compatibleSae} LIKE ${"%" + input.sae + "%"}`);
      }

      // Build sort
      let orderBy;
      switch (input?.sort) {
        case "price_asc": orderBy = products.price; break;
        case "price_desc": orderBy = desc(products.price); break;
        case "rating": orderBy = desc(products.rating); break;
        case "new": orderBy = desc(products.createdAt); break;
        default: orderBy = desc(products.reviewsCount); break;
      }

      const items = await db
        .select()
        .from(products)
        .where(and(...conditions))
        .orderBy(orderBy)
        .limit(input?.limit || 20)
        .offset(input?.offset || 0);

      const [countResult] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(products)
        .where(and(...conditions));

      return {
        items,
        total: countResult?.count || 0,
      };
    }),

  // ─── Get single product ───
  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [item] = await db
        .select()
        .from(products)
        .where(and(eq(products.slug, input.slug), eq(products.isActive, "active")))
        .limit(1);
      return item || null;
    }),

  // ─── Get filters (brands, categories) ───
  filters: publicQuery.query(async () => {
    const db = getDb();

    const brands = await db
      .selectDistinct({ brand: products.brand })
      .from(products)
      .where(eq(products.isActive, "active"));

    const categories = await db
      .selectDistinct({ category: products.category })
      .from(products)
      .where(eq(products.isActive, "active"));

    return {
      brands: brands.map((b) => b.brand).filter(Boolean),
      categories: categories.map((c) => c.category).filter(Boolean),
    };
  }),

  // ─── Seed demo products (admin) ───
  seed: adminQuery.mutation(async () => {
    const db = getDb();

    const demoProducts = [
      {
        name: "ЛУКОЙЛ GENESIS ARMORTECH JP 5W-30",
        slug: "lukoil-genesis-armortech-jp-5w-30",
        description: "Синтетическое моторное масло для японских автомобилей. API SP, SP-RC, SN PLUS, SN-RC, SN. ILSAC GF-6A, GF-5.",
        price: 260300,
        oldPrice: 503500,
        discountPercent: 48,
        imageUrl: "https://via.placeholder.com/300x400/0057b8/ffffff?text=LUKOIL+5W-30",
        brand: "ЛУКОЙЛ",
        category: "motor-oil",
        subcategory: "synthetic",
        specs: { viscosity: "5W-30", api: "SP/SN", volume: "4л", type: "Синтетическое" },
        rating: "4.9",
        reviewsCount: 16417,
        deliveryText: "Завтра",
        badges: ["Распродажа", "0% до 140 дней"],
        sellerName: "OILPODBOR",
        isOriginal: "yes" as const,
        compatibleSae: ["5W-30"],
        compatibleApi: ["SP", "SN"],
      },
      {
        name: "ЛУКОЙЛ GENESIS ARMORTECH 5W-40",
        slug: "lukoil-genesis-armortech-5w-40",
        description: "Синтетическое моторное масло для европейских автомобилей. API SN/CF, ACEA A3/B4.",
        price: 299400,
        oldPrice: null,
        discountPercent: null,
        imageUrl: "https://via.placeholder.com/300x400/e31e24/ffffff?text=LUKOIL+5W-40",
        brand: "ЛУКОЙЛ",
        category: "motor-oil",
        subcategory: "synthetic",
        specs: { viscosity: "5W-40", api: "SN/CF", volume: "4л", type: "Синтетическое" },
        rating: "4.9",
        reviewsCount: 43170,
        deliveryText: "Завтра",
        badges: ["0% до 140 дней"],
        sellerName: "OILPODBOR",
        isOriginal: "yes" as const,
        compatibleSae: ["5W-40"],
        compatibleApi: ["SN", "CF"],
      },
      {
        name: "ЛУКОЙЛ GENESIS ARMORTECH DX1 5W-30",
        slug: "lukoil-genesis-armortech-dx1-5w-30",
        description: "Синтетическое моторное масло для бензиновых двигателей. API SP, ACEA C2/C3.",
        price: 320000,
        oldPrice: 450000,
        discountPercent: 29,
        imageUrl: "https://via.placeholder.com/300x400/00a651/ffffff?text=LUKOIL+DX1",
        brand: "ЛУКОЙЛ",
        category: "motor-oil",
        subcategory: "synthetic",
        specs: { viscosity: "5W-30", api: "SP", volume: "4л", type: "Синтетическое" },
        rating: "4.8",
        reviewsCount: 8900,
        deliveryText: "Завтра",
        badges: ["Распродажа"],
        sellerName: "OILPODBOR",
        isOriginal: "yes" as const,
        compatibleSae: ["5W-30"],
        compatibleApi: ["SP"],
      },
      {
        name: "ЛУКОЙЛ GENESIS UNIVERSAL 10W-40",
        slug: "lukoil-genesis-universal-10w-40",
        description: "Масло на основе синтетических технологий для бензиновых и дизельных двигателей.",
        price: 189900,
        oldPrice: null,
        discountPercent: null,
        imageUrl: "https://via.placeholder.com/300x400/6b2d8e/ffffff?text=LUKOIL+10W-40",
        brand: "ЛУКОЙЛ",
        category: "motor-oil",
        subcategory: "semi-synthetic",
        specs: { viscosity: "10W-40", api: "SN/CF", volume: "4л", type: "Полусинтетическое" },
        rating: "4.7",
        reviewsCount: 22100,
        deliveryText: "Завтра",
        badges: ["Хит"],
        sellerName: "OILPODBOR",
        isOriginal: "yes" as const,
        compatibleSae: ["10W-40"],
        compatibleApi: ["SN", "CF"],
      },
      {
        name: "SHELL HELIX ULTRA 5W-40",
        slug: "shell-helix-ultra-5w-40",
        description: "Полностью синтетическое моторное масло. API SN/CF, ACEA A3/B4.",
        price: 450000,
        oldPrice: 620000,
        discountPercent: 27,
        imageUrl: "https://via.placeholder.com/300x400/fdd000/333333?text=SHELL+5W-40",
        brand: "SHELL",
        category: "motor-oil",
        subcategory: "synthetic",
        specs: { viscosity: "5W-40", api: "SN/CF", volume: "4л", type: "Синтетическое" },
        rating: "4.9",
        reviewsCount: 34500,
        deliveryText: "Завтра",
        badges: ["Распродажа", "Оригинал"],
        sellerName: "OILPODBOR",
        isOriginal: "yes" as const,
        compatibleSae: ["5W-40"],
        compatibleApi: ["SN", "CF"],
      },
      {
        name: "MOBIL 1 ESP FORMULA 5W-30",
        slug: "mobil-1-esp-formula-5w-30",
        description: "Синтетическое моторное масло для современных дизельных и бензиновых двигателей.",
        price: 520000,
        oldPrice: null,
        discountPercent: null,
        imageUrl: "https://via.placeholder.com/300x400/ed1c24/ffffff?text=MOBIL+5W-30",
        brand: "MOBIL",
        category: "motor-oil",
        subcategory: "synthetic",
        specs: { viscosity: "5W-30", api: "SN Plus", volume: "4л", type: "Синтетическое" },
        rating: "4.9",
        reviewsCount: 28900,
        deliveryText: "Завтра",
        badges: ["Премиум"],
        sellerName: "OILPODBOR",
        isOriginal: "yes" as const,
        compatibleSae: ["5W-30"],
        compatibleApi: ["SN Plus"],
      },
      {
        name: "CASTROL EDGE 5W-30 LL",
        slug: "castrol-edge-5w-30-ll",
        description: "Синтетическое моторное масло с технологией Titanium FST. API SN/CF, ACEA C3.",
        price: 380000,
        oldPrice: 550000,
        discountPercent: 31,
        imageUrl: "https://via.placeholder.com/300x400/00a74a/ffffff?text=CASTROL+5W-30",
        brand: "CASTROL",
        category: "motor-oil",
        subcategory: "synthetic",
        specs: { viscosity: "5W-30", api: "SN/CF", volume: "4л", type: "Синтетическое" },
        rating: "4.8",
        reviewsCount: 15600,
        deliveryText: "Завтра",
        badges: ["Распродажа"],
        sellerName: "OILPODBOR",
        isOriginal: "yes" as const,
        compatibleSae: ["5W-30"],
        compatibleApi: ["SN", "CF"],
      },
      {
        name: "MANN-FILTER W 712/80 Масляный фильтр",
        slug: "mann-filter-w-712-80",
        description: "Оригинальный масляный фильтр MANN-FILTER для широкого спектра автомобилей.",
        price: 89000,
        oldPrice: 120000,
        discountPercent: 26,
        imageUrl: "https://via.placeholder.com/300x300/0057b8/ffffff?text=MANN+FILTER",
        brand: "MANN-FILTER",
        category: "filter",
        subcategory: "oil-filter",
        specs: { type: "Масляный", thread: "3/4-16 UNF", diameter: "76 мм" },
        rating: "4.9",
        reviewsCount: 5200,
        deliveryText: "Завтра",
        badges: ["Оригинал"],
        sellerName: "OILPODBOR",
        isOriginal: "yes" as const,
      },
      {
        name: "BOSCH 0 986 AF0 042 Масляный фильтр",
        slug: "bosch-0986-af0-042",
        description: "Высококачественный масляный фильтр BOSCH с долгим сроком службы.",
        price: 65000,
        oldPrice: null,
        discountPercent: null,
        imageUrl: "https://via.placeholder.com/300x300/ed1c24/ffffff?text=BOSCH+FILTER",
        brand: "BOSCH",
        category: "filter",
        subcategory: "oil-filter",
        specs: { type: "Масляный", height: "85 мм", diameter: "65 мм" },
        rating: "4.7",
        reviewsCount: 3800,
        deliveryText: "Завтра",
        badges: ["Хит"],
        sellerName: "OILPODBOR",
        isOriginal: "yes" as const,
      },
      {
        name: "ZF LIFEGUARDFLUID 8 1Л Жидкость АКПП",
        slug: "zf-lifeguardfluid-8-1l",
        description: "Оригинальная жидкость для 8-ступенчатых АКПП ZF. Синтетическая ATF.",
        price: 210000,
        oldPrice: 280000,
        discountPercent: 25,
        imageUrl: "https://via.placeholder.com/300x400/004899/ffffff?text=ZF+ATF",
        brand: "ZF",
        category: "transmission",
        subcategory: "atf",
        specs: { type: "ATF", volume: "1л", oem: "ZF 8HP" },
        rating: "4.9",
        reviewsCount: 1200,
        deliveryText: "Завтра",
        badges: ["Распродажа", "Оригинал"],
        sellerName: "OILPODBOR",
        isOriginal: "yes" as const,
      },
    ];

    let inserted = 0;
    for (const p of demoProducts) {
      try {
        await db.insert(products).values(p);
        inserted++;
      } catch {
        // skip duplicates
      }
    }

    return { inserted, total: demoProducts.length };
  }),
});
