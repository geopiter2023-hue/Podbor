import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { brands, models, modifications } from "@db/schema";
import { sql, like } from "drizzle-orm";

/**
 * Local plate search - searches in the car database only
 */

async function findInLocalDb(data: {
  make?: string;
  model?: string;
  year?: number;
  engineCode?: string;
}): Promise<any | null> {
  const db = getDb();
  if (!data.make) return null;

  const brandList = await db
    .select()
    .from(brands)
    .where(like(brands.name, `%${data.make}%`))
    .limit(5);

  const brand = brandList.find(
    (b) => b.name?.toLowerCase() === data.make?.toLowerCase()
  ) || brandList[0];

  if (!brand) return null;

  const modelList = data.model
    ? await db
        .select()
        .from(models)
        .where(
          sql`${models.makeId} = ${brand.id} AND ${like(models.modelName, `%${data.model}%`)}`
        )
        .limit(10)
    : await db
        .select()
        .from(models)
        .where(sql`${models.makeId} = ${brand.id}`)
        .limit(10);

  if (modelList.length === 0) return null;

  const modelIds = modelList.map((m) => m.modelId);
  const mods = await db
    .select()
    .from(modifications)
    .where(
      sql`${modifications.makeId} = ${brand.id} AND ${modifications.modelId} IN (${sql.join(modelIds, sql`, `)})`
    )
    .limit(10);

  return {
    brand: { id: brand.id, name: brand.name },
    models: modelList.map((m) => ({
      modelId: m.modelId,
      modelName: m.modelName,
      imageUrl: m.imageUrl,
      yearFrom: m.yearFrom,
      yearTo: m.yearTo,
    })),
    modifications: mods.map((m) => ({
      id: m.id,
      name: m.name,
      engineCode: m.engineCode,
      fuel: m.fuel,
      horsePower: m.horsePower,
      startDate: m.startDate,
      endDate: m.endDate,
      engineCapacity: m.engineCapacity,
    })),
  };
}

export const plateSearchRouter = createRouter({
  // ─── Search by text query in local DB ───
  search: publicQuery
    .input(z.object({
      plate: z.string().min(2).max(50),
      vin: z.string().optional(),
    }))
    .query(async ({ input }) => {
      const query = (input.vin || input.plate).trim();
      if (!query) return { found: false, error: "Введите запрос" };

      // Try to find brand by query
      const db = getDb();
      const brandList = await db
        .select()
        .from(brands)
        .where(like(brands.name, `%${query}%`))
        .limit(5);

      if (brandList.length > 0) {
        const brand = brandList[0];
        const match = await findInLocalDb({ make: brand.name || "" });
        if (match) return { found: true, source: "local", make: brand.name, localMatch: match };
      }

      // Try to find by model name
      const modelList = await db
        .select()
        .from(models)
        .where(like(models.modelName, `%${query}%`))
        .limit(5);

      if (modelList.length > 0) {
        const firstModel = modelList[0];
        const [brand] = await db.select().from(brands).where(sql`${brands.id} = ${firstModel.makeId}`).limit(1);
        const match = await findInLocalDb({ make: brand?.name || "", model: firstModel.modelName || "" });
        if (match) return { found: true, source: "local", make: brand?.name, model: firstModel.modelName, localMatch: match };
      }

      return { found: false, source: "local", error: "Автомобиль не найден в базе" };
    }),

  // ─── Find car in local DB ───
  findLocal: publicQuery
    .input(z.object({
      make: z.string(),
      model: z.string().optional(),
      year: z.number().optional(),
    }))
    .query(async ({ input }) => {
      return findInLocalDb({
        make: input.make,
        model: input.model,
        year: input.year,
      });
    }),
});
