import { getDb } from "../queries/connection";
import { carFluidSpecs, aiLogs } from "@db/schema";
import { eq, like, and, desc } from "drizzle-orm";
import { getSetting } from "../lib/env";

export interface AgentConfig {
  name: string;
  provider: "anthropic" | "openai" | "perplexity" | "gemini" | "manual";
  model: string;
  prompt: string;
  enabled: boolean;
}

// Default agent configs
export const DEFAULT_AGENTS: Record<string, AgentConfig> = {
  "oil-master": {
    name: "Мастер масел",
    provider: "anthropic",
    model: "claude-3-haiku-20240307",
    prompt: `For car {make} {model} {engine}, return ONLY JSON:
{"engine":{"oilVolume":"X","oilSae":"5W-30","oilApi":"SN","oilAcea":"C3","oilOem":""},"transmission":{"type":"","oilVolume":"","oilSpec":""},"cooling":{"coolantVolume":"","coolantType":""},"brakes":{"fluidType":""},"differentials":{"front":{"volume":"","oil":""},"rear":{"volume":"","oil":""}},"filters":{"oil":"","air":"","cabin":"","fuel":""}}
All values as strings.`,
    enabled: true,
  },
  "openai-oil": {
    name: "OpenAI GPT",
    provider: "openai",
    model: "gpt-3.5-turbo",
    prompt: `Car: {make} {model} {engine}. Return JSON with engine oil specs (SAE, API, volume), transmission fluid, coolant, brake fluid, filters part numbers. Only JSON, no explanation.`,
    enabled: true,
  },
  "manual-entry": {
    name: "Ручной ввод",
    provider: "manual",
    model: "",
    prompt: "",
    enabled: true,
  },
};

/**
 * Run research with flexible agent configuration
 */
export async function runFlexibleResearch(payload: {
  make: string;
  model: string;
  engineCode?: string;
  year?: number;
  agentId?: string;
}) {
  const startTime = Date.now();
  const v = payload;

  // Get agent config
  const agentConfig = await getAgentConfig(payload.agentId || "oil-master");

  console.log(`[FlexibleResearch] Agent: ${agentConfig.name}, Provider: ${agentConfig.provider}`);

  // If manual mode — just create empty record
  if (agentConfig.provider === "manual") {
    return createEmptyRecord(v);
  }

  // Build prompt
  const prompt = agentConfig.prompt
    .replace(/{make}/g, v.make)
    .replace(/{model}/g, v.model)
    .replace(/{engine}/g, v.engineCode || "")
    .replace(/{year}/g, String(v.year || ""));

  // Call API based on provider
  let aiText = "";
  let tokensUsed = { input: 0, output: 0 };
  let source = "none";

  try {
    switch (agentConfig.provider) {
      case "anthropic":
        ({ text: aiText, tokens: tokensUsed, source } = await callAnthropic(prompt, agentConfig.model));
        break;
      case "openai":
        ({ text: aiText, tokens: tokensUsed, source } = await callOpenAI(prompt, agentConfig.model));
        break;
      case "perplexity":
        ({ text: aiText, tokens: tokensUsed, source } = await callPerplexity(prompt, agentConfig.model));
        break;
      case "gemini":
        ({ text: aiText, tokens: tokensUsed, source } = await callGemini(prompt, agentConfig.model));
        break;
    }
  } catch (e: any) {
    console.error(`[FlexibleResearch] ${agentConfig.provider} error:`, e.message);
    return { error: e.message, source: "none", recordId: 0, filledFields: [] as string[], tokensUsed };
  }

  // Parse response
  const parsed = parseAIResponse(aiText);

  // Build filled fields list
  const filledFields: string[] = [];
  const d = parsed;

  const addField = (val: any, name: string) => {
    if (val && String(val).trim() !== "" && String(val).trim() !== "X") {
      filledFields.push(name);
    }
  };

  addField(d.engine?.oilVolume, "Объём масла");
  addField(d.engine?.oilSae, "SAE");
  addField(d.engine?.oilApi, "API");
  addField(d.engine?.oilAcea, "ACEA");
  addField(d.engine?.oilOem, "OEM");
  addField(d.transmission?.type, "Тип КПП");
  addField(d.transmission?.oilVolume, "Объём КПП");
  addField(d.transmission?.oilSpec, "Масло КПП");
  addField(d.cooling?.coolantVolume, "Объём антифриза");
  addField(d.cooling?.coolantType, "Тип антифриза");
  addField(d.brakes?.fluidType, "Тормозная жидкость");
  addField(d.differentials?.front?.volume, "Дифф. передний");
  addField(d.differentials?.rear?.volume, "Дифф. задний");
  addField(d.filters?.oil, "Фильтр масляный");

  // Save to DB
  const db = getDb();
  const mod = v.modification || `${v.make} ${v.model} ${v.engineCode || ""}`.trim();

  const [existing] = await db
    .select()
    .from(carFluidSpecs)
    .where(and(like(carFluidSpecs.make, `%${v.make}%`), like(carFluidSpecs.model, `%${v.model}%`)))
    .limit(1);

  let recordId: number;

  const updateData = {
    vehicleType: "Легковой автомобиль" as const,
    modification: mod,
    engineCode: v.engineCode || existing?.engineCode,
    engineFillVolume: d.engine?.oilVolume || existing?.engineFillVolume,
    prefOilSae: d.engine?.oilSae || existing?.prefOilSae,
    prefOilApi: d.engine?.oilApi || existing?.prefOilApi,
    prefOilAcea: d.engine?.oilAcea || existing?.prefOilAcea,
    prefOilOe: d.engine?.oilOem || existing?.prefOilOe,
    transmissionType: d.transmission?.type || existing?.transmissionType,
    transmissionFillVolume: d.transmission?.oilVolume || existing?.transmissionFillVolume,
    transmissionPrefOil: d.transmission?.oilSpec || existing?.transmissionPrefOil,
    coolantFillVolume: d.cooling?.coolantVolume || existing?.coolantFillVolume,
    coolantType: d.cooling?.coolantType || existing?.coolantType,
    brakeFluidType: d.brakes?.fluidType || existing?.brakeFluidType,
    frontDiffFillVolume: d.differentials?.front?.volume || existing?.frontDiffFillVolume,
    frontDiffOil: d.differentials?.front?.oil || existing?.frontDiffOil,
    rearDiffFillVolume: d.differentials?.rear?.volume || existing?.rearDiffFillVolume,
    rearDiffOil: d.differentials?.rear?.oil || existing?.rearDiffOil,
    oilFilter: d.filters?.oil || existing?.oilFilter,
    airFilter: d.filters?.air || existing?.airFilter,
    cabinFilter: d.filters?.cabin || existing?.cabinFilter,
    fuelFilter: d.filters?.fuel || existing?.fuelFilter,
    importBatch: `ai_${source}`,
    updatedAt: new Date(),
  };

  if (existing) {
    await db.update(carFluidSpecs).set(updateData).where(eq(carFluidSpecs.id, existing.id));
    recordId = existing.id;
  } else {
    const [inserted] = await db.insert(carFluidSpecs).values({
      make: v.make,
      model: v.model,
      ...updateData,
    }).$returningId();
    recordId = inserted.id;
  }

  // Log
  try {
    await db.insert(aiLogs).values({
      make: v.make,
      model: v.model,
      query: prompt.substring(0, 300),
      rawResponse: aiText.substring(0, 2000),
      parsedJson: parsed,
      filledFields,
      tokensInput: tokensUsed.input,
      tokensOutput: tokensUsed.output,
      source,
      durationMs: Date.now() - startTime,
    });
  } catch { /* ignore */ }

  return {
    recordId,
    source,
    confidence: filledFields.length > 5 ? "high" : filledFields.length > 0 ? "medium" : "low",
    tokensUsed,
    filledFields,
    error: filledFields.length === 0 ? "AI вернул пустой ответ" : undefined,
  };
}

// ─── API Callers ───

async function callAnthropic(prompt: string, model: string) {
  const apiKey = await getSetting("anthropic_api_key");
  if (!apiKey) throw new Error("Anthropic API key not configured");

  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({ model, max_tokens: 2000, messages: [{ role: "user", content: prompt }] }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Anthropic ${resp.status}: ${err.substring(0, 200)}`);
  }

  const data = await resp.json();
  return {
    text: data.content?.[0]?.text || "",
    tokens: { input: data.usage?.input_tokens || 0, output: data.usage?.output_tokens || 0 },
    source: "claude",
  };
}

async function callOpenAI(prompt: string, model: string) {
  const apiKey = await getSetting("openai_api_key");
  if (!apiKey) throw new Error("OpenAI API key not configured");

  const resp = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: "Return ONLY JSON. No markdown, no explanation." },
        { role: "user", content: prompt },
      ],
      temperature: 0.1,
      max_tokens: 1500,
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`OpenAI ${resp.status}: ${err.substring(0, 200)}`);
  }

  const data = await resp.json();
  return {
    text: data.choices?.[0]?.message?.content || "",
    tokens: { input: data.usage?.prompt_tokens || 0, output: data.usage?.completion_tokens || 0 },
    source: "openai",
  };
}

async function callPerplexity(prompt: string, model: string) {
  const apiKey = await getSetting("perplexity_api_key");
  if (!apiKey) throw new Error("Perplexity API key not configured");

  const resp = await fetch("https://api.perplexity.ai/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: model || "sonar",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1500,
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Perplexity ${resp.status}: ${err.substring(0, 200)}`);
  }

  const data = await resp.json();
  return {
    text: data.choices?.[0]?.message?.content || "",
    tokens: { input: data.usage?.prompt_tokens || 0, output: data.usage?.completion_tokens || 0 },
    source: "perplexity",
  };
}

async function callGemini(prompt: string, model: string) {
  const apiKey = await getSetting("gemini_api_key");
  if (!apiKey) throw new Error("Gemini API key not configured");

  const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model || "gemini-1.5-flash"}:generateContent?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt + "\n\nReturn ONLY JSON. No markdown." }] }],
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Gemini ${resp.status}: ${err.substring(0, 200)}`);
  }

  const data = await resp.json();
  return {
    text: data.candidates?.[0]?.content?.parts?.[0]?.text || "",
    tokens: { input: 0, output: 0 }, // Gemini doesn't always return tokens
    source: "gemini",
  };
}

// ─── Helpers ───

function parseAIResponse(text: string): any {
  try {
    let clean = text.trim();
    if (clean.startsWith("```")) {
      clean = clean.replace(/```[a-z]*\n?/, "").replace(/\n?```$/, "").trim();
    }
    const m = clean.match(/\{[\s\S]*\}/);
    if (!m) return {};
    return JSON.parse(m[0]);
  } catch {
    return {};
  }
}

async function createEmptyRecord(v: { make: string; model: string; engineCode?: string; modification?: string }) {
  const db = getDb();
  const mod = v.modification || `${v.make} ${v.model}`.trim();

  const [existing] = await db
    .select()
    .from(carFluidSpecs)
    .where(and(like(carFluidSpecs.make, `%${v.make}%`), like(carFluidSpecs.model, `%${v.model}%`)))
    .limit(1);

  if (existing) {
    return { recordId: existing.id, source: "manual", filledFields: [], tokensUsed: { input: 0, output: 0 } };
  }

  const [inserted] = await db.insert(carFluidSpecs).values({
    make: v.make,
    model: v.model,
    modification: mod,
    vehicleType: "Легковой автомобиль",
    engineCode: v.engineCode,
    importBatch: "manual",
  }).$returningId();

  return { recordId: inserted.id, source: "manual", filledFields: [], tokensUsed: { input: 0, output: 0 } };
}

async function getAgentConfig(agentId: string): Promise<AgentConfig> {
  // Try to get from DB first
  try {
    const db = getDb();
    const rows = await db.select().from(systemSettings).where(eq(systemSettings.key, `agent_config_${agentId}`)).limit(1);
    if (rows.length > 0 && rows[0].value) {
      return JSON.parse(rows[0].value) as AgentConfig;
    }
  } catch { /* ignore */ }

  // Fallback to defaults
  return DEFAULT_AGENTS[agentId] || DEFAULT_AGENTS["oil-master"];
}
