/**
 * AI Agent: Owner Manual Finder
 * Ищет руководства по эксплуатации (PDF) для автомобилей
 * 
 * Стратегии поиска:
 * 1. AI-генерация URL официальных сайтов производителей
 * 2. Поиск через поисковые системы
 * 3. Парсинг известных каталогов руководств
 * 
 * Использование:
 * npx tsx api/agents/manualFinder.ts --make=BMW --model=X5 --year=2015
 */

import { getDb } from "../queries/connection";
import { ownerManuals, aiTasks, aiAgents } from "@db/schema";
import { eq, and, like } from "drizzle-orm";
import { env } from "../lib/env";

// ─── Types ───
interface ManualPayload {
  make: string;
  model: string;
  year?: number;
  generation?: string;
  modification?: string;
}

interface ManualResult {
  title: string;
  pdfUrl: string;
  pdfOriginalUrl: string;
  source: string;
  language: string;
  isOfficial: "yes" | "no";
  pdfSize?: string;
  pdfPages?: number;
  yearFrom?: number;
  yearTo?: number;
}

// ─── Known sources for owner manuals ───
const KNOWN_SOURCES: Record<string, (make: string, model: string, year?: number) => string[]> = {
  // BMW
  bmw: (make, model, year) => [
    `https://www.bmw.com/en/services/manuals/${model.toLowerCase().replace(/\s+/g, "-")}.html`,
    `https://www.bmw.ru/ru/topics/offers-and-services/bmw-service/owners-manual.html`,
    `https://www.bmw.com/content/dam/bmw/common/owners-manual/${model.toLowerCase().replace(/\s+/g, "_")}_OM.pdf`,
  ],
  // Mercedes
  mercedes: (make, model, year) => [
    `https://www.mercedes-benz.com/en/owners/manuals/`,
    `https://www.mbusa.com/en/owners/manuals`,
    `https://www.mercedes-benz-publications.com/${model.toLowerCase().replace(/\s+/g, "-")}-owners-manual`,
  ],
  // Audi
  audi: (make, model, year) => [
    `https://www.audi.com/en/service-and-accessories/owner-s-manual.html`,
    `https://www.audiusa.com/us/web/en/owners.html`,
  ],
  // Volkswagen
  volkswagen: (make, model, year) => [
    `https://www.vw.com/en/owners/manuals.html`,
    `https://www.volkswagen.com/en/service-and-accessories/owner-s-manual.html`,
  ],
  // Toyota
  toyota: (make, model, year) => [
    `https://www.toyota.com/owners/manuals/`,
    `https://www.toyota-europe.com/service-and-accessories/owners-manuals`,
  ],
  // Lexus
  lexus: (make, model, year) => [
    `https://www.lexus.com/owners/manuals/`,
  ],
  // Hyundai
  hyundai: (make, model, year) => [
    `https://www.hyundai.com/worldwide/en/service/owners-manual`,
  ],
  // Kia
  kia: (make, model, year) => [
    `https://www.kia.com/us/en/owners/manuals`,
  ],
  // Nissan
  nissan: (make, model, year) => [
    `https://www.nissanusa.com/owners/manuals-guides.html`,
  ],
  // Porsche
  porsche: (make, model, year) => [
    `https://www.porsche.com/international/accessoriesandservice/service/owner-manuals/`,
  ],
  // Ford
  ford: (make, model, year) => [
    `https://www.ford.com/support/owner-manuals/`,
  ],
  // Chevrolet
  chevrolet: (make, model, year) => [
    `https://www.chevrolet.com/support/owner-manuals`,
  ],
};

// ─── Generic manual source URLs ───
function getGenericUrls(make: string, model: string, year?: number): string[] {
  const yearStr = year ? ` ${year}` : "";
  const urls = [
    // Carmanuals.org
    `https://carmanuals.org/${make.toLowerCase()}/${model.toLowerCase().replace(/\s+/g, "-")}${year ? `-${year}` : ""}`,
    // Manuals.co
    `https://www.manuals.co/${make.toLowerCase()}/${model.toLowerCase().replace(/\s+/g, "-")}/owner-manual`,
    // Onlymanuals
    `https://www.onlymanuals.com/${make.toLowerCase()}-${model.toLowerCase().replace(/\s+/g, "-")}-owners-manual`,
    // CarPDFmanual
    `https://carpdfmanual.com/${make.toLowerCase()}/${model.toLowerCase().replace(/\s+/g, "-")}${year ? `-${year}` : ""}`,
    // Auto-manual
    `https://www.auto-manual.com/${make.toLowerCase()}/${model.toLowerCase().replace(/\s+/g, "-")}`,
    // Autodocs
    `https://www.autodocs.info/${make.toLowerCase()}/manuals/${model.toLowerCase().replace(/\s+/g, "_")}`,
  ];
  return urls;
}

// ─── AI-powered URL discovery ───
async function aiDiscoverUrls(payload: ManualPayload): Promise<ManualResult[]> {
  const results: ManualResult[] = [];
  const { make, model, year } = payload;

  // Try known manufacturer sources
  const makeKey = make.toLowerCase();
  const sourceFn = KNOWN_SOURCES[makeKey];
  if (sourceFn) {
    const urls = sourceFn(make, model, year);
    for (const url of urls) {
      results.push({
        title: `Owner Manual ${make} ${model}${year ? ` ${year}` : ""}`,
        pdfUrl: url,
        pdfOriginalUrl: url,
        source: `${make} Official`,
        language: "en",
        isOfficial: "yes",
      });
    }
  }

  // Generic sources
  const genericUrls = getGenericUrls(make, model, year);
  for (const url of genericUrls) {
    results.push({
      title: `Руководство по эксплуатации ${make} ${model}${year ? ` ${year}` : ""}`,
      pdfUrl: url,
      pdfOriginalUrl: url,
      source: new URL(url).hostname,
      language: "ru",
      isOfficial: "no",
    });
  }

  // AI-powered search via API if key available
  if (env.anthropicApiKey) {
    try {
      const query = `Find direct PDF download links for ${make} ${model}${year ? ` ${year}` : ""} owner manual / service manual / руководство по эксплуатации.
Return ONLY JSON array of objects with fields: title, url, source, language (ru/en), isOfficial (yes/no). No markdown.`;

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": env.anthropicApiKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-3-haiku-20240307",
          max_tokens: 1500,
          messages: [{ role: "user", content: query }],
        }),
        signal: AbortSignal.timeout(30000),
      });

      if (response.ok) {
        const data = await response.json();
        const text = data.content?.[0]?.text || "";
        const jsonMatch = text.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          const aiResults = JSON.parse(jsonMatch[0]);
          for (const r of aiResults) {
            if (r.url) {
              results.push({
                title: r.title || `Manual ${make} ${model}`,
                pdfUrl: r.url,
                pdfOriginalUrl: r.url,
                source: r.source || "AI Search",
                language: r.language || "en",
                isOfficial: r.isOfficial === "yes" ? "yes" : "no",
              });
            }
          }
        }
      }
    } catch (e: any) {
      console.error("[ManualFinder] AI error:", e.message);
    }
  }

  // Deduplicate by URL
  const seen = new Set<string>();
  return results.filter((r) => {
    if (seen.has(r.pdfUrl)) return false;
    seen.add(r.pdfUrl);
    return true;
  });
}

// ─── Verify PDF URL is accessible ───
async function verifyPdfUrl(url: string): Promise<boolean> {
  try {
    const response = await fetch(url, {
      method: "HEAD",
      signal: AbortSignal.timeout(10000),
    });
    const contentType = response.headers.get("content-type") || "";
    return response.ok && (contentType.includes("pdf") || contentType.includes("application/octet"));
  } catch {
    return false;
  }
}

// ─── Save results to database ───
async function saveResults(payload: ManualPayload, results: ManualResult[]) {
  const db = getDb();
  const saved = [];

  for (const result of results) {
    try {
      const [inserted] = await db.insert(ownerManuals).values({
        make: payload.make,
        model: payload.model,
        yearFrom: result.yearFrom || payload.year || undefined,
        yearTo: result.yearTo || undefined,
        generation: payload.generation || undefined,
        modification: payload.modification || undefined,
        title: result.title,
        pdfUrl: result.pdfUrl,
        pdfOriginalUrl: result.pdfOriginalUrl,
        pdfSize: result.pdfSize || undefined,
        pdfPages: result.pdfPages || undefined,
        source: result.source,
        language: result.language,
        isOfficial: result.isOfficial,
        isActive: "active",
      }).$returningId();
      saved.push({ id: inserted.id, ...result });
    } catch (e: any) {
      console.error("[ManualFinder] Save error:", e.message);
    }
  }

  return saved;
}

// ─── Main function ───
export async function runManualFinder(payload: ManualPayload, taskId?: number) {
  console.log("[ManualFinder] Searching for:", payload);
  const startTime = Date.now();

  try {
    // 1. Check if already exists
    const db = getDb();
    const existing = await db
      .select()
      .from(ownerManuals)
      .where(
        and(
          like(ownerManuals.make, `%${payload.make}%`),
          like(ownerManuals.model, `%${payload.model}%`),
          eq(ownerManuals.isActive, "active"),
        )
      )
      .limit(3);

    if (existing.length > 0 && !payload.year) {
      console.log("[ManualFinder] Already exists:", existing.length);
      return { skipped: true, existing: existing.length, items: existing };
    }

    // 2. AI Discover URLs
    const results = await aiDiscoverUrls(payload);
    console.log(`[ManualFinder] Found ${results.length} potential sources`);

    // 3. Save to database
    const saved = await saveResults(payload, results);

    // 4. Update task
    if (taskId) {
      await db.update(aiTasks).set({
        status: "completed",
        result: JSON.stringify({ found: results.length, saved: saved.length }),
        completedAt: new Date(),
        itemsProcessed: saved.length,
      }).where(eq(aiTasks.id, taskId));
    }

    const duration = Date.now() - startTime;
    console.log(`[ManualFinder] Done in ${duration}ms. Found: ${results.length}, Saved: ${saved.length}`);

    return {
      success: true,
      found: results.length,
      saved: saved.length,
      items: saved,
      duration,
    };
  } catch (e: any) {
    console.error("[ManualFinder] Error:", e.message);

    if (taskId) {
      const db = getDb();
      await db.update(aiTasks).set({
        status: "failed",
        errorMessage: e.message,
        completedAt: new Date(),
      }).where(eq(aiTasks.id, taskId));
    }

    return { success: false, error: e.message };
  }
}

// ─── Batch search: find manuals for cars in database ───
export async function runBatchManualFinder(options: { limit?: number; agentId?: number } = {}) {
  const db = getDb();
  const limit = options.limit || 10;

  // Get cars without manuals
  const carsWithManuals = await db
    .select({ make: ownerManuals.make, model: ownerManuals.model })
    .from(ownerManuals)
    .where(eq(ownerManuals.isActive, "active"));

  const existingKeys = new Set(carsWithManuals.map((c) => `${c.make}-${c.model}`));

  // Get unique makes/models from carFluidSpecs
  const cars = await db
    .selectDistinct({ make: sql<string>`${ownerManuals.make}`, model: sql<string>`${ownerManuals.model}` })
    .from(ownerManuals)
    .limit(limit * 2);

  const results = [];
  for (let i = 0; i < Math.min(limit, cars.length); i++) {
    const car = cars[i];
    const key = `${car.make}-${car.model}`;
    if (existingKeys.has(key)) {
      results.push({ make: car.make, model: car.model, skipped: true });
      continue;
    }

    const res = await runManualFinder({ make: car.make, model: car.model });
    results.push({ make: car.make, model: car.model, ...res });

    await new Promise((r) => setTimeout(r, 1500));
  }

  return { processed: results.length, results };
}

// ─── CLI ───
if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  const make = args.find((a) => a.startsWith("--make="))?.split("=")[1];
  const model = args.find((a) => a.startsWith("--model="))?.split("=")[1];
  const year = args.find((a) => a.startsWith("--year="))?.split("=")[1];
  const limit = args.find((a) => a.startsWith("--limit="))?.split("=")[1];

  if (make && model) {
    runManualFinder({ make, model, year: year ? parseInt(year) : undefined })
      .then((r) => { console.log(JSON.stringify(r, null, 2)); process.exit(0); })
      .catch((e) => { console.error(e); process.exit(1); });
  } else if (limit) {
    runBatchManualFinder({ limit: parseInt(limit) })
      .then((r) => { console.log(JSON.stringify(r, null, 2)); process.exit(0); })
      .catch((e) => { console.error(e); process.exit(1); });
  } else {
    console.log(`
Usage:
  Single:  npx tsx api/agents/manualFinder.ts --make=BMW --model=X5 --year=2015
  Batch:   npx tsx api/agents/manualFinder.ts --limit=10
`);
    process.exit(1);
  }
}
