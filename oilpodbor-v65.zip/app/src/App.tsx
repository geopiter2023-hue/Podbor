import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import Login from "./pages/Login"
import NotFound from "./pages/NotFound"
import Admin from "./pages/Admin"
import Company from "./pages/Company"
import Widget from "./pages/Widget"
import Marketplace from "./pages/Marketplace"

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/admin" element={<Admin />} />
      <Route path="/company" element={<Company />} />
      <Route path="/embed" element={<Widget />} />
      <Route path="/marketplace" element={<Marketplace />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
