import { Key, Bot, Search, ExternalLink } from "lucide-react";

export function ApiKeyStatus(props: { settings: any[] }) {
  const settings = props.settings;
  const anthropic = settings.find((s: any) => s.key === "anthropic_api_key");
  const openai = settings.find((s: any) => s.key === "openai_api_key");
  const nomerogram = settings.find((s: any) => s.key === "nomerogram_token");

  const hasAnthropic = anthropic?.value && anthropic.value.length > 10;
  const hasOpenAI = openai?.value && openai.value.length > 10;
  const hasNomerogram = nomerogram?.value && nomerogram.value.length > 5;

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
      <div className="p-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between">
        <h3 className="text-gray-800 text-sm font-semibold flex items-center gap-2">
          <Key className="w-4 h-4" />
          Статус API-ключей
        </h3>
        <span className={`text-xs px-2 py-1 rounded-full font-medium ${hasAnthropic ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
          {hasAnthropic ? "ИИ готов к работе" : "Требуется ключ Anthropic"}
        </span>
      </div>
      <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className={`rounded-lg border p-3 ${hasAnthropic ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}`}>
          <div className="flex items-center gap-2 mb-2">
            <Bot className={`w-4 h-4 ${hasAnthropic ? "text-green-600" : "text-red-500"}`} />
            <span className="text-sm font-medium text-gray-800">Anthropic Claude</span>
            <span className={`ml-auto text-[10px] px-1.5 py-0.5 rounded ${hasAnthropic ? "bg-green-200 text-green-800" : "bg-red-200 text-red-800"}`}>
              {hasAnthropic ? "АКТИВЕН" : "ПУСТО"}
            </span>
          </div>
          <p className="text-xs text-gray-500 mb-2">Основной ИИ для 6 агентов. Модель: Haiku.</p>
          {!hasAnthropic && (
            <a href="https://console.anthropic.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 font-medium">
              <ExternalLink className="w-3 h-3" />
              Получить ключ — console.anthropic.com
            </a>
          )}
        </div>

        <div className={`rounded-lg border p-3 ${hasOpenAI ? "border-green-200 bg-green-50" : "border-amber-200 bg-amber-50"}`}>
          <div className="flex items-center gap-2 mb-2">
            <Bot className={`w-4 h-4 ${hasOpenAI ? "text-green-600" : "text-amber-500"}`} />
            <span className="text-sm font-medium text-gray-800">OpenAI GPT</span>
            <span className={`ml-auto text-[10px] px-1.5 py-0.5 rounded ${hasOpenAI ? "bg-green-200 text-green-800" : "bg-amber-200 text-amber-800"}`}>
              {hasOpenAI ? "АКТИВЕН" : "РЕЗЕРВ"}
            </span>
          </div>
          <p className="text-xs text-gray-500 mb-2">Резервный ИИ если Claude недоступен.</p>
          {!hasOpenAI && (
            <a href="https://platform.openai.com" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 font-medium">
              <ExternalLink className="w-3 h-3" />
              platform.openai.com
            </a>
          )}
        </div>

        <div className={`rounded-lg border p-3 ${hasNomerogram ? "border-green-200 bg-green-50" : "border-amber-200 bg-amber-50"}`}>
          <div className="flex items-center gap-2 mb-2">
            <Search className={`w-4 h-4 ${hasNomerogram ? "text-green-600" : "text-amber-500"}`} />
            <span className="text-sm font-medium text-gray-800">Номерограм</span>
            <span className={`ml-auto text-[10px] px-1.5 py-0.5 rounded ${hasNomerogram ? "bg-green-200 text-green-800" : "bg-amber-200 text-amber-800"}`}>
              {hasNomerogram ? "АКТИВЕН" : "РЕЗЕРВ"}
            </span>
          </div>
          <p className="text-xs text-gray-500 mb-2">Поиск авто по гос. номеру.</p>
          {!hasNomerogram && (
            <a href="https://api-cloud.ru" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 font-medium">
              <ExternalLink className="w-3 h-3" />
              api-cloud.ru
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
