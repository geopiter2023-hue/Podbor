import { useState, useCallback } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import type { ReactNode } from "react";
import {
  Car, Droplets, Settings, BookOpen, ChevronRight, ChevronDown,
  Plus, Trash2, Search, Save, X, Menu, LogOut, Gauge,
  Wrench, Cog, Snowflake, Fuel, Filter, Table,
  FileText, TreeDeciduous, Link2, Users, BarChart3, Code,
  Key, Globe, Copy, RefreshCw, Activity, TrendingUp, Eye,
  FileUp, FileDown, Bot, Play, Pause, RotateCw, UploadCloud, ExternalLink,
} from "lucide-react";
import { ApiKeyStatus } from "@/components/ApiKeyStatus";

// ═══════════════════════════════════════════
//  TYPES
// ═══════════════════════════════════════════
type SidebarItem = {
  id: string;
  label: string;
  icon: React.ElementType;
  children?: { id: string; label: string; icon?: React.ElementType }[];
};

type ContentView =
  | "dashboard"
  | "cars-list" | "car-edit" | "car-create"
  | "liquids-list" | "liquid-edit"
  | "ref-vehicleTypes" | "ref-steering" | "ref-bodyTypes" | "ref-fuelTypes"
  | "ref-transmissionTypes" | "ref-viscosity" | "ref-categories" | "ref-trees"
  | "car-liquid-link"
  | "companies" | "products" | "assignments"
  | "widgets"
  | "import-export"
  | "ai-agents"
  | "settings";

// ═══════════════════════════════════════════
//  SIDEBAR DATA
// ═══════════════════════════════════════════
const sidebarItems: SidebarItem[] = [
  { id: "dashboard", label: "Главная", icon: BarChart3 },
  {
    id: "liquids",
    label: "Жидкости",
    icon: Droplets,
    children: [
      { id: "liquids-list", label: "Список жидкостей", icon: Table },
    ],
  },
  {
    id: "cars",
    label: "Автомобили",
    icon: Car,
    children: [
      { id: "cars-list", label: "Список автомобилей", icon: Table },
      { id: "car-create", label: "Добавить автомобиль", icon: Plus },
    ],
  },
  {
    id: "ref",
    label: "Справочники",
    icon: BookOpen,
    children: [
      { id: "ref-categories", label: "Категории жидкостей", icon: Filter },
      { id: "ref-trees", label: "Дерево агрегатов", icon: TreeDeciduous },
      { id: "ref-vehicleTypes", label: "Типы транспортных средств", icon: Car },
      { id: "ref-steering", label: "Расположение руля", icon: Settings },
      { id: "ref-bodyTypes", label: "Типы кузовов", icon: Car },
      { id: "ref-fuelTypes", label: "Типы топлива", icon: Fuel },
      { id: "ref-transmissionTypes", label: "Типы коробок передач", icon: Cog },
      { id: "ref-viscosity", label: "Классы вязкости", icon: Droplets },
    ],
  },
  {
    id: "links",
    label: "Связь",
    icon: Link2,
    children: [
      { id: "car-liquid-link", label: "Автомобиль/Жидкость", icon: Link2 },
    ],
  },
  {
    id: "data",
    label: "Данные",
    icon: FileUp,
    children: [
      { id: "import-export", label: "Импорт / Экспорт Excel", icon: FileUp },
    ],
  },
  { id: "ai-agents", label: "ИИ Агенты", icon: Bot },
  { id: "settings", label: "Настройки", icon: Settings },
  { id: "widgets", label: "Виджеты", icon: Code },
  { id: "companies", label: "Компании", icon: Users },
];

// ═══════════════════════════════════════════
//  BREADCRUMB MAP
// ═══════════════════════════════════════════
const breadcrumbMap: Record<string, string> = {
  dashboard: "Главная",
  "cars-list": "Автомобили / Список",
  "car-edit": "Автомобили / Редактирование",
  "car-create": "Автомобили / Создание",
  "liquids-list": "Жидкости / Список",
  "liquid-edit": "Жидкости / Редактирование",
  "ref-vehicleTypes": "Справочники / Типы ТС",
  "ref-steering": "Справочники / Расположение руля",
  "ref-bodyTypes": "Справочники / Типы кузовов",
  "ref-fuelTypes": "Справочники / Типы топлива",
  "ref-transmissionTypes": "Справочники / Типы КПП",
  "ref-viscosity": "Справочники / Классы вязкости",
  "ref-categories": "Справочники / Категории жидкостей",
  "ref-trees": "Справочники / Дерево агрегатов",
  "car-liquid-link": "Связь / Автомобиль-Жидкость",
  companies: "Компании",
  products: "Продукты",
  assignments: "Привязки",
  widgets: "Виджеты",
  "import-export": "Импорт / Экспорт Excel",
  "ai-agents": "ИИ Агенты",
  "settings": "Настройки системы",
};

// ═══════════════════════════════════════════
//  GENERIC REFERENCE TABLE
// ═══════════════════════════════════════════
function RefTable({
  title,
  endpoint,
  createEndpoint,
  deleteEndpoint,
  columns,
}: {
  title: string;
  endpoint: any;
  createEndpoint: any;
  deleteEndpoint: any;
  columns: { key: string; label: string }[];
}) {
  const utils = trpc.useUtils();
  const { data: items, isLoading } = endpoint.useQuery();
  const create = createEndpoint.useMutation({
    onSuccess: () => {
      utils.invalidate();
      setNewName("");
    },
  });
  const remove = deleteEndpoint.useMutation({
    onSuccess: () => utils.invalidate(),
  });
  const [newName, setNewName] = useState("");

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h2 className="text-gray-800 text-lg font-semibold">{title}</h2>
      </div>
      <div className="p-4">
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && newName.trim()) {
                create.mutate({ name: newName.trim() });
              }
            }}
            placeholder="Название..."
            className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
          />
          <button
            onClick={() => newName.trim() && create.mutate({ name: newName.trim() })}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-1 transition-colors"
          >
            <Plus className="w-4 h-4" /> Создать
          </button>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3 text-gray-500 text-xs font-medium uppercase w-16">Действия</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium uppercase">ID</th>
                  {columns.map((c) => (
                    <th key={c.key} className="text-left p-3 text-gray-500 text-xs font-medium uppercase">{c.label}</th>
                  ))}
                  <th className="text-left p-3 text-gray-500 text-xs font-medium uppercase w-32">Статус</th>
                </tr>
              </thead>
              <tbody>
                {items?.map((item: any) => (
                  <tr key={item.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                    <td className="p-3">
                      <button
                        onClick={() => { if (confirm("Удалить?")) remove.mutate({ id: item.id }); }}
                        className="text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                    <td className="p-3 font-mono text-xs text-gray-500">{item.id}</td>
                    {columns.map((c) => (
                      <td key={c.key} className="p-3 text-gray-700 text-sm">{item[c.key] || "—"}</td>
                    ))}
                    <td className="p-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${item.isActive === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                        {item.isActive === "active" ? "Активен" : "Неактивен"}
                      </span>
                    </td>
                  </tr>
                ))}
                {(!items || items.length === 0) && (
                  <tr>
                    <td colSpan={columns.length + 3} className="p-8 text-center text-gray-400 text-sm">
                      Нет данных
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  CAR EDIT FORM
// ═══════════════════════════════════════════
const FLUID_FIELDS: { section: string; icon: React.ElementType; color: string; fields: { key: string; label: string; width?: string }[] }[] = [
  {
    section: "Общие данные",
    icon: Car,
    color: "blue",
    fields: [
      { key: "vehicleType", label: "Тип ТС" },
      { key: "steeringPosition", label: "Расположение руля" },
      { key: "make", label: "Марка" },
      { key: "model", label: "Модель" },
      { key: "body", label: "Кузов" },
      { key: "modification", label: "Модификация" },
      { key: "yearFrom", label: "Год от" },
      { key: "yearTo", label: "Год до" },
    ],
  },
  {
    section: "Двигатель",
    icon: Gauge,
    color: "amber",
    fields: [
      { key: "engineCode", label: "Код ДВС" },
      { key: "engineVolume", label: "Объём ДВС" },
      { key: "fuelType", label: "Тип топлива" },
      { key: "engineFillVolume", label: "Объём масла (л)" },
      { key: "engineReplaceInterval", label: "Регламент замены" },
      { key: "engineName", label: "Название двигателя" },
      { key: "horsePower", label: "Мощность (л.с.)" },
    ],
  },
  {
    section: "Моторное масло (предпочт.)",
    icon: Droplets,
    color: "emerald",
    fields: [
      { key: "prefOilSae", label: "SAE" },
      { key: "prefOilApi", label: "API" },
      { key: "prefOilAcea", label: "ACEA" },
      { key: "prefOilIlsac", label: "ILSAC" },
      { key: "prefOilOe", label: "OEM допуски" },
    ],
  },
  {
    section: "Моторное масло (альт.)",
    icon: Droplets,
    color: "teal",
    fields: [
      { key: "altOilViscosities", label: "Вязкости" },
      { key: "altOilApi", label: "API" },
      { key: "altOilAcea", label: "ACEA" },
      { key: "altOilIlsac", label: "ILSAC" },
      { key: "altOilOe", label: "OEM" },
    ],
  },
  {
    section: "КПП",
    icon: Cog,
    color: "cyan",
    fields: [
      { key: "transmissionType", label: "Тип КПП" },
      { key: "transmissionGears", label: "Кол-во передач" },
      { key: "transmissionCode", label: "Код КПП" },
      { key: "transmissionFillVolume", label: "Объём масла (л)" },
      { key: "transmissionPrefOil", label: "Масло КПП" },
      { key: "transmissionAltOil", label: "Альт. масло" },
      { key: "transmissionReplaceInterval", label: "Регламент замены" },
    ],
  },
  {
    section: "Раздаточная коробка",
    icon: Settings,
    color: "indigo",
    fields: [
      { key: "transferCaseCode", label: "Код РКП" },
      { key: "transferCaseFillVolume", label: "Объём (л)" },
      { key: "transferCaseOil", label: "Масло" },
      { key: "transferCaseInterval", label: "Регламент" },
    ],
  },
  {
    section: "Передний дифференциал",
    icon: Settings,
    color: "violet",
    fields: [
      { key: "frontDiffCode", label: "Код" },
      { key: "frontDiffFillVolume", label: "Объём (л)" },
      { key: "frontDiffOil", label: "Масло" },
      { key: "frontDiffInterval", label: "Регламент" },
    ],
  },
  {
    section: "Задний дифференциал",
    icon: Settings,
    color: "purple",
    fields: [
      { key: "rearDiffCode", label: "Код" },
      { key: "rearDiffFillVolume", label: "Объём (л)" },
      { key: "rearDiffOil", label: "Масло" },
      { key: "rearDiffInterval", label: "Регламент" },
    ],
  },
  {
    section: "Система охлаждения",
    icon: Snowflake,
    color: "sky",
    fields: [
      { key: "coolantFillVolume", label: "Объём антифриза (л)" },
      { key: "coolantType", label: "Тип антифриза" },
      { key: "coolantInterval", label: "Регламент" },
    ],
  },
  {
    section: "Тормозная система",
    icon: Gauge,
    color: "red",
    fields: [
      { key: "brakeFluidVolume", label: "Объём (л)" },
      { key: "brakeFluidType", label: "Тип жидкости" },
      { key: "brakeFluidInterval", label: "Регламент" },
    ],
  },
  {
    section: "ГУР и подвеска",
    icon: Wrench,
    color: "orange",
    fields: [
      { key: "psFluidVolume", label: "Объём ГУР (л)" },
      { key: "psFluidType", label: "Тип ГУР" },
      { key: "suspFluidVolume", label: "Объём подвески (л)" },
      { key: "suspFluidType", label: "Тип подвески" },
    ],
  },
  {
    section: "AdBlue",
    icon: Droplets,
    color: "blue",
    fields: [
      { key: "adblueVolume", label: "Объём (л)" },
      { key: "adblueType", label: "Тип" },
    ],
  },
  {
    section: "Фильтры",
    icon: Filter,
    color: "rose",
    fields: [
      { key: "oilFilter", label: "Масляный" },
      { key: "airFilter", label: "Воздушный" },
      { key: "cabinFilter", label: "Салонный" },
      { key: "fuelFilter", label: "Топливный" },
      { key: "transmissionFilter", label: "АКПП" },
    ],
  },
];

function CarEditForm({
  carId,
  onBack,
}: {
  carId: string;
  onBack: () => void;
}) {
  const utils = trpc.useUtils();
  const { data } = trpc.cars.getById.useQuery({ id: carId });
  const update = trpc.cars.update.useMutation({
    onSuccess: () => {
      utils.cars.getById.invalidate({ id: carId });
    },
  });
  const { data: refData } = trpc.reference.all.useQuery();

  const car = data?.car;
  const make = car?.make || "";
  const model = car?.model || "";

  // Owner manuals for this car
  const { data: carManuals } = trpc.manuals.findByCar.useQuery(
    { make, model },
    { enabled: !!make && !!model }
  );
  const createManual = trpc.manuals.create.useMutation({
    onSuccess: () => utils.manuals.findByCar.invalidate(),
  });

  // Data completeness
  const { data: completeness } = trpc.excel.completeness.useQuery(
    { make, model },
    { enabled: !!make && !!model }
  );

  // carFluidSpecs data (57 fields)
  const { data: fluidData } = trpc.excel.getByCar.useQuery(
    { make, model },
    { enabled: !!make && !!model }
  );
  const updateFluid = trpc.excel.updateByCar.useMutation({
    onSuccess: () => {
      utils.excel.getByCar.invalidate();
      utils.excel.completeness.invalidate();
    },
  });

  // AI Fill mutation
  const fillAI = trpc.excel.fillWithAI.useMutation({
    onSuccess: (result) => {
      alert(`ИИ заполнение завершено! Результаты:\n- Масла: ${result.results.oil?.success ? "OK" : result.results.oil?.error || "Нет данных"}\n- Жидкости: ${result.results.fluids?.success ? "OK" : result.results.fluids?.error || "Нет данных"}\n- Руководства: ${result.results.manual?.success ? "OK" : "Нет данных"}\n\nОбновите страницу для просмотра результатов.`);
      utils.excel.completeness.invalidate();
      utils.excel.getByCar.invalidate();
    },
    onError: (err) => alert("Ошибка: " + err.message),
  });

  const [form, setForm] = useState<Record<string, any>>({});

  // Populate form when carFluidSpecs loads
  const baseData = fluidData || {};
  // Merge car base info into form
  const mergedBase = car ? {
    vehicleType: car.vehicleTypeId === 1 ? "Легковой" : baseData.vehicleType || "",
    make: car.make || baseData.make || "",
    model: car.model || baseData.model || "",
    body: car.body || baseData.body || "",
    modification: car.modification || baseData.modification || "",
    yearFrom: car.yearFrom || baseData.yearFrom || "",
    yearTo: car.yearTo || baseData.yearTo || "",
    engineCode: car.engineCode || baseData.engineCode || "",
    engineName: car.engineName || baseData.engineName || "",
    engineVolume: car.engineCapacity || baseData.engineVolume || "",
    horsePower: car.horsePower || baseData.horsePower || "",
    transmissionType: car.transmissionTypeId ? String(car.transmissionTypeId) : baseData.transmissionType || "",
    transmissionGears: car.transmissionGears || baseData.transmissionGears || "",
    transmissionCode: car.transmissionCode || baseData.transmissionCode || "",
    transferCaseCode: car.transferCaseCode || baseData.transferCaseCode || "",
    frontDiffCode: car.frontDifferentialCode || baseData.frontDiffCode || "",
    rearDiffCode: car.rearDifferentialCode || baseData.rearDiffCode || "",
    refrigerantType: car.refrigerantType || baseData.refrigerantType || "",
  } : {};

  const allData = { ...baseData, ...mergedBase };

  if (Object.keys(form).length === 0 && (fluidData || car)) {
    setForm(allData);
  }

  const updateField = (field: string, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    // Save base car data
    if (car) {
      const { id: _id, createdAt, updatedAt, ...updateData } = form;
      update.mutate({ id: carId, ...updateData });
    }
    // Save carFluidSpecs data (all 57 fields)
    if (make && model) {
      const fluidPayload: Record<string, any> = {};
      FLUID_FIELDS.forEach((section) => {
        section.fields.forEach((f) => {
          if (form[f.key] !== undefined && form[f.key] !== null && form[f.key] !== "") {
            fluidPayload[f.key] = String(form[f.key]);
          }
        });
      });
      updateFluid.mutate({ make, model, modification: form.modification, data: fluidPayload });
    }
    alert("Сохранено!");
  };

  if (!car) {
    return (
      <div className="flex justify-center py-12">
        <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Calculate section fill percentages
  const sectionStats = FLUID_FIELDS.map((section) => {
    const filled = section.fields.filter((f) => form[f.key] && String(form[f.key]).trim() !== "").length;
    return { name: section.section, filled, total: section.fields.length, percent: Math.round((filled / section.fields.length) * 100) };
  });
  const totalFilled = sectionStats.reduce((s, sec) => s + sec.filled, 0);
  const totalFields = sectionStats.reduce((s, sec) => s + sec.total, 0);
  const overallPercent = totalFields > 0 ? Math.round((totalFilled / totalFields) * 100) : 0;

  // Search images query
  const { data: carImages } = trpc.cars.searchImages.useQuery(
    { make, model },
    { enabled: !!make && !!model }
  );
  const updateImages = trpc.cars.updateImages.useMutation({
    onSuccess: () => utils.cars.getById.invalidate({ id: carId }),
  });

  return (
    <div>
      {/* Toolbar */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-gray-500 hover:text-gray-700 flex items-center gap-1 text-sm">
            <ChevronRight className="w-4 h-4 rotate-180" /> Назад
          </button>
          <h2 className="text-gray-800 text-xl font-semibold">
            {car.make} {car.model} {car.modification ? `— ${car.modification.substring(0, 30)}` : ""}
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleSave}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-1 transition-colors"
          >
            <Save className="w-4 h-4" /> Сохранить
          </button>
          <button
            onClick={onBack}
            className="border border-gray-300 text-gray-600 px-4 py-2 rounded-md text-sm hover:bg-gray-50 transition-colors"
          >
            Отмена
          </button>
        </div>
      </div>

      {/* Data Completeness + AI Fill */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-3 flex-wrap">
            <h3 className="text-gray-800 text-sm font-semibold">Заполненность данных</h3>
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${overallPercent >= 80 ? "bg-green-100 text-green-700" : overallPercent >= 50 ? "bg-amber-100 text-amber-700" : overallPercent >= 20 ? "bg-orange-100 text-orange-700" : "bg-red-100 text-red-700"}`}>
              {overallPercent}%
            </span>
            <span className="text-gray-400 text-xs">({totalFilled} из {totalFields} полей)</span>
            {overallPercent === 0 && <span className="text-[10px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded">Нет данных — заполните ИИ или введите вручную</span>}
          </div>
          <button
            onClick={() => {
              if (confirm(`Запустить ИИ агентов для заполнения данных ${car.make} ${car.model}?`)) {
                fillAI.mutate({
                  make: car.make || "",
                  model: car.model || "",
                  engineCode: car.engineCode || undefined,
                  modification: car.modification || undefined,
                });
              }
            }}
            disabled={fillAI.isPending}
            className="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-purple-700 disabled:opacity-50 flex items-center gap-2 transition-colors w-full sm:w-auto justify-center"
          >
            {fillAI.isPending ? <><RefreshCw className="w-4 h-4 animate-spin" />Заполнение...</> : <><Bot className="w-4 h-4" />Заполнить ИИ</>}
          </button>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5 mb-3">
          <div className={`h-2.5 rounded-full transition-all ${overallPercent >= 80 ? "bg-green-500" : overallPercent >= 50 ? "bg-amber-500" : overallPercent >= 20 ? "bg-orange-500" : "bg-red-500"}`} style={{ width: `${overallPercent}%` }} />
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
          {sectionStats.map((section) => (
            <div key={section.name} className="bg-gray-50 rounded-lg p-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-gray-600 text-[10px] leading-tight">{section.name}</span>
                <span className={`text-[10px] font-medium ${section.percent >= 80 ? "text-green-600" : section.percent >= 50 ? "text-amber-600" : "text-red-600"}`}>{section.percent}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-1">
                <div className={`h-1 rounded-full ${section.percent >= 80 ? "bg-green-500" : section.percent >= 50 ? "bg-amber-500" : "bg-red-500"}`} style={{ width: `${section.percent}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Owner Manuals / PDF Section */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 mb-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-gray-800 text-sm font-semibold flex items-center gap-2"><BookOpen className="w-4 h-4 text-purple-600" />Руководства по эксплуатации / Сервисные книжки</h3>
          <span className="text-gray-400 text-xs">{carManuals?.length ?? 0} документов</span>
        </div>

        {/* Existing manuals */}
        {carManuals && carManuals.length > 0 ? (
          <div className="space-y-2 mb-4">
            {carManuals.map((m: any) => (
              <div key={m.id} className="flex items-center gap-3 bg-gray-50 rounded-lg p-3 border border-gray-100">
                <div className="w-8 h-8 rounded bg-purple-100 flex items-center justify-center flex-shrink-0">
                  <FileText className="w-4 h-4 text-purple-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-gray-800 text-sm font-medium truncate">{m.title || `Руководство ${m.make} ${m.model}`}</p>
                  <div className="flex gap-2 text-[10px] text-gray-400">
                    {m.source && <span>{m.source}</span>}
                    <span>{m.language === "ru" ? "RU" : m.language === "en" ? "EN" : m.language}</span>
                    {m.isOfficial === "yes" && <span className="text-purple-600 font-medium">Официальное</span>}
                    {m.pdfSize && <span>{m.pdfSize}</span>}
                  </div>
                </div>
                <a href={m.pdfUrl} target="_blank" rel="noopener noreferrer" className="p-2 bg-blue-50 rounded hover:bg-blue-100 transition-colors flex-shrink-0" title="Открыть PDF">
                  <ExternalLink className="w-4 h-4 text-blue-600" />
                </a>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-4 text-gray-400 text-sm mb-4 bg-gray-50 rounded-lg">
            <BookOpen className="w-8 h-8 mx-auto mb-2 text-gray-300" />
            Нет руководств. Добавьте PDF или запустите ИИ-поиск.
          </div>
        )}

        {/* Add manual form */}
        <div className="border-t border-gray-200 pt-3">
          <p className="text-gray-500 text-xs mb-2 font-medium">Добавить руководство вручную:</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input
              type="text"
              id="manual-title"
              placeholder="Название (например: Руководство ACURA ILX 2019)"
              className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-purple-500 sm:col-span-1"
            />
            <input
              type="text"
              id="manual-url"
              placeholder="Ссылка на PDF"
              className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-purple-500 sm:col-span-1"
            />
            <div className="flex gap-2">
              <select id="manual-official" className="border border-gray-300 rounded-md px-2 py-2 text-sm text-gray-800 flex-1">
                <option value="no">Неофициальное</option>
                <option value="yes">Официальное</option>
              </select>
              <button
                onClick={() => {
                  const title = (document.getElementById("manual-title") as HTMLInputElement)?.value;
                  const url = (document.getElementById("manual-url") as HTMLInputElement)?.value;
                  const official = (document.getElementById("manual-official") as HTMLSelectElement)?.value as "yes" | "no";
                  if (url && car.make && car.model) {
                    createManual.mutate({
                      make: car.make,
                      model: car.model,
                      title: title || undefined,
                      pdfUrl: url,
                      pdfOriginalUrl: url,
                      isOfficial: official,
                      source: "Ручная загрузка",
                    }, {
                      onSuccess: () => {
                        (document.getElementById("manual-title") as HTMLInputElement).value = "";
                        (document.getElementById("manual-url") as HTMLInputElement).value = "";
                      },
                    });
                  }
                }}
                disabled={createManual.isPending}
                className="bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-800 disabled:opacity-50 flex items-center gap-1"
              >
                <UploadCloud className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Car Images */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 mb-4">
        <h3 className="text-gray-800 text-sm font-semibold mb-3 flex items-center gap-2">
          <Car className="w-4 h-4" />
          Изображения автомобиля
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Photo */}
          <div className="space-y-2">
            <label className="text-xs text-gray-500">Фото автомобиля</label>
            {car?.carPhotoUrl || carImages?.photoUrl ? (
              <img
                src={car?.carPhotoUrl || carImages?.photoUrl}
                alt={`${make} ${model}`}
                className="w-full h-48 object-contain bg-gray-50 rounded-lg border border-gray-100"
                onError={(e) => { (e.target as HTMLImageElement).src = carImages?.placeholders?.[0] || ""; }}
              />
            ) : (
              <div className="w-full h-48 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400 text-sm">
                Нет фото
              </div>
            )}
            <input
              type="text"
              value={form.carPhotoUrl || car?.carPhotoUrl || ""}
              onChange={(e) => updateField("carPhotoUrl", e.target.value)}
              placeholder="URL фото или вставьте Imagin URL"
              className="w-full border border-gray-300 rounded-md px-3 py-1.5 text-xs text-gray-800 font-mono"
            />
            {carImages?.photoUrl && (
              <button
                onClick={() => {
                  updateField("carPhotoUrl", carImages.photoUrl);
                  updateImages.mutate({ id: carId, carPhotoUrl: carImages.photoUrl });
                }}
                className="text-xs text-blue-600 hover:text-blue-800"
              >
                Загрузить с Imagin
              </button>
            )}
          </div>
          {/* Vector */}
          <div className="space-y-2">
            <label className="text-xs text-gray-500">Векторное изображение</label>
            {car?.carVectorUrl || carImages?.vectorUrl ? (
              <img
                src={car?.carVectorUrl || carImages?.vectorUrl}
                alt={`${make} ${model} vector`}
                className="w-full h-48 object-contain bg-gray-50 rounded-lg border border-gray-100"
                onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
              />
            ) : (
              <div className="w-full h-48 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400 text-sm">
                Нет вектора
              </div>
            )}
            <input
              type="text"
              value={form.carVectorUrl || car?.carVectorUrl || ""}
              onChange={(e) => updateField("carVectorUrl", e.target.value)}
              placeholder="URL SVG вектора"
              className="w-full border border-gray-300 rounded-md px-3 py-1.5 text-xs text-gray-800 font-mono"
            />
          </div>
        </div>
      </div>

      {/* 57 Fields Form */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {FLUID_FIELDS.map((section) => {
          const Icon = section.icon;
          const colorMap: Record<string, string> = {
            blue: "border-blue-200",
            amber: "border-amber-200",
            emerald: "border-emerald-200",
            teal: "border-teal-200",
            cyan: "border-cyan-200",
            indigo: "border-indigo-200",
            violet: "border-violet-200",
            purple: "border-purple-200",
            sky: "border-sky-200",
            red: "border-red-200",
            orange: "border-orange-200",
            rose: "border-rose-200",
          };
          const filled = section.fields.filter((f) => form[f.key] && String(form[f.key]).trim() !== "").length;
          return (
            <div key={section.section} className={`bg-white rounded-lg border ${colorMap[section.color] || "border-gray-200"} shadow-sm p-4`}>
              <div className="flex items-center justify-between mb-3 border-b border-gray-100 pb-2">
                <h3 className="text-gray-800 font-semibold text-sm uppercase tracking-wide flex items-center gap-2">
                  <Icon className="w-4 h-4 text-gray-500" />
                  {section.section}
                </h3>
                <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${filled === section.fields.length ? "bg-green-100 text-green-700" : filled > 0 ? "bg-amber-100 text-amber-700" : "bg-gray-100 text-gray-500"}`}>
                  {filled}/{section.fields.length}
                </span>
              </div>
              <div className="space-y-2">
                {section.fields.map((f) => (
                  <FormRow key={f.key} label={f.label}>
                    <input
                      type="text"
                      value={form[f.key] || ""}
                      onChange={(e) => updateField(f.key, e.target.value)}
                      placeholder={f.label}
                      className="w-full border border-gray-300 rounded-md px-3 py-1.5 text-sm text-gray-800 focus:outline-none focus:border-blue-500 placeholder:text-gray-300"
                    />
                  </FormRow>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Assigned Liquids */}
      <div className="mt-6 bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <h3 className="text-gray-800 font-semibold text-sm mb-4 uppercase tracking-wide border-b border-gray-100 pb-2">
          Назначенные жидкости
        </h3>
        {data?.liquids && data.liquids.length > 0 ? (
          <div className="overflow-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Агрегат</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Жидкость</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Объём</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Интервал</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-20">Основная</th>
                </tr>
              </thead>
              <tbody>
                {data.liquids.map((a: any) => (
                  <tr key={a.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                    <td className="p-3 text-gray-700 text-sm">{a.aggregationTreeName || "—"}</td>
                    <td className="p-3 text-gray-700 text-sm font-medium">{a.liquidName || a.liquidId}</td>
                    <td className="p-3 text-gray-600 text-sm">{a.fillVolume || "—"}</td>
                    <td className="p-3 text-gray-600 text-sm">{a.replaceInterval || "—"}</td>
                    <td className="p-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${a.isPrimary === "yes" ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-500"}`}>
                        {a.isPrimary === "yes" ? "Да" : "Нет"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-400 text-sm">Жидкости не назначены</p>
        )}
      </div>
    </div>
  );
}

function FormRow(props: { label: string; children: ReactNode }) {
  const { label, children } = props;
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 items-center">
      <label className="text-gray-600 text-sm font-medium">{label}</label>
      <div className="sm:col-span-2">{children}</div>
    </div>
  );
}

// Mini progress component for car list
function FillBar(props: { make: string; model: string }) {
  const { make, model } = props;
  const { data: comp } = trpc.excel.completeness.useQuery(
    { make, model },
    { enabled: !!make && !!model }
  );

  if (!comp) return <span className="text-gray-300 text-xs">—</span>;

  const pct = comp.overall;
  const color = pct >= 80 ? "bg-green-500" : pct >= 50 ? "bg-amber-500" : pct >= 20 ? "bg-orange-500" : "bg-red-500";
  const labelColor = pct >= 80 ? "text-green-700" : pct >= 50 ? "text-amber-700" : pct >= 20 ? "text-orange-700" : "text-red-700";

  return (
    <div className="flex items-center gap-2">
      <div className="w-16 bg-gray-200 rounded-full h-1.5 flex-shrink-0">
        <div className={`h-1.5 rounded-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className={`text-[10px] font-medium ${labelColor} flex-shrink-0`}>{pct}%</span>
    </div>
  );
}

// ═══════════════════════════════════════════
//  CAR LIST
// ═══════════════════════════════════════════
function CarList(props: { onEdit: (id: string) => void }) {
  const { onEdit } = props;
  const [filters, setFilters] = useState({ make: "", model: "", modification: "" });
  const [page, setPage] = useState(0);
  const [showMakeDropdown, setShowMakeDropdown] = useState(false);
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const pageSize = 50;

  const { data, isLoading } = trpc.cars.list.useQuery({
    make: filters.make || undefined,
    model: filters.model || undefined,
    modification: filters.modification || undefined,
    limit: pageSize,
    offset: page * pageSize,
  });

  const { data: totalCount } = trpc.cars.count.useQuery({
    make: filters.make || undefined,
    model: filters.model || undefined,
    modification: filters.modification || undefined,
  });

  // Dropdown data
  const { data: allMakes } = trpc.cars.getMakes.useQuery();
  const { data: modelsForMake } = trpc.cars.getModels.useQuery(
    { make: filters.make },
    { enabled: !!filters.make }
  );
  const { data: modsForMakeModel } = trpc.cars.getModifications.useQuery(
    { make: filters.make, model: filters.model },
    { enabled: !!filters.make && !!filters.model }
  );

  const totalPages = Math.ceil((totalCount || 0) / pageSize);

  const selectMake = (m: string) => {
    setFilters((p) => ({ ...p, make: m, model: "", modification: "" }));
    setPage(0);
    setShowMakeDropdown(false);
  };
  const selectModel = (m: string) => {
    setFilters((p) => ({ ...p, model: m, modification: "" }));
    setPage(0);
    setShowModelDropdown(false);
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <div>
          <h2 className="text-gray-800 text-lg font-semibold">Список автомобилей</h2>
          <p className="text-gray-400 text-xs mt-0.5">{totalCount?.toLocaleString("ru") || "..."} авто в базе</p>
        </div>
      </div>
      <div className="p-4">
        {/* Smart filters */}
        <div className="flex gap-2 mb-4 flex-wrap relative z-10">
          {/* Make dropdown */}
          <div className="relative">
            <input
              type="text"
              value={filters.make}
              onChange={(e) => { setFilters((p) => ({ ...p, make: e.target.value, model: "", modification: "" })); setPage(0); }}
              onFocus={() => setShowMakeDropdown(true)}
              onBlur={() => setTimeout(() => setShowMakeDropdown(false), 200)}
              placeholder="Все марки"
              className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 w-44"
            />
            {showMakeDropdown && allMakes && allMakes.length > 0 && (
              <div className="absolute top-full left-0 w-44 max-h-60 overflow-auto bg-white border border-gray-200 rounded-md shadow-lg mt-1 z-50">
                <button onMouseDown={() => selectMake("")} className="w-full text-left px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-50">— Все марки</button>
                {allMakes.map((m) => (
                  <button key={m} onMouseDown={() => selectMake(m)} className={`w-full text-left px-3 py-1.5 text-sm hover:bg-blue-50 ${filters.make === m ? "bg-blue-50 text-blue-700 font-medium" : "text-gray-800"}`}>{m}</button>
                ))}
              </div>
            )}
          </div>

          {/* Model dropdown */}
          <div className="relative">
            <input
              type="text"
              value={filters.model}
              onChange={(e) => { setFilters((p) => ({ ...p, model: e.target.value, modification: "" })); setPage(0); }}
              onFocus={() => setShowModelDropdown(true)}
              onBlur={() => setTimeout(() => setShowModelDropdown(false), 200)}
              placeholder={filters.make ? "Все модели" : "Сначала выберите марку"}
              disabled={!filters.make}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 w-44 disabled:bg-gray-100 disabled:text-gray-400"
            />
            {showModelDropdown && modelsForMake && modelsForMake.length > 0 && (
              <div className="absolute top-full left-0 w-44 max-h-60 overflow-auto bg-white border border-gray-200 rounded-md shadow-lg mt-1 z-50">
                <button onMouseDown={() => selectModel("")} className="w-full text-left px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-50">— Все модели</button>
                {modelsForMake.map((m) => (
                  <button key={m} onMouseDown={() => selectModel(m)} className={`w-full text-left px-3 py-1.5 text-sm hover:bg-blue-50 ${filters.model === m ? "bg-blue-50 text-blue-700 font-medium" : "text-gray-800"}`}>{m}</button>
                ))}
              </div>
            )}
          </div>

          {/* Modification text (too many values for dropdown) */}
          <input
            type="text"
            value={filters.modification}
            onChange={(e) => { setFilters((p) => ({ ...p, modification: e.target.value })); setPage(0); }}
            placeholder="Модификация..."
            className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 w-48"
          />
        </div>

        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-16">Действия</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-16">Фото</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Марка</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Модель</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Модификация</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-24">Годы</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-32">Заполненность</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-20">Статус</th>
                </tr>
              </thead>
              <tbody>
                {data?.items?.map((car: any) => (
                  <tr key={car.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50 cursor-pointer" onClick={() => onEdit(car.id)}>
                    <td className="p-3">
                      <button
                        onClick={(e) => { e.stopPropagation(); onEdit(car.id); }}
                        className="text-blue-600 hover:text-blue-800 transition-colors"
                      >
                        <Settings className="w-4 h-4" />
                      </button>
                    </td>
                    <td className="p-2">
                      {car.carPhotoUrl ? (
                        <img src={car.carPhotoUrl} alt={car.make} className="w-12 h-8 object-contain bg-gray-50 rounded" />
                      ) : (
                        <div className="w-12 h-8 bg-gray-100 rounded flex items-center justify-center text-gray-300 text-[10px]">Нет</div>
                      )}
                    </td>
                    <td className="p-3 text-gray-800 text-sm font-medium">{car.make}</td>
                    <td className="p-3 text-gray-700 text-sm">{car.model}</td>
                    <td className="p-3 text-gray-600 text-sm">{car.modification}</td>
                    <td className="p-3 text-gray-500 text-xs">{car.yearFrom}{car.yearTo ? ` — ${car.yearTo}` : " — н.в."}</td>
                    <td className="p-3"><FillBar make={car.make} model={car.model} /></td>
                    <td className="p-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${car.isActive === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                        {car.isActive === "active" ? "Активен" : "Неактивен"}
                      </span>
                    </td>
                  </tr>
                ))}
                {(!data?.items || data.items.length === 0) && (
                  <tr><td colSpan={8} className="p-8 text-center text-gray-400 text-sm">Нет данных</td></tr>
                )}
              </tbody>
            </table>
            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-200">
                <span className="text-gray-500 text-xs">
                  Страница {page + 1} из {totalPages} ({totalCount?.toLocaleString("ru")} авто)
                </span>
                <div className="flex gap-1">
                  <button onClick={() => setPage(0)} disabled={page === 0} className="px-2 py-1 text-xs rounded border border-gray-300 disabled:opacity-30 hover:bg-gray-50">«</button>
                  <button onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0} className="px-2 py-1 text-xs rounded border border-gray-300 disabled:opacity-30 hover:bg-gray-50">‹</button>
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pg: number;
                    if (totalPages <= 5) pg = i;
                    else if (page <= 2) pg = i;
                    else if (page >= totalPages - 3) pg = totalPages - 5 + i;
                    else pg = page - 2 + i;
                    return (
                      <button key={pg} onClick={() => setPage(pg)} className={`px-2.5 py-1 text-xs rounded border ${page === pg ? "bg-blue-600 text-white border-blue-600" : "border-gray-300 hover:bg-gray-50"}`}>
                        {pg + 1}
                      </button>
                    );
                  })}
                  <button onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1} className="px-2 py-1 text-xs rounded border border-gray-300 disabled:opacity-30 hover:bg-gray-50">›</button>
                  <button onClick={() => setPage(totalPages - 1)} disabled={page >= totalPages - 1} className="px-2 py-1 text-xs rounded border border-gray-300 disabled:opacity-30 hover:bg-gray-50">»</button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  LIQUID LIST
// ═══════════════════════════════════════════
function LiquidList() {
  const [search, setSearch] = useState("");
  const { data, isLoading } = trpc.liquids.list.useQuery({
    search: search || undefined,
    limit: 50,
  });

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h2 className="text-gray-800 text-lg font-semibold">Список жидкостей</h2>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-md text-sm font-medium flex items-center gap-1 transition-colors">
          <Plus className="w-4 h-4" /> Добавить
        </button>
      </div>
      <div className="p-4">
        <div className="flex gap-2 mb-4">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Поиск по названию, артикулу, спецификации..."
              className="w-full border border-gray-300 rounded-md pl-9 pr-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-16">Действия</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">ID</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Название</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-16">Приоритет</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-20">Активность</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-16">Объём</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-32">Создан</th>
                </tr>
              </thead>
              <tbody>
                {data?.items?.map((item: any) => (
                  <tr key={item.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                    <td className="p-3">
                      <button className="text-blue-600 hover:text-blue-800 transition-colors">
                        <Settings className="w-4 h-4" />
                      </button>
                    </td>
                    <td className="p-3 font-mono text-xs text-gray-500">{item.id.substring(0, 16)}...</td>
                    <td className="p-3 text-gray-800 text-sm">{item.name}</td>
                    <td className="p-3 text-gray-600 text-sm text-center">{item.priority}</td>
                    <td className="p-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${item.isActive === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                        {item.isActive === "active" ? "Активен" : "Неактивен"}
                      </span>
                    </td>
                    <td className="p-3 text-gray-600 text-sm">{item.volume || "—"}</td>
                    <td className="p-3 text-gray-500 text-xs">{item.createdAt ? new Date(item.createdAt).toLocaleDateString("ru-RU") : "—"}</td>
                  </tr>
                ))}
                {(!data?.items || data.items.length === 0) && (
                  <tr><td colSpan={8} className="p-8 text-center text-gray-400 text-sm">Нет данных</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  MAIN ADMIN PAGE
// ═══════════════════════════════════════════
export default function Admin() {
  const { user, isLoading: authLoading } = useAuth({
    redirectOnUnauthenticated: true,
    redirectPath: "/login",
  });
  const navigate = useNavigate();

  const [view, setView] = useState<ContentView>("dashboard");
  const [editCarId, setEditCarId] = useState<string | null>(null);
  const [expandedMenus, setExpandedMenus] = useState<Set<string>>(new Set(["cars", "liquids", "ref", "links"]));
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleMenu = (id: string) => {
    setExpandedMenus((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleNav = (id: string) => {
    if (id === "car-edit" && editCarId) {
      setView("car-edit");
    } else {
      setView(id as ContentView);
    }
    setEditCarId(null);
    setSidebarOpen(false);
  };

  // Breadcrumb
  const breadcrumb = breadcrumbMap[view] || view;

  if (authLoading) return null;
  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-red-500 text-lg mb-2">Доступ запрещён</p>
          <p className="text-gray-500 text-sm mb-4">Требуется роль администратора</p>
          <button onClick={() => navigate("/")} className="text-blue-600 hover:underline text-sm">На главную</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`w-64 bg-[#1e1e1e] flex-shrink-0 flex flex-col h-screen fixed left-0 top-0 overflow-y-auto z-50 transition-transform duration-300 ease-in-out ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0`}>
        {/* Logo */}
        <div className="p-4 border-b border-gray-700">
          <h1 className="text-white text-lg font-bold tracking-tight">oilpodbor</h1>
        </div>

        {/* Menu */}
        <nav className="flex-1 py-2">
          {sidebarItems.map((item) => (
            <div key={item.id}>
              {item.children ? (
                <>
                  <button
                    onClick={() => toggleMenu(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${
                      expandedMenus.has(item.id)
                        ? "text-white bg-gray-800/50"
                        : "text-gray-400 hover:text-white hover:bg-gray-800/30"
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    <span className="flex-1 text-left">{item.label}</span>
                    {expandedMenus.has(item.id) ? (
                      <ChevronDown className="w-3 h-3 text-gray-500" />
                    ) : (
                      <ChevronRight className="w-3 h-3 text-gray-500" />
                    )}
                  </button>
                  {expandedMenus.has(item.id) && (
                    <div className="bg-gray-900/30">
                      {item.children.map((child) => (
                        <button
                          key={child.id}
                          onClick={() => handleNav(child.id)}
                          className={`w-full flex items-center gap-3 pl-11 pr-4 py-2 text-sm transition-colors ${
                            view === child.id
                              ? "text-blue-400 bg-blue-500/10 border-l-2 border-blue-500"
                              : "text-gray-400 hover:text-white hover:bg-gray-800/30 border-l-2 border-transparent"
                          }`}
                        >
                          {child.icon && <child.icon className="w-3.5 h-3.5" />}
                          <span>{child.label}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <button
                  onClick={() => handleNav(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${
                    view === item.id
                      ? "text-blue-400 bg-blue-500/10 border-l-2 border-blue-500"
                      : "text-gray-400 hover:text-white hover:bg-gray-800/30 border-l-2 border-transparent"
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              )}
            </div>
          ))}
        </nav>

        {/* User */}
        <div className="p-4 border-t border-gray-700">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center text-white text-xs font-medium">
              {user.name?.charAt(0) || "U"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-medium truncate">{user.name || "Admin"}</p>
              <p className="text-gray-500 text-xs">Пользователь</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 lg:ml-64">
        {/* Top bar */}
        <div className="bg-white border-b border-gray-200 px-4 lg:px-6 py-3 flex items-center justify-between sticky top-0 z-10">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 -ml-2 text-gray-600 hover:text-gray-900"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <span className="hover:text-gray-700 cursor-pointer">Главная</span>
            <ChevronRight className="w-3 h-3" />
            <span className="text-gray-800">{breadcrumb}</span>
          </div>
          <button
            onClick={() => { localStorage.removeItem("local_auth_token"); window.location.href = "/login"; }}
            className="text-gray-500 hover:text-red-500 text-sm flex items-center gap-1 transition-colors"
          >
            <LogOut className="w-4 h-4" /> Выход
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {view === "dashboard" && <DashboardView onNavigate={(v) => setView(v)} />}
          {view === "cars-list" && <CarList onEdit={(id) => { setEditCarId(id); setView("car-edit"); }} />}
          {view === "car-edit" && editCarId && <CarEditForm carId={editCarId} onBack={() => setView("cars-list")} />}
          {view === "car-create" && <CarCreateForm onBack={() => setView("cars-list")} />}
          {view === "liquids-list" && <LiquidList />}
          {view === "ref-vehicleTypes" && (
            <RefTable title="Типы транспортных средств" endpoint={trpc.reference.vehicleType.list} createEndpoint={trpc.reference.vehicleType.create} deleteEndpoint={trpc.reference.vehicleType.delete} columns={[{ key: "name", label: "Название" }, { key: "sortOrder", label: "Порядок" }]} />
          )}
          {view === "ref-steering" && (
            <RefTable title="Расположение руля" endpoint={trpc.reference.steeringPosition.list} createEndpoint={trpc.reference.steeringPosition.create} deleteEndpoint={trpc.reference.steeringPosition.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "ref-bodyTypes" && (
            <RefTable title="Типы кузовов" endpoint={trpc.reference.carBodyType.list} createEndpoint={trpc.reference.carBodyType.create} deleteEndpoint={trpc.reference.carBodyType.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "ref-fuelTypes" && (
            <RefTable title="Типы топлива" endpoint={trpc.reference.fuelType.list} createEndpoint={trpc.reference.fuelType.create} deleteEndpoint={trpc.reference.fuelType.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "ref-transmissionTypes" && (
            <RefTable title="Типы коробок передач" endpoint={trpc.reference.transmissionType.list} createEndpoint={trpc.reference.transmissionType.create} deleteEndpoint={trpc.reference.transmissionType.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "ref-viscosity" && (
            <RefTable title="Классы вязкости" endpoint={trpc.reference.viscosityClass.list} createEndpoint={trpc.reference.viscosityClass.create} deleteEndpoint={trpc.reference.viscosityClass.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "ref-categories" && (
            <RefTable title="Категории жидкостей" endpoint={trpc.reference.liquidCategory.list} createEndpoint={trpc.reference.liquidCategory.create} deleteEndpoint={trpc.reference.liquidCategory.delete} columns={[{ key: "name", label: "Название" }, { key: "displayName", label: "Отображаемое имя" }]} />
          )}
          {view === "ref-trees" && (
            <RefTable title="Дерево агрегатов" endpoint={trpc.reference.aggregationTree.list} createEndpoint={trpc.reference.aggregationTree.create} deleteEndpoint={trpc.reference.aggregationTree.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "companies" && <CompaniesView />}
          {view === "widgets" && <WidgetsView />}
          {view === "import-export" && <ImportExportView />}
          {view === "ai-agents" && <AiAgentsView />}
          {view === "settings" && <SettingsView />}
          {(view === "car-liquid-link" || view === "car-create" || view === "liquid-edit" || view === "assignments" || view === "products") && (
            <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-12 text-center">
              <p className="text-gray-400 text-lg">В разработке</p>
              <p className="text-gray-300 text-sm mt-1">Этот раздел будет доступен в следующей версии</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

// ═══════════════════════════════════════════
//  DASHBOARD VIEW
// ═══════════════════════════════════════════
function DashboardView(props: { onNavigate: (view: ContentView) => void }) {
  const { onNavigate } = props;
  const { data: stats } = trpc.admin.stats.useQuery();
  const { data: carsCount } = trpc.cars.list.useQuery({ limit: 1 });
  const { data: aiStats } = trpc.excel.stats.useQuery(undefined, { refetchInterval: 5000 });

  const cards = [
    { label: "Компании", value: stats?.companies || 0, icon: Users, color: "bg-blue-50 text-blue-600" },
    { label: "Продукты", value: stats?.products || 0, icon: Droplets, color: "bg-green-50 text-green-600" },
    { label: "Привязки", value: stats?.assignments || 0, icon: Link2, color: "bg-yellow-50 text-yellow-600" },
    { label: "Автомобили", value: carsCount?.total || 0, icon: Car, color: "bg-purple-50 text-purple-600" },
    { label: "Пользователи", value: stats?.users || 0, icon: Users, color: "bg-gray-100 text-gray-600" },
  ];

  const aiCards = [
    { label: "Заполнено ИИ", value: aiStats?.filledCarsCount || 0, icon: Bot, color: "bg-purple-50 text-purple-600", desc: "авто с данными" },
    { label: "Записей в БД", value: aiStats?.totalRecords || 0, icon: Table, color: "bg-blue-50 text-blue-600", desc: "всего записей" },
    { label: "Средняя заполненность", value: `${aiStats?.avgFillPercent || 0}%`, icon: Activity, color: "bg-green-50 text-green-600", desc: "по 28 ключевым полям" },
    { label: "Осталось", value: (carsCount?.total || 0) - (aiStats?.filledCarsCount || 0), icon: TrendingUp, color: "bg-orange-50 text-orange-600", desc: "авто без данных" },
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-gray-800 text-xl font-semibold">Главная</h2>

      {/* Base stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {cards.map((card) => (
          <div key={card.label} className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-gray-500 text-xs">{card.label}</span>
              <card.icon className={`w-5 h-5 ${card.color.split(" ")[1]}`} />
            </div>
            <span className="text-gray-800 text-2xl font-bold">{card.value}</span>
          </div>
        ))}
      </div>

      {/* AI Stats */}
      <div>
        <h3 className="text-gray-800 text-sm font-semibold mb-3 flex items-center gap-2">
          <Bot className="w-4 h-4 text-purple-600" />
          Статистика ИИ-заполнения
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {aiCards.map((card) => (
            <div key={card.label} className={`rounded-lg border shadow-sm p-4 ${card.color.split(" ")[0]}`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-600 text-xs">{card.label}</span>
                <card.icon className={`w-4 h-4 ${card.color.split(" ")[1]}`} />
              </div>
              <span className={`text-2xl font-bold ${card.color.split(" ")[1]}`}>{card.value}</span>
              <p className="text-gray-400 text-[10px] mt-1">{card.desc}</p>
            </div>
          ))}
        </div>

        {/* Progress bar */}
        <div className="mt-3 bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-gray-600 text-xs">Прогресс заполнения базы ИИ</span>
            <span className="text-purple-600 text-xs font-medium">
              {aiStats?.filledCarsCount || 0} / {carsCount?.total || 0} авто
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="bg-purple-500 h-3 rounded-full transition-all"
              style={{
                width: `${carsCount?.total ? Math.min(100, ((aiStats?.filledCarsCount || 0) / carsCount.total) * 100) : 0}%`,
              }}
            />
          </div>
        </div>

        {/* Big START button */}
        <div className="mt-4">
          <button
            onClick={() => onNavigate("ai-agents")}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-4 rounded-xl text-lg font-bold flex items-center justify-center gap-3 hover:from-purple-700 hover:to-blue-700 transition-all shadow-lg active:scale-95"
          >
            <Play className="w-6 h-6" />
            ЗАПУСТИТЬ ИИ
          </button>
          <p className="text-center text-gray-400 text-xs mt-2">Перейти в ИИ Агенты для массового заполнения</p>
        </div>

        {/* Recently filled cars */}
        {aiStats?.recentCars && aiStats.recentCars.length > 0 && (
          <div className="mt-3 bg-white rounded-lg border border-gray-200 shadow-sm p-4">
            <h4 className="text-gray-600 text-xs font-medium mb-2">Последние заполненные авто:</h4>
            <div className="flex flex-wrap gap-1">
              {aiStats.recentCars.map((car, i) => (
                <span key={i} className="text-[10px] bg-purple-50 text-purple-700 px-2 py-0.5 rounded-full">{car}</span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  COMPANIES VIEW (simplified)
// ═══════════════════════════════════════════
function CompaniesView() {
  const utils = trpc.useUtils();
  const { data: list, isLoading } = trpc.admin.listCompanies.useQuery();
  const create = trpc.admin.createCompany.useMutation({
    onSuccess: () => { utils.admin.listCompanies.invalidate(); setNewName(""); },
  });
  const remove = trpc.admin.deleteCompany.useMutation({
    onSuccess: () => utils.admin.listCompanies.invalidate(),
  });
  const [newName, setNewName] = useState("");

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h2 className="text-gray-800 text-lg font-semibold">Компании</h2>
      </div>
      <div className="p-4">
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && newName.trim()) create.mutate({ name: newName.trim(), slug: newName.trim().toLowerCase().replace(/\\s+/g, "-") }); }}
            placeholder="Название компании..."
            className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
          />
          <button onClick={() => newName.trim() && create.mutate({ name: newName.trim(), slug: newName.trim().toLowerCase().replace(/\\s+/g, "-") })} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-1 transition-colors">
            <Plus className="w-4 h-4" /> Создать
          </button>
        </div>
        {isLoading ? (
          <div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>
        ) : (
          <div className="overflow-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-16">Действия</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Название</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Slug</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-20">Статус</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-32">Создана</th>
                </tr>
              </thead>
              <tbody>
                {list?.map((c: any) => (
                  <tr key={c.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                    <td className="p-3">
                      <button onClick={() => { if (confirm("Удалить?")) remove.mutate({ id: c.id }); }} className="text-gray-400 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                    </td>
                    <td className="p-3 text-gray-800 text-sm font-medium">{c.name}</td>
                    <td className="p-3 text-gray-500 text-sm font-mono">{c.slug}</td>
                    <td className="p-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${c.isActive === "active" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>{c.isActive === "active" ? "Активна" : "Приостановлена"}</span>
                    </td>
                    <td className="p-3 text-gray-500 text-xs">{c.createdAt ? new Date(c.createdAt).toLocaleDateString("ru-RU") : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  WIDGETS VIEW
// ═══════════════════════════════════════════
function WidgetsView() {
  const utils = trpc.useUtils();
  const { data: companiesList, isLoading } = trpc.admin.listCompanies.useQuery();
  const generateKey = trpc.admin.generateApiKey.useMutation({
    onSuccess: () => { utils.admin.listCompanies.invalidate(); alert("API ключ сгенерирован!"); },
  });
  const updateDomains = trpc.admin.updateDomains.useMutation({
    onSuccess: () => utils.admin.listCompanies.invalidate(),
  });

  const [selectedCompany, setSelectedCompany] = useState<number | null>(null);
  const [domainInput, setDomainInput] = useState("");
  const [copied, setCopied] = useState(false);

  const selected = companiesList?.find((c: any) => c.id === selectedCompany);
  const domains: string[] = selected?.allowedDomains ? (typeof selected.allowedDomains === "string" ? JSON.parse(selected.allowedDomains) : selected.allowedDomains) || [] : [];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200"><h2 className="text-gray-800 text-lg font-semibold">Компании</h2></div>
        <div className="p-4">
          {isLoading ? (
            <div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>
          ) : (
            <div className="divide-y divide-gray-100">
              {companiesList?.map((c: any) => (
                <button key={c.id} onClick={() => { setSelectedCompany(c.id); setDomainInput(""); }} className={`w-full text-left p-4 transition-colors ${selectedCompany === c.id ? "bg-blue-50 border-l-2 border-l-blue-500" : "hover:bg-gray-50 border-l-2 border-transparent"}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-gray-800 text-sm font-medium">{c.name}</span>
                      <span className="text-gray-400 text-xs ml-2">{c.slug}</span>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${c.apiKey ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>{c.apiKey ? "Активен" : "Нет ключа"}</span>
                  </div>
                  {c.apiKey && <p className="text-gray-400 text-xs mt-1 font-mono">{c.apiKey.substring(0, 20)}...</p>}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div>
        {selected ? (
          <div className="space-y-4">
            <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
              <h3 className="text-gray-800 font-medium text-sm mb-4 flex items-center gap-2"><Key className="w-4 h-4 text-blue-600" /> API Ключ</h3>
              {selected.apiKey ? (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <code className="flex-1 bg-gray-50 border border-gray-200 rounded-md px-3 py-2 text-blue-600 text-xs font-mono break-all">{selected.apiKey}</code>
                    <button onClick={() => handleCopy(selected.apiKey)} className="p-2 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors" title="Копировать"><Copy className="w-4 h-4 text-gray-500" /></button>
                  </div>
                  {copied && <p className="text-green-600 text-xs mb-2">Скопировано!</p>}
                  <button onClick={() => selected.id && generateKey.mutate({ companyId: selected.id })} className="flex items-center gap-2 text-gray-500 text-xs hover:text-blue-600 transition-colors"><RefreshCw className="w-3 h-3" /> Перегенерировать</button>
                </div>
              ) : (
                <div>
                  <p className="text-gray-500 text-sm mb-3">API ключ ещё не сгенерирован</p>
                  <button onClick={() => selected.id && generateKey.mutate({ companyId: selected.id })} className="bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition-colors">Сгенерировать ключ</button>
                </div>
              )}
            </div>

            <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
              <h3 className="text-gray-800 font-medium text-sm mb-4 flex items-center gap-2"><Globe className="w-4 h-4 text-blue-600" /> Разрешённые домены</h3>
              <div className="space-y-2 mb-4">
                {domains.length === 0 ? <p className="text-gray-400 text-sm">Домены не указаны</p> : domains.map((d: string, i: number) => (
                  <div key={i} className="flex items-center justify-between bg-gray-50 rounded-md px-3 py-2">
                    <span className="text-gray-700 text-sm">{d}</span>
                    <button onClick={() => { const newDomains = domains.filter((_: string, idx: number) => idx !== i); selected.id && updateDomains.mutate({ companyId: selected.id, domains: newDomains }); }} className="text-gray-400 hover:text-red-500 transition-colors"><X className="w-3 h-3" /></button>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <input type="text" value={domainInput} onChange={(e) => setDomainInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && domainInput.trim()) { const newDomains = [...domains, domainInput.trim().toLowerCase()]; selected.id && updateDomains.mutate({ companyId: selected.id, domains: newDomains }); setDomainInput(""); } }} placeholder="example.com" className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500" />
                <button onClick={() => { if (domainInput.trim()) { const newDomains = [...domains, domainInput.trim().toLowerCase()]; selected.id && updateDomains.mutate({ companyId: selected.id, domains: newDomains }); setDomainInput(""); } }} className="bg-blue-600 text-white px-3 py-2 rounded-md text-sm hover:bg-blue-700 transition-colors"><Plus className="w-4 h-4" /></button>
              </div>
            </div>

            {selected.apiKey && (
              <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
                <h3 className="text-gray-800 font-medium text-sm mb-4 flex items-center gap-2"><Code className="w-4 h-4 text-blue-600" /> Код для встраивания</h3>
                <p className="text-gray-500 text-xs mb-3">Вставьте этот код на сайт компании</p>
                <pre className="bg-gray-50 border border-gray-200 rounded-md p-3 text-xs text-gray-600 overflow-auto font-mono">{`<script src="${window.location.origin}/widget.js" data-api-key="${selected.apiKey}"></script>\n<div id="motornaya-widget"></div>`}</pre>
                <button onClick={() => handleCopy(`<script src="${window.location.origin}/widget.js" data-api-key="${selected.apiKey}"></script>\n<div id="motornaya-widget"></div>`)} className="mt-3 flex items-center gap-2 text-gray-500 text-xs hover:text-blue-600 transition-colors"><Copy className="w-3 h-3" /> Копировать код</button>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-8 text-center">
            <Globe className="w-10 h-10 mx-auto mb-3 text-gray-300" />
            <p className="text-gray-400 text-sm">Выберите компанию слева</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  CAR CREATE FORM (placeholder)
// ═══════════════════════════════════════════
function CarCreateForm(props: { onBack: () => void }) {
  const { onBack } = props;
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-gray-500 hover:text-gray-700 flex items-center gap-1 text-sm"><ChevronRight className="w-4 h-4 rotate-180" /> Назад</button>
          <h2 className="text-gray-800 text-xl font-semibold">Добавить автомобиль</h2>
        </div>
      </div>
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-12 text-center">
        <p className="text-gray-400">В разработке — используйте импорт из каталога</p>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  IMPORT / EXPORT VIEW
// ═══════════════════════════════════════════
function ImportExportView() {
  const utils = trpc.useUtils();
  const [file, setFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [makeFilter, setMakeFilter] = useState("");
  const [batchFilter, setBatchFilter] = useState("");

  const importMutation = trpc.excel.import.useMutation({
    onSuccess: (data) => { setResult(data); setImporting(false); utils.excel.list.invalidate(); utils.excel.batches.invalidate(); },
    onError: (err) => { setResult({ error: err.message }); setImporting(false); },
  });

  const { data: batches } = trpc.excel.batches.useQuery();
  const { data: listData } = trpc.excel.list.useQuery(
    { make: makeFilter || undefined, batch: batchFilter || undefined, limit: 50 },
    { enabled: !!batchFilter || !!makeFilter }
  );

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) setFile(f);
  };

  const handleImport = async () => {
    if (!file) return;
    setImporting(true);
    setResult(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = (e.target?.result as string)?.split(",")[1];
      if (base64) importMutation.mutate({ fileBase64: base64, batchName: file.name.replace(/\\.xlsx?$/i, "") });
    };
    reader.readAsDataURL(file);
  };

  const [exporting, setExporting] = useState(false);
  const [exportResult, setExportResult] = useState<{ count: number; filename: string } | null>(null);

  const handleExport = async () => {
    setExporting(true);
    setExportResult(null);
    try {
      const res = await utils.excel.export.fetch({ make: makeFilter || undefined, batch: batchFilter || undefined });
      if (res?.data) {
        const link = document.createElement("a");
        link.href = `data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,${res.data}`;
        link.download = res.filename;
        link.click();
        setExportResult({ count: res.count, filename: res.filename });
      } else {
        setExportResult({ count: 0, filename: "" });
      }
    } catch (e: any) {
      setExportResult({ count: -1, filename: e.message || "Ошибка экспорта" });
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Import Card */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200"><h2 className="text-gray-800 text-lg font-semibold flex items-center gap-2"><FileUp className="w-5 h-5 text-blue-600" />Импорт Excel</h2></div>
        <div className="p-4 space-y-4">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
            <input type="file" accept=".xlsx,.xls" onChange={handleFileChange} className="hidden" id="excel-file" />
            <label htmlFor="excel-file" className="cursor-pointer">
              <FileUp className="w-10 h-10 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-600 text-sm">{file ? file.name : "Нажмите чтобы выбрать файл Excel"}</p>
              <p className="text-gray-400 text-xs mt-1">Поддерживаются .xlsx, .xls</p>
            </label>
          </div>
          <button onClick={handleImport} disabled={!file || importing} className="bg-blue-600 text-white px-6 py-2.5 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center gap-2">
            {importing ? <><RefreshCw className="w-4 h-4 animate-spin" />Импорт...</> : <><FileUp className="w-4 h-4" />Импортировать</>}
          </button>
          {result && (
            <div className={`p-3 rounded-lg text-sm ${result.error ? "bg-red-50 text-red-700 border border-red-200" : "bg-green-50 text-green-700 border border-green-200"}`}>
              {result.error ? `Ошибка: ${result.error}` : `Импортировано: ${result.inserted} из ${result.total} строк (пропущено: ${result.skipped}, батч: ${result.batch})`}
            </div>
          )}
        </div>
      </div>

      {/* Export Card */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200"><h2 className="text-gray-800 text-lg font-semibold flex items-center gap-2"><FileDown className="w-5 h-5 text-green-600" />Экспорт Excel</h2></div>
        <div className="p-4 space-y-4">
          <div className="flex gap-2 flex-wrap">
            <input type="text" value={makeFilter} onChange={(e) => setMakeFilter(e.target.value)} placeholder="Фильтр по марке..." className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 w-48" />
            <select value={batchFilter} onChange={(e) => setBatchFilter(e.target.value)} className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 w-56">
              <option value="">Все батчи</option>
              {batches?.map((b: any) => <option key={b.batch} value={b.batch}>{b.batch} ({b.count} записей)</option>)}
            </select>
          </div>
          <button onClick={handleExport} disabled={exporting} className="bg-green-600 text-white px-6 py-2.5 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors flex items-center gap-2 disabled:opacity-50">
            {exporting ? <><RefreshCw className="w-4 h-4 animate-spin" />Выгрузка...</> : <><FileDown className="w-4 h-4" />Экспортировать в Excel</>}
          </button>
          {exportResult && (
            <div className={`p-3 rounded-lg text-sm ${exportResult.count < 0 ? "bg-red-50 text-red-700 border border-red-200" : exportResult.count === 0 ? "bg-amber-50 text-amber-700 border border-amber-200" : "bg-green-50 text-green-700 border border-green-200"}`}>
              {exportResult.count < 0 ? `Ошибка: ${exportResult.filename}` : exportResult.count === 0 ? "Нет данных для экспорта (таблица carFluidSpecs пуста)" : `Выгружено: ${exportResult.count} записей`}
            </div>
          )}
        </div>
      </div>

      {/* Data Preview */}
      {listData && listData.items.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="p-4 border-b border-gray-200"><h2 className="text-gray-800 text-lg font-semibold">Просмотр данных ({listData.total} записей)</h2></div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead><tr className="border-b border-gray-200 bg-gray-50">
                <th className="p-2 text-left text-gray-500">Марка</th><th className="p-2 text-left text-gray-500">Модель</th><th className="p-2 text-left text-gray-500">Модификация</th>
                <th className="p-2 text-left text-gray-500">ДВС</th><th className="p-2 text-left text-gray-500">Объем</th><th className="p-2 text-left text-gray-500">SAE</th>
                <th className="p-2 text-left text-gray-500">КПП</th><th className="p-2 text-left text-gray-500">Охлаждение</th><th className="p-2 text-left text-gray-500">Тормоза</th>
              </tr></thead>
              <tbody>{listData.items.map((item: any) => (
                <tr key={item.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="p-2 text-gray-800 font-medium">{item.make}</td><td className="p-2 text-gray-700">{item.model}</td><td className="p-2 text-gray-600">{item.modification || "—"}</td>
                  <td className="p-2 text-gray-600">{item.engineCode || "—"}</td><td className="p-2 text-gray-600">{item.engineFillVolume || "—"}</td><td className="p-2 text-gray-600">{item.prefOilSae || "—"}</td>
                  <td className="p-2 text-gray-600">{item.transmissionType || "—"}</td><td className="p-2 text-gray-600">{item.coolantType || "—"}</td><td className="p-2 text-gray-600">{item.brakeFluidType || "—"}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════
//  AI AGENTS VIEW
// ═══════════════════════════════════════════
// ═══════════════════════════════════════════
//  AI DATA VIEWER — check AI results per car
// ═══════════════════════════════════════════
const AI_DATA_FIELDS = [
  { section: "Моторное масло", fields: [
    { key: "prefOilSae", label: "SAE" },
    { key: "prefOilApi", label: "API" },
    { key: "prefOilAcea", label: "ACEA" },
    { key: "prefOilOe", label: "OEM" },
    { key: "altOilViscosities", label: "Альт. вязкости" },
    { key: "altOilApi", label: "Альт. API" },
    { key: "altOilAcea", label: "Альт. ACEA" },
    { key: "altOilOe", label: "Альт. OEM" },
    { key: "engineFillVolume", label: "Объём масла" },
    { key: "engineReplaceInterval", label: "Интервал замены" },
  ]},
  { section: "КПП", fields: [
    { key: "transmissionType", label: "Тип КПП" },
    { key: "transmissionGears", label: "Передачи" },
    { key: "transmissionCode", label: "Код КПП" },
    { key: "transmissionFillVolume", label: "Объём масла КПП" },
    { key: "transmissionPrefOil", label: "Масло КПП" },
    { key: "transmissionAltOil", label: "Альт. масло КПП" },
    { key: "transmissionReplaceInterval", label: "Интервал КПП" },
  ]},
  { section: "Дифференциалы", fields: [
    { key: "transferCaseCode", label: "Код РКП" },
    { key: "transferCaseFillVolume", label: "Объём РКП" },
    { key: "transferCaseOil", label: "Масло РКП" },
    { key: "frontDiffCode", label: "Код перед. дифф." },
    { key: "frontDiffFillVolume", label: "Объём перед. дифф." },
    { key: "frontDiffOil", label: "Масло перед. дифф." },
    { key: "rearDiffCode", label: "Код задн. дифф." },
    { key: "rearDiffFillVolume", label: "Объём задн. дифф." },
    { key: "rearDiffOil", label: "Масло задн. дифф." },
  ]},
  { section: "Жидкости", fields: [
    { key: "coolantFillVolume", label: "Объём антифриза" },
    { key: "coolantType", label: "Тип антифриза" },
    { key: "coolantInterval", label: "Интервал антифриза" },
    { key: "brakeFluidVolume", label: "Объём тормозной" },
    { key: "brakeFluidType", label: "Тип тормозной" },
    { key: "brakeFluidInterval", label: "Интервал тормозной" },
    { key: "psFluidVolume", label: "Объём ГУР" },
    { key: "psFluidType", label: "Тип ГУР" },
    { key: "suspFluidVolume", label: "Объём подвески" },
    { key: "suspFluidType", label: "Тип подвески" },
    { key: "adblueVolume", label: "Объём AdBlue" },
    { key: "adblueType", label: "Тип AdBlue" },
  ]},
  { section: "Фильтры", fields: [
    { key: "oilFilter", label: "Масляный фильтр" },
    { key: "airFilter", label: "Воздушный фильтр" },
    { key: "cabinFilter", label: "Салонный фильтр" },
    { key: "fuelFilter", label: "Топливный фильтр" },
    { key: "transmissionFilter", label: "Фильтр АКПП" },
  ]},
  { section: "Общие", fields: [
    { key: "vehicleType", label: "Тип ТС" },
    { key: "make", label: "Марка" },
    { key: "model", label: "Модель" },
    { key: "modification", label: "Модификация" },
    { key: "yearFrom", label: "Год от" },
    { key: "yearTo", label: "Год до" },
    { key: "engineCode", label: "Код двигателя" },
    { key: "engineName", label: "Название двигателя" },
    { key: "engineVolume", label: "Объём двигателя" },
    { key: "horsePower", label: "Мощность" },
  ]},
];

function AIDataViewer() {
  const [viewerMake, setViewerMake] = useState("");
  const [viewerModel, setViewerModel] = useState("");
  const { data: allMakes } = trpc.cars.getMakes.useQuery();
  const { data: modelsForMake } = trpc.cars.getModels.useQuery(
    { make: viewerMake },
    { enabled: !!viewerMake }
  );
  const { data: viewerData } = trpc.excel.getByCar.useQuery(
    { make: viewerMake, model: viewerModel },
    { enabled: !!viewerMake && !!viewerModel }
  );

  const filledCount = viewerData
    ? AI_DATA_FIELDS.reduce((total, section) =>
        total + section.fields.filter((f) => viewerData[f.key] && String(viewerData[f.key]).trim() !== "").length, 0)
    : 0;
  const totalFields = AI_DATA_FIELDS.reduce((t, s) => t + s.fields.length, 0);
  const fillPercent = Math.round((filledCount / totalFields) * 100);

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between">
        <h2 className="text-gray-800 text-lg font-semibold flex items-center gap-2">
          <Eye className="w-5 h-5 text-blue-600" />
          Проверка данных ИИ
        </h2>
        {viewerData && (
          <span className={`text-xs px-2 py-1 rounded-full font-medium ${fillPercent >= 80 ? "bg-green-100 text-green-700" : fillPercent >= 50 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"}`}>
            {fillPercent}% ({filledCount}/{totalFields})
          </span>
        )}
      </div>

      <div className="p-4">
        {/* Filters */}
        <div className="flex gap-2 flex-wrap mb-4">
          <div className="relative">
            <select
              value={viewerMake}
              onChange={(e) => { setViewerMake(e.target.value); setViewerModel(""); }}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 w-44 bg-white"
            >
              <option value="">Все марки</option>
              {allMakes?.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          <div className="relative">
            <select
              value={viewerModel}
              onChange={(e) => setViewerModel(e.target.value)}
              disabled={!viewerMake}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 w-44 bg-white disabled:bg-gray-100"
            >
              <option value="">Все модели</option>
              {modelsForMake?.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
        </div>

        {/* Progress bar */}
        {viewerData && (
          <div className="mb-4">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className={`h-2 rounded-full ${fillPercent >= 80 ? "bg-green-500" : fillPercent >= 50 ? "bg-amber-500" : "bg-red-500"}`}
                style={{ width: `${fillPercent}%` }}
              />
            </div>
          </div>
        )}

        {/* Data sections */}
        {!viewerData ? (
          <div className="text-center py-8 text-gray-400 text-sm">
            Выберите марку и модель для просмотра данных ИИ
          </div>
        ) : (
          <div className="space-y-4">
            {AI_DATA_FIELDS.map((section) => {
              const sectionFilled = section.fields.filter((f) => viewerData[f.key] && String(viewerData[f.key]).trim() !== "").length;
              const sectionTotal = section.fields.length;
              return (
                <div key={section.section} className="border border-gray-100 rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-3 py-2 flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-gray-700">{section.section}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${sectionFilled === sectionTotal ? "bg-green-100 text-green-700" : sectionFilled > 0 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"}`}>
                      {sectionFilled}/{sectionTotal}
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 p-3">
                    {section.fields.map((f) => (
                      <div key={f.key} className={`flex items-center justify-between text-xs px-3 py-2 rounded ${viewerData[f.key] && String(viewerData[f.key]).trim() !== "" ? "bg-green-50 border border-green-100" : "bg-gray-50 border border-gray-100"}`}>
                        <span className="text-gray-500">{f.label}</span>
                        <span className={`font-medium ${viewerData[f.key] && String(viewerData[f.key]).trim() !== "" ? "text-gray-800" : "text-gray-300"}`}>
                          {viewerData[f.key] && String(viewerData[f.key]).trim() !== "" ? String(viewerData[f.key]) : "—"}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// 5 AI AGENTS VIEW
const AGENT_COLORS: Record<string, { bg: string; text: string; border: string; light: string }> = {
  "catalog-parser": { bg: "bg-blue-500", text: "text-blue-700", border: "border-blue-200", light: "bg-blue-50" },
  "oil-researcher": { bg: "bg-amber-500", text: "text-amber-700", border: "border-amber-200", light: "bg-amber-50" },
  "transmission-researcher": { bg: "bg-emerald-500", text: "text-emerald-700", border: "border-emerald-200", light: "bg-emerald-50" },
  "fluids-researcher": { bg: "bg-cyan-500", text: "text-cyan-700", border: "border-cyan-200", light: "bg-cyan-50" },
  "filters-researcher": { bg: "bg-rose-500", text: "text-rose-700", border: "border-rose-200", light: "bg-rose-50" },
  "manual-finder": { bg: "bg-violet-500", text: "text-violet-700", border: "border-violet-200", light: "bg-violet-50" },
};

function AiAgentsView() {
  const utils = trpc.useUtils();
  const { data: agents, isLoading } = trpc.agents.list.useQuery();
  const { data: tasks } = trpc.agents.tasks.useQuery();
  const runBySlug = trpc.agents.runBySlug.useMutation({
    onSuccess: () => { utils.agents.tasks.invalidate(); utils.agents.list.invalidate(); utils.excel.list.invalidate(); },
    onError: (err) => alert(err.message),
  });
  const updateStatus = trpc.agents.update.useMutation({
    onSuccess: () => utils.agents.list.invalidate(),
  });
  const [forms, setForms] = useState<Record<string, { make: string; model: string; engine: string; year: string }>>({});

  // Batch settings
  const [batchLimit, setBatchLimit] = useState("10");
  const [batchMake, setBatchMake] = useState("");
  const [batchDelay, setBatchDelay] = useState("2");
  const [batchAuto, setBatchAuto] = useState(false);
  const [batchAll, setBatchAll] = useState(false);

  // Live batch progress
  const [batchQueue, setBatchQueue] = useState<{
    make: string;
    model: string;
    status: "pending" | "running" | "done" | "error";
    error?: string;
    filledFields?: string[];
    tokensUsed?: { input: number; output: number };
    recordId?: number;
  }[]>([]);
  const [batchRunning, setBatchRunning] = useState(false);
  const [batchTotalProcessed, setBatchTotalProcessed] = useState(0);
  const [batchCurrentBatch, setBatchCurrentBatch] = useState(0);
  const [totalTokens, setTotalTokens] = useState({ input: 0, output: 0 });
  const fillSingle = trpc.excel.fillWithAI.useMutation();
  const batchAbortRef = { current: false };

  const runBatchWithProgress = async () => {
    if (batchRunning) return;
    setBatchQueue([]);
    setBatchRunning(true);
    setBatchTotalProcessed(0);
    setBatchCurrentBatch(0);
    batchAbortRef.current = false;

    const limit = batchAll ? 100 : (parseInt(batchLimit) || 10);
    let offset = 0;
    let totalProcessed = 0;
    let batchNum = 0;

    try {
      while (!batchAbortRef.current) {
        batchNum++;
        setBatchCurrentBatch(batchNum);

        // Fetch queue
        let res: any[] = [];
        try {
          res = await utils.agents.missingData.fetch({
            agentSlug: "oil-researcher",
            make: batchMake || undefined,
            limit,
          });
        } catch (fetchErr: any) {
          alert("Ошибка загрузки очереди: " + (fetchErr.data?.message || fetchErr.message));
          setBatchRunning(false);
          return;
        }

        if (!res || res.length === 0) {
          if (totalProcessed === 0) {
            alert("Нет авто для заполнения — все уже заполнены!");
          } else {
            alert(`Готово! Обработано ${totalProcessed} авто за ${batchNum} циклов.`);
          }
          break;
        }

        const queue = res.map((c: any) => ({ make: c.make, model: c.model, status: "pending" as const }));
        setBatchQueue(queue);

        for (let i = 0; i < queue.length; i++) {
          if (batchAbortRef.current) break;
          setBatchQueue((prev) => prev.map((item, idx) => idx === i ? { ...item, status: "running" } : item));
          try {
            const fillResult = await fillSingle.mutateAsync({ make: queue[i].make, model: queue[i].model });
            setBatchQueue((prev) => prev.map((item, idx) => idx === i ? {
              ...item,
              status: "done",
              filledFields: fillResult.filledFields,
              tokensUsed: fillResult.tokensUsed,
              recordId: fillResult.recordId,
            } : item));
            totalProcessed++;
            setBatchTotalProcessed(totalProcessed);
            // Accumulate tokens
            if (fillResult.tokensUsed) {
              setTotalTokens((t) => ({
                input: t.input + (fillResult.tokensUsed?.input || 0),
                output: t.output + (fillResult.tokensUsed?.output || 0),
              }));
            }
          } catch (e: any) {
            const errMsg = e.data?.message || e.message || "Unknown error";
            setBatchQueue((prev) => prev.map((item, idx) => idx === i ? { ...item, status: "error", error: errMsg } : item));
          }
          // Rate limit between requests
          const delayMs = parseInt(batchDelay) * 1000;
          if (i < queue.length - 1 && !batchAbortRef.current) {
            await new Promise((r) => setTimeout(r, delayMs));
          }
        }

        if (!batchAuto || batchAbortRef.current) {
          if (res.length < limit) {
            alert(`Готово! Обработано ${totalProcessed} авто.`);
          } else {
            alert(`Цикл ${batchNum} завершен (${totalProcessed} всего). Нажмите снова для продолжения.`);
          }
          break;
        }

        // Auto-continue: if we got a full batch, there might be more
        if (res.length < limit) {
          alert(`Готово! Обработано ${totalProcessed} авто за ${batchNum} циклов.`);
          break;
        }

        offset += limit;
      }

      utils.excel.list.invalidate();
      utils.agents.list.invalidate();
    } catch (e: any) {
      alert("Ошибка: " + e.message);
    } finally {
      setBatchRunning(false);
    }
  };

  const stopBatch = () => {
    batchAbortRef.current = true;
    setBatchRunning(false);
  };

  const setForm = (slug: string, field: string, value: string) => {
    setForms((prev) => ({ ...prev, [slug]: { ...prev[slug], [field]: value } }));
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {agents?.map((agent: any) => {
          const c = AGENT_COLORS[agent.slug] || AGENT_COLORS["catalog-parser"];
          return (
            <div key={agent.id} className={`rounded-lg border border-gray-200 shadow-sm p-3 ${c.light}`}>
              <p className={`text-xs ${c.text} opacity-80`}>{agent.name}</p>
              <div className="flex items-center gap-2 mt-1">
                <span className={`w-2 h-2 rounded-full ${agent.isActive === "active" ? "bg-green-500" : agent.isActive === "error" ? "bg-red-500" : "bg-gray-400"}`} />
                <p className="text-lg font-bold text-gray-800">{agent.runsSuccess || 0}/{agent.runsTotal || 0}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Batch Fill All */}
      <div className="bg-white rounded-lg border border-purple-200 shadow-sm">
        <div className="p-4 border-b border-purple-100 flex items-center justify-between bg-purple-50">
          <h2 className="text-gray-800 text-lg font-semibold flex items-center gap-2"><RotateCw className="w-5 h-5 text-purple-600" />Массовое заполнение ИИ</h2>
          <span className="text-purple-600 text-xs bg-purple-100 px-2 py-1 rounded-full">{batchRunning ? `Цикл ${batchCurrentBatch} | Всего: ${batchTotalProcessed}` : "Готов"}</span>
        </div>
        <div className="p-4 space-y-3">
          <p className="text-gray-500 text-xs">ИИ заполнит данные для авто подряд. Пропускает уже заполненные. Настройте параметры ниже.</p>

          {/* Settings row */}
          <div className="flex gap-2 flex-wrap items-center bg-gray-50 p-3 rounded-lg">
            <span className="text-xs font-medium text-purple-700 bg-purple-100 px-2 py-1 rounded">ВСЕ ДАННЫЕ: масло + КПП + дифф + жидкости + фильтры</span>
            <input type="text" value={batchMake} onChange={(e) => setBatchMake(e.target.value)} placeholder="Марка (пусто = все)" className="border border-gray-300 rounded-md px-2 py-1.5 text-sm text-gray-800 w-36" />
            <input type="number" min="1" max="100" value={batchLimit} onChange={(e) => setBatchLimit(e.target.value)} disabled={batchAll} className="border border-gray-300 rounded-md px-2 py-1.5 text-sm text-gray-800 w-20 disabled:bg-gray-100" />
            <label className="flex items-center gap-1 text-xs text-gray-600 cursor-pointer">
              <input type="checkbox" checked={batchAll} onChange={(e) => setBatchAll(e.target.checked)} className="rounded" />
              Все авто
            </label>
            <select value={batchDelay} onChange={(e) => setBatchDelay(e.target.value)} className="border border-gray-300 rounded-md px-2 py-1.5 text-sm text-gray-800 w-24">
              <option value="1">1 сек</option>
              <option value="2">2 сек</option>
              <option value="3">3 сек</option>
              <option value="5">5 сек</option>
            </select>
            <label className="flex items-center gap-1 text-xs text-gray-600 cursor-pointer">
              <input type="checkbox" checked={batchAuto} onChange={(e) => setBatchAuto(e.target.checked)} className="rounded" />
              Авто-продолжение
            </label>
          </div>

          {/* Tokens */}
          {batchTotalProcessed > 0 && (
            <div className="flex gap-4 text-xs text-gray-500">
              <span>Токены: {totalTokens.input.toLocaleString()} in + {totalTokens.output.toLocaleString()} out = {(totalTokens.input + totalTokens.output).toLocaleString()} всего</span>
              <span>~${((totalTokens.input + totalTokens.output) * 0.000001).toFixed(3)} (Haiku ~$1/M токенов)</span>
            </div>
          )}

          {/* Buttons */}
          <div className="flex gap-2">
            <button onClick={runBatchWithProgress} disabled={batchRunning} className="bg-purple-600 text-white px-6 py-2 rounded-lg text-sm font-medium hover:bg-purple-700 disabled:opacity-50 flex items-center gap-2">
              {batchRunning && batchQueue.length === 0 ? <><RefreshCw className="w-4 h-4 animate-spin" />Загрузка...</> : batchRunning ? <><RefreshCw className="w-4 h-4 animate-spin" />{batchTotalProcessed} обработано</> : <><RotateCw className="w-4 h-4" />{batchAll ? "Запустить по ВСЕМ авто" : `Запустить на ${batchLimit} авто`}</>}
            </button>
            {batchRunning && (
              <button onClick={stopBatch} className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 flex items-center gap-2">
                <X className="w-4 h-4" />Стоп
              </button>
            )}
          </div>
        </div>
        {/* Live progress */}
        {batchQueue.length > 0 && (
          <div className="px-4 pb-4 space-y-3">
            <div className="flex items-center gap-3 text-sm">
              <span className="text-green-700 font-medium">{batchQueue.filter((q) => q.status === "done").length} готово</span>
              <span className="text-purple-700 font-medium">{batchQueue.filter((q) => q.status === "running").length} в работе</span>
              <span className="text-gray-500">{batchQueue.filter((q) => q.status === "pending").length} в очереди</span>
              <span className="text-red-500">{batchQueue.filter((q) => q.status === "error").length} ошибок</span>
              <div className="flex-1 bg-gray-200 rounded-full h-2 ml-2">
                <div className="bg-purple-500 h-2 rounded-full transition-all" style={{ width: `${(batchQueue.filter((q) => q.status === "done").length / batchQueue.length) * 100}%` }} />
              </div>
            </div>
            {/* Results table */}
            <div className="overflow-auto border border-gray-200 rounded-lg max-h-72">
              <table className="w-full text-[11px]">
                <thead className="bg-gray-50 sticky top-0 z-10">
                  <tr>
                    <th className="text-left px-2 py-1.5 text-gray-500 font-medium w-40">Авто</th>
                    <th className="text-left px-2 py-1.5 text-gray-500 font-medium">SAE</th>
                    <th className="text-left px-2 py-1.5 text-gray-500 font-medium">API</th>
                    <th className="text-left px-2 py-1.5 text-gray-500 font-medium">КПП</th>
                    <th className="text-left px-2 py-1.5 text-gray-500 font-medium">Антифриз</th>
                    <th className="text-left px-2 py-1.5 text-gray-500 font-medium">Фильтр</th>
                    <th className="text-left px-2 py-1.5 text-gray-500 font-medium">Токены</th>
                    <th className="text-left px-2 py-1.5 text-gray-500 font-medium w-16">Статус</th>
                  </tr>
                </thead>
                <tbody>
                  {batchQueue.map((q, i) => (
                    <tr key={i} className={`border-t border-gray-100 ${q.status === "done" ? "bg-green-50/50" : q.status === "running" ? "bg-purple-50/50" : q.status === "error" ? "bg-red-50/50" : ""}`}>
                      <td className="px-2 py-1.5 font-medium text-gray-800 truncate max-w-[150px]">{q.make} {q.model}</td>
                      <td className="px-2 py-1.5 text-gray-600">{q.filledFields?.find((f) => f.includes("SAE")) || "—"}</td>
                      <td className="px-2 py-1.5 text-gray-600">{q.filledFields?.find((f) => f.includes("API")) || "—"}</td>
                      <td className="px-2 py-1.5 text-gray-600">{q.filledFields?.find((f) => f.includes("КПП")) ? "есть" : "—"}</td>
                      <td className="px-2 py-1.5 text-gray-600">{q.filledFields?.find((f) => f.includes("антифриз")) ? "есть" : "—"}</td>
                      <td className="px-2 py-1.5 text-gray-600">{q.filledFields?.find((f) => f.includes("Фильтр")) ? "есть" : "—"}</td>
                      <td className="px-2 py-1.5 text-gray-500">{q.tokensUsed ? `${q.tokensUsed.input || 0}+${q.tokensUsed.output || 0}` : "—"}</td>
                      <td className={`px-2 py-1.5 font-medium ${q.status === "done" ? "text-green-600" : q.status === "running" ? "text-purple-600" : q.status === "error" ? "text-red-600" : "text-gray-400"}`}>
                        {q.status === "done" ? `+${q.filledFields?.length || 0}` : q.status === "running" ? "..." : q.status === "error" ? (
                          <span className="text-red-500 truncate max-w-[80px] inline-block" title={q.error || "Unknown error"}>
                            {q.error ? (q.error.length > 20 ? q.error.substring(0, 20) + "..." : q.error) : "Err"}
                          </span>
                        ) : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* AI Data Viewer */}
      <AIDataViewer />

      {/* 5 Agent Cards */}
      {isLoading ? (
        <div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>
      ) : (
        <div className="space-y-4">
          {agents?.map((agent: any) => {
            const slug = agent.slug;
            const c = AGENT_COLORS[slug] || AGENT_COLORS["catalog-parser"];
            const form = forms[slug] || { make: "", model: "", engine: "", year: "" };
            const config = typeof agent.config === "string" ? JSON.parse(agent.config) : agent.config;
            const columns = config?.columns || [];
            const isRunning = runBySlug.isPending && runBySlug.variables?.slug === slug;

            return (
              <div key={agent.id} className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                <div className={`p-4 border-b border-gray-200 flex items-center justify-between ${c.light}`}>
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${c.bg} bg-opacity-20`}>
                      <Bot className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-gray-800 text-sm font-semibold">{agent.name}</h3>
                      <p className="text-gray-500 text-xs">{agent.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${agent.isActive === "active" ? "bg-green-100 text-green-700" : agent.isActive === "error" ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-500"}`}>
                      {agent.isActive === "active" ? "Активен" : agent.isActive === "error" ? "Ошибка" : "Пауза"}
                    </span>
                    <button onClick={() => updateStatus.mutate({ id: agent.id, isActive: agent.isActive === "active" ? "paused" : "active" })} className="p-1.5 bg-white rounded hover:bg-gray-100 transition-colors" title={agent.isActive === "active" ? "Пауза" : "Активировать"}>
                      {agent.isActive === "active" ? <Pause className="w-3.5 h-3.5 text-gray-500" /> : <Play className="w-3.5 h-3.5 text-green-600" />}
                    </button>
                  </div>
                </div>

                <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
                  <p className="text-gray-500 text-[10px] uppercase tracking-wider mb-1">Заполняемые поля ({columns.length}):</p>
                  <div className="flex flex-wrap gap-1">
                    {columns.map((col: any, i: number) => (
                      <span key={i} className={`text-[10px] px-1.5 py-0.5 rounded ${c.light} ${c.text} border ${c.border}`}>{col.label}</span>
                    ))}
                  </div>
                </div>

                <div className="p-4">
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 mb-3">
                    <input type="text" value={form.make} onChange={(e) => setForm(slug, "make", e.target.value)} placeholder="Марка" className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-gray-500" />
                    <input type="text" value={form.model} onChange={(e) => setForm(slug, "model", e.target.value)} placeholder="Модель" className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-gray-500" />
                    <input type="text" value={form.engine} onChange={(e) => setForm(slug, "engine", e.target.value)} placeholder="Двигатель" className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-gray-500" />
                    <input type="text" value={form.year} onChange={(e) => setForm(slug, "year", e.target.value)} placeholder="Год" className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-gray-500" />
                  </div>
                  <button
                    onClick={() => { if (form.make && form.model) runBySlug.mutate({ slug, payload: { make: form.make, model: form.model, engineCode: form.engine || undefined, year: form.year || undefined } }); }}
                    disabled={!form.make || !form.model || isRunning}
                    className="bg-gray-900 text-white px-5 py-2 rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors disabled:opacity-50 flex items-center gap-2"
                  >
                    {isRunning ? <><RefreshCw className="w-4 h-4 animate-spin" />Работаю...</> : <><Play className="w-4 h-4" />Запустить агента</>}
                  </button>
                </div>

                {agent.lastRunAt && (
                  <div className="px-4 py-2 bg-gray-50 border-t border-gray-200 flex gap-4 text-[10px] text-gray-400">
                    <span>Запусков: {agent.runsTotal || 0}</span>
                    <span>Успешно: {agent.runsSuccess || 0}</span>
                    <span>Ошибок: {agent.runsError || 0}</span>
                    <span>Записей: {agent.itemsProcessed || 0}</span>
                    <span className="ml-auto">Последний: {new Date(agent.lastRunAt).toLocaleString("ru-RU")}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Tasks */}
      {tasks && tasks.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="p-4 border-b border-gray-200"><h2 className="text-gray-800 text-lg font-semibold flex items-center gap-2"><Activity className="w-5 h-5 text-blue-600" />История задач</h2></div>
          <div className="divide-y divide-gray-100 max-h-64 overflow-auto">
            {tasks.slice(0, 30).map((task: any) => (
              <div key={task.id} className="p-3 flex items-center justify-between hover:bg-gray-50">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${task.status === "completed" ? "bg-green-500" : task.status === "running" ? "bg-blue-500 animate-pulse" : task.status === "failed" ? "bg-red-500" : "bg-gray-400"}`} />
                  <span className="text-gray-700 text-sm">Агент #{task.agentId}</span>
                  <span className="text-gray-400 text-xs">{task.status}</span>
                </div>
                <span className="text-gray-400 text-xs">{task.createdAt ? new Date(task.createdAt).toLocaleString("ru-RU") : "—"}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════
//  SETTINGS VIEW
// ═══════════════════════════════════════════
function SettingsView() {
  const utils = trpc.useUtils();
  const { data: settings, isLoading } = trpc.settings.list.useQuery();
  const { data: stats } = trpc.settings.stats.useQuery();
  const seedMutation = trpc.settings.seed.useMutation({ onSuccess: () => { utils.settings.list.invalidate(); utils.settings.stats.invalidate(); } });
  const setMutation = trpc.settings.set.useMutation({ onSuccess: () => { utils.settings.list.invalidate(); utils.settings.stats.invalidate(); } });
  const setManyMutation = trpc.settings.setMany.useMutation({ onSuccess: () => { utils.settings.list.invalidate(); utils.settings.stats.invalidate(); } });

  const [editValues, setEditValues] = useState<Record<string, string>>({});
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});
  const [savedKeys, setSavedKeys] = useState<Set<string>>(new Set());

  const handleSave = (key: string) => {
    const value = editValues[key];
    if (value !== undefined) {
      // Validate Anthropic key format
      if (key === "anthropic_api_key" && value && !value.startsWith("sk-ant")) {
        alert("Ключ Anthropic должен начинаться с \"sk-ant-api03-...\". Получите ключ на console.anthropic.com");
        return;
      }
      setMutation.mutate({ key, value }, {
        onSuccess: () => {
          setSavedKeys((prev) => new Set(prev).add(key));
          setTimeout(() => setSavedKeys((prev) => { const n = new Set(prev); n.delete(key); return n; }), 2000);
        },
      });
    }
  };

  const handleSaveAll = () => {
    const toSave = Object.entries(editValues).map(([key, value]) => ({ key, value }));
    if (toSave.length > 0) {
      setManyMutation.mutate({ settings: toSave });
    }
  };

  const grouped = settings?.reduce((acc: Record<string, any[]>, s: any) => {
    const cat = s.category || "general";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(s);
    return acc;
  }, {}) || {};

  const catLabels: Record<string, string> = {
    api_keys: "API Ключи",
    widget: "Виджет",
    system: "Система",
    general: "Общие",
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <p className="text-gray-500 text-xs">Всего настроек</p>
          <p className="text-gray-800 text-2xl font-bold">{stats?.total || 0}</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <p className="text-gray-500 text-xs">Заполнено</p>
          <p className="text-green-600 text-2xl font-bold">{stats?.filled || 0}</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <p className="text-gray-500 text-xs">Секретные</p>
          <p className="text-amber-600 text-2xl font-bold">{stats?.secrets || 0}</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <p className="text-gray-500 text-xs">Категорий</p>
          <p className="text-blue-600 text-2xl font-bold">{stats?.byCategory?.length || 0}</p>
        </div>
      </div>

      {/* API Key Status */}
      {settings && settings.length > 0 && (
        <ApiKeyStatus settings={settings} />
      )}

      {/* Seed */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4 flex items-center gap-3">
        <button onClick={() => seedMutation.mutate()} disabled={seedMutation.isPending} className="bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-800 disabled:opacity-50">
          {seedMutation.isPending ? "Загрузка..." : "Загрузить стандартные настройки"}
        </button>
        <span className="text-gray-400 text-xs">Создает все настройки по умолчанию (API ключи, виджет, система)</span>
        {seedMutation.data && (
          <span className="text-green-600 text-xs">Создано: {seedMutation.data.inserted}, обновлено: {seedMutation.data.updated}</span>
        )}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>
      ) : (
        <>
          {Object.entries(grouped).map(([cat, items]) => (
            <div key={cat} className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-gray-200 bg-gray-50">
                <h3 className="text-gray-800 text-sm font-semibold">{catLabels[cat] || cat}</h3>
              </div>
              {cat === "api_keys" && (
                <div className="p-4 bg-blue-50 border-b border-blue-100">
                  <p className="text-blue-800 text-xs font-medium mb-1">Как получить API-ключи:</p>
                  <ol className="text-blue-700 text-xs space-y-1 list-decimal list-inside">
                    <li>Перейдите на <a href="https://console.anthropic.com" target="_blank" rel="noopener noreferrer" className="underline hover:text-blue-900">console.anthropic.com</a> — зарегистрируйтесь</li>
                    <li>Пополните баланс (минимум $5) в разделе Billing</li>
                    <li>Создайте ключ (Create Key), скопируйте (начинается с sk-ant-api03-...)</li>
                    <li>Вставьте в поле ниже → Сохранить. Готово!</li>
                  </ol>
                </div>
              )}
              <div className="divide-y divide-gray-100">
                {items.map((s: any) => {
                  const isSecret = s.isSecret === "yes";
                  const showValue = !isSecret || showSecrets[s.key];
                  const currentValue = editValues[s.key] !== undefined ? editValues[s.key] : (s.value || "");
                  const displayValue = isSecret && !showSecrets[s.key] && currentValue
                    ? "••••••••••••••••"
                    : currentValue;

                  return (
                    <div key={s.key} className="p-4 flex items-start gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-gray-800 text-sm font-medium">{s.label || s.key}</p>
                          {isSecret && <span className="text-[10px] bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded">СЕКРЕТ</span>}
                          {savedKeys.has(s.key) && <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded">СОХРАНЕНО</span>}
                        </div>
                        {s.description && <p className="text-gray-400 text-xs mt-0.5">{s.description}</p>}
                        {/* Color palette for widget_primary_color */}
                        {s.key === "widget_primary_color" ? (
                          <>
                            <div className="flex items-center gap-2 mt-2">
                              <input
                                type="text"
                                value={displayValue}
                                onChange={(e) => setEditValues((prev) => ({ ...prev, [s.key]: e.target.value }))}
                                className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 font-mono"
                              />
                              <div className="w-8 h-8 rounded border border-gray-300 flex-shrink-0" style={{ backgroundColor: displayValue || "#d32f2f" }} />
                              <button
                                onClick={() => handleSave(s.key)}
                                disabled={editValues[s.key] === undefined || setMutation.isPending}
                                className="p-2 bg-blue-50 rounded hover:bg-blue-100 transition-colors disabled:opacity-50"
                                title="Сохранить"
                              >
                                <Save className="w-4 h-4 text-blue-600" />
                              </button>
                            </div>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {[
                                { name: "Красный", hex: "#d32f2f" },
                                { name: "Синий", hex: "#1976d2" },
                                { name: "Зелёный", hex: "#388e3c" },
                                { name: "Оранжевый", hex: "#f57c00" },
                                { name: "Фиолетовый", hex: "#7b1fa2" },
                                { name: "Чёрный", hex: "#212121" },
                                { name: "Бирюзовый", hex: "#00838f" },
                                { name: "Розовый", hex: "#c2185b" },
                              ].map((c) => (
                                <button
                                  key={c.hex}
                                  onClick={() => {
                                    setEditValues((prev) => ({ ...prev, [s.key]: c.hex }));
                                    setTimeout(() => handleSave(s.key), 100);
                                  }}
                                  className="flex items-center gap-1.5 px-2 py-1.5 rounded-full border border-gray-200 hover:border-gray-400 transition-colors text-xs"
                                  title={c.name}
                                >
                                  <span className="w-4 h-4 rounded-full border border-gray-300" style={{ backgroundColor: c.hex }} />
                                  <span className="text-gray-600">{c.name}</span>
                                </button>
                              ))}
                            </div>
                          </>
                        ) : (
                          <div className="flex items-center gap-2 mt-2">
                            <div className="flex-1">
                              <input
                                type={showValue ? "text" : "password"}
                                value={displayValue}
                                onChange={(e) => setEditValues((prev) => ({ ...prev, [s.key]: e.target.value }))}
                                placeholder={s.value ? "" : "Не задано"}
                                className={`w-full border rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 font-mono ${
                                  s.key === "anthropic_api_key" && currentValue && !currentValue.startsWith("sk-ant") && currentValue.length > 5
                                    ? "border-red-300 bg-red-50"
                                    : s.key === "anthropic_api_key" && currentValue.startsWith("sk-ant")
                                    ? "border-green-300 bg-green-50"
                                    : "border-gray-300"
                                }`}
                              />
                              {s.key === "anthropic_api_key" && currentValue && !currentValue.startsWith("sk-ant") && currentValue.length > 5 && (
                                <p className="text-red-500 text-[10px] mt-1">Ключ должен начинаться с "sk-ant-api03-..."</p>
                              )}
                              {s.key === "anthropic_api_key" && currentValue.startsWith("sk-ant") && (
                                <p className="text-green-600 text-[10px] mt-1">Формат ключа верный</p>
                              )}
                            </div>
                            {currentValue && (
                              <button
                                onClick={() => setEditValues((prev) => ({ ...prev, [s.key]: "" }))}
                                className="p-2 text-gray-400 hover:text-red-500"
                                title="Очистить"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            )}
                            {isSecret && (
                              <button
                                onClick={() => setShowSecrets((prev) => ({ ...prev, [s.key]: !prev[s.key] }))}
                                className="p-2 text-gray-400 hover:text-gray-600"
                                title={showSecrets[s.key] ? "Скрыть" : "Показать"}
                              >
                                {showSecrets[s.key] ? <Eye className="w-4 h-4" /> : <Eye className="w-4 h-4 opacity-50" />}
                              </button>
                            )}
                            <button
                              onClick={() => handleSave(s.key)}
                              disabled={editValues[s.key] === undefined || setMutation.isPending}
                              className="p-2 bg-blue-50 rounded hover:bg-blue-100 transition-colors disabled:opacity-50"
                              title="Сохранить"
                            >
                              <Save className="w-4 h-4 text-blue-600" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}

          {settings && settings.length > 0 && (
            <div className="flex justify-end">
              <button onClick={handleSaveAll} disabled={Object.keys(editValues).length === 0 || setManyMutation.isPending} className="bg-gray-900 text-white px-6 py-2.5 rounded-lg text-sm font-medium hover:bg-gray-800 disabled:opacity-50">
                {setManyMutation.isPending ? "Сохранение..." : `Сохранить все изменения (${Object.keys(editValues).length})`}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
