/**
 * AI Agent: Vehicle Data Researcher
 * Ищет технические характеристики автомобилей через AI и внешние источники
 * 
 * Возможности:
 * 1. Поиск объёмов масел, антифриза, тормозной жидкости по марке/модели/двигателю
 * 2. Поиск спецификаций (SAE, API, ACEA, OEM допуски)
 * 3. Поиск номеров фильтров
 * 4. Валидация данных
 * 
 * Использование:
 * npx tsx api/agents/researcher.ts --make="BMW" --model="X5" --engine="N55" --year=2015
 */

import { getDb } from "../queries/connection";
import { carFluidSpecs, aiTasks, aiAgents } from "@db/schema";
import { eq, sql, like, and } from "drizzle-orm";
import { env } from "../lib/env";

// ─── Types ───
interface ResearchPayload {
  make: string;
  model: string;
  engineCode?: string;
  year?: number;
  body?: string;
  modification?: string;
}

interface ResearchResult {
  vehicle: ResearchPayload;
  engine?: {
    oilVolume?: string;
    oilSae?: string;
    oilApi?: string;
    oilAcea?: string;
    oilOem?: string;
    replaceInterval?: string;
  };
  transmission?: {
    type?: string;
    code?: string;
    oilVolume?: string;
    oilSpec?: string;
    replaceInterval?: string;
  };
  cooling?: {
    coolantVolume?: string;
    coolantType?: string;
    replaceInterval?: string;
  };
  brakes?: {
    fluidVolume?: string;
    fluidType?: string;
    replaceInterval?: string;
  };
  differentials?: {
    front?: { volume?: string; oil?: string; };
    rear?: { volume?: string; oil?: string; };
  };
  filters?: {
    oil?: string;
    air?: string;
    cabin?: string;
    fuel?: string;
  };
  source: string;
  confidence: "high" | "medium" | "low";
}

// ─── AI-Powered Research via External API ───
async function aiResearch(payload: ResearchPayload): Promise<ResearchResult> {
  const { make, model, engineCode, year } = payload;

  // Build research query
  const query = `Find exact technical specifications for ${make} ${model}${year ? ` (${year})` : ""}${engineCode ? ` engine ${engineCode}` : ""}.

Return ONLY a valid JSON object in this exact format, no markdown, no explanation, no code blocks:

{"engine":{"oilVolume":"6.5","oilSae":"5W-30","oilApi":"SN Plus","oilAcea":"C3","oilOem":"VW 504.00/507.00","replaceInterval":"15000 km"},"transmission":{"type":"Automatic","code":"8HP-55","oilVolume":"8.0","oilSpec":"ZF LifeguardFluid 8","replaceInterval":"60000 km"},"cooling":{"coolantVolume":"10.0","coolantType":"G13","replaceInterval":"120000 km"},"brakes":{"fluidVolume":"1.0","fluidType":"DOT 4","replaceInterval":"40000 km"},"differentials":{"front":{"volume":"0.8","oil":"75W-90"},"rear":{"volume":"1.2","oil":"75W-90"}},"filters":{"oil":"HU 719/7 X","air":"C 30 130","cabin":"CU 30 001","fuel":"WK 820/17"}}

Rules:
- ALL values must be strings
- oilVolume in liters with dot decimal (e.g. "6.5")
- oilSae format like "5W-30" or "0W-20"
- Return ONLY the JSON, nothing else`;

  console.log("[AI Research] Query:", query.substring(0, 100) + "...");

  const result: ResearchResult = {
    vehicle: payload,
    source: "ai_research",
    confidence: "medium",
  };

  // Try AI API if configured
  if (env.anthropicApiKey) {
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": env.anthropicApiKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-3-haiku-20240307",
          max_tokens: 2000,
          messages: [{ role: "user", content: query }],
        }),
        signal: AbortSignal.timeout(30000),
      });

      if (response.ok) {
        const data = await response.json();
        const text = data.content?.[0]?.text || "";
        const parsed = parseAIResponse(text);
        Object.assign(result, parsed);
        result.source = "anthropic_claude";
        result.confidence = "high";
      }
    } catch (e: any) {
      console.error("[AI Research] Claude error:", e.message);
    }
  }

  // Fallback to OpenAI
  if (result.confidence !== "high" && env.openaiApiKey) {
    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${env.openaiApiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "You are an automotive technical specialist. Return data in JSON format only." },
            { role: "user", content: query },
          ],
          temperature: 0.1,
          max_tokens: 1500,
        }),
        signal: AbortSignal.timeout(30000),
      });

      if (response.ok) {
        const data = await response.json();
        const text = data.choices?.[0]?.message?.content || "";
        const parsed = parseAIResponse(text);
        Object.assign(result, parsed);
        result.source = "openai_gpt";
        result.confidence = "medium";
      }
    } catch (e: any) {
      console.error("[AI Research] OpenAI error:", e.message);
    }
  }

  return result;
}

// ─── Parse AI Response ───
function parseAIResponse(text: string): Partial<ResearchResult> {
  try {
    // Clean the text - remove markdown code blocks
    let cleanText = text.trim();
    // Remove ```json ... ``` or ``` ... ``` wrappers
    if (cleanText.startsWith("```")) {
      cleanText = cleanText.replace(/```[a-z]*\n?/, "").replace(/\n?```$/, "").trim();
    }
    // Extract JSON object
    const jsonMatch = cleanText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.log("[AI Research] No JSON found in response:", text.substring(0, 200));
      return {};
    }
    const data = JSON.parse(jsonMatch[0]);
    console.log("[AI Research] Parsed JSON keys:", Object.keys(data).join(", "));

    return {
      engine: data.engine || {
        oilVolume: data.oilVolume || data.engineOilVolume,
        oilSae: data.oilSae || data.engineOilSae,
        oilApi: data.oilApi || data.engineOilApi,
        oilAcea: data.oilAcea || data.engineOilAcea,
        oilOem: data.oilOem || data.engineOilOem,
        replaceInterval: data.oilInterval || data.engineReplaceInterval,
      },
      transmission: data.transmission || {
        type: data.transmissionType,
        code: data.transmissionCode,
        oilVolume: data.transmissionOilVolume,
        oilSpec: data.transmissionOilSpec,
        replaceInterval: data.transmissionInterval,
      },
      cooling: data.cooling || {
        coolantVolume: data.coolantVolume,
        coolantType: data.coolantType,
        replaceInterval: data.coolantInterval,
      },
      brakes: data.brakes || {
        fluidVolume: data.brakeFluidVolume,
        fluidType: data.brakeFluidType,
        replaceInterval: data.brakeFluidInterval,
      },
      differentials: data.differentials,
      filters: data.filters,
    };
  } catch (e) {
    console.log("[AI Research] Failed to parse AI response, attempting heuristic parse");
    return heuristicParse(text);
  }
}

// ─── Heuristic parsing from text ───
function heuristicParse(text: string): Partial<ResearchResult> {
  const result: Partial<ResearchResult> = {};
  const lower = text.toLowerCase();

  // Oil SAE
  const saeMatch = text.match(/(\dW-\d{2,3})/i);
  if (saeMatch) {
    result.engine = { ...result.engine, oilSae: saeMatch[1] };
  }

  // Oil volume
  const volMatch = text.match(/(\d+\.?\d*)\s*[лЛlL]/i);
  if (volMatch) {
    result.engine = { ...result.engine, oilVolume: volMatch[1] + " л" };
  }

  // API
  const apiMatch = text.match(/API\s+([A-Z0-9\/\s,]+)/i);
  if (apiMatch) {
    result.engine = { ...result.engine, oilApi: apiMatch[1].trim() };
  }

  // Coolant type
  if (lower.includes("g13")) {
    result.cooling = { ...result.cooling, coolantType: "G13" };
  } else if (lower.includes("g12")) {
    result.cooling = { ...result.cooling, coolantType: "G12+" };
  }

  return result;
}

// ─── Save research result to database ───
async function saveToDatabase(result: ResearchResult): Promise<number> {
  const db = getDb();
  const v = result.vehicle;

  const [inserted] = await db.insert(carFluidSpecs).values({
    vehicleType: "Легковой автомобиль",
    make: v.make,
    model: v.model,
    body: v.body || null,
    modification: v.modification || `${v.make} ${v.model} ${v.engineCode || ""}`.trim(),
    engineCode: v.engineCode || null,
    engineFillVolume: result.engine?.oilVolume || null,
    prefOilSae: result.engine?.oilSae || null,
    prefOilApi: result.engine?.oilApi || null,
    prefOilAcea: result.engine?.oilAcea || null,
    prefOilOe: result.engine?.oilOem || null,
    engineReplaceInterval: result.engine?.replaceInterval || null,
    transmissionType: result.transmission?.type || null,
    transmissionCode: result.transmission?.code || null,
    transmissionFillVolume: result.transmission?.oilVolume || null,
    transmissionPrefOil: result.transmission?.oilSpec || null,
    transmissionReplaceInterval: result.transmission?.replaceInterval || null,
    coolantFillVolume: result.cooling?.coolantVolume || null,
    coolantType: result.cooling?.coolantType || null,
    coolantInterval: result.cooling?.replaceInterval || null,
    brakeFluidVolume: result.brakes?.fluidVolume || null,
    brakeFluidType: result.brakes?.fluidType || null,
    brakeFluidInterval: result.brakes?.replaceInterval || null,
    frontDiffFillVolume: result.differentials?.front?.volume || null,
    frontDiffOil: result.differentials?.front?.oil || null,
    rearDiffFillVolume: result.differentials?.rear?.volume || null,
    rearDiffOil: result.differentials?.rear?.oil || null,
    oilFilter: result.filters?.oil || null,
    airFilter: result.filters?.air || null,
    cabinFilter: result.filters?.cabin || null,
    fuelFilter: result.filters?.fuel || null,
    importBatch: `ai_research_${result.source}`,
  }).$returningId();

  return inserted.id;
}

// ─── Main Research Runner ───
export async function runResearcher(payload: ResearchPayload, taskId?: number) {
  console.log("[Researcher] Starting research for:", payload);
  const startTime = Date.now();

  try {
    // 1. Check if we already have data
    const db = getDb();
    const existing = await db
      .select()
      .from(carFluidSpecs)
      .where(
        and(
          like(carFluidSpecs.make, `%${payload.make}%`),
          like(carFluidSpecs.model, `%${payload.model}%`),
        )
      )
      .limit(1);

    // 2. AI Research
    const result = await aiResearch(payload);

    // Log what AI returned
    console.log("[Researcher] AI returned:", JSON.stringify({
      engine: result.engine,
      source: result.source,
      confidence: result.confidence,
    }));

    // 3. Save or update database
    let recordId: number;
    if (existing.length > 0) {
      // UPDATE existing record with new data
      await db.update(carFluidSpecs)
        .set({
          vehicleType: "Легковой автомобиль",
          make: payload.make,
          model: payload.model,
          body: payload.body || existing[0].body,
          modification: payload.modification || `${payload.make} ${payload.model} ${payload.engineCode || ""}`.trim(),
          engineCode: payload.engineCode || existing[0].engineCode,
          engineFillVolume: result.engine?.oilVolume || existing[0].engineFillVolume,
          prefOilSae: result.engine?.oilSae || existing[0].prefOilSae,
          prefOilApi: result.engine?.oilApi || existing[0].prefOilApi,
          prefOilAcea: result.engine?.oilAcea || existing[0].prefOilAcea,
          prefOilOe: result.engine?.oilOem || existing[0].prefOilOe,
          engineReplaceInterval: result.engine?.replaceInterval || existing[0].engineReplaceInterval,
          transmissionType: result.transmission?.type || existing[0].transmissionType,
          transmissionCode: result.transmission?.code || existing[0].transmissionCode,
          transmissionFillVolume: result.transmission?.oilVolume || existing[0].transmissionFillVolume,
          transmissionPrefOil: result.transmission?.oilSpec || existing[0].transmissionPrefOil,
          transmissionReplaceInterval: result.transmission?.replaceInterval || existing[0].transmissionReplaceInterval,
          coolantFillVolume: result.cooling?.coolantVolume || existing[0].coolantFillVolume,
          coolantType: result.cooling?.coolantType || existing[0].coolantType,
          coolantInterval: result.cooling?.replaceInterval || existing[0].coolantInterval,
          brakeFluidVolume: result.brakes?.fluidVolume || existing[0].brakeFluidVolume,
          brakeFluidType: result.brakes?.fluidType || existing[0].brakeFluidType,
          brakeFluidInterval: result.brakes?.replaceInterval || existing[0].brakeFluidInterval,
          frontDiffFillVolume: result.differentials?.front?.volume || existing[0].frontDiffFillVolume,
          frontDiffOil: result.differentials?.front?.oil || existing[0].frontDiffOil,
          rearDiffFillVolume: result.differentials?.rear?.volume || existing[0].rearDiffFillVolume,
          rearDiffOil: result.differentials?.rear?.oil || existing[0].rearDiffOil,
          oilFilter: result.filters?.oil || existing[0].oilFilter,
          airFilter: result.filters?.air || existing[0].airFilter,
          cabinFilter: result.filters?.cabin || existing[0].cabinFilter,
          fuelFilter: result.filters?.fuel || existing[0].fuelFilter,
          importBatch: `ai_research_${result.source}`,
          updatedAt: new Date(),
        })
        .where(eq(carFluidSpecs.id, existing[0].id));
      recordId = existing[0].id;
      console.log(`[Researcher] Updated existing record #${recordId}`);
    } else {
      // INSERT new record
      recordId = await saveToDatabase(result);
    }

    // 4. Update task if provided
    if (taskId) {
      await db.update(aiTasks).set({
        status: "completed",
        result: JSON.stringify({ recordId, confidence: result.confidence, source: result.source }),
        completedAt: new Date(),
        itemsProcessed: 1,
      }).where(eq(aiTasks.id, taskId));
    }

    const duration = Date.now() - startTime;
    console.log(`[Researcher] Done in ${duration}ms. Record #${recordId}, confidence: ${result.confidence}`);

    return {
      success: true,
      recordId,
      confidence: result.confidence,
      source: result.source,
      duration,
    };
  } catch (e: any) {
    console.error("[Researcher] Error:", e.message);

    if (taskId) {
      const db = getDb();
      await db.update(aiTasks).set({
        status: "failed",
        errorMessage: e.message,
        completedAt: new Date(),
      }).where(eq(aiTasks.id, taskId));
    }

    return { success: false, error: e.message };
  }
}

// ─── Batch Research: process multiple cars ───
export async function runBatchResearch(options: {
  make?: string;
  model?: string;
  limit?: number;
  agentId?: number;
}) {
  const db = getDb();
  const { make, model, limit = 10 } = options;

  // Get cars from modifications that don't have fluid specs yet
  let query = db
    .selectDistinct({
      make: carFluidSpecs.make,
      model: carFluidSpecs.model,
      modification: carFluidSpecs.modification,
      engineCode: carFluidSpecs.engineCode,
    })
    .from(carFluidSpecs)
    .limit(limit);

  // Actually, let's find cars WITHOUT fluid specs
  // Get list of makes/models from modifications
  const mods = await db
    .selectDistinct({
      make: sql<string>`(SELECT name FROM TObrands WHERE TObrands.id = ${modifications.makeId})`,
      model: sql<string>`(SELECT modelName FROM TOmodels WHERE TOmodels.makeId = ${modifications.makeId} AND TOmodels.modelId = ${modifications.modelId})`,
      engineCode: modifications.engineCode,
      fullName: modifications.fullName,
    })
    .from(modifications)
    .limit(limit * 3);

  const uniqueCars = mods
    .filter((m) => m.make && m.model)
    .slice(0, limit);

  console.log(`[BatchResearch] Found ${uniqueCars.length} cars to research`);

  const results = [];
  for (const car of uniqueCars) {
    // Check if already researched
    const existing = await db
      .select()
      .from(carFluidSpecs)
      .where(
        and(
          like(carFluidSpecs.make, `%${car.make}%`),
          like(carFluidSpecs.model, `%${car.model}%`),
        )
      )
      .limit(1);

    if (existing.length > 0) {
      results.push({ make: car.make, model: car.model, skipped: true });
      continue;
    }

    // Create task
    let taskId: number | undefined;
    if (options.agentId) {
      const [task] = await db.insert(aiTasks).values({
        agentId: options.agentId,
        status: "running",
        payload: JSON.stringify({ make: car.make, model: car.model, engineCode: car.engineCode }),
      }).$returningId();
      taskId = task.id;
    }

    // Run research
    const researchResult = await runResearcher({
      make: car.make!,
      model: car.model!,
      engineCode: car.engineCode || undefined,
      modification: car.fullName || undefined,
    }, taskId);

    results.push({
      make: car.make,
      model: car.model,
      ...researchResult,
    });

    // Rate limit: wait between requests
    await new Promise((r) => setTimeout(r, 2000));
  }

  return { processed: results.length, results };
}

// ─── CLI Usage ───
if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  const make = args.find((a) => a.startsWith("--make="))?.split("=")[1];
  const model = args.find((a) => a.startsWith("--model="))?.split("=")[1];
  const engineCode = args.find((a) => a.startsWith("--engine="))?.split("=")[1];
  const year = args.find((a) => a.startsWith("--year="))?.split("=")[1];
  const limit = args.find((a) => a.startsWith("--limit="))?.split("=")[1];

  if (make && model) {
    // Single research
    runResearcher({ make, model, engineCode, year: year ? parseInt(year) : undefined })
      .then((result) => {
        console.log(JSON.stringify(result, null, 2));
        process.exit(0);
      })
      .catch((e) => {
        console.error(e);
        process.exit(1);
      });
  } else if (limit) {
    // Batch research
    runBatchResearch({ limit: parseInt(limit) })
      .then((result) => {
        console.log(JSON.stringify(result, null, 2));
        process.exit(0);
      })
      .catch((e) => {
        console.error(e);
        process.exit(1);
      });
  } else {
    console.log(`
Usage:
  Single research:  npx tsx api/agents/researcher.ts --make=BMW --model=X5 --engine=N55 --year=2015
  Batch research:   npx tsx api/agents/researcher.ts --limit=10

Environment variables required:
  ANTHROPIC_API_KEY or OPENAI_API_KEY - for AI research
`);
    process.exit(1);
  }
}
