import { useState, useRef } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { LogIn, User, Lock, AlertCircle, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleError = (msg: string) => {
    setError(msg);
    setLoading(false);
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
  };

  const loginMutation = trpc.localAuth.login.useMutation({
    onSuccess: (data) => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      localStorage.setItem("local_auth_token", data.token);
      // Invalidate all queries to pick up new auth state
      utils.invalidate();
      const target = data.user?.role === "admin" ? "/admin" : "/";
      navigate(target);
    },
    onError: (err) => {
      handleError(err.message || "Ошибка входа. Проверьте логин и пароль.");
    },
  });

  const registerMutation = trpc.localAuth.register.useMutation({
    onSuccess: (data) => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      localStorage.setItem("local_auth_token", data.token);
      utils.invalidate();
      navigate("/");
    },
    onError: (err) => {
      handleError(err.message || "Ошибка регистрации");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      setError("Сервер не отвечает. Проверьте подключение или обратитесь к администратору.");
      setLoading(false);
    }, 10000);

    if (isRegister) {
      registerMutation.mutate({ username, password, name: name || username });
    } else {
      loginMutation.mutate({ username, password });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{ background: 'var(--bg-void)' }}>
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-10">
          <div
            className="w-14 h-14 mx-auto mb-5 rounded-2xl flex items-center justify-center text-white text-2xl font-bold"
            style={{ background: 'var(--accent-red)' }}
          >
            O
          </div>
          <h1 className="text-3xl font-bold tracking-tight" style={{ color: 'var(--text-primary)' }}>
            {isRegister ? "Регистрация" : "Вход в систему"}
          </h1>
          <p className="mt-2 text-base" style={{ color: 'var(--text-muted)' }}>
            oilpodbor — подбор масел и технических жидкостей
          </p>
        </div>

        {/* Form Card */}
        <div
          className="rounded-2xl p-8"
          style={{
            background: 'var(--bg-elevated)',
            boxShadow: 'var(--shadow-sm)',
          }}
        >
          {error && (
            <div
              className="mb-5 rounded-xl p-4 flex items-start gap-3"
              style={{ background: 'var(--accent-red-light)', border: '1px solid rgba(227,30,36,0.15)' }}
            >
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: 'var(--accent-red)' }} />
              <div>
                <p className="font-semibold text-sm" style={{ color: 'var(--accent-red)' }}>Ошибка</p>
                <p className="text-sm mt-0.5" style={{ color: 'var(--accent-red)' }}>{error}</p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
                Логин
              </label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: 'var(--text-muted)' }} />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  autoComplete="username"
                  className="input-tinkoff pl-12"
                  placeholder="Введите логин"
                />
              </div>
            </div>

            {isRegister && (
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
                  Имя
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="input-tinkoff"
                  placeholder="Ваше имя"
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
                Пароль
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: 'var(--text-muted)' }} />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  autoComplete={isRegister ? "new-password" : "current-password"}
                  className="input-tinkoff pl-12 pr-12"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 transition-colors"
                  style={{ color: 'var(--text-muted)' }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--text-primary)')}
                  onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--text-muted)')}
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-tinkoff w-full mt-2"
              style={{ fontSize: '16px', padding: '14px' }}
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <LogIn className="w-5 h-5" />
              )}
              {isRegister ? "Создать аккаунт" : "Войти"}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => { setIsRegister(!isRegister); setError(""); }}
              className="text-sm font-medium transition-colors hover:underline"
              style={{ color: 'var(--text-muted)' }}
            >
              {isRegister
                ? "Уже есть аккаунт? Войти"
                : "Нет аккаунта? Зарегистрироваться"}
            </button>
          </div>
        </div>

        {/* Back link */}
        <div className="mt-8 text-center">
          <button
            onClick={() => navigate("/")}
            className="text-sm font-medium transition-colors inline-flex items-center gap-1.5"
            style={{ color: 'var(--text-muted)' }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
            На главную
          </button>
        </div>
      </div>
    </div>
  );
}
