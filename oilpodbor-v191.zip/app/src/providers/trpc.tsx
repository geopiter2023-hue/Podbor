import { createTRPCReact } from "@trpc/react-query";
import { httpBatchLink } from "@trpc/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import superjson from "superjson";
import type { AppRouter } from "../../api/router";
import type { ReactNode } from "react";

export const trpc = createTRPCReact<AppRouter>();

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      retryDelay: 1000,
      staleTime: 2 * 60 * 1000, // 2 min — brands, models rarely change
      gcTime: 10 * 60 * 1000,   // 10 min keep in cache
      refetchOnWindowFocus: false,
      refetchOnMount: false,
      placeholderData: (prev: any) => prev, // keep previous data while loading
    },
    mutations: {
      retry: 1,
      retryDelay: 1000,
    },
  },
});
const trpcClient = trpc.createClient({
  links: [
    httpBatchLink({
      url: "/api/trpc",
      transformer: superjson,
      headers() {
        const token = localStorage.getItem("local_auth_token");
        return {
          ...(token ? { "x-local-auth-token": token } : {}),
        };
      },
      fetch(input, init) {
        const url = typeof input === "string" ? input : input instanceof Request ? input.url : input.toString();
        const isHealth = url.includes("health");
        return globalThis.fetch(input, {
          ...(init ?? {}),
          credentials: "include",
          signal: AbortSignal.timeout(isHealth ? 10000 : 30000),
        });
      },
    }),
  ],
});

export function TRPCProvider({ children }: { children: ReactNode }) {
  return (
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        {children}
      </QueryClientProvider>
    </trpc.Provider>
  );
}
