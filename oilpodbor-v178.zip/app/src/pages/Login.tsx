import { useState, useRef } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { LogIn, User, Lock, AlertCircle, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleError = (msg: string) => {
    setError(msg);
    setLoading(false);
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
  };

  const loginMutation = trpc.localAuth.login.useMutation({
    onSuccess: (data) => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      localStorage.setItem("local_auth_token", data.token);
      // Full page reload to ensure me query uses the new token
      const target = data.user?.role === "admin" ? "admin" : "";
      window.location.href = "/#/" + target;
    },
    onError: (err) => {
      handleError(err.message || "Ошибка входа. Проверьте логин и пароль.");
    },
  });

  const registerMutation = trpc.localAuth.register.useMutation({
    onSuccess: (data) => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      localStorage.setItem("local_auth_token", data.token);
      window.location.href = "/#/";
    },
    onError: (err) => {
      handleError(err.message || "Ошибка регистрации");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    // Timeout: if server doesn't respond in 10s, show error
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      setError("Сервер не отвечает. Проверьте подключение или обратитесь к администратору.");
      setLoading(false);
    }, 10000);

    if (isRegister) {
      registerMutation.mutate({ username, password, name: name || username });
    } else {
      loginMutation.mutate({ username, password });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <img src="/logo.png" alt="oilpodbor" className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-gray-900 text-2xl font-bold">
            {isRegister ? "Регистрация" : "Вход в систему"}
          </h1>
          <p className="text-gray-500 text-sm mt-2">
            oilpodbor — подбор масел и технических жидкостей
          </p>
        </div>

        {/* Form Card */}
        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
          {error && (
            <div className="mb-4 bg-red-50 border border-red-200 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                <span className="text-red-700 text-sm font-medium">Ошибка</span>
              </div>
              <span className="text-red-600 text-sm">{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-gray-600 text-sm mb-1.5 font-medium">
                Логин
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  autoComplete="username"
                  className="w-full bg-white border border-gray-300 rounded-lg pl-10 pr-3 py-2.5 text-gray-900 text-sm focus:border-[#d32f2f] focus:ring-1 focus:ring-[#d32f2f] focus:outline-none transition-colors placeholder-gray-400"
                  placeholder="admin"
                />
              </div>
            </div>

            {isRegister && (
              <div>
                <label className="block text-gray-600 text-sm mb-1.5 font-medium">
                  Имя
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2.5 text-gray-900 text-sm focus:border-[#d32f2f] focus:ring-1 focus:ring-[#d32f2f] focus:outline-none transition-colors placeholder-gray-400"
                  placeholder="Ваше имя"
                />
              </div>
            )}

            <div>
              <label className="block text-gray-600 text-sm mb-1.5 font-medium">
                Пароль
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  autoComplete={isRegister ? "new-password" : "current-password"}
                  className="w-full bg-white border border-gray-300 rounded-lg pl-10 pr-10 py-2.5 text-gray-900 text-sm focus:border-[#d32f2f] focus:ring-1 focus:ring-[#d32f2f] focus:outline-none transition-colors placeholder-gray-400"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 focus:outline-none"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#d32f2f] text-white font-semibold py-2.5 rounded-lg hover:bg-[#b71c1c] transition-colors disabled:opacity-50 flex items-center justify-center gap-2 shadow-sm"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <LogIn className="w-4 h-4" />
              )}
              {isRegister ? "Создать аккаунт" : "Войти"}
            </button>
          </form>

          <div className="mt-4 text-center">
            <button
              onClick={() => {
                setIsRegister(!isRegister);
                setError("");
              }}
              className="text-gray-500 text-sm hover:text-[#d32f2f] transition-colors"
            >
              {isRegister
                ? "Уже есть аккаунт? Войти"
                : "Нет аккаунта? Зарегистрироваться"}
            </button>
          </div>
        </div>

        {/* Back link */}
        <div className="mt-6 text-center">
          <button
            onClick={() => navigate("/")}
            className="text-gray-400 text-sm hover:text-gray-600 transition-colors"
          >
            ← На главную
          </button>
        </div>
      </div>
    </div>
  );
}
