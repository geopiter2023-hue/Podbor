import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { brands, models, modifications, cars as carsTable } from "@db/schema";
import { eq, asc, sql, count, like, or } from "drizzle-orm";

export const carRouter = createRouter({
  // ─── Get all brands directly from TObrands ───
  brands: publicQuery.query(async () => {
    try {
      const db = getDb();
      const result = await db
        .select({
          id: brands.id,
          name: brands.name,
        })
        .from(brands)
        .orderBy(asc(brands.name));
      return result.map((r) => ({
        id: Number(r.id),
        name: r.name,
      }));
    } catch (e: any) {
      console.error("[car.brands] ERROR:", e.message);
      return [];
    }
  }),

  // ─── Get cars list (paginated + search) ───
  list: publicQuery
    .input(z.object({
      limit: z.number().default(50),
      offset: z.number().default(0),
      search: z.string().optional(),
    }).optional())
    .query(async ({ input }) => {
      try {
        const db = getDb();
        const limit = input?.limit || 50;
        const offset = input?.offset || 0;
        const search = input?.search || "";

        let query = db.select().from(carsTable);
        let countQuery = db.select({ count: count() }).from(carsTable);

        if (search) {
          const searchTerm = `%${search}%`;
          const whereClause = or(
            like(carsTable.make, searchTerm),
            like(carsTable.model, searchTerm),
            like(carsTable.modification, searchTerm),
          );
          query = query.where(whereClause) as any;
          countQuery = countQuery.where(whereClause) as any;
        }

        const [totalResult] = await countQuery;
        const total = Number(totalResult?.count || 0);

        const result = await query.limit(limit).offset(offset).orderBy(asc(carsTable.make), asc(carsTable.model));

        return { cars: result, total };
      } catch (e: any) {
        console.error("[car.list] ERROR:", e.message);
        return { cars: [], total: 0 };
      }
    }),

  // ─── Get models for a brand with imageUrl ───
  models: publicQuery
    .input(z.object({ makeId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      let result = await db
        .select({
          modelId: models.modelId,
          makeId: models.makeId,
          modelName: models.modelName,
          yearFrom: models.yearFrom,
          yearTo: models.yearTo,
          imageUrl: models.imageUrl,
        })
        .from(models)
        .where(eq(models.makeId, input.makeId))
        .orderBy(asc(models.modelName));

      // Fallback: if no results, search models by brand name
      if (result.length === 0) {
        const brand = await db
          .select()
          .from(brands)
          .where(eq(brands.id, input.makeId))
          .limit(1);
        if (brand.length > 0) {
          result = await db
            .select({
              modelId: models.modelId,
              makeId: models.makeId,
              modelName: models.modelName,
              yearFrom: models.yearFrom,
              yearTo: models.yearTo,
              imageUrl: models.imageUrl,
            })
            .from(models)
            .where(sql`LOWER(${models.modelName}) LIKE LOWER(${'%' + brand[0].name + '%'})`)
            .orderBy(asc(models.modelName));
        }
      }

      return result.map((r) => ({
        modelId: Number(r.modelId),
        makeId: Number(r.makeId),
        modelName: r.modelName,
        yearFrom: r.yearFrom,
        yearTo: r.yearTo,
        imageUrl: r.imageUrl,
      }));
    }),

  // ─── Get modifications directly from TOmodifications ───
  modifications: publicQuery
    .input(z.object({ makeId: z.number(), modelId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select({
          id: modifications.id,
          name: modifications.name,
          engineCode: modifications.engineCode,
          fuel: modifications.fuel,
          horsePower: modifications.horsePower,
          startDate: modifications.startDate,
          endDate: modifications.endDate,
          engineCapacity: modifications.engineCapacity,
          constructionType: modifications.constructionType,
          motorType: modifications.motorType,
        })
        .from(modifications)
        .where(eq(modifications.makeId, input.makeId))
        .orderBy(asc(modifications.modelId), asc(modifications.name));
      return result.map((r) => ({
        id: Number(r.id),
        name: r.name,
        engineCode: r.engineCode,
        fuel: r.fuel,
        horsePower: r.horsePower,
        startDate: r.startDate,
        endDate: r.endDate,
        engineCapacity: r.engineCapacity,
        constructionType: r.constructionType,
        motorType: r.motorType,
      }));
    }),
});
