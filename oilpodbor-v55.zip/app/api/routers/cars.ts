import { z } from "zod";
import { createRouter, adminQuery, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { cars, carLiquidAssignments, liquids, aggregationTrees } from "@db/schema";
import { eq, and, like, sql, asc, desc } from "drizzle-orm";

export const carsRouter = createRouter({
  // ─── List with filters ───
  list: adminQuery
    .input(z.object({
      make: z.string().optional(),
      model: z.string().optional(),
      modification: z.string().optional(),
      fuelTypeId: z.number().optional(),
      vehicleTypeId: z.number().optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
      limit: z.number().min(1).max(500).default(50),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const filters = [];

      if (input?.make) filters.push(like(cars.make, `%${input.make}%`));
      if (input?.model) filters.push(like(cars.model, `%${input.model}%`));
      if (input?.modification) filters.push(like(cars.modification, `%${input.modification}%`));
      if (input?.fuelTypeId) filters.push(eq(cars.fuelTypeId, input.fuelTypeId));
      if (input?.vehicleTypeId) filters.push(eq(cars.vehicleTypeId, input.vehicleTypeId));
      if (input?.isActive) filters.push(eq(cars.isActive, input.isActive));

      const where = filters.length > 0 ? and(...filters) : undefined;

      const items = await db.select().from(cars)
        .where(where)
        .orderBy(asc(cars.make), asc(cars.model), asc(cars.modification))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);

      const [countResult] = await db.select({ count: sql<number>`COUNT(*)` })
        .from(cars).where(where);

      return {
        items,
        total: countResult.count,
      };
    }),

  // ─── Get single car with liquids ───
  getById: adminQuery
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();

      const [car] = await db.select().from(cars).where(eq(cars.id, input.id)).limit(1);
      if (!car) return null;

      const assignments = await db.select({
        id: carLiquidAssignments.id,
        liquidId: carLiquidAssignments.liquidId,
        aggregationTreeId: carLiquidAssignments.aggregationTreeId,
        fillVolume: carLiquidAssignments.fillVolume,
        replaceInterval: carLiquidAssignments.replaceInterval,
        isPrimary: carLiquidAssignments.isPrimary,
        notes: carLiquidAssignments.notes,
        liquidName: liquids.name,
        liquidCategoryId: liquids.categoryId,
        aggregationTreeName: aggregationTrees.name,
      })
        .from(carLiquidAssignments)
        .leftJoin(liquids, eq(carLiquidAssignments.liquidId, liquids.id))
        .leftJoin(aggregationTrees, eq(carLiquidAssignments.aggregationTreeId, aggregationTrees.id))
        .where(eq(carLiquidAssignments.carId, input.id));

      return { car, liquids: assignments };
    }),

  // ─── Create ───
  create: adminQuery
    .input(z.object({
      id: z.string().min(1),
      vehicleTypeId: z.number().optional(),
      steeringPositionId: z.number().optional(),
      make: z.string().min(1),
      model: z.string().min(1),
      bodyTypeId: z.number().optional(),
      modification: z.string().min(1),
      yearFrom: z.number().optional(),
      yearTo: z.number().optional(),
      engineCapacity: z.string().optional(),
      fuelTypeId: z.number().optional(),
      engineCode: z.string().optional(),
      engineName: z.string().optional(),
      horsePower: z.string().optional(),
      transmissionTypeId: z.number().optional(),
      transmissionGears: z.string().optional(),
      transmissionCode: z.string().optional(),
      transferCaseCode: z.string().optional(),
      frontDifferentialCode: z.string().optional(),
      rearDifferentialCode: z.string().optional(),
      refrigerantType: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      await getDb().insert(cars).values({
        id: input.id,
        vehicleTypeId: input.vehicleTypeId || null,
        steeringPositionId: input.steeringPositionId || null,
        make: input.make,
        model: input.model,
        bodyTypeId: input.bodyTypeId || null,
        modification: input.modification,
        yearFrom: input.yearFrom || null,
        yearTo: input.yearTo || null,
        engineCapacity: input.engineCapacity || null,
        fuelTypeId: input.fuelTypeId || null,
        engineCode: input.engineCode || null,
        engineName: input.engineName || null,
        horsePower: input.horsePower || null,
        transmissionTypeId: input.transmissionTypeId || null,
        transmissionGears: input.transmissionGears || null,
        transmissionCode: input.transmissionCode || null,
        transferCaseCode: input.transferCaseCode || null,
        frontDifferentialCode: input.frontDifferentialCode || null,
        rearDifferentialCode: input.rearDifferentialCode || null,
        refrigerantType: input.refrigerantType || null,
      });
      return { success: true };
    }),

  // ─── Update ───
  update: adminQuery
    .input(z.object({
      id: z.string(),
      vehicleTypeId: z.number().optional(),
      steeringPositionId: z.number().optional(),
      make: z.string().optional(),
      model: z.string().optional(),
      bodyTypeId: z.number().optional(),
      modification: z.string().optional(),
      yearFrom: z.number().optional(),
      yearTo: z.number().optional(),
      engineCapacity: z.string().optional(),
      fuelTypeId: z.number().optional(),
      engineCode: z.string().optional(),
      engineName: z.string().optional(),
      horsePower: z.string().optional(),
      transmissionTypeId: z.number().optional(),
      transmissionGears: z.string().optional(),
      transmissionCode: z.string().optional(),
      transferCaseCode: z.string().optional(),
      frontDifferentialCode: z.string().optional(),
      rearDifferentialCode: z.string().optional(),
      refrigerantType: z.string().optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await getDb().update(cars).set(data).where(eq(cars.id, id));
      return { success: true };
    }),

  // ─── Delete ───
  delete: adminQuery
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      await getDb().delete(carLiquidAssignments).where(eq(carLiquidAssignments.carId, input.id));
      await getDb().delete(cars).where(eq(cars.id, input.id));
      return { success: true };
    }),

  // ─── Assign liquid to car ───
  assignLiquid: adminQuery
    .input(z.object({
      carId: z.string(),
      liquidId: z.string(),
      aggregationTreeId: z.number().optional(),
      fillVolume: z.string().optional(),
      replaceInterval: z.string().optional(),
      isPrimary: z.enum(["yes", "no"]).optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      await getDb().insert(carLiquidAssignments).values({
        carId: input.carId,
        liquidId: input.liquidId,
        aggregationTreeId: input.aggregationTreeId || null,
        fillVolume: input.fillVolume || null,
        replaceInterval: input.replaceInterval || null,
        isPrimary: input.isPrimary || "yes",
        notes: input.notes || null,
      });
      return { success: true };
    }),

  // ─── Remove liquid assignment ───
  removeLiquid: adminQuery
    .input(z.object({ assignmentId: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(carLiquidAssignments).where(eq(carLiquidAssignments.id, input.assignmentId));
      return { success: true };
    }),

  // ─── Get unique makes (for filters) ───
  getMakes: adminQuery.query(async () => {
    const db = getDb();
    const result = await db.selectDistinct({ make: cars.make }).from(cars).orderBy(asc(cars.make));
    return result.map((r) => r.make).filter(Boolean);
  }),

  // ─── Get models for a make ───
  getModels: adminQuery
    .input(z.object({ make: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.selectDistinct({ model: cars.model })
        .from(cars)
        .where(eq(cars.make, input.make))
        .orderBy(asc(cars.model));
      return result.map((r) => r.model).filter(Boolean);
    }),

  // ─── Get modifications for make+model ───
  getModifications: adminQuery
    .input(z.object({ make: z.string(), model: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.selectDistinct({ modification: cars.modification })
        .from(cars)
        .where(and(eq(cars.make, input.make), eq(cars.model, input.model)))
        .orderBy(asc(cars.modification));
      return result.map((r) => r.modification).filter(Boolean);
    }),

  // ─── Count total cars ───
  count: adminQuery
    .input(z.object({
      make: z.string().optional(),
      model: z.string().optional(),
      modification: z.string().optional(),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [eq(cars.isActive, "active")];
      if (input?.make) conditions.push(like(cars.make, `%${input.make}%`));
      if (input?.model) conditions.push(like(cars.model, `%${input.model}%`));
      if (input?.modification) conditions.push(like(cars.modification, `%${input.modification}%`));
      const [result] = await db.select({ count: sql<number>`COUNT(*)` })
        .from(cars)
        .where(and(...conditions));
      return result?.count || 0;
    }),
});
