import { useCallback, useState, useEffect } from "react";
import { trpc } from "@/providers/trpc";

export interface AuthUser {
  id: number;
  name: string | null;
  username: string | null;
  email: string | null;
  avatar: string | null;
  role: "user" | "admin";
}

export function useAuth() {
  const utils = trpc.useUtils();
  const [timedOut, setTimedOut] = useState(false);

  const { data: localUser, isLoading, error } = trpc.localAuth.me.useQuery(
    undefined,
    { retry: false, refetchOnWindowFocus: false }
  );

  // Timeout: if auth check takes more than 5s, treat as not authenticated
  useEffect(() => {
    if (!isLoading) return;
    const timer = setTimeout(() => {
      console.log("[useAuth] Auth check timed out after 5s, treating as not authenticated");
      setTimedOut(true);
    }, 5000);
    return () => clearTimeout(timer);
  }, [isLoading]);

  // Reset timeout when loading finishes
  useEffect(() => {
    if (!isLoading && timedOut) {
      setTimedOut(false);
    }
  }, [isLoading, timedOut]);

  const logout = useCallback(() => {
    localStorage.removeItem("local_auth_token");
    utils.invalidate();
    window.location.reload();
  }, [utils]);

  // If me query errors (no token, invalid token), user is not authenticated
  const isAuthCheckDone = !isLoading || timedOut;
  const isAuthenticated = !!localUser && !error && !timedOut;

  return {
    user: (localUser || null) as AuthUser | null,
    isAuthenticated,
    isLoading: !isAuthCheckDone, // false after timeout
    logout,
  };
}
