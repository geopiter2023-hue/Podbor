// ─── 1. Load .env FIRST (before any imports) ───
try {
  require("dotenv").config();
} catch {
  /* dotenv not available */
}

// ─── 2. Debug env ───
const dbUrl = process.env.DATABASE_URL || "";
console.log("[BOOT] cwd:", process.cwd());
console.log("[BOOT] .env exists:", require("fs").existsSync("./.env"));
console.log("[BOOT] DATABASE_URL:", dbUrl ? "SET" : "NOT SET!");

if (!dbUrl) {
  console.error("\n╔══════════════════════════════════════════════════════╗");
  console.error("║  ERROR: DATABASE_URL not set!                       ║");
  console.error("║  Create .env file: echo 'DATABASE_URL=mysql://...'  ║");
  console.error("║  > .env                                              ║");
  console.error("╚══════════════════════════════════════════════════════╝\n");
}

// ─── 3. Polyfill ───
if (typeof (AbortSignal as any).timeout !== "function") {
  (AbortSignal as any).timeout = function(ms: number) {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), ms);
    return ctrl.signal;
  };
}

// ─── 4. Imports ───
import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import { serve } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import fs from "fs";
import path from "path";

const app = new Hono();
const PORT = parseInt(process.env.PORT || "3000");

// CORS
app.use("*", async (c, next) => {
  c.header("Access-Control-Allow-Origin", "*");
  c.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  c.header("Access-Control-Allow-Headers", "Content-Type, Authorization, x-local-auth-token");
  if (c.req.method === "OPTIONS") return c.body(null, 204);
  await next();
});

// Logging
app.use("*", async (c, next) => {
  const start = Date.now();
  await next();
  console.log(`[${c.req.method}] ${c.req.path} — ${c.res.status} (${Date.now() - start}ms)`);
});

// Body limit
app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));

// Health check
app.get("/health", (c) => c.json({
  status: "ok",
  version: "v145",
  time: new Date().toISOString(),
  uptime: process.uptime(),
}));

// tRPC API
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
    onError: ({ error, path }) => console.error(`[tRPC ERR] ${path}:`, error.message),
  });
});

// Static files (SPA fallback)
const staticDir = path.join(process.cwd(), "dist", "public");
app.use("/*", async (c) => {
  const url = new URL(c.req.url).pathname;
  let file = path.join(staticDir, url === "/" ? "/index.html" : url);
  if (!fs.existsSync(file)) file = path.join(staticDir, "index.html");
  try {
    const ext = path.extname(file).slice(1);
    const ct: Record<string, string> = {
      html: "text/html", js: "application/javascript", css: "text/css",
      json: "application/json", png: "image/png", jpg: "image/jpeg",
      jpeg: "image/jpeg", svg: "image/svg+xml", ico: "image/x-icon",
    };
    return c.body(fs.readFileSync(file), 200, { "Content-Type": ct[ext] || "text/plain" });
  } catch {
    return c.text("Not found", 404);
  }
});

// Global error
app.onError((err, c) => {
  console.error(`[ERR] ${c.req.method} ${c.req.path}:`, err.message);
  return c.json({ error: "Server error", msg: err.message }, 500);
});

// ─── 5. START SERVER ───
console.log("[BOOT] Starting server...");
serve({ fetch: app.fetch, port: PORT }, () => {
  console.log(`[SERVER] http://0.0.0.0:${PORT}/`);
  console.log(`[SERVER] Health: http://0.0.0.0:${PORT}/health`);
  console.log(`[SERVER] API: http://0.0.0.0:${PORT}/api/trpc`);
});

export default app;
