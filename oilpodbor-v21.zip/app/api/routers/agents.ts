import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { aiAgents, aiTasks } from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const agentsRouter = createRouter({
  // ─── List all agents ───
  list: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(aiAgents).orderBy(aiAgents.id);
  }),

  // ─── Get agent by ID with tasks ───
  getById: adminQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [agent] = await db.select().from(aiAgents).where(eq(aiAgents.id, input.id)).limit(1);
      if (!agent) return null;
      const tasks = await db.select().from(aiTasks).where(eq(aiTasks.agentId, input.id)).orderBy(desc(aiTasks.createdAt)).limit(20);
      return { ...agent, tasks };
    }),

  // ─── Update agent settings ───
  update: adminQuery
    .input(z.object({
      id: z.number(),
      isActive: z.enum(["active", "paused", "error"]).optional(),
      schedule: z.string().optional(),
      config: z.record(z.any()).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(aiAgents).set(data).where(eq(aiAgents.id, id));
      return { success: true };
    }),

  // ─── Create task (run agent) ───
  run: adminQuery
    .input(z.object({
      agentId: z.number(),
      payload: z.record(z.any()).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(aiTasks).values({
        agentId: input.agentId,
        status: "queued",
        payload: input.payload ? JSON.stringify(input.payload) : null,
      }).$returningId();
      return { taskId: result.id };
    }),

  // ─── Get tasks list ───
  tasks: adminQuery
    .input(z.object({
      agentId: z.number().optional(),
      limit: z.number().default(50),
    }))
    .query(async ({ input }) => {
      const db = getDb();
      const query = input.agentId
        ? db.select().from(aiTasks).where(eq(aiTasks.agentId, input.agentId)).orderBy(desc(aiTasks.createdAt)).limit(input.limit)
        : db.select().from(aiTasks).orderBy(desc(aiTasks.createdAt)).limit(input.limit);
      return query;
    }),

  // ─── Get stats ───
  stats: adminQuery.query(async () => {
    const db = getDb();
    const [totalAgents] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiAgents);
    const [activeAgents] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiAgents).where(eq(aiAgents.isActive, "active"));
    const [totalTasks] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiTasks);
    const [completedTasks] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiTasks).where(eq(aiTasks.status, "completed"));
    const [runningTasks] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiTasks).where(eq(aiTasks.status, "running"));
    const [failedTasks] = await db.select({ count: sql<number>`COUNT(*)` }).from(aiTasks).where(eq(aiTasks.status, "failed"));

    return {
      agents: { total: totalAgents.count, active: activeAgents.count },
      tasks: { total: totalTasks.count, completed: completedTasks.count, running: runningTasks.count, failed: failedTasks.count },
    };
  }),
});
