import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { systemSettings } from "@db/schema";
import { eq, sql } from "drizzle-orm";

// Default settings to seed
export const DEFAULT_SETTINGS = [
  // API Keys
  { key: "nomerogram_token", value: "", label: "Токен API Номерограм", category: "api_keys", isSecret: "yes" as const, description: "Токен для api-cloud.ru/nomerogram.php" },
  { key: "dadata_api_key", value: "", label: "Ключ API DaData", category: "api_keys", isSecret: "yes" as const, description: "Ключ для подсказок DaData (dadata.ru)" },
  { key: "dadata_secret_key", value: "", label: "Секретный ключ DaData", category: "api_keys", isSecret: "yes" as const, description: "Секретный ключ DaData" },
  { key: "anthropic_api_key", value: "", label: "Ключ API Anthropic Claude", category: "api_keys", isSecret: "yes" as const, description: "Ключ для AI-агентов (console.anthropic.com)" },
  { key: "openai_api_key", value: "", label: "Ключ API OpenAI", category: "api_keys", isSecret: "yes" as const, description: "Ключ для AI-агентов (platform.openai.com)" },
  { key: "yandex_metrika_id", value: "", label: "ID Яндекс Метрики", category: "api_keys", isSecret: "no" as const, description: "Номер счётчика Яндекс Метрики" },
  { key: "yandex_metrika_token", value: "", label: "OAuth-токен Яндекс Метрики", category: "api_keys", isSecret: "yes" as const, description: "Токен для API Яндекс Метрики" },
  { key: "google_analytics_id", value: "", label: "ID Google Analytics", category: "api_keys", isSecret: "no" as const, description: "GA4 Measurement ID (G-XXXXXXXXXX)" },
  // Widget Settings
  { key: "widget_title", value: "oilpodbor — подбор масел", label: "Заголовок виджета", category: "widget", isSecret: "no" as const, description: "Отображается в шапке виджета" },
  { key: "widget_primary_color", value: "#d32f2f", label: "Основной цвет виджета", category: "widget", isSecret: "no" as const, description: "Hex-код основного цвета (#d32f2f)" },
  { key: "widget_company_name", value: "oilpodbor", label: "Название компании", category: "widget", isSecret: "no" as const, description: "Имя компании в виджете" },
  // System
  { key: "site_title", value: "oilpodbor — подбор масел и технических жидкостей", label: "Заголовок сайта", category: "system", isSecret: "no" as const, description: "HTML <title> сайта" },
  { key: "items_per_page", value: "50", label: "Записей на страницу", category: "system", isSecret: "no" as const, description: "Количество записей в таблицах админки" },
  { key: "max_search_results", value: "100", label: "Макс. результатов поиска", category: "system", isSecret: "no" as const, description: "Лимит результатов поиска в виджете" },
];

// Helper: get setting value
export async function getSetting(key: string): Promise<string | null> {
  const db = getDb();
  const [row] = await db.select().from(systemSettings).where(eq(systemSettings.key, key)).limit(1);
  return row?.value || null;
}

// Helper: get all settings as object
export async function getAllSettings(): Promise<Record<string, string>> {
  const db = getDb();
  const rows = await db.select().from(systemSettings);
  const result: Record<string, string> = {};
  for (const row of rows) {
    if (row.value) result[row.key] = row.value;
  }
  return result;
}

export const settingsRouter = createRouter({
  // ─── List all settings (admin only, secrets masked) ───
  list: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db.select().from(systemSettings).orderBy(systemSettings.category, systemSettings.key);
    return rows.map((r) => ({
      ...r,
      value: r.isSecret === "yes" && r.value ? `${r.value.substring(0, 8)}...` : r.value,
    }));
  }),

  // ─── Get single setting (admin, full value) ───
  get: adminQuery
    .input(z.object({ key: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [row] = await db.select().from(systemSettings).where(eq(systemSettings.key, input.key)).limit(1);
      return row || null;
    }),

  // ─── Update setting ───
  set: adminQuery
    .input(z.object({
      key: z.string(),
      value: z.string(),
      updatedBy: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userName = ctx.user?.name || "admin";

      const [existing] = await db.select().from(systemSettings).where(eq(systemSettings.key, input.key)).limit(1);

      if (existing) {
        await db.update(systemSettings).set({
          value: input.value,
          updatedBy: userName,
        }).where(eq(systemSettings.key, input.key));
      } else {
        await db.insert(systemSettings).values({
          key: input.key,
          value: input.value,
          updatedBy: userName,
        });
      }

      return { ok: true };
    }),

  // ─── Update multiple settings ───
  setMany: adminQuery
    .input(z.object({
      settings: z.array(z.object({ key: z.string(), value: z.string() })),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userName = ctx.user?.name || "admin";

      for (const s of input.settings) {
        const [existing] = await db.select().from(systemSettings).where(eq(systemSettings.key, s.key)).limit(1);
        if (existing) {
          await db.update(systemSettings).set({ value: s.value, updatedBy: userName }).where(eq(systemSettings.key, s.key));
        } else {
          await db.insert(systemSettings).values({ key: s.key, value: s.value, updatedBy: userName });
        }
      }

      return { ok: true, count: input.settings.length };
    }),

  // ─── Delete setting ───
  delete: adminQuery
    .input(z.object({ key: z.string() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(systemSettings).where(eq(systemSettings.key, input.key));
      return { ok: true };
    }),

  // ─── Seed default settings ───
  seed: adminQuery.mutation(async () => {
    const db = getDb();
    let inserted = 0;
    let updated = 0;

    for (const s of DEFAULT_SETTINGS) {
      const [existing] = await db.select().from(systemSettings).where(eq(systemSettings.key, s.key)).limit(1);
      if (existing) {
        updated++;
      } else {
        await db.insert(systemSettings).values(s);
        inserted++;
      }
    }

    return { inserted, updated, total: DEFAULT_SETTINGS.length };
  }),

  // ─── Stats ───
  stats: adminQuery.query(async () => {
    const db = getDb();
    const [total] = await db.select({ count: sql<number>`COUNT(*)` }).from(systemSettings);
    const [filled] = await db.select({ count: sql<number>`COUNT(*)` }).from(systemSettings).where(sql`${systemSettings.value} IS NOT NULL AND ${systemSettings.value} != ''`);
    const [secrets] = await db.select({ count: sql<number>`COUNT(*)` }).from(systemSettings).where(eq(systemSettings.isSecret, "yes"));

    // By category
    const byCategory = await db
      .select({ category: systemSettings.category, count: sql<number>`COUNT(*)` })
      .from(systemSettings)
      .groupBy(systemSettings.category);

    return { total: total.count, filled: filled.count, secrets: secrets.count, byCategory };
  }),
});
