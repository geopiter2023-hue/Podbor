-- Создание таблицы users и администратора Ushakov
-- Выполните на сервере: mysql -h <host> -u <user> -p <password> <database> < fix-users.sql

-- 1. Создаем таблицу users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `unionId` varchar(100) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `passwordHash` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `avatar` varchar(500) DEFAULT NULL,
  `role` enum('admin','user','company') DEFAULT 'user',
  `createdAt` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastSignInAt` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `users_username_idx` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Создаем таблицу systemSettings (если нет)
CREATE TABLE IF NOT EXISTS `systemSettings` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `key` varchar(100) NOT NULL UNIQUE,
  `value` text DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `category` varchar(50) DEFAULT 'general',
  `isSecret` enum('yes','no') DEFAULT 'no',
  `description` text DEFAULT NULL,
  `updatedAt` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` varchar(100) DEFAULT NULL,
  KEY `systemSettings_key_idx` (`key`),
  KEY `systemSettings_category_idx` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Создаем таблицу ownerManuals (если нет)
CREATE TABLE IF NOT EXISTS `ownerManuals` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `make` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `yearFrom` int DEFAULT NULL,
  `yearTo` int DEFAULT NULL,
  `generation` varchar(255) DEFAULT NULL,
  `modification` varchar(255) DEFAULT NULL,
  `title` varchar(500) DEFAULT NULL,
  `pdfUrl` varchar(1000) DEFAULT NULL,
  `pdfOriginalUrl` varchar(1000) DEFAULT NULL,
  `pdfSize` varchar(50) DEFAULT NULL,
  `pdfPages` int DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `language` varchar(50) DEFAULT 'ru',
  `isOfficial` enum('yes','no') DEFAULT 'no',
  `downloadCount` int DEFAULT 0,
  `viewCount` int DEFAULT 0,
  `isActive` enum('active','inactive') DEFAULT 'active',
  `createdAt` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `ownerManuals_make_idx` (`make`),
  KEY `ownerManuals_model_idx` (`model`),
  KEY `ownerManuals_active_idx` (`isActive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Создаем таблицу carFluidSpecs (если нет)
CREATE TABLE IF NOT EXISTS `carFluidSpecs` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `vehicleType` varchar(100) DEFAULT NULL,
  `steeringPosition` varchar(100) DEFAULT NULL,
  `make` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `body` varchar(500) DEFAULT NULL,
  `modification` varchar(500) DEFAULT NULL,
  `engineVolume` varchar(50) DEFAULT NULL,
  `fuelType` varchar(100) DEFAULT NULL,
  `engineCode` varchar(100) DEFAULT NULL,
  `engineReplaceInterval` varchar(255) DEFAULT NULL,
  `engineFillVolume` varchar(50) DEFAULT NULL,
  `prefOilSae` varchar(50) DEFAULT NULL,
  `prefOilApi` varchar(100) DEFAULT NULL,
  `prefOilAcea` varchar(100) DEFAULT NULL,
  `prefOilIlsac` varchar(100) DEFAULT NULL,
  `prefOilOe` varchar(255) DEFAULT NULL,
  `altOilViscosities` varchar(255) DEFAULT NULL,
  `altOilApi` varchar(100) DEFAULT NULL,
  `altOilAcea` varchar(100) DEFAULT NULL,
  `altOilIlsac` varchar(100) DEFAULT NULL,
  `altOilOe` varchar(255) DEFAULT NULL,
  `transmissionType` varchar(100) DEFAULT NULL,
  `transmissionGears` varchar(50) DEFAULT NULL,
  `transmissionCode` varchar(100) DEFAULT NULL,
  `transmissionReplaceInterval` varchar(255) DEFAULT NULL,
  `transmissionFillVolume` varchar(50) DEFAULT NULL,
  `transmissionPrefOil` varchar(255) DEFAULT NULL,
  `transmissionAltOil` varchar(255) DEFAULT NULL,
  `transferCaseCode` varchar(100) DEFAULT NULL,
  `transferCaseInterval` varchar(255) DEFAULT NULL,
  `transferCaseFillVolume` varchar(50) DEFAULT NULL,
  `transferCaseOil` varchar(255) DEFAULT NULL,
  `frontDiffCode` varchar(100) DEFAULT NULL,
  `frontDiffFillVolume` varchar(50) DEFAULT NULL,
  `frontDiffInterval` varchar(255) DEFAULT NULL,
  `frontDiffOil` varchar(255) DEFAULT NULL,
  `rearDiffCode` varchar(100) DEFAULT NULL,
  `rearDiffFillVolume` varchar(50) DEFAULT NULL,
  `rearDiffInterval` varchar(255) DEFAULT NULL,
  `rearDiffOil` varchar(255) DEFAULT NULL,
  `coolantFillVolume` varchar(50) DEFAULT NULL,
  `coolantInterval` varchar(255) DEFAULT NULL,
  `coolantType` varchar(255) DEFAULT NULL,
  `brakeFluidVolume` varchar(50) DEFAULT NULL,
  `brakeFluidInterval` varchar(255) DEFAULT NULL,
  `brakeFluidType` varchar(255) DEFAULT NULL,
  `psFluidVolume` varchar(50) DEFAULT NULL,
  `psFluidType` varchar(255) DEFAULT NULL,
  `suspFluidVolume` varchar(50) DEFAULT NULL,
  `suspFluidType` varchar(255) DEFAULT NULL,
  `adblueVolume` varchar(50) DEFAULT NULL,
  `adblueType` varchar(255) DEFAULT NULL,
  `oilFilter` varchar(100) DEFAULT NULL,
  `airFilter` varchar(100) DEFAULT NULL,
  `cabinFilter` varchar(100) DEFAULT NULL,
  `fuelFilter` varchar(100) DEFAULT NULL,
  `transmissionFilter` varchar(100) DEFAULT NULL,
  `rawData` json DEFAULT NULL,
  `importBatch` varchar(50) DEFAULT NULL,
  `importDate` timestamp DEFAULT CURRENT_TIMESTAMP,
  `isActive` enum('active','inactive') DEFAULT 'active',
  KEY `carFluidSpecs_make_idx` (`make`),
  KEY `carFluidSpecs_model_idx` (`model`),
  KEY `carFluidSpecs_batch_idx` (`importBatch`),
  KEY `carFluidSpecs_active_idx` (`isActive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Создаем администратора Ushakov (пароль: Ushakov1987)
-- Пароль захеширован bcrypt с salt rounds 10
INSERT INTO `users` (`username`, `passwordHash`, `name`, `role`, `email`)
VALUES (
  'Ushakov',
  '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
  'Ushakov',
  'admin',
  'admin@oilpodbor.ru'
)
ON DUPLICATE KEY UPDATE 
  `passwordHash` = '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
  `role` = 'admin';

-- 6. Заполняем стандартные настройки
INSERT INTO `systemSettings` (`key`, `value`, `label`, `category`, `isSecret`, `description`) VALUES
  ('nomerogram_token', '', 'Токен API Номерограм', 'api_keys', 'yes', 'Токен для api-cloud.ru/nomerogram.php'),
  ('dadata_api_key', '', 'Ключ API DaData', 'api_keys', 'yes', 'Ключ для подсказок DaData (dadata.ru)'),
  ('dadata_secret_key', '', 'Секретный ключ DaData', 'api_keys', 'yes', 'Секретный ключ DaData'),
  ('anthropic_api_key', '', 'Ключ API Anthropic Claude', 'api_keys', 'yes', 'Ключ для AI-агентов (console.anthropic.com)'),
  ('openai_api_key', '', 'Ключ API OpenAI', 'api_keys', 'yes', 'Ключ для AI-агентов (platform.openai.com)'),
  ('yandex_metrika_id', '', 'ID Яндекс Метрики', 'api_keys', 'no', 'Номер счётчика Яндекс Метрики'),
  ('widget_title', 'oilpodbor — подбор масел', 'Заголовок виджета', 'widget', 'no', 'Отображается в шапке виджета'),
  ('widget_primary_color', '#d32f2f', 'Основной цвет виджета', 'widget', 'no', 'Hex-код основного цвета'),
  ('site_title', 'oilpodbor — подбор масел и технических жидкостей', 'Заголовок сайта', 'system', 'no', 'HTML <title> сайта')
ON DUPLICATE KEY UPDATE `key` = `key`;

-- 7. Создаем таблицы для AI агентов (если нет)
CREATE TABLE IF NOT EXISTS `aiAgents` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `config` json DEFAULT NULL,
  `schedule` varchar(100) DEFAULT NULL,
  `isActive` enum('active','paused','error') DEFAULT 'paused',
  `lastRunAt` timestamp NULL DEFAULT NULL,
  `lastRunStatus` varchar(50) DEFAULT NULL,
  `lastRunResult` text DEFAULT NULL,
  `runsTotal` int DEFAULT 0,
  `runsSuccess` int DEFAULT 0,
  `runsError` int DEFAULT 0,
  `itemsProcessed` int DEFAULT 0,
  `createdAt` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `aiAgents_slug_idx` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `aiTasks` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `agentId` int DEFAULT NULL,
  `status` enum('queued','running','completed','failed') DEFAULT 'queued',
  `payload` text DEFAULT NULL,
  `result` text DEFAULT NULL,
  `errorMessage` text DEFAULT NULL,
  `itemsProcessed` int DEFAULT 0,
  `startedAt` timestamp NULL DEFAULT NULL,
  `completedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Seed AI агентов
INSERT INTO `aiAgents` (`name`, `slug`, `description`, `category`, `config`, `isActive`) VALUES
  ('Парсер каталога', 'catalog-parser', 'Парсит базовые данные автомобилей из TOmodifications', 'parser', '{"targetTable":"cars","columns":9}', 'paused'),
  ('Исследователь масел', 'oil-researcher', 'Ищет данные по моторному маслу через AI: SAE, API, ACEA, OEM, объём', 'enricher', '{"targetTable":"carFluidSpecs","columns":12}', 'paused'),
  ('Исследователь трансмиссии', 'transmission-researcher', 'Ищет данные по КПП, раздатке, дифференциалам', 'enricher', '{"targetTable":"carFluidSpecs","columns":19}', 'paused'),
  ('Исследователь жидкостей', 'fluids-researcher', 'Ищет данные по охлаждению, тормозам, ГУР, AdBlue', 'enricher', '{"targetTable":"carFluidSpecs","columns":12}', 'paused'),
  ('Исследователь фильтров', 'filters-researcher', 'Ищет номера фильтров: масляный, воздушный, салонный, топливный', 'enricher', '{"targetTable":"carFluidSpecs","columns":5}', 'paused'),
  ('Поисковик руководств', 'manual-finder', 'Ищет руководства по эксплуатации (PDF) для автомобилей', 'enricher', '{"targetTable":"ownerManuals","columns":6}', 'paused')
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`), `description` = VALUES(`description`);
