import { z } from "zod";
import { createRouter, adminQuery, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { cars, carLiquidAssignments, liquids, aggregationTrees } from "@db/schema";
import { eq, and, like, sql, asc, desc } from "drizzle-orm";

// Safe car select — falls back to raw SQL if new columns don't exist in DB
async function safeSelectCars(db: any, filters: any[] = [], limit = 50, offset = 0) {
  const where = filters.length > 0 ? and(...filters) : undefined;
  try {
    return await db.select().from(cars)
      .where(where)
      .orderBy(asc(cars.make), asc(cars.model), asc(cars.modification))
      .limit(limit).offset(offset);
  } catch {
    // Fallback: raw SQL without image columns
    const conditions = filters.map(() => "?").join(" AND ");
    const condStr = conditions ? `WHERE ${conditions}` : "";
    return await db.execute(sql`SELECT id, vehicleTypeId, steeringPositionId, make, model, modification, body, yearFrom, yearTo, engineCode, engineCapacity, engineName, horsePower, torque, fuelTypeId, transmissionTypeId, transmissionGears, transmissionCode, transferCaseCode, frontDifferentialCode, rearDifferentialCode, refrigerantType, isActive, createdAt, updatedAt FROM cars ${sql.raw(condStr)} ORDER BY make, model, modification LIMIT ${limit} OFFSET ${offset}`);
  }
}

async function safeCountCars(db: any, filters: any[] = []) {
  const where = filters.length > 0 ? and(...filters) : undefined;
  try {
    const [result] = await db.select({ count: sql<number>`COUNT(*)` }).from(cars).where(where);
    return result?.count || 0;
  } catch {
    const [result] = await db.execute(sql`SELECT COUNT(*) as count FROM cars`);
    return Number(result?.count || 0);
  }
}

export const carsRouter = createRouter({
  // ─── List with filters ───
  list: adminQuery
    .input(z.object({
      make: z.string().optional(),
      model: z.string().optional(),
      modification: z.string().optional(),
      fuelTypeId: z.number().optional(),
      vehicleTypeId: z.number().optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
      limit: z.number().min(1).max(500).default(50),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const filters = [];

      if (input?.make) filters.push(like(cars.make, `%${input.make}%`));
      if (input?.model) filters.push(like(cars.model, `%${input.model}%`));
      if (input?.modification) filters.push(like(cars.modification, `%${input.modification}%`));
      if (input?.fuelTypeId) filters.push(eq(cars.fuelTypeId, input.fuelTypeId));
      if (input?.vehicleTypeId) filters.push(eq(cars.vehicleTypeId, input.vehicleTypeId));
      if (input?.isActive) filters.push(eq(cars.isActive, input.isActive));

      const items = await safeSelectCars(db, filters, input?.limit || 50, input?.offset || 0);
      const total = await safeCountCars(db, filters);

      return { items, total };
    }),

  // ─── Get single car with liquids ───
  getById: adminQuery
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();

      // Safe car select with fallback for missing columns
      let car: any;
      try {
        [car] = await db.select().from(cars).where(eq(cars.id, input.id)).limit(1);
      } catch {
        const rows = await db.execute(sql`SELECT * FROM cars WHERE id = ${input.id} LIMIT 1`);
        car = rows?.[0] || null;
      }
      if (!car) return null;

      const assignments = await db.select({
        id: carLiquidAssignments.id,
        liquidId: carLiquidAssignments.liquidId,
        aggregationTreeId: carLiquidAssignments.aggregationTreeId,
        fillVolume: carLiquidAssignments.fillVolume,
        replaceInterval: carLiquidAssignments.replaceInterval,
        isPrimary: carLiquidAssignments.isPrimary,
        notes: carLiquidAssignments.notes,
        liquidName: liquids.name,
        liquidCategoryId: liquids.categoryId,
        aggregationTreeName: aggregationTrees.name,
      })
        .from(carLiquidAssignments)
        .leftJoin(liquids, eq(carLiquidAssignments.liquidId, liquids.id))
        .leftJoin(aggregationTrees, eq(carLiquidAssignments.aggregationTreeId, aggregationTrees.id))
        .where(eq(carLiquidAssignments.carId, input.id));

      return { car, liquids: assignments };
    }),

  // ─── Update ───
  update: adminQuery
    .input(z.object({
      id: z.string(),
      vehicleTypeId: z.number().optional(),
      steeringPositionId: z.number().optional(),
      make: z.string().optional(),
      model: z.string().optional(),
      bodyTypeId: z.number().optional(),
      modification: z.string().optional(),
      yearFrom: z.number().optional(),
      yearTo: z.number().optional(),
      engineCapacity: z.string().optional(),
      fuelTypeId: z.number().optional(),
      engineCode: z.string().optional(),
      engineName: z.string().optional(),
      horsePower: z.string().optional(),
      transmissionTypeId: z.number().optional(),
      transmissionGears: z.string().optional(),
      transmissionCode: z.string().optional(),
      transferCaseCode: z.string().optional(),
      frontDifferentialCode: z.string().optional(),
      rearDifferentialCode: z.string().optional(),
      refrigerantType: z.string().optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await getDb().update(cars).set(data).where(eq(cars.id, id));
      return { success: true };
    }),

  // ─── Delete ───
  delete: adminQuery
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      await getDb().delete(carLiquidAssignments).where(eq(carLiquidAssignments.carId, input.id));
      await getDb().delete(cars).where(eq(cars.id, input.id));
      return { success: true };
    }),

  // ─── Assign liquid to car ───
  assignLiquid: adminQuery
    .input(z.object({
      carId: z.string(),
      liquidId: z.string(),
      aggregationTreeId: z.number().optional(),
      fillVolume: z.string().optional(),
      replaceInterval: z.string().optional(),
      isPrimary: z.enum(["yes", "no"]).optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      await getDb().insert(carLiquidAssignments).values({
        carId: input.carId,
        liquidId: input.liquidId,
        aggregationTreeId: input.aggregationTreeId || null,
        fillVolume: input.fillVolume || null,
        replaceInterval: input.replaceInterval || null,
        isPrimary: input.isPrimary || "yes",
        notes: input.notes || null,
      });
      return { success: true };
    }),

  // ─── Remove liquid assignment ───
  removeLiquid: adminQuery
    .input(z.object({ assignmentId: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(carLiquidAssignments).where(eq(carLiquidAssignments.id, input.assignmentId));
      return { success: true };
    }),

  // ─── Get unique makes (for filters) ───
  getMakes: adminQuery.query(async () => {
    const db = getDb();
    const result = await db.selectDistinct({ make: cars.make }).from(cars).orderBy(asc(cars.make));
    return result.map((r) => r.make).filter(Boolean);
  }),

  // ─── Get models for a make ───
  getModels: adminQuery
    .input(z.object({ make: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.selectDistinct({ model: cars.model })
        .from(cars)
        .where(eq(cars.make, input.make))
        .orderBy(asc(cars.model));
      return result.map((r) => r.model).filter(Boolean);
    }),

  // ─── Get modifications for make+model ───
  getModifications: adminQuery
    .input(z.object({ make: z.string(), model: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.selectDistinct({ modification: cars.modification })
        .from(cars)
        .where(and(eq(cars.make, input.make), eq(cars.model, input.model)))
        .orderBy(asc(cars.modification));
      return result.map((r) => r.modification).filter(Boolean);
    }),

  // ─── Update car images ───
  updateImages: adminQuery
    .input(z.object({
      id: z.string(),
      carPhotoUrl: z.string().optional(),
      carVectorUrl: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(cars).set({
        carPhotoUrl: input.carPhotoUrl,
        carVectorUrl: input.carVectorUrl,
      }).where(eq(cars.id, input.id));
      return { ok: true };
    }),

  // ─── Search car images ───
  searchImages: adminQuery
    .input(z.object({
      make: z.string(),
      model: z.string(),
    }))
    .query(async ({ input }) => {
      // Generate placeholder images based on car make/model
      const makeSlug = input.make.toLowerCase().replace(/\s+/g, "-");
      const modelSlug = input.model.toLowerCase().replace(/\s+/g, "-");

      return {
        photoUrl: `https://cdn.imagin.studio/getimage?customer=img&make=${encodeURIComponent(input.make)}&modelFamily=${encodeURIComponent(input.model)}&angle=01&width=800&zoomType=fullscreen`,
        vectorUrl: `https://cdn-frontend-r2.synsam.com/models/${makeSlug}-${modelSlug}.svg`,
        placeholders: [
          `https://placehold.co/600x400/e2e8f0/475569?text=${encodeURIComponent(input.make + " " + input.model)}`,
          `https://placehold.co/600x400/1e293b/94a3b8?text=${encodeURIComponent(input.make)}`,
        ],
      };
    }),

  // ─── Create new car ───
  create: adminQuery
    .input(z.object({
      make: z.string().min(1),
      model: z.string().min(1),
      yearFrom: z.number().optional(),
      yearTo: z.number().optional(),
      engineCode: z.string().optional(),
      engineCapacity: z.string().optional(),
      fuel: z.string().optional(),
      powerHp: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(cars).values({
        make: input.make,
        model: input.model,
        yearFrom: input.yearFrom || null,
        yearTo: input.yearTo || null,
        engineCode: input.engineCode || null,
        engineCapacity: input.engineCapacity || null,
        fuelTypeId: input.fuel === "Бензин" ? 1 : input.fuel === "Дизель" ? 2 : input.fuel === "Гибрид" ? 3 : input.fuel === "Электро" ? 4 : null,
        horsePower: input.powerHp || null,
        isActive: "active",
      }).$returningId();
      return { id: result.id, success: true };
    }),

  // ─── Count total cars ───
  count: adminQuery
    .input(z.object({
      make: z.string().optional(),
      model: z.string().optional(),
      modification: z.string().optional(),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [eq(cars.isActive, "active")];
      if (input?.make) conditions.push(like(cars.make, `%${input.make}%`));
      if (input?.model) conditions.push(like(cars.model, `%${input.model}%`));
      if (input?.modification) conditions.push(like(cars.modification, `%${input.modification}%`));
      const [result] = await db.select({ count: sql<number>`COUNT(*)` })
        .from(cars)
        .where(and(...conditions));
      return result?.count || 0;
    }),
});
