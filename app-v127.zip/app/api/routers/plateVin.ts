import { z } from "zod";
import { createRouter, adminQuery, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { plateVinRegistry } from "@db/schema";
import { eq, and, sql, desc, like } from "drizzle-orm";

export const plateVinRouter = createRouter({
  // ─── List all entries ───
  list: adminQuery
    .input(z.object({
      search: z.string().optional(),
      verified: z.enum(["yes", "no", "pending", "all"]).default("all"),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const conditions: any[] = [];

      if (input?.search) {
        const s = input.search.toLowerCase();
        conditions.push(sql`(
          LOWER(${plateVinRegistry.plateNumber}) LIKE ${"%" + s + "%"} OR
          LOWER(${plateVinRegistry.vin}) LIKE ${"%" + s + "%"} OR
          LOWER(${plateVinRegistry.make}) LIKE ${"%" + s + "%"} OR
          LOWER(${plateVinRegistry.model}) LIKE ${"%" + s + "%"}
        )`);
      }
      if (input?.verified && input.verified !== "all") {
        conditions.push(eq(plateVinRegistry.isVerified, input.verified as any));
      }

      const where = conditions.length > 0 ? and(...conditions) : undefined;

      const items = await db.select().from(plateVinRegistry)
        .where(where)
        .orderBy(desc(plateVinRegistry.createdAt))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);

      const countResult = await db.select({ count: sql<number>`COUNT(*)` }).from(plateVinRegistry).where(where);

      return { items, total: Number(countResult[0]?.count || 0) };
    }),

  // ─── Get by plate ───
  getByPlate: publicQuery
    .input(z.object({ plate: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [entry] = await db.select().from(plateVinRegistry)
        .where(sql`LOWER(${plateVinRegistry.plateNumber}) = LOWER(${input.plate})`)
        .limit(1);
      return entry || null;
    }),

  // ─── Get by VIN ───
  getByVin: publicQuery
    .input(z.object({ vin: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [entry] = await db.select().from(plateVinRegistry)
        .where(sql`LOWER(${plateVinRegistry.vin}) = LOWER(${input.vin})`)
        .limit(1);
      return entry || null;
    }),

  // ─── Create / Update ───
  upsert: adminQuery
    .input(z.object({
      plateNumber: z.string().min(3).max(20),
      vin: z.string().optional(),
      make: z.string().min(1),
      model: z.string().min(1),
      year: z.number().optional(),
      engineCode: z.string().optional(),
      engineCapacity: z.string().optional(),
      transmission: z.string().optional(),
      fuel: z.string().optional(),
      source: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();

      // Check if exists by plate
      const [existing] = await db.select().from(plateVinRegistry)
        .where(sql`LOWER(${plateVinRegistry.plateNumber}) = LOWER(${input.plateNumber})`)
        .limit(1);

      if (existing) {
        await db.update(plateVinRegistry).set({
          vin: input.vin || existing.vin,
          make: input.make,
          model: input.model,
          year: input.year || existing.year,
          engineCode: input.engineCode || existing.engineCode,
          engineCapacity: input.engineCapacity || existing.engineCapacity,
          transmission: input.transmission || existing.transmission,
          fuel: input.fuel || existing.fuel,
          source: input.source || existing.source,
          notes: input.notes || existing.notes,
          updatedAt: new Date(),
        }).where(eq(plateVinRegistry.id, existing.id));
        return { id: existing.id, action: "updated" };
      }

      const [result] = await db.insert(plateVinRegistry).values({
        plateNumber: input.plateNumber,
        vin: input.vin || null,
        make: input.make,
        model: input.model,
        year: input.year || null,
        engineCode: input.engineCode || null,
        engineCapacity: input.engineCapacity || null,
        transmission: input.transmission || null,
        fuel: input.fuel || null,
        source: input.source || "manual",
        notes: input.notes || null,
      }).$returningId();

      return { id: result.id, action: "created" };
    }),

  // ─── Verify entry ───
  verify: adminQuery
    .input(z.object({ id: z.number(), notes: z.string().optional() }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      await db.update(plateVinRegistry).set({
        isVerified: "yes",
        verifiedBy: ctx.user?.id,
        verifiedAt: new Date(),
        notes: input.notes || null,
      }).where(eq(plateVinRegistry.id, input.id));
      return { success: true };
    }),

  // ─── Update check/fill dates ───
  updateDates: adminQuery
    .input(z.object({
      id: z.number(),
      lastCheckedAt: z.string().optional(),
      lastFilledAt: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const updates: any = {};
      if (input.lastCheckedAt) updates.lastCheckedAt = new Date(input.lastCheckedAt);
      if (input.lastFilledAt) updates.lastFilledAt = new Date(input.lastFilledAt);
      await db.update(plateVinRegistry).set(updates).where(eq(plateVinRegistry.id, input.id));
      return { success: true };
    }),

  // ─── Delete ───
  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(plateVinRegistry).where(eq(plateVinRegistry.id, input.id));
      return { success: true };
    }),

  // ─── Stats ───
  stats: adminQuery.query(async () => {
    const db = getDb();
    const total = await db.select({ count: sql<number>`COUNT(*)` }).from(plateVinRegistry);
    const verified = await db.select({ count: sql<number>`COUNT(*)` }).from(plateVinRegistry).where(eq(plateVinRegistry.isVerified, "yes" as any));
    const pending = await db.select({ count: sql<number>`COUNT(*)` }).from(plateVinRegistry).where(eq(plateVinRegistry.isVerified, "pending" as any));
    const withVin = await db.select({ count: sql<number>`COUNT(*)` }).from(plateVinRegistry).where(sql`${plateVinRegistry.vin} IS NOT NULL AND ${plateVinRegistry.vin} != ''`);
    const recent = await db.select({ count: sql<number>`COUNT(*)` }).from(plateVinRegistry).where(sql`${plateVinRegistry.createdAt} >= DATE_SUB(NOW(), INTERVAL 7 DAY)`);

    return {
      total: Number(total[0]?.count || 0),
      verified: Number(verified[0]?.count || 0),
      pending: Number(pending[0]?.count || 0),
      withVin: Number(withVin[0]?.count || 0),
      recent: Number(recent[0]?.count || 0),
    };
  }),
});
