#!/usr/bin/env python3
"""
Import products from Excel file to MySQL database.
Usage: python import_products.py <excel_file>
"""
import sys
import json
import math
import pandas as pd
import pymysql

# Database connection — update these for your server
DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "",
    "database": "oilpodbor",
    "charset": "utf8mb4",
}

def clean_value(val):
    """Clean NaN and empty values."""
    if pd.isna(val):
        return None
    val = str(val).strip()
    if val == "" or val == "-":
        return None
    return val

def parse_price(val):
    """Parse price from string, return cents."""
    if pd.isna(val):
        return None
    try:
        price = float(str(val).replace(" ", "").replace(",", "."))
        return int(price * 100)  # Convert to cents
    except:
        return None

def slugify(name):
    """Create URL-friendly slug."""
    import re
    slug = re.sub(r'[^a-z0-9\-]', '-', name.lower())
    slug = re.sub(r'-+', '-', slug).strip('-')
    return slug[:200]

def extract_specs(row):
    """Extract technical specs from row."""
    specs = {}

    # Find SAE column
    for col in row.index:
        col_str = str(col).upper()
        if 'Viscosity' in col_str or 'SAE' in col_str:
            val = clean_value(row[col])
            if val:
                specs["viscosity"] = val
        if 'API' in col_str and 'ACEA' not in col_str:
            val = clean_value(row[col])
            if val:
                specs["api"] = val
        if 'ACEA' in col_str:
            val = clean_value(row[col])
            if val:
                specs["acea"] = val

    # Also check specific named columns
    sae = clean_value(row.get('Вязкость SAE', '')) or clean_value(row.get('Viscosity SAE', ''))
    if sae:
        specs["viscosity"] = sae

    api = clean_value(row.get('API', ''))
    if api:
        specs["api"] = api

    acea = clean_value(row.get('ACEA', ''))
    if acea:
        specs["acea"] = acea

    return specs if specs else None

def main():
    if len(sys.argv) < 2:
        print("Usage: python import_products.py <excel_file>")
        sys.exit(1)

    excel_file = sys.argv[1]

    # Read Excel — skip first row (header is on row 2)
    df = pd.read_excel(excel_file, header=1)

    print(f"Loaded {len(df)} rows from {excel_file}")
    print(f"Columns: {list(df.columns)}")

    # Connect to DB
    conn = pymysql.connect(**DB_CONFIG)
    cursor = conn.cursor()

    # Clear existing products
    cursor.execute("DELETE FROM products")
    conn.commit()
    print("Cleared existing products")

    inserted = 0
    errors = 0

    for idx, row in df.iterrows():
        try:
            # Extract fields
            ksss = clean_value(row.get('КССС', ''))
            name_ru = clean_value(row.get('Наименование продукции', ''))
            name_eng = clean_value(row.get('Наименование продукции ENG', ''))
            tara = clean_value(row.get('Вид тары\n(1 - 1000л)', ''))
            ves = clean_value(row.get('Вес** продукта, кг', ''))
            tex_spec = clean_value(row.get('Технические характеристики', ''))
            price_type = clean_value(row.get('Тип цены В2В/В2С', ''))
            price_rrp = row.get('РРПруб/шт***', None)
            price_per_liter = row.get('РРПруб/л', None)
            gtin = clean_value(row.get('GTIN', ''))
            full_name = clean_value(row.get('Полное наименовение', ''))
            volume = clean_value(row.get('Объемфасовки', ''))
            fasovka = clean_value(row.get('Фасовка', ''))
            product_type = clean_value(row.get('Продукт', ''))
            direction = clean_value(row.get('Направление', ''))
            brand = clean_value(row.get('Бренд', ''))
            line = clean_value(row.get('Линейка', ''))
            subline = clean_value(row.get('Под-линейка', ''))
            vid = clean_value(row.get('Вид', ''))
            sae = clean_value(row.get('Вязкость SAE', ''))
            api = clean_value(row.get('API', ''))
            acea = clean_value(row.get('ACEA', ''))
            category_section = clean_value(row.get('Наименование раздела', ''))

            # Build product name
            name = full_name or name_ru or name_eng or f"Product {ksss}"
            if not name or name == "None":
                errors += 1
                continue

            # Parse price
            price_cents = parse_price(price_rrp)

            # Build specs
            specs = {}
            if sae: specs["viscosity"] = sae
            if api: specs["api"] = api
            if acea: specs["acea"] = acea
            if vid: specs["type"] = vid
            if tex_spec: specs["technicalSpec"] = tex_spec

            # Build description
            description_parts = []
            if direction: description_parts.append(f"Направление: {direction}")
            if line: description_parts.append(f"Линейка: {line}")
            if subline: description_parts.append(f"Серия: {subline}")
            if tara: description_parts.append(f"Тара: {tara}")
            if ves: description_parts.append(f"Вес: {ves} кг")
            if gtin: description_parts.append(f"GTIN: {gtin}")
            description = "\n".join(description_parts) if description_parts else None

            # Build badges
            badges = []
            if clean_value(row.get('Статус производства', '')) == 'Активный':
                badges.append({"text": "В наличии", "color": "green"})
            if price_type:
                badges.append({"text": price_type, "color": "blue"})

            # Slug
            slug = slugify(name) + f"-{ksss or idx}"

            # Category
            category = category_section or direction or "Другое"

            # Image URL placeholder
            image_url = None

            # Insert into DB
            cursor.execute("""
                INSERT INTO products (
                    name, slug, sku, brand, category, subcategory, description,
                    price, volume, specs, imageUrl, inStock, badges, currency,
                    deliveryText, sellerName
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                name, slug, str(ksss) if ksss else None,
                brand or "ЛУКОЙЛ", category, subline or line or None,
                description, price_cents, volume,
                json.dumps(specs, ensure_ascii=False) if specs else None,
                image_url, "yes" if clean_value(row.get('Статус производства', '')) == 'Активный' else "no",
                json.dumps(badges, ensure_ascii=False) if badges else None,
                "RUB", "Завтра", "OILPODBOR"
            ))

            inserted += 1

        except Exception as e:
            errors += 1
            print(f"  Error on row {idx}: {e}")

    conn.commit()
    cursor.close()
    conn.close()

    print(f"\nDone! Inserted: {inserted}, Errors: {errors}")

if __name__ == "__main__":
    main()
