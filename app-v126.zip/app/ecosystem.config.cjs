module.exports = {
  apps: [
    {
      name: "oilpodbor",
      script: "./dist/boot.js",
      cwd: "/var/www/oilpodbor",
      instances: 1,
      exec_mode: "fork",
      env: {
        NODE_ENV: "production",
        PORT: 3000,
      },
      // Auto-restart on crash
      autorestart: true,
      // Restart memory limit (512MB)
      max_memory_restart: "512M",
      // Log files
      out_file: "./logs/out.log",
      error_file: "./logs/error.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss Z",
      // Graceful shutdown
      kill_timeout: 5000,
      // Wait between restarts
      restart_delay: 3000,
      // Max restarts in 10 seconds
      max_restarts: 10,
      // Min uptime to be considered stable
      min_uptime: "10s",
    },
  ],
};
