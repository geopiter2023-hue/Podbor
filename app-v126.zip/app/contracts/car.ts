import { z } from "zod";

export const brandSchema = z.object({
  id: z.number(),
  name: z.string().nullable(),
});

export const modelSchema = z.object({
  modelId: z.number(),
  makeId: z.number(),
  modelName: z.string().nullable(),
  yearFrom: z.string().nullable(),
  yearTo: z.string().nullable(),
});

export const modificationSchema = z.object({
  id: z.number(),
  name: z.string().nullable(),
  engineCode: z.string().nullable(),
  constructionType: z.string().nullable(),
  fuel: z.string().nullable(),
  horsePower: z.string().nullable(),
  startDate: z.string().nullable(),
  endDate: z.string().nullable(),
  engineCapacity: z.string().nullable(),
  motorType: z.string().nullable(),
});

export const oilSchema = z.object({
  id: z.number(),
  makeId: z.number().nullable(),
  modelId: z.number().nullable(),
  modificationId: z.number().nullable(),
  originalName: z.string().nullable(),
  artNumber: z.string().nullable(),
  volume: z.string().nullable(),
  commentName: z.string().nullable(),
  orderPosition: z.number().nullable(),
});

export type Brand = z.infer<typeof brandSchema>;
export type CarModel = z.infer<typeof modelSchema>;
export type Modification = z.infer<typeof modificationSchema>;
export type Oil = z.infer<typeof oilSchema>;
