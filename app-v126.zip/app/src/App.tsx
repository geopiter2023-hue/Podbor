import { Routes, Route } from 'react-router'
import { Component, type ReactNode } from 'react'
import Home from './pages/Home'
import Login from "./pages/Login"
import NotFound from "./pages/NotFound"
import Admin from "./pages/Admin"
import Company from "./pages/Company"
import Widget from "./pages/Widget"
import Marketplace from "./pages/Marketplace"
import ServiceBook from "./pages/ServiceBook"

// Global Error Boundary - catches render crashes and shows error details
class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean; errorMsg: string }> {
  constructor(props: { children: ReactNode }) {
    super(props)
    this.state = { hasError: false, errorMsg: "" }
  }
  static getDerivedStateFromError(error: any) {
    return { hasError: true, errorMsg: String(error?.message || error || "Unknown error") }
  }
  componentDidCatch(error: any, info: any) {
    console.error("[App ErrorBoundary]", error, info)
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#fff", padding: "20px" }}>
          <div style={{ maxWidth: "600px", textAlign: "center" }}>
            <div style={{ width: "64px", height: "64px", background: "#fee2e2", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#d32f2f" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>
            </div>
            <h1 style={{ fontSize: "20px", fontWeight: "bold", color: "#1a1a1a", marginBottom: "8px" }}>Ошибка загрузки страницы</h1>
            <p style={{ fontSize: "14px", color: "#666", marginBottom: "16px" }}>Произошла ошибка при открытии страницы. Попробуйте обновить.</p>
            <pre style={{ background: "#f5f5f5", padding: "12px", borderRadius: "8px", fontSize: "12px", color: "#d32f2f", textAlign: "left", overflowWrap: "break-word", maxHeight: "200px", overflow: "auto" }}>{this.state.errorMsg}</pre>
            <div style={{ marginTop: "16px", display: "flex", gap: "8px", justifyContent: "center" }}>
              <button onClick={() => window.location.reload()} style={{ background: "#d32f2f", color: "#fff", border: "none", padding: "10px 24px", borderRadius: "8px", fontSize: "14px", cursor: "pointer" }}>Обновить страницу</button>
              <button onClick={() => { this.setState({ hasError: false, errorMsg: "" }); window.location.hash = "/"; }} style={{ background: "#f5f5f5", color: "#333", border: "none", padding: "10px 24px", borderRadius: "8px", fontSize: "14px", cursor: "pointer" }}>На главную</button>
            </div>
          </div>
        </div>
      )
    }
    return this.props.children
  }
}

// Lazy load Admin to reduce initial bundle
// import { lazy, Suspense } from 'react'
// const Admin = lazy(() => import('./pages/Admin'))

export default function App() {
  return (
    <ErrorBoundary>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/company" element={<Company />} />
        <Route path="/embed" element={<Widget />} />
        <Route path="/marketplace" element={<Marketplace />} />
        <Route path="/service-book/:make/:model" element={<ServiceBook />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </ErrorBoundary>
  )
}
