import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { useNavigate, useSearchParams } from "react-router";
import {
  Building2,
  Package,
  Link2,
  Plus,
  Trash2,
  ChevronLeft,
  X,
  BarChart3,
  Users,
  Activity,
  Search,
  TrendingUp,
  Eye,
} from "lucide-react";

type Tab = "dashboard" | "products" | "assignments" | "stats";

function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative bg-[#0a0a0a] border border-[#262626] rounded-lg w-full max-w-lg max-h-[80vh] overflow-auto">
        <div className="flex items-center justify-between p-4 border-b border-[#262626]">
          <h3 className="text-white font-semibold">{title}</h3>
          <button onClick={onClose} className="text-[#a3a3a3] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}

// ─── Products Tab ───
function ProductsTab({ companyId, myRole }: { companyId: number; myRole: string }) {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.company.listProducts.useQuery({ companyId });
  const createProduct = trpc.company.createProduct.useMutation({
    onSuccess: () => utils.company.listProducts.invalidate({ companyId }),
  });
  const deleteProduct = trpc.company.deleteProduct.useMutation({
    onSuccess: () => utils.company.listProducts.invalidate({ companyId }),
  });

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    name: "",
    sku: "",
    brand: "",
    category: "",
    description: "",
    price: 0,
    volume: "",
    specs: "",
  });

  const canEdit = myRole === "owner" || myRole === "manager";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const specsObj = form.specs
      ? Object.fromEntries(
          form.specs.split(",").map((s) => {
            const [k, v] = s.split("=");
            return [k?.trim(), v?.trim()];
          })
        )
      : undefined;
    createProduct.mutate({
      companyId,
      name: form.name,
      sku: form.sku,
      brand: form.brand || undefined,
      category: form.category || undefined,
      description: form.description || undefined,
      price: form.price * 100 || undefined,
      volume: form.volume || undefined,
      specs: specsObj,
    });
    setModalOpen(false);
    setForm({ name: "", sku: "", brand: "", category: "", description: "", price: 0, volume: "", specs: "" });
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-white text-xl font-semibold">Продукты компании</h2>
        {canEdit && (
          <button
            onClick={() => setModalOpen(true)}
            className="flex items-center gap-2 bg-[#f59e0b] text-black px-4 py-2 rounded-lg font-medium hover:bg-[#f59e0b]/90 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Добавить продукт
          </button>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 rounded-lg shimmer-skeleton" />
          ))}
        </div>
      ) : data?.length === 0 ? (
        <div className="text-center py-16 text-[#a3a3a3]">
          <Package className="w-12 h-12 mx-auto mb-4 text-[#525252]" />
          <p>Продуктов пока нет</p>
          {canEdit && <p className="text-sm mt-2">Добавьте первый продукт</p>}
        </div>
      ) : (
        <div className="bg-[#171717] border border-[#262626] rounded-lg overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#262626]">
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">SKU</th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">Название</th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">Бренд</th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">Категория</th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">Цена</th>
                <th className="text-left p-4 text-[#a3a3a3] text-sm font-medium">Объём</th>
                {canEdit && <th className="text-right p-4 text-[#a3a3a3] text-sm font-medium">Действия</th>}
              </tr>
            </thead>
            <tbody>
              {data?.map((p) => (
                <tr key={p.id} className="border-b border-[#262626] last:border-0 hover:bg-[#1f1f1f]">
                  <td className="p-4 font-mono-tech text-xs text-[#f59e0b]">{p.sku}</td>
                  <td className="p-4 text-white text-sm">{p.name}</td>
                  <td className="p-4 text-[#a3a3a3] text-sm">{p.brand || "—"}</td>
                  <td className="p-4 text-[#a3a3a3] text-sm">{p.category || "—"}</td>
                  <td className="p-4 text-white text-sm">{p.price ? `${(p.price / 100).toFixed(0)} ₽` : "—"}</td>
                  <td className="p-4 text-[#a3a3a3] text-sm">{p.volume || "—"}</td>
                  {canEdit && (
                    <td className="p-4 text-right">
                      <button
                        onClick={() => p.id && deleteProduct.mutate({ companyId, id: p.id })}
                        className="text-[#525252] hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {canEdit && (
        <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Новый продукт">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#a3a3a3] text-sm mb-1">Название *</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none" />
              </div>
              <div>
                <label className="block text-[#a3a3a3] text-sm mb-1">SKU *</label>
                <input required value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })}
                  className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white font-mono-tech focus:border-[#f59e0b] focus:outline-none" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#a3a3a3] text-sm mb-1">Бренд</label>
                <input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })}
                  className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none" />
              </div>
              <div>
                <label className="block text-[#a3a3a3] text-sm mb-1">Категория</label>
                <input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#a3a3a3] text-sm mb-1">Цена (₽)</label>
                <input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
                  className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none" />
              </div>
              <div>
                <label className="block text-[#a3a3a3] text-sm mb-1">Объём</label>
                <input value={form.volume} onChange={(e) => setForm({ ...form, volume: e.target.value })}
                  className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none" />
              </div>
            </div>
            <div>
              <label className="block text-[#a3a3a3] text-sm mb-1">Описание</label>
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2}
                className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white focus:border-[#f59e0b] focus:outline-none" />
            </div>
            <div>
              <label className="block text-[#a3a3a3] text-sm mb-1">Спецификации (key=value, через запятую)</label>
              <input value={form.specs} onChange={(e) => setForm({ ...form, specs: e.target.value })} placeholder="viscosity=5W-30, api=SN"
                className="w-full bg-[#171717] border border-[#262626] rounded-lg px-3 py-2 text-white font-mono-tech text-xs focus:border-[#f59e0b] focus:outline-none" />
            </div>
            <button type="submit" className="w-full bg-[#f59e0b] text-black font-medium py-2 rounded-lg hover:bg-[#f59e0b]/90 transition-colors">
              Создать продукт
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
}

// ─── Stats Tab ───
function StatsTab({ companyId }: { companyId: number }) {
  const { data: overview } = trpc.stats.overview.useQuery({ companyId });
  const { data: dailyChart } = trpc.stats.dailyChart.useQuery({ companyId, days: 30 });
  const { data: recent } = trpc.stats.recentSearches.useQuery({ companyId, limit: 20 });
  const { data: topCars } = trpc.stats.topCars.useQuery({ companyId, limit: 10 });

  const maxCount = Math.max(...(dailyChart?.map((d) => d.count) || [1]), 1);

  return (
    <div>
      <h2 className="text-white text-xl font-semibold mb-6">Статистика запросов</h2>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-[#171717] border border-[#262626] rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[#a3a3a3] text-xs">Всего запросов</span>
            <Search className="w-4 h-4 text-[#f59e0b]" />
          </div>
          <span className="text-white text-2xl font-bold">{overview?.searches.total || 0}</span>
        </div>
        <div className="bg-[#171717] border border-[#262626] rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[#a3a3a3] text-xs">Сегодня</span>
            <Activity className="w-4 h-4 text-green-400" />
          </div>
          <span className="text-white text-2xl font-bold">{overview?.searches.today || 0}</span>
        </div>
        <div className="bg-[#171717] border border-[#262626] rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[#a3a3a3] text-xs">За 7 дней</span>
            <TrendingUp className="w-4 h-4 text-blue-400" />
          </div>
          <span className="text-white text-2xl font-bold">{overview?.searches.thisWeek || 0}</span>
        </div>
        <div className="bg-[#171717] border border-[#262626] rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[#a3a3a3] text-xs">Уникальных авто</span>
            <Eye className="w-4 h-4 text-purple-400" />
          </div>
          <span className="text-white text-2xl font-bold">{overview?.searches.uniqueCars || 0}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Chart */}
        <div className="bg-[#171717] border border-[#262626] rounded-lg p-5">
          <h3 className="text-white font-medium text-sm mb-4">Запросы по дням</h3>
          {dailyChart && dailyChart.length > 0 ? (
            <div className="space-y-2">
              {dailyChart.map((d, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-[#a3a3a3] text-xs w-20 flex-shrink-0">{d.date}</span>
                  <div className="flex-1 bg-[#0a0a0a] rounded-full h-5 overflow-hidden">
                    <div
                      className="bg-[#f59e0b] h-full rounded-full transition-all duration-500"
                      style={{ width: `${(d.count / maxCount) * 100}%` }}
                    />
                  </div>
                  <span className="text-white text-xs w-8 text-right">{d.count}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-[#525252] text-sm text-center py-8">Нет данных</p>
          )}
        </div>

        {/* Top Cars */}
        <div className="bg-[#171717] border border-[#262626] rounded-lg p-5">
          <h3 className="text-white font-medium text-sm mb-4">Топ автомобилей</h3>
          {topCars && topCars.length > 0 ? (
            <div className="space-y-2">
              {topCars.map((car, i) => (
                <div key={i} className="flex items-center gap-3 p-2 bg-[#0a0a0a] rounded-lg">
                  <span className="text-[#f59e0b] text-xs font-mono-tech w-5">#{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-xs truncate">
                      {car.makeName} {car.modelName}
                    </p>
                    <p className="text-[#525252] text-[10px]">
                      {car.modificationName} {car.engineCode ? `(${car.engineCode})` : ""}
                    </p>
                  </div>
                  <span className="text-[#f59e0b] text-xs font-medium">{car.count}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-[#525252] text-sm text-center py-8">Нет данных</p>
          )}
        </div>
      </div>

      {/* Recent Searches */}
      <div className="mt-6 bg-[#171717] border border-[#262626] rounded-lg overflow-hidden">
        <div className="p-4 border-b border-[#262626]">
          <h3 className="text-white font-medium text-sm">Последние запросы</h3>
        </div>
        {recent && recent.length > 0 ? (
          <div className="overflow-auto max-h-96">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#262626]">
                  <th className="text-left p-3 text-[#a3a3a3] text-xs font-medium">Автомобиль</th>
                  <th className="text-left p-3 text-[#a3a3a3] text-xs font-medium">Модификация</th>
                  <th className="text-left p-3 text-[#a3a3a3] text-xs font-medium">Домен</th>
                  <th className="text-left p-3 text-[#a3a3a3] text-xs font-medium">Время</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((r) => (
                  <tr key={r.id} className="border-b border-[#262626] last:border-0 hover:bg-[#1f1f1f]">
                    <td className="p-3 text-white text-xs">
                      {r.makeName} {r.modelName}
                    </td>
                    <td className="p-3 text-[#a3a3a3] text-xs">
                      {r.modificationName || "—"}
                      {r.engineCode ? ` (${r.engineCode})` : ""}
                    </td>
                    <td className="p-3 font-mono-tech text-xs text-[#f59e0b]">{r.domain || "—"}</td>
                    <td className="p-3 text-[#525252] text-xs">
                      {r.createdAt
                        ? new Date(r.createdAt).toLocaleString("ru-RU", {
                            day: "2-digit",
                            month: "2-digit",
                            hour: "2-digit",
                            minute: "2-digit",
                          })
                        : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-[#525252] text-sm text-center py-8">Пока нет запросов</p>
        )}
      </div>
    </div>
  );
}

// ─── Main Company Page ───
export default function CompanyPage() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const companyId = Number(searchParams.get("id"));
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");

  const { data: companyData } = trpc.company.getCompany.useQuery(
    { companyId },
    { enabled: !!companyId && isAuthenticated }
  );

  const { data: stats } = trpc.company.stats.useQuery(
    { companyId },
    { enabled: !!companyId && isAuthenticated }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#f59e0b] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-lg mb-4">Требуется авторизация</p>
          <button onClick={() => navigate("/login")} className="bg-[#f59e0b] text-black px-6 py-2 rounded-lg font-medium">
            Войти
          </button>
        </div>
      </div>
    );
  }

  if (!companyId || !companyData) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center text-[#a3a3a3]">
          <Building2 className="w-12 h-12 mx-auto mb-4 text-[#525252]" />
          <p className="text-white text-lg mb-2">Компания не найдена</p>
          <p className="text-sm mb-4">У вас нет доступа к этой компании</p>
          <button onClick={() => navigate("/")} className="text-[#f59e0b] hover:underline">
            На главную
          </button>
        </div>
      </div>
    );
  }

  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: "dashboard", label: "Обзор", icon: BarChart3 },
    { id: "stats", label: "Статистика", icon: Activity },
    { id: "products", label: "Продукты", icon: Package },
    { id: "assignments", label: "Привязки", icon: Link2 },
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-[#262626] bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-[#f59e0b] flex items-center justify-center">
              <Building2 className="w-4 h-4 text-black" />
            </div>
            <div>
              <h1 className="text-white font-semibold text-sm">{companyData.company?.name}</h1>
              <p className="text-[#525252] text-xs">
                Кабинет компании · {companyData.myRole}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-[#a3a3a3] text-sm">{user?.name}</span>
            <button onClick={() => navigate("/")} className="text-[#a3a3a3] hover:text-white text-sm flex items-center gap-1">
              <ChevronLeft className="w-4 h-4" />На главную
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 flex gap-8">
        {/* Sidebar */}
        <nav className="w-48 flex-shrink-0">
          <div className="space-y-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                  activeTab === tab.id
                    ? "bg-[#f59e0b]/10 text-[#f59e0b] border border-[#f59e0b]/20"
                    : "text-[#a3a3a3] hover:bg-[#171717] hover:text-white"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Members */}
          <div className="mt-8 pt-6 border-t border-[#262626]">
            <h3 className="text-[#525252] text-xs uppercase tracking-wider mb-3 flex items-center gap-2">
              <Users className="w-3 h-3" />Участники
            </h3>
            <div className="space-y-2">
              {companyData.members?.map((m) => (
                <div key={m.id} className="flex items-center gap-2 px-2">
                  <div className="w-6 h-6 rounded-full bg-[#262626] flex items-center justify-center text-xs text-[#a3a3a3]">
                    {(m.name || "?").charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-xs truncate">{m.name || "—"}</p>
                    <p className="text-[#525252] text-[10px] uppercase">{m.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </nav>

        {/* Content */}
        <main className="flex-1 min-w-0">
          {activeTab === "dashboard" && (
            <div>
              <h2 className="text-white text-xl font-semibold mb-6">Обзор компании</h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#171717] border border-[#262626] rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[#a3a3a3] text-sm">Продуктов</span>
                    <Package className="w-5 h-5 text-[#f59e0b]" />
                  </div>
                  <span className="text-white text-3xl font-bold">{stats?.products || 0}</span>
                </div>
                <div className="bg-[#171717] border border-[#262626] rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[#a3a3a3] text-sm">Привязок</span>
                    <Link2 className="w-5 h-5 text-[#f59e0b]" />
                  </div>
                  <span className="text-white text-3xl font-bold">{stats?.assignments || 0}</span>
                </div>
              </div>

              <div className="mt-8 bg-[#171717] border border-[#262626] rounded-lg p-6">
                <h3 className="text-white font-medium mb-4">Быстрые действия</h3>
                <div className="grid grid-cols-2 gap-3">
                  <button onClick={() => setActiveTab("products")}
                    className="selector-card text-left flex items-center gap-3">
                    <Package className="w-5 h-5 text-[#f59e0b]" />
                    <div>
                      <span className="text-white text-sm block">Каталог продуктов</span>
                      <span className="text-[#525252] text-xs">Управление SKU</span>
                    </div>
                  </button>
                  <button onClick={() => setActiveTab("assignments")}
                    className="selector-card text-left flex items-center gap-3">
                    <Link2 className="w-5 h-5 text-[#f59e0b]" />
                    <div>
                      <span className="text-white text-sm block">Привязки к авто</span>
                      <span className="text-[#525252] text-xs">Продукт → автомобиль</span>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "stats" && <StatsTab companyId={companyId} />}

          {activeTab === "products" && (
            <ProductsTab companyId={companyId} myRole={companyData.myRole || "viewer"} />
          )}

          {activeTab === "assignments" && (
            <div>
              <h2 className="text-white text-xl font-semibold mb-6">Привязки к автомобилям</h2>
              <p className="text-[#a3a3a3] text-sm">
                Управляйте привязками через публичный подбор масел. Выберите автомобиль и привяжите продукты к нему.
              </p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
