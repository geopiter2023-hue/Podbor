import { useState, useEffect, useCallback, useRef } from "react";
import { WidgetTRPCProvider, widgetTrpc } from "@/providers/widget-trpc";
import { Droplets, ChevronRight, ChevronLeft, Car, Zap } from "lucide-react";

// ─── Resize helper ───
function useResizeToParent() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const sendHeight = () => {
      if (containerRef.current) {
        const height = containerRef.current.scrollHeight;
        window.parent.postMessage(
          { type: "motornaya-resize", height: Math.max(height + 20, 400) },
          "*"
        );
      }
    };

    sendHeight();
    const interval = setInterval(sendHeight, 500);
    window.addEventListener("load", sendHeight);

    return () => {
      clearInterval(interval);
      window.removeEventListener("load", sendHeight);
    };
  }, []);

  return containerRef;
}

// ─── Types ───
interface CarSelection {
  makeId: number;
  makeName: string;
  modelId: number;
  modelName: string;
  modificationId: number;
  modificationName: string;
  engineCode?: string;
}

// ─── Widget Content ───
function WidgetContent({ apiKey }: { apiKey: string }) {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [selection, setSelection] = useState<Partial<CarSelection>>({});
  const [error, setError] = useState("");
  const containerRef = useResizeToParent();

  const { data: makes, isLoading: makesLoading } =
    widgetTrpc.widget.brands.useQuery({ apiKey });
  const { data: models, isLoading: modelsLoading } =
    widgetTrpc.widget.models.useQuery(
      { apiKey, makeId: selection.makeId || 0 },
      { enabled: !!selection.makeId }
    );
  const { data: modifications, isLoading: modLoading } =
    widgetTrpc.widget.modifications.useQuery(
      {
        apiKey,
        makeId: selection.makeId || 0,
        modelId: selection.modelId || 0,
      },
      { enabled: !!selection.makeId && !!selection.modelId }
    );
  const { data: results, isLoading: resultsLoading } =
    widgetTrpc.widget.results.useQuery(
      {
        apiKey,
        makeId: selection.makeId || 0,
        modelId: selection.modelId || 0,
        modificationId: selection.modificationId || 0,
      },
      { enabled: !!selection.modificationId && step === 4 }
    );

  const handleSelectMake = useCallback(
    (makeId: number, makeName: string) => {
      setSelection({ makeId, makeName });
      setStep(2);
      setError("");
    },
    []
  );

  const handleSelectModel = useCallback(
    (modelId: number, modelName: string) => {
      setSelection((prev) => ({ ...prev, modelId, modelName }));
      setStep(3);
      setError("");
    },
    []
  );

  const handleSelectModification = useCallback(
    (modificationId: number, modificationName: string, engineCode?: string) => {
      setSelection((prev) => ({
        ...prev,
        modificationId,
        modificationName,
        engineCode,
      }));
      setStep(4);
      setError("");
    },
    []
  );

  const handleBack = useCallback(() => {
    setStep((prev) => (Math.max(prev - 1, 1) as 1 | 2 | 3 | 4));
    setError("");
  }, []);

  return (
    <div ref={containerRef} className="bg-[#0a0a0a] min-h-[400px]">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#f59e0b] to-[#fbbf24] px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Droplets className="w-5 h-5 text-black" />
          <span className="text-black font-bold text-sm">Подбор масла</span>
        </div>
        {step > 1 && (
          <button
            onClick={handleBack}
            className="flex items-center gap-1 text-black/70 hover:text-black text-xs transition-colors"
          >
            <ChevronLeft className="w-3 h-3" /> Назад
          </button>
        )}
      </div>

      {/* Breadcrumbs */}
      {step > 1 && selection.makeName && (
        <div className="px-4 py-2 bg-black/50 border-b border-[#262626] flex items-center gap-1 text-xs">
          <Car className="w-3 h-3 text-[#f59e0b]" />
          <span className="text-[#a3a3a3]">{selection.makeName}</span>
          {selection.modelName && (
            <>
              <ChevronRight className="w-3 h-3 text-[#525252]" />
              <span className="text-[#a3a3a3]">{selection.modelName}</span>
            </>
          )}
          {selection.modificationName && step === 4 && (
            <>
              <ChevronRight className="w-3 h-3 text-[#525252]" />
              <span className="text-[#a3a3a3] truncate max-w-[150px]">
                {selection.modificationName}
              </span>
            </>
          )}
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="mx-4 mt-3 bg-red-500/10 border border-red-500/20 rounded-lg p-2 text-red-400 text-xs">
          {error}
        </div>
      )}

      {/* Step 1: Brands */}
      {step === 1 && (
        <div className="p-4">
          <h3 className="text-white text-sm font-medium mb-3">Выберите марку</h3>
          {makesLoading ? (
            <div className="flex justify-center py-8">
              <div className="w-6 h-6 border-2 border-[#f59e0b] border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {makes?.map((make) => (
                <button
                  key={make.id}
                  onClick={() => handleSelectMake(make.id, make.name || "")}
                  className="selector-card text-left px-3 py-2.5 text-white text-xs hover:border-[#f59e0b]/50 transition-all"
                >
                  {make.name}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Step 2: Models */}
      {step === 2 && (
        <div className="p-4">
          <h3 className="text-white text-sm font-medium mb-3">Выберите модель</h3>
          {modelsLoading ? (
            <div className="flex justify-center py-8">
              <div className="w-6 h-6 border-2 border-[#f59e0b] border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <div className="space-y-1 max-h-[350px] overflow-auto">
              {models?.map((model) => (
                <button
                  key={model.modelId}
                  onClick={() =>
                    handleSelectModel(model.modelId, model.modelName || "")
                  }
                  className="w-full selector-card text-left px-3 py-2.5 flex items-center justify-between"
                >
                  <div>
                    <span className="text-white text-xs block">
                      {model.modelName}
                    </span>
                    <span className="text-[#525252] text-[10px]">
                      {model.yearFrom} — {model.yearTo || "н.в."}
                    </span>
                  </div>
                  <ChevronRight className="w-3 h-3 text-[#525252]" />
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Step 3: Modifications */}
      {step === 3 && (
        <div className="p-4">
          <h3 className="text-white text-sm font-medium mb-3">Выберите двигатель</h3>
          {modLoading ? (
            <div className="flex justify-center py-8">
              <div className="w-6 h-6 border-2 border-[#f59e0b] border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <div className="space-y-1 max-h-[350px] overflow-auto">
              {modifications?.map((mod) => (
                <button
                  key={mod.id}
                  onClick={() =>
                    handleSelectModification(
                      mod.id,
                      mod.name || "",
                      mod.engineCode || undefined
                    )
                  }
                  className="w-full selector-card text-left px-3 py-2.5"
                >
                  <span className="text-white text-xs block">{mod.name}</span>
                  <div className="flex items-center gap-2 mt-0.5">
                    {mod.engineCode && (
                      <span className="text-[#f59e0b] text-[10px] font-mono-tech">
                        {mod.engineCode}
                      </span>
                    )}
                    {mod.fuel && (
                      <span className="text-[#525252] text-[10px]">
                        {mod.fuel}
                      </span>
                    )}
                    {mod.horsePower && (
                      <span className="text-[#525252] text-[10px]">
                        {mod.horsePower} л.с.
                      </span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Step 4: Results */}
      {step === 4 && (
        <div className="p-4">
          {resultsLoading ? (
            <div className="flex justify-center py-8">
              <div className="w-6 h-6 border-2 border-[#f59e0b] border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <div>
              {/* Car Info */}
              <div className="mb-4 p-3 bg-[#171717] border border-[#262626] rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Car className="w-4 h-4 text-[#f59e0b]" />
                  <span className="text-white text-sm font-medium">
                    {results?.carInfo?.make} {results?.carInfo?.model}
                  </span>
                </div>
                <span className="text-[#a3a3a3] text-xs">
                  {results?.carInfo?.modification}
                </span>
                {results?.carInfo?.engineCode && (
                  <span className="text-[#f59e0b] text-xs ml-2 font-mono-tech">
                    {results.carInfo.engineCode}
                  </span>
                )}
              </div>

              {/* Company Products */}
              {results?.companyProducts && results.companyProducts.length > 0 && (
                <div className="mb-4">
                  <h4 className="text-[#f59e0b] text-xs uppercase tracking-wider mb-2 flex items-center gap-1">
                    <Zap className="w-3 h-3" />
                    Рекомендуемые масла
                  </h4>
                  <div className="space-y-2">
                    {results.companyProducts.map((product) => (
                      <div
                        key={product.id}
                        className={`p-3 rounded-lg border ${
                          product.isRecommended === "yes"
                            ? "bg-[#f59e0b]/5 border-[#f59e0b]/30"
                            : "bg-[#171717] border-[#262626]"
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <span className="text-white text-xs font-medium block">
                              {product.name}
                            </span>
                            <span className="text-[#525252] text-[10px]">
                              {product.brand} · {product.volume}
                            </span>
                          </div>
                          {product.price && (
                            <span className="text-[#f59e0b] text-xs font-medium">
                              {(product.price / 100).toFixed(0)} ₽
                            </span>
                          )}
                        </div>
                        {product.notes && (
                          <p className="text-[#a3a3a3] text-[10px] mt-1">
                            {product.notes}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Catalog Oils */}
              {results?.catalogOils && results.catalogOils.length > 0 && (
                <div>
                  <h4 className="text-[#a3a3a3] text-xs uppercase tracking-wider mb-2">
                    Каталожные данные
                  </h4>
                  <div className="space-y-1">
                    {results.catalogOils.map((oil) => (
                      <div
                        key={oil.id}
                        className="flex items-center justify-between p-2 bg-[#171717] rounded-lg"
                      >
                        <div className="flex items-center gap-2">
                          <Droplets className="w-3 h-3 text-[#525252]" />
                          <span className="text-white text-xs">
                            {oil.originalName}
                          </span>
                        </div>
                        {oil.volume && (
                          <span className="text-[#a3a3a3] text-[10px]">
                            {oil.volume}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {(!results?.catalogOils || results.catalogOils.length === 0) &&
                (!results?.companyProducts ||
                  results.companyProducts.length === 0) && (
                  <p className="text-[#a3a3a3] text-sm text-center py-8">
                    Данные не найдены
                  </p>
                )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Main Widget Page ───
export default function WidgetPage() {
  const [apiKey, setApiKey] = useState("");
  const [valid, setValid] = useState<boolean | null>(null);
  const [companyName, setCompanyName] = useState("");

  // Parse API key from URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const key = params.get("apiKey");
    if (key) {
      setApiKey(key);
    } else {
      setValid(false);
    }
  }, []);

  // Validate API key
  const { data: validation, isLoading: validating } =
    widgetTrpc.widget.validate.useQuery(
      { apiKey },
      { enabled: !!apiKey, retry: false }
    );

  useEffect(() => {
    if (validation) {
      if (validation.valid) {
        setValid(true);
        setCompanyName(validation.company?.name || "");
      } else {
        setValid(false);
      }
    }
  }, [validation]);

  // Handle validation error
  useEffect(() => {
    if (!validating && apiKey && !validation) {
      setValid(false);
    }
  }, [validating, apiKey, validation]);

  if (valid === false) {
    return (
      <div className="min-h-[200px] bg-[#0a0a0a] flex items-center justify-center p-6">
        <div className="text-center">
          <p className="text-red-400 text-sm mb-2">Ошибка авторизации виджета</p>
          <p className="text-[#525252] text-xs">
            Проверьте API ключ или обратитесь к администратору
          </p>
        </div>
      </div>
    );
  }

  if (!valid || validating) {
    return (
      <div className="min-h-[200px] bg-[#0a0a0a] flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-[#f59e0b] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <WidgetTRPCProvider apiKey={apiKey}>
      <WidgetContent apiKey={apiKey} />
    </WidgetTRPCProvider>
  );
}
