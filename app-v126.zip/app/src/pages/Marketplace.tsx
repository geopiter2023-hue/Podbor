import { useState } from "react";
import { useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import {
  Search, SlidersHorizontal, Star, ShoppingCart, Truck,
  ChevronDown, Heart, Check, Filter, X
} from "lucide-react";

function formatPrice(kop: number): string {
  return (kop / 100).toLocaleString("ru-RU") + " ₽";
}

export default function Marketplace() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get("category") || "");
  const [selectedBrand, setSelectedBrand] = useState(searchParams.get("brand") || "");
  const [sort, setSort] = useState<"popular" | "price_asc" | "price_desc" | "rating" | "new">("popular");
  const [showSort, setShowSort] = useState(false);

  const { data: filters } = trpc.products.filters.useQuery();
  const { data: productsData, isLoading } = trpc.products.list.useQuery({
    category: selectedCategory || undefined,
    brand: selectedBrand || undefined,
    search: search || undefined,
    sort,
    limit: 24,
  });

  const seedProducts = trpc.products.seed.useMutation({
    onSuccess: () => window.location.reload(),
  });

  const sortLabels: Record<string, string> = {
    popular: "Популярные",
    price_asc: "Дешевле",
    price_desc: "Дороже",
    rating: "Высокий рейтинг",
    new: "Новинки",
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-[#005bff] text-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
          <a href="/" className="text-xl font-bold tracking-tight">OILPODBOR</a>
          <div className="flex-1 relative">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Искать товары..."
              className="w-full bg-white text-gray-800 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          </div>
          <button className="relative p-2">
            <ShoppingCart className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">0</span>
          </button>
        </div>
      </header>

      {/* Filters bar */}
      <div className="bg-white border-b border-gray-200 sticky top-14 z-40">
        <div className="max-w-7xl mx-auto px-4 py-2 flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full border border-gray-300 text-sm text-gray-700 whitespace-nowrap hover:bg-gray-50"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            Фильтры
          </button>

          {/* Categories */}
          {[
            { id: "", label: "Все" },
            { id: "motor-oil", label: "Моторные масла" },
            { id: "filter", label: "Фильтры" },
            { id: "transmission", label: "Трансмиссия" },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-full text-sm whitespace-nowrap ${selectedCategory === cat.id ? "bg-[#005bff] text-white" : "border border-gray-300 text-gray-700 hover:bg-gray-50"}`}
            >
              {cat.label}
            </button>
          ))}

          <div className="ml-auto relative">
            <button
              onClick={() => setShowSort(!showSort)}
              className="flex items-center gap-1 px-3 py-1.5 text-sm text-gray-700 whitespace-nowrap"
            >
              {sortLabels[sort]}
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
            {showSort && (
              <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-50 w-44">
                {Object.entries(sortLabels).map(([key, label]) => (
                  <button
                    key={key}
                    onClick={() => { setSort(key as any); setShowSort(false); }}
                    className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 ${sort === key ? "text-[#005bff] font-medium" : "text-gray-700"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-4 flex gap-4">
        {/* Sidebar filters */}
        {showFilters && (
          <aside className="w-60 flex-shrink-0 space-y-4">
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <h3 className="font-semibold text-gray-800 text-sm mb-3">Категории</h3>
              <div className="space-y-1">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input type="radio" checked={selectedCategory === ""} onChange={() => setSelectedCategory("")} className="accent-[#005bff]" />
                  Все категории
                </label>
                {filters?.categories?.map((cat) => (
                  <label key={cat} className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="radio" checked={selectedCategory === cat} onChange={() => setSelectedCategory(cat)} className="accent-[#005bff]" />
                    {cat === "motor-oil" ? "Моторные масла" : cat === "filter" ? "Фильтры" : cat === "transmission" ? "Трансмиссия" : cat}
                  </label>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <h3 className="font-semibold text-gray-800 text-sm mb-3">Бренды</h3>
              <div className="space-y-1 max-h-40 overflow-auto">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input type="radio" checked={selectedBrand === ""} onChange={() => setSelectedBrand("")} className="accent-[#005bff]" />
                  Все бренды
                </label>
                {filters?.brands?.map((brand) => (
                  <label key={brand} className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="radio" checked={selectedBrand === brand} onChange={() => setSelectedBrand(brand)} className="accent-[#005bff]" />
                    {brand}
                  </label>
                ))}
              </div>
            </div>

            <button
              onClick={() => { setSelectedCategory(""); setSelectedBrand(""); setSearch(""); }}
              className="w-full py-2 text-sm text-gray-500 hover:text-gray-700 border border-gray-200 rounded-lg"
            >
              Сбросить фильтры
            </button>
          </aside>
        )}

        {/* Products grid */}
        <main className="flex-1">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="w-8 h-8 border-3 border-[#005bff] border-t-transparent rounded-full animate-spin" />
            </div>
          ) : productsData?.items && productsData.items.length > 0 ? (
            <>
              <p className="text-gray-500 text-sm mb-3">{productsData.total} товаров</p>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {productsData.items.map((product: any) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500 mb-4">Товары не найдены</p>
              <button
                onClick={() => seedProducts.mutate()}
                disabled={seedProducts.isPending}
                className="bg-[#005bff] text-white px-6 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
              >
                {seedProducts.isPending ? "Загрузка..." : "Загрузить демо-товары"}
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

function ProductCard({ product }: { product: any }) {
  const [liked, setLiked] = useState(false);

  const badges: string[] = product.badges ? JSON.parse(JSON.stringify(product.badges)) : [];
  const specs = product.specs ? JSON.parse(JSON.stringify(product.specs)) : {};

  return (
    <div className="bg-white rounded-xl border border-gray-100 overflow-hidden hover:shadow-lg transition-shadow group">
      {/* Image */}
      <div className="relative bg-gray-100 aspect-[3/4] overflow-hidden">
        <img
          src={product.imageUrl || "/placeholder.jpg"}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
          loading="lazy"
        />
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {badges.map((badge: string, i: number) => (
            <span
              key={i}
              className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                badge.includes("Распродажа") ? "bg-[#f91155] text-white" :
                badge.includes("0%") ? "bg-[#00d009] text-white" :
                "bg-[#005bff] text-white"
              }`}
            >
              {badge}
            </span>
          ))}
        </div>
        {/* Like button */}
        <button
          onClick={() => setLiked(!liked)}
          className="absolute top-2 right-2 w-8 h-8 bg-white/80 rounded-full flex items-center justify-center"
        >
          <Heart className={`w-4 h-4 ${liked ? "fill-red-500 text-red-500" : "text-gray-500"}`} />
        </button>
        {/* Original badge */}
        {product.isOriginal === "yes" && (
          <div className="absolute bottom-2 left-2 flex items-center gap-1 bg-white/90 px-2 py-0.5 rounded-full text-[10px] text-green-700">
            <Check className="w-3 h-3" />
            Оригинал
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-3">
        {/* Price */}
        <div className="flex items-baseline gap-2 mb-1">
          <span className="text-lg font-bold text-gray-900">{formatPrice(product.price)}</span>
          {product.oldPrice && (
            <span className="text-sm text-gray-400 line-through">{formatPrice(product.oldPrice)}</span>
          )}
        </div>
        {product.discountPercent && (
          <span className="text-[11px] font-medium text-[#f91155]">-{product.discountPercent}%</span>
        )}

        {/* Rating */}
        <div className="flex items-center gap-1 mt-1 mb-1.5">
          <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
          <span className="text-sm font-medium text-gray-800">{product.rating}</span>
          <span className="text-xs text-gray-400">{product.reviewsCount?.toLocaleString("ru")} отзывов</span>
        </div>

        {/* Name */}
        <h3 className="text-sm text-gray-800 leading-tight line-clamp-2 mb-2">{product.name}</h3>

        {/* Specs */}
        {specs.viscosity && (
          <div className="flex flex-wrap gap-1 mb-2">
            <span className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{specs.viscosity}</span>
            {specs.api && <span className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{specs.api}</span>}
            {specs.volume && <span className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{specs.volume}</span>}
          </div>
        )}

        {/* Delivery */}
        <div className="flex items-center gap-1 text-[11px] text-gray-500">
          <Truck className="w-3 h-3" />
          {product.deliveryText || "Завтра"}
        </div>
      </div>
    </div>
  );
}
