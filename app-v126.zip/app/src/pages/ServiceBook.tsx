import { useParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { FileDown, Printer, ArrowLeft, Car, BookOpen, Calendar, Wrench, Droplets, Settings, AlertCircle } from "lucide-react";
import { useState } from "react";

export default function ServiceBook() {
  const { make, model } = useParams<{ make: string; model: string }>();
  const decodedMake = decodeURIComponent(make || "");
  const decodedModel = decodeURIComponent(model || "");
  const [generating, setGenerating] = useState(false);

  const { data: fluidSpecs } = trpc.excel.getByCar.useQuery(
    { make: decodedMake, model: decodedModel },
    { enabled: !!(decodedMake && decodedModel) }
  );

  const { data: manuals } = trpc.manuals.findByCar.useQuery(
    { make: decodedMake, model: decodedModel },
    { enabled: !!(decodedMake && decodedModel) }
  );

  const { data: matchedProducts } = trpc.matching.forCar.useQuery(
    { make: decodedMake, model: decodedModel },
    { enabled: !!(decodedMake && decodedModel) }
  );

  const generatePdf = trpc.pdf.generateLubricationCard.useMutation({
    onSuccess: (data) => {
      setGenerating(false);
      const byteCharacters = atob(data.pdfBase64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) byteNumbers[i] = byteCharacters.charCodeAt(i);
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      window.open(url, "_blank");
      URL.revokeObjectURL(url);
    },
    onError: () => setGenerating(false),
  });

  const handleDownload = () => {
    setGenerating(true);
    generatePdf.mutate({
      make: decodedMake,
      model: decodedModel,
    });
  };

  const handlePrint = () => window.print();

  // Service intervals
  const intervals = [
    { km: "15 000", operation: "Замена моторного масла и фильтра", icon: Droplets },
    { km: "30 000", operation: "Замена воздушного, салонного, топливного фильтров", icon: Settings },
    { km: "45 000", operation: "Замена свечей зажигания, проверка тормозов", icon: Wrench },
    { km: "60 000", operation: "Замена масла в КПП, антифриза", icon: Droplets },
    { km: "90 000", operation: "Замена ремня ГРМ, роликов", icon: Settings },
    { km: "120 000", operation: "Полное ТО: все жидкости, фильтры, свечи", icon: Wrench },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#1a1a1a] text-white sticky top-0 z-30 print:hidden">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => window.close()} className="text-gray-400 hover:text-white transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <img src="/logo.png" alt="oilpodbor" className="w-7 h-7" />
            <span className="font-bold tracking-wider uppercase text-sm">oilpodbor</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownload}
              disabled={generating}
              className="bg-[#d32f2f] hover:bg-[#b71c1c] text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors disabled:opacity-50"
            >
              {generating ? "Формирование..." : <><FileDown className="w-4 h-4" />Скачать PDF</>}
            </button>
            <button
              onClick={handlePrint}
              className="border border-gray-600 text-gray-300 hover:text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors"
            >
              <Printer className="w-4 h-4" />Печать
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-6 py-8">
        {/* Title Page */}
        <div className="text-center mb-10 border-b-2 border-[#d32f2f] pb-8">
          <div className="w-20 h-20 bg-[#f5f5f5] rounded-xl mx-auto mb-4 flex items-center justify-center">
            <Car className="w-10 h-10 text-[#d32f2f]" />
          </div>
          <h1 className="text-3xl font-bold text-[#1a1a1a] mb-2">Сервисная книга</h1>
          <p className="text-xl text-[#d32f2f] font-semibold">{decodedMake} {decodedModel}</p>
          <p className="text-sm text-gray-500 mt-2">oilpodbor.ru | {new Date().toLocaleDateString("ru-RU")}</p>
        </div>

        {/* Car Specs */}
        <section className="mb-10">
          <h2 className="text-lg font-bold text-[#1a1a1a] mb-4 flex items-center gap-2">
            <Car className="w-5 h-5 text-[#d32f2f]" />
            Технические характеристики
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Марка", value: decodedMake },
              { label: "Модель", value: decodedModel },
              { label: "Модификация", value: fluidSpecs?.modification || "—" },
              { label: "Код двигателя", value: fluidSpecs?.engineCode || "—" },
              { label: "Объём масла ДВС", value: fluidSpecs?.engineFillVolume ? `${fluidSpecs.engineFillVolume} л` : "—" },
              { label: "SAE моторного масла", value: fluidSpecs?.prefOilSae || "—" },
              { label: "API спецификация", value: fluidSpecs?.prefOilApi || "—" },
              { label: "ACEA спецификация", value: fluidSpecs?.prefOilAcea || "—" },
              { label: "OEM допуски", value: fluidSpecs?.prefOilOe || "—" },
              { label: "Тип КПП", value: fluidSpecs?.transmissionType || "—" },
              { label: "Объём масла КПП", value: fluidSpecs?.transmissionFillVolume ? `${fluidSpecs.transmissionFillVolume} л` : "—" },
              { label: "Масло КПП", value: fluidSpecs?.transmissionPrefOil || "—" },
              { label: "Тип антифриза", value: fluidSpecs?.coolantType || "—" },
              { label: "Объём антифриза", value: fluidSpecs?.coolantFillVolume ? `${fluidSpecs.coolantFillVolume} л` : "—" },
              { label: "Тормозная жидкость", value: fluidSpecs?.brakeFluidType || "—" },
            ].map((row) => (
              <div key={row.label} className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-500 text-sm">{row.label}</span>
                <span className="text-gray-800 text-sm font-medium">{row.value}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Recommended Products */}
        {matchedProducts && (
          <section className="mb-10">
            <h2 className="text-lg font-bold text-[#1a1a1a] mb-4 flex items-center gap-2">
              <Droplets className="w-5 h-5 text-[#d32f2f]" />
              Рекомендуемые продукты
            </h2>
            <div className="space-y-3">
              {matchedProducts.engineOil && matchedProducts.engineOil.length > 0 && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Моторное масло</p>
                  {matchedProducts.engineOil.slice(0, 3).map((p: any, i: number) => (
                    <p key={i} className="text-sm text-gray-800 font-medium">{p.name}</p>
                  ))}
                </div>
              )}
              {matchedProducts.transmissionOil && matchedProducts.transmissionOil.length > 0 && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Масло КПП</p>
                  {matchedProducts.transmissionOil.slice(0, 3).map((p: any, i: number) => (
                    <p key={i} className="text-sm text-gray-800 font-medium">{p.name}</p>
                  ))}
                </div>
              )}
              {matchedProducts.coolant && matchedProducts.coolant.length > 0 && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Охлаждающая жидкость</p>
                  {matchedProducts.coolant.slice(0, 3).map((p: any, i: number) => (
                    <p key={i} className="text-sm text-gray-800 font-medium">{p.name}</p>
                  ))}
                </div>
              )}
            </div>
          </section>
        )}

        {/* Service Intervals */}
        <section className="mb-10">
          <h2 className="text-lg font-bold text-[#1a1a1a] mb-4 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#d32f2f]" />
            Регламент технического обслуживания
          </h2>
          <div className="space-y-2">
            {intervals.map((item, i) => {
              const Icon = item.icon;
              return (
                <div key={i} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                  <div className="w-16 text-center flex-shrink-0">
                    <p className="text-[#d32f2f] font-bold text-sm">{item.km}</p>
                    <p className="text-gray-400 text-[10px]">км</p>
                  </div>
                  <Icon className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  <p className="text-sm text-gray-700 flex-1">{item.operation}</p>
                </div>
              );
            })}
          </div>
          <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700">Регламент указан приблизительно. Точные интервалы смотрите в руководстве по эксплуатации производителя.</p>
          </div>
        </section>

        {/* Owner Manuals */}
        {manuals && manuals.length > 0 && (
          <section className="mb-10">
            <h2 className="text-lg font-bold text-[#1a1a1a] mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#d32f2f]" />
              Руководства по эксплуатации
            </h2>
            <div className="space-y-2">
              {manuals.map((m: any) => (
                <a
                  key={m.id}
                  href={m.pdfUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg hover:border-[#d32f2f] transition-colors group"
                >
                  <BookOpen className="w-5 h-5 text-gray-400 group-hover:text-[#d32f2f]" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{m.title || `${m.make} ${m.model}`}</p>
                    <p className="text-xs text-gray-500">{m.source} | {m.language === "ru" ? "Русский" : m.language === "en" ? "English" : m.language}</p>
                  </div>
                </a>
              ))}
            </div>
          </section>
        )}

        {/* Footer */}
        <footer className="text-center pt-6 border-t border-gray-200 mt-8">
          <p className="text-[#d32f2f] font-bold text-sm">oilpodbor.ru</p>
          <p className="text-gray-400 text-xs mt-1">Система подбора технических жидкостей</p>
          <p className="text-gray-300 text-[10px] mt-2">Данная сервисная книга сформирована автоматически. Всегда следуйте рекомендациям производителя.</p>
        </footer>
      </main>
    </div>
  );
}
