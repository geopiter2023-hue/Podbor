import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Database, Zap, Clock, Globe } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const stats = [
  { value: "45 000+", label: "Моделей в базе", icon: Database },
  { value: "99.8%", label: "Точность подбора", icon: Zap },
  { value: "<200ms", label: "Время ответа API", icon: Clock },
  { value: "24/7", label: "Доступность", icon: Globe },
];

const apiPayload = `{
  "makeId": 1741,
  "modelId": 20422,
  "modification": "N57D30A",
  "oils": [
    {
      "name": "Motor Oil 5W-30",
      "volume": "6.5L",
      "spec": "LL-04"
    }
  ]
}`;

export default function TechnicalSpecsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!sectionRef.current || !statsRef.current) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        ".tech-stat",
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: statsRef.current,
            start: "top 80%",
            toggleActions: "play none none none",
          },
        }
      );

      gsap.fromTo(
        ".liquid-glass-panel",
        { opacity: 0, x: 30 },
        {
          opacity: 1,
          x: 0,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: ".liquid-glass-panel",
            start: "top 80%",
            toggleActions: "play none none none",
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const highlightJson = (json: string) => {
    return json.split(/(".*?"|\{|\}|\[|\]|:|,|\d+)/).map((part, i) => {
      if (part.match(/^".*"$/)) {
        const isKey = json[json.indexOf(part) + part.length] === ":";
        return (
          <span
            key={i}
            className={isKey ? "text-[#f59e0b]" : "text-white/90"}
          >
            {part}
          </span>
        );
      }
      if (part.match(/^\d+$/)) {
        return (
          <span key={i} className="text-[#4ade80]">
            {part}
          </span>
        );
      }
      if (part.match(/^[{}\[\]:,]$/)) {
        return (
          <span key={i} className="text-[#a3a3a3]">
            {part}
          </span>
        );
      }
      return <span key={i}>{part}</span>;
    });
  };

  return (
    <section
      ref={sectionRef}
      className="min-h-[60vh] bg-black px-6 py-24"
    >
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-[55%_45%] gap-12 items-start">
        {/* Left Column */}
        <div>
          <p className="font-mono-tech text-xs text-[#a3a3a3] uppercase tracking-[0.1em] mb-4">
            Технические данные
          </p>
          <h2 className="text-white text-3xl md:text-4xl font-bold tracking-tight mb-6">
            Полная прозрачность
            <br />
            состава
          </h2>
          <p className="text-[#a3a3a3] text-base leading-relaxed mb-10 max-w-lg">
            Каждая рекомендация основана на официальных данных производителя
            автомобиля. Мы используем прямое API-подключение к базам данных для
            обеспечения 100% точности подбора.
          </p>

          {/* Stats Grid */}
          <div
            ref={statsRef}
            className="grid grid-cols-2 gap-6"
          >
            {stats.map((stat, i) => (
              <div key={i} className="tech-stat opacity-0">
                <div className="flex items-center gap-2 mb-2">
                  <stat.icon className="w-4 h-4 text-[#f59e0b]" />
                  <span className="text-[#f59e0b] text-3xl md:text-4xl font-bold">
                    {stat.value}
                  </span>
                </div>
                <span className="font-mono-tech text-xs text-[#a3a3a3] uppercase tracking-wider">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column — Liquid Glass Panel */}
        <div className="liquid-glass-panel opacity-0">
          <div className="liquid-glass p-6 relative overflow-hidden">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-2 h-2 rounded-full bg-[#f59e0b]" />
              <span className="font-mono-tech text-xs text-[#a3a3a3] uppercase tracking-wider">
                API Response Preview
              </span>
            </div>
            <pre className="font-mono-tech text-sm leading-relaxed overflow-x-auto">
              <code>{highlightJson(apiPayload)}</code>
            </pre>
          </div>
        </div>
      </div>
    </section>
  );
}
