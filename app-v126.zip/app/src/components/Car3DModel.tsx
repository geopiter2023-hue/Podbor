import { useRef, useState, useMemo, Suspense } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Html } from "@react-three/drei";
import * as THREE from "three";

// ─── Color tokens ───
const BASE_RED = "#c0392b";
const HOVER_RED = "#d32f2f";
const HOVER_EMISSIVE = "#ff1744";

// ─── Animated fluid particles ───
function FluidParticles({ path, color, speed = 1, count = 20 }) {
  const points = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(path.map((p) => new THREE.Vector3(...p)));
    return Array.from({ length: count }, (_, i) => ({
      t: i / count,
      offset: Math.random() * 0.3,
    }));
  }, [path, count]);

  const groupRef = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (!groupRef.current) return;
    groupRef.current.children.forEach((child, i) => {
      const p = points[i];
      p.t += delta * speed * 0.3;
      if (p.t > 1) p.t -= 1;
      const curve = new THREE.CatmullRomCurve3(path.map((pp) => new THREE.Vector3(...pp)));
      const pos = curve.getPointAt(p.t);
      child.position.copy(pos);
    });
  });

  return (
    <group ref={groupRef}>
      {points.map((_, i) => (
        <mesh key={i}>
          <sphereGeometry args={[0.06, 8, 8]} />
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.8} transparent opacity={0.9} />
        </mesh>
      ))}
    </group>
  );
}

// ─── Fluid tube ───
function FluidTube({ path, color }) {
  const curve = useMemo(() => {
    return new THREE.CatmullRomCurve3(path.map((p) => new THREE.Vector3(...p)));
  }, [path]);

  return (
    <mesh>
      <tubeGeometry args={[curve, 64, 0.03, 8, false]} />
      <meshStandardMaterial color={color} transparent opacity={0.4} emissive={color} emissiveIntensity={0.3} />
    </mesh>
  );
}

// ─── Car body (semi-transparent) ───
function CarBody() {
  return (
    <group>
      <mesh position={[0, 0.7, 0]}>
        <boxGeometry args={[4.2, 0.8, 1.8]} />
        <meshStandardMaterial color="#e8e8e8" transparent opacity={0.25} metalness={0.3} roughness={0.2} />
      </mesh>
      <mesh position={[0, 1.35, 0]}>
        <boxGeometry args={[2.2, 0.5, 1.6]} />
        <meshStandardMaterial color="#e8e8e8" transparent opacity={0.2} metalness={0.3} roughness={0.2} />
      </mesh>
      <mesh position={[1.3, 0.7, 0]}>
        <boxGeometry args={[1.6, 0.65, 1.75]} />
        <meshStandardMaterial color="#e8e8e8" transparent opacity={0.2} metalness={0.3} roughness={0.2} />
      </mesh>
      <mesh position={[-1.5, 0.7, 0]}>
        <boxGeometry args={[1.2, 0.65, 1.75]} />
        <meshStandardMaterial color="#e8e8e8" transparent opacity={0.2} metalness={0.3} roughness={0.2} />
      </mesh>
      {[[-1.3, 0.25, 0.9], [-1.3, 0.25, -0.9], [1.3, 0.25, 0.9], [1.3, 0.25, -0.9]].map((pos, i) => (
        <mesh key={i} position={pos as [number, number, number]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.35, 0.35, 0.2, 16]} />
          <meshStandardMaterial color="#555" metalness={0.5} roughness={0.8} />
        </mesh>
      ))}
    </group>
  );
}

// ─── Generic agregate component ───
function Agregate({ name, subtext, subtext2, position, geometry, hoverKey, hovered, onHover, tubeColor }) {
  const isHovered = hovered === hoverKey;

  return (
    <group
      position={position as [number, number, number]}
      onPointerOver={(e) => { e.stopPropagation(); onHover(hoverKey); }}
      onPointerOut={() => onHover(null)}
    >
      <mesh>
        {geometry}
        <meshStandardMaterial
          color={isHovered ? HOVER_RED : BASE_RED}
          metalness={0.6}
          roughness={0.3}
          emissive={isHovered ? HOVER_EMISSIVE : "#000"}
          emissiveIntensity={isHovered ? 0.4 : 0}
        />
      </mesh>
      {isHovered && (
        <Html position={[0, 0.5, 0]} center zIndexRange={[100, 0]}>
          <div className="rounded-lg shadow-lg px-3 py-2 text-xs whitespace-nowrap border-2"
            style={{ backgroundColor: "#d32f2f", borderColor: "#b71c1c", color: "#fff" }}>
            <p className="font-bold text-white">{name}</p>
            <p className="text-white/90">{subtext}</p>
            {subtext2 && <p className="text-white/70">{subtext2}</p>}
          </div>
        </Html>
      )}
    </group>
  );
}

// ─── Main 3D Scene ───
function Scene() {
  const [hovered, setHovered] = useState<string | null>(null);

  const engineOilPath: [number, number, number][] = [
    [1.0, 0.55, 0.2], [0.8, 0.7, 0.3], [0.5, 0.9, 0.1], [0.2, 0.7, -0.2], [0.1, 0.55, 0.2],
  ];
  const coolantPath: [number, number, number][] = [
    [1.6, 0.55, 0], [1.3, 0.8, 0.1], [1.0, 0.9, 0], [0.7, 0.8, -0.1], [0.4, 0.6, 0],
  ];
  const transOilPath: [number, number, number][] = [
    [0.1, 0.45, 0.2], [0.2, 0.6, 0.4], [0.4, 0.8, 0.2], [0.6, 0.65, 0], [0.8, 0.5, -0.2],
  ];
  const brakeFluidPath: [number, number, number][] = [
    [-0.8, 0.4, 0.6], [-0.4, 0.6, 0.5], [0, 0.8, 0.3], [0.5, 0.7, 0.1], [1.0, 0.5, 0],
  ];
  const steeringFluidPath: [number, number, number][] = [
    [1.2, 0.35, -0.4], [0.9, 0.55, -0.3], [0.5, 0.75, -0.2], [0.1, 0.65, -0.1], [-0.3, 0.45, 0],
  ];

  return (
    <>
      <ambientLight intensity={0.7} />
      <directionalLight position={[5, 5, 5]} intensity={0.9} />
      <directionalLight position={[-3, 3, -3]} intensity={0.3} color="#ffcccc" />
      <pointLight position={[0, 2, 0]} intensity={0.3} color="#d32f2f" />

      <CarBody />

      <Agregate
        name="Двигатель" subtext="Моторное масло 5W-30" subtext2="API SN / ACEA C3"
        position={[1.0, 0.55, 0.2]}
        geometry={<boxGeometry args={[0.7, 0.5, 0.6]} />}
        hoverKey="engine" hovered={hovered} onHover={setHovered}
        tubeColor="#f1c40f"
      />
      <Agregate
        name="КПП / АКПП" subtext="Трансмиссионное масло 75W-90"
        position={[0.1, 0.45, 0.2]}
        geometry={<cylinderGeometry args={[0.25, 0.25, 0.5, 16]} />}
        hoverKey="transmission" hovered={hovered} onHover={setHovered}
        tubeColor="#1abc9c"
      />
      <Agregate
        name="Радиатор / Охлаждение" subtext="Антифриз G12+ / G13"
        position={[1.6, 0.55, 0]}
        geometry={<boxGeometry args={[0.15, 0.5, 0.9]} />}
        hoverKey="radiator" hovered={hovered} onHover={setHovered}
        tubeColor="#3498db"
      />
      <Agregate
        name="Тормозная система" subtext="DOT 4 / DOT 5.1"
        position={[-0.8, 0.4, 0.6]}
        geometry={<cylinderGeometry args={[0.12, 0.12, 0.15, 12]} />}
        hoverKey="brakes" hovered={hovered} onHover={setHovered}
        tubeColor="#9b59b6"
      />
      <Agregate
        name="ГУР / ЭГУ" subtext="ATF DEXRON VI"
        position={[1.2, 0.35, -0.4]}
        geometry={<cylinderGeometry args={[0.1, 0.1, 0.2, 12]} />}
        hoverKey="steering" hovered={hovered} onHover={setHovered}
        tubeColor="#e84393"
      />
      <Agregate
        name="Дифференциал" subtext="Масло 75W-90 GL-5"
        position={[-1.0, 0.35, 0.2]}
        geometry={<boxGeometry args={[0.4, 0.25, 0.4]} />}
        hoverKey="diff" hovered={hovered} onHover={setHovered}
        tubeColor="#00b894"
      />

      <FluidTube path={engineOilPath} color="#f1c40f" />
      <FluidTube path={coolantPath} color="#3498db" />
      <FluidTube path={transOilPath} color="#1abc9c" />
      <FluidTube path={brakeFluidPath} color="#9b59b6" />
      <FluidTube path={steeringFluidPath} color="#e84393" />

      <FluidParticles path={engineOilPath} color="#f1c40f" speed={1.2} count={15} />
      <FluidParticles path={coolantPath} color="#3498db" speed={0.8} count={12} />
      <FluidParticles path={transOilPath} color="#1abc9c" speed={1.0} count={10} />
      <FluidParticles path={brakeFluidPath} color="#9b59b6" speed={0.6} count={8} />
      <FluidParticles path={steeringFluidPath} color="#e84393" speed={0.9} count={10} />

      <OrbitControls
        enablePan={false}
        minDistance={3}
        maxDistance={8}
        minPolarAngle={Math.PI / 6}
        maxPolarAngle={Math.PI / 2.2}
        autoRotate
        autoRotateSpeed={0.5}
      />
    </>
  );
}

// ─── Fallback loader ───
function CanvasFallback() {
  return (
    <div className="w-full h-[500px] rounded-xl bg-gray-50 border border-gray-200 flex items-center justify-center">
      <div className="text-center space-y-3">
        <div className="w-8 h-8 border-2 border-[#d32f2f] border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-gray-500 text-sm">Загрузка 3D модели...</p>
      </div>
    </div>
  );
}

// ─── Exported component with error boundary ───
export default function Car3DModel() {
  return (
    <div className="w-full h-[500px] rounded-xl overflow-hidden bg-gradient-to-b from-gray-50 to-gray-100 border border-gray-200 shadow-sm relative">
      {/* Legend */}
      <div className="absolute top-3 left-3 z-10 rounded-lg shadow-sm border border-gray-200 px-3 py-2 space-y-1"
        style={{ backgroundColor: "rgba(255,255,255,0.92)", backdropFilter: "blur(8px)" }}>
        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Агрегаты</p>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: BASE_RED }} /><span className="text-[10px] text-gray-600">Двигатель — масло</span></div>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-blue-500" /><span className="text-[10px] text-gray-600">Радиатор — антифриз</span></div>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-teal-500" /><span className="text-[10px] text-gray-600">КПП — трансмиссия</span></div>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-purple-500" /><span className="text-[10px] text-gray-600">Тормоза — DOT</span></div>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-pink-500" /><span className="text-[10px] text-gray-600">ГУР — ATF</span></div>
        <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /><span className="text-[10px] text-gray-600">Дифференциал</span></div>
      </div>
      <Suspense fallback={<CanvasFallback />}>
        <Canvas camera={{ position: [3, 2.5, 4], fov: 45 }}>
          <Scene />
        </Canvas>
      </Suspense>
    </div>
  );
}
