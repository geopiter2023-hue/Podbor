import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Bot, Trash2, CheckCircle, XCircle, AlertTriangle, Loader2, ChevronDown, ChevronUp, Zap, Clock, Hash } from "lucide-react";

export function AiAgentDetails({ make, model }: { make: string; model: string }) {
  const utils = trpc.useUtils();
  const { data: results, isLoading } = trpc.aiAgents.listByCar.useQuery({ make, model });
  const clearCar = trpc.aiAgents.clearByCar.useMutation({
    onSuccess: () => {
      utils.aiAgents.listByCar.invalidate({ make, model });
      alert("Данные агентов очищены");
    },
  });

  const [expandedAgent, setExpandedAgent] = useState<number | null>(null);

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 text-gray-400 text-sm py-4">
        <Loader2 className="w-4 h-4 animate-spin" />
        Загрузка данных агентов...
      </div>
    );
  }

  if (!results?.length) {
    return (
      <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
        <p className="text-gray-400 text-sm text-center">Нет данных от агентов для этого автомобиля</p>
      </div>
    );
  }

  // Group by agent provider
  const byAgent: Record<string, typeof results> = {};
  for (const r of results) {
    if (!byAgent[r.agentProvider]) byAgent[r.agentProvider] = [];
    byAgent[r.agentProvider].push(r);
  }

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
          <Bot className="w-4 h-4 text-[#d32f2f]" />
          Результаты ИИ-агентов ({results.length} запусков)
        </h4>
        <button
          onClick={() => { if (confirm(`Очистить все данные агентов для ${make} ${model}?`)) clearCar.mutate({ make, model }); }}
          className="text-red-500 hover:text-red-700 text-xs flex items-center gap-1 px-2 py-1 rounded hover:bg-red-50 transition-colors"
        >
          <Trash2 className="w-3 h-3" /> Очистить
        </button>
      </div>

      {/* Agent cards */}
      {Object.entries(byAgent).map(([provider, agentResults]) => {
        const latest = agentResults[0];
        const totalTokens = agentResults.reduce((sum, r) => sum + (r.tokensTotal || 0), 0);
        const avgTokens = Math.round(totalTokens / agentResults.length);
        const totalFields = agentResults.reduce((sum, r) => sum + (r.filledCount || 0), 0);
        const successRate = Math.round((agentResults.filter((r) => r.status === "success").length / agentResults.length) * 100);

        return (
          <div key={provider} className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
            {/* Agent header */}
            <div
              className="p-3 flex items-center justify-between cursor-pointer hover:bg-gray-50 transition-colors"
              onClick={() => setExpandedAgent(expandedAgent === latest.id ? null : latest.id)}
            >
              <div className="flex items-center gap-3">
                <div className={`w-2 h-2 rounded-full ${latest.status === "success" ? "bg-green-500" : latest.status === "error" ? "bg-red-500" : "bg-amber-500"}`} />
                <span className="text-sm font-medium text-gray-800">{latest.agentName}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-500 font-mono">{provider}</span>
              </div>
              <div className="flex items-center gap-3 text-xs text-gray-500">
                <span className="flex items-center gap-1" title="Заполнено полей"><CheckCircle className="w-3 h-3 text-green-500" /> {latest.filledCount || 0}</span>
                <span className="flex items-center gap-1" title="Токенов"><Zap className="w-3 h-3 text-amber-500" /> {latest.tokensTotal || 0}</span>
                <span className="flex items-center gap-1" title="Время"><Clock className="w-3 h-3 text-blue-500" /> {latest.durationMs ? `${(latest.durationMs / 1000).toFixed(1)}с` : "—"}</span>
                {expandedAgent === latest.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </div>
            </div>

            {/* Expanded details */}
            {expandedAgent === latest.id && (
              <div className="border-t border-gray-100 p-3 space-y-3">
                {/* Stats summary */}
                <div className="grid grid-cols-4 gap-2 text-xs">
                  <div className="bg-gray-50 rounded p-2 text-center">
                    <p className="text-gray-400">Запусков</p>
                    <p className="font-bold text-gray-700">{agentResults.length}</p>
                  </div>
                  <div className="bg-gray-50 rounded p-2 text-center">
                    <p className="text-gray-400">Успех</p>
                    <p className={`font-bold ${successRate >= 80 ? "text-green-600" : successRate >= 50 ? "text-amber-600" : "text-red-600"}`}>{successRate}%</p>
                  </div>
                  <div className="bg-gray-50 rounded p-2 text-center">
                    <p className="text-gray-400">Всего токенов</p>
                    <p className="font-bold text-gray-700">{totalTokens.toLocaleString()}</p>
                  </div>
                  <div className="bg-gray-50 rounded p-2 text-center">
                    <p className="text-gray-400">Средне/запуск</p>
                    <p className="font-bold text-gray-700">{avgTokens.toLocaleString()}</p>
                  </div>
                </div>

                {/* Filled fields */}
                {latest.filledFields && (
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Заполненные поля</p>
                    <div className="flex flex-wrap gap-1">
                      {(typeof latest.filledFields === "string" ? JSON.parse(latest.filledFields) : latest.filledFields).map((f: string, i: number) => (
                        <span key={i} className="text-[10px] px-1.5 py-0.5 bg-green-50 text-green-700 rounded border border-green-200">{f}</span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Error message */}
                {latest.errorMessage && (
                  <div className="bg-red-50 rounded p-2 border border-red-200">
                    <p className="text-[10px] font-bold text-red-500 flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> Ошибка</p>
                    <p className="text-xs text-red-700 mt-0.5">{latest.errorMessage}</p>
                  </div>
                )}

                {/* Raw response preview */}
                {latest.rawResponse && (
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Ответ агента</p>
                    <pre className="text-[10px] bg-gray-50 rounded p-2 border border-gray-200 overflow-x-auto max-h-32 overflow-y-auto">{String(latest.rawResponse).substring(0, 1000)}</pre>
                  </div>
                )}

                {/* History */}
                {agentResults.length > 1 && (
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">История ({agentResults.length} запусков)</p>
                    <div className="space-y-1 max-h-32 overflow-y-auto">
                      {agentResults.map((r, i) => (
                        <div key={r.id} className="flex items-center justify-between text-[10px] py-1 border-b border-gray-50 last:border-0">
                          <span className="text-gray-400">#{agentResults.length - i}</span>
                          <span className={`px-1 rounded ${r.status === "success" ? "bg-green-100 text-green-700" : r.status === "error" ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"}`}>{r.status}</span>
                          <span className="text-gray-500">{r.filledCount || 0} полей</span>
                          <span className="text-gray-400">{r.tokensTotal || 0} токенов</span>
                          <span className="text-gray-400">{r.durationMs ? `${(r.durationMs / 1000).toFixed(1)}с` : "—"}</span>
                          <span className="text-gray-400">{new Date(r.createdAt).toLocaleString("ru-RU")}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
