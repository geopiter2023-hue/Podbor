export default function Footer() {
  return (
    <footer className="border-t border-[#262626] bg-black px-6 py-8">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="font-mono-tech text-xs text-[#525252]">
          &copy; 2025 oilpodbor. Система подбора технических жидкостей.
        </p>
        <div className="flex items-center gap-4">
          <span className="font-mono-tech text-xs text-[#a3a3a3] hover:text-white cursor-pointer transition-colors">
            API Документация
          </span>
          <span className="text-[#262626]">·</span>
          <span className="font-mono-tech text-xs text-[#a3a3a3] hover:text-white cursor-pointer transition-colors">
            База данных
          </span>
          <span className="text-[#262626]">·</span>
          <span className="font-mono-tech text-xs text-[#a3a3a3] hover:text-white cursor-pointer transition-colors">
            Контакты
          </span>
        </div>
        <p className="font-mono-tech text-[11px] text-[#525252]">
          Powered by AutoDataBases
        </p>
      </div>
    </footer>
  );
}
