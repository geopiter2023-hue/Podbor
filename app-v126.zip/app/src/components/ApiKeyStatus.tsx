import { Key, Bot, Search, ExternalLink, Check, X, Globe } from "lucide-react";

const PROVIDERS = [
  { key: "anthropic_api_key", name: "Anthropic Claude", icon: "Bot", url: "https://console.anthropic.com", color: "amber" },
  { key: "openai_api_key", name: "OpenAI GPT", icon: "Bot", url: "https://platform.openai.com", color: "green" },
  { key: "perplexity_api_key", name: "Perplexity", icon: "Bot", url: "https://perplexity.ai", color: "blue" },
  { key: "deepseek_api_key", name: "DeepSeek", icon: "Bot", url: "https://platform.deepseek.com", color: "indigo" },
  { key: "gemini_api_key", name: "Google Gemini", icon: "Bot", url: "https://ai.google.dev", color: "cyan" },
  { key: "groq_api_key", name: "Groq", icon: "Bot", url: "https://console.groq.com", color: "violet" },
  { key: "mistral_api_key", name: "Mistral AI", icon: "Bot", url: "https://console.mistral.ai", color: "orange" },
  { key: "cohere_api_key", name: "Cohere", icon: "Bot", url: "https://cohere.com", color: "teal" },
  { key: "yandex_api_key", name: "Yandex GPT", icon: "Globe", url: "https://yandex.cloud", color: "red" },
  { key: "gigachat_client_secret", name: "GigaChat (Сбер)", icon: "Globe", url: "https://developers.sber.ru", color: "emerald" },
  { key: "vsegpt_api_key", name: "VseGPT.ru", icon: "Globe", url: "https://vsegpt.ru", color: "sky" },
  { key: "nomerogram_token", name: "Номерограм", icon: "Search", url: "https://api-cloud.ru", color: "slate" },
];

export function ApiKeyStatus(props: { settings: any[] }) {
  const settings = props.settings;

  const active = PROVIDERS.filter((p) => {
    const s = settings.find((s: any) => s.key === p.key);
    return s?.value && s.value.length > 8 && !s.value.includes("***");
  });

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
      <div className="p-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between">
        <h3 className="text-gray-800 text-sm font-semibold flex items-center gap-2">
          <Key className="w-4 h-4" />
          Статус API-ключей — {active.length} из {PROVIDERS.length} активно
        </h3>
        <span className={`text-xs px-2 py-1 rounded-full font-medium ${active.length >= 3 ? "bg-green-100 text-green-700" : active.length > 0 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"}`}>
          {active.length >= 3 ? "ИИ готов к работе" : active.length > 0 ? "Частичная работа" : "Требуются ключи"}
        </span>
      </div>

      <div className="p-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {PROVIDERS.map((p) => {
          const s = settings.find((s: any) => s.key === p.key);
          const isActive = s?.value && s.value.length > 8 && !s.value.includes("***");
          const Icon = p.icon === "Search" ? Search : p.icon === "Globe" ? Globe : Bot;

          return (
            <div key={p.key} className={`rounded-lg border p-3 transition-all ${isActive ? "border-green-200 bg-green-50/50" : "border-gray-200 bg-gray-50/50 opacity-70"}`}>
              <div className="flex items-center gap-2 mb-1.5">
                <Icon className={`w-3.5 h-3.5 ${isActive ? "text-green-600" : "text-gray-400"}`} />
                <span className="text-xs font-medium text-gray-700 truncate">{p.name}</span>
                {isActive ? (
                  <Check className="w-3 h-3 text-green-500 ml-auto flex-shrink-0" />
                ) : (
                  <X className="w-3 h-3 text-gray-300 ml-auto flex-shrink-0" />
                )}
              </div>
              <div className="flex items-center justify-between">
                <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-400"}`}>
                  {isActive ? "АКТИВЕН" : "ПУСТО"}
                </span>
                {!isActive && (
                  <a href={p.url} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-600 transition-colors">
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {active.length === 0 && (
        <div className="px-4 pb-4">
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-center">
            <p className="text-red-700 text-sm font-medium">Нет активных API-ключей</p>
            <p className="text-red-500 text-xs mt-1">Добавьте хотя бы один ключ в Настройки → API-ключи для начала работы ИИ-агентов</p>
          </div>
        </div>
      )}
    </div>
  );
}
