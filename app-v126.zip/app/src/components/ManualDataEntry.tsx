import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Save, User, CheckCircle } from "lucide-react";

const FIELDS = [
  { key: "oilVolume", label: "Объём масла (л)", group: "Двигатель" },
  { key: "oilSae", label: "Вязкость SAE", group: "Двигатель" },
  { key: "oilApi", label: "Спецификация API", group: "Двигатель" },
  { key: "oilAcea", label: "Спецификация ACEA", group: "Двигатель" },
  { key: "oilOem", label: "OEM допуск", group: "Двигатель" },
  { key: "transmissionType", label: "Тип КПП", group: "Трансмиссия" },
  { key: "transmissionVolume", label: "Объём КПП (л)", group: "Трансмиссия" },
  { key: "coolantVolume", label: "Объём антифриза (л)", group: "Охлаждение" },
  { key: "coolantType", label: "Тип антифриза", group: "Охлаждение" },
  { key: "brakeFluid", label: "Тормозная жидкость", group: "Тормоза" },
  { key: "frontDiffVolume", label: "Объём перед. дифф. (л)", group: "Дифференциал" },
  { key: "rearDiffVolume", label: "Объём задн. дифф. (л)", group: "Дифференциал" },
  { key: "oilFilter", label: "Фильтр масляный", group: "Фильтры" },
  { key: "airFilter", label: "Фильтр воздушный", group: "Фильтры" },
  { key: "cabinFilter", label: "Фильтр салона", group: "Фильтры" },
  { key: "fuelFilter", label: "Фильтр топливный", group: "Фильтры" },
];

export function ManualDataEntry({ make, model, generation, modification }: {
  make: string;
  model: string;
  generation?: string;
  modification?: string;
}) {
  const [data, setData] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState(false);
  const saveManual = trpc.aiAgents.saveManual.useMutation({
    onSuccess: () => {
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    },
  });

  const handleSave = () => {
    const filled: Record<string, string> = {};
    for (const [key, value] of Object.entries(data)) {
      if (value?.trim()) filled[key] = value.trim();
    }
    if (Object.keys(filled).length === 0) {
      alert("Заполните хотя бы одно поле");
      return;
    }
    saveManual.mutate({ make, model, generation, modification, data: filled });
  };

  // Group fields
  const groups: Record<string, typeof FIELDS> = {};
  for (const f of FIELDS) {
    if (!groups[f.group]) groups[f.group] = [];
    groups[f.group].push(f);
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
      <div className="p-3 border-b border-gray-200 bg-amber-50 flex items-center justify-between">
        <h4 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
          <User className="w-4 h-4 text-amber-600" />
          Ручной ввод данных
        </h4>
        {saved && (
          <span className="text-xs text-green-600 flex items-center gap-1">
            <CheckCircle className="w-3 h-3" /> Сохранено
          </span>
        )}
      </div>
      <div className="p-4 space-y-4">
        {Object.entries(groups).map(([groupName, fields]) => (
          <div key={groupName}>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">{groupName}</p>
            <div className="grid grid-cols-2 gap-3">
              {fields.map((f) => (
                <div key={f.key}>
                  <label className="block text-gray-500 text-xs mb-1">{f.label}</label>
                  <input
                    type="text"
                    value={data[f.key] || ""}
                    onChange={(e) => setData((prev) => ({ ...prev, [f.key]: e.target.value }))}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-[#d32f2f]"
                    placeholder="—"
                  />
                </div>
              ))}
            </div>
          </div>
        ))}
        <button
          onClick={handleSave}
          disabled={saveManual.isPending}
          className="w-full bg-amber-600 hover:bg-amber-700 text-white py-2.5 rounded-lg text-sm font-medium disabled:opacity-50 flex items-center justify-center gap-2 transition-colors"
        >
          {saveManual.isPending ? "Сохранение..." : <><Save className="w-4 h-4" /> Сохранить ручной ввод</>}
        </button>
      </div>
    </div>
  );
}
