/**
 * Seed reference tables with default data
 * Run: npx tsx api/seed-references.ts
 */
import { getDb } from "./queries/connection";
import {
  vehicleTypes, steeringPositions, carBodyTypes, fuelTypes,
  transmissionTypes, viscosityClasses, liquidCategories, aggregationTrees,
} from "@db/schema";

const db = getDb();

async function seed() {
  console.log("[Seed] Starting...");

  // ─── Vehicle Types ───
  const vt = await db.select().from(vehicleTypes).limit(1);
  if (vt.length === 0) {
    await db.insert(vehicleTypes).values([
      { name: "Легковой автомобиль", sortOrder: 1, isActive: "active" },
      { name: "Внедорожник / SUV", sortOrder: 2, isActive: "active" },
      { name: "Минивэн", sortOrder: 3, isActive: "active" },
      { name: "Пикап", sortOrder: 4, isActive: "active" },
      { name: "Легкий коммерческий", sortOrder: 5, isActive: "active" },
      { name: "Грузовой автомобиль", sortOrder: 6, isActive: "active" },
      { name: "Автобус", sortOrder: 7, isActive: "active" },
      { name: "Мотоцикл", sortOrder: 8, isActive: "active" },
    ]);
    console.log("[Seed] Vehicle types: 8 rows");
  }

  // ─── Steering Positions ───
  const sp = await db.select().from(steeringPositions).limit(1);
  if (sp.length === 0) {
    await db.insert(steeringPositions).values([
      { name: "Левый руль (LHD)", sortOrder: 1, isActive: "active" },
      { name: "Правый руль (RHD)", sortOrder: 2, isActive: "active" },
    ]);
    console.log("[Seed] Steering positions: 2 rows");
  }

  // ─── Car Body Types ───
  const bt = await db.select().from(carBodyTypes).limit(1);
  if (bt.length === 0) {
    await db.insert(carBodyTypes).values([
      { name: "Седан", sortOrder: 1, isActive: "active" },
      { name: "Хэтчбек", sortOrder: 2, isActive: "active" },
      { name: "Универсал", sortOrder: 3, isActive: "active" },
      { name: "Купе", sortOrder: 4, isActive: "active" },
      { name: "Кабриолет", sortOrder: 5, isActive: "active" },
      { name: "Внедорожник 3 дв.", sortOrder: 6, isActive: "active" },
      { name: "Внедорожник 5 дв.", sortOrder: 7, isActive: "active" },
      { name: "Минивэн", sortOrder: 8, isActive: "active" },
      { name: "Пикап", sortOrder: 9, isActive: "active" },
      { name: "Лифтбэк", sortOrder: 10, isActive: "active" },
      { name: "Кроссовер", sortOrder: 11, isActive: "active" },
      { name: "Фургон", sortOrder: 12, isActive: "active" },
    ]);
    console.log("[Seed] Body types: 12 rows");
  }

  // ─── Fuel Types ───
  const ft = await db.select().from(fuelTypes).limit(1);
  if (ft.length === 0) {
    await db.insert(fuelTypes).values([
      { name: "Бензин", sortOrder: 1, isActive: "active" },
      { name: "Дизель", sortOrder: 2, isActive: "active" },
      { name: "Гибрид", sortOrder: 3, isActive: "active" },
      { name: "Электро", sortOrder: 4, isActive: "active" },
      { name: "Газ (ГБО)", sortOrder: 5, isActive: "active" },
      { name: "Гибрид (Plugin)", sortOrder: 6, isActive: "active" },
    ]);
    console.log("[Seed] Fuel types: 6 rows");
  }

  // ─── Transmission Types ───
  const tt = await db.select().from(transmissionTypes).limit(1);
  if (tt.length === 0) {
    await db.insert(transmissionTypes).values([
      { name: "Механическая (MT)", sortOrder: 1, isActive: "active" },
      { name: "Автоматическая (AT)", sortOrder: 2, isActive: "active" },
      { name: "Роботизированная (AMT)", sortOrder: 3, isActive: "active" },
      { name: "Вариатор (CVT)", sortOrder: 4, isActive: "active" },
      { name: "Двойное сцепление (DCT)", sortOrder: 5, isActive: "active" },
    ]);
    console.log("[Seed] Transmission types: 5 rows");
  }

  // ─── Viscosity Classes ───
  const vc = await db.select().from(viscosityClasses).limit(1);
  if (vc.length === 0) {
    await db.insert(viscosityClasses).values([
      { name: "0W-16", sortOrder: 1, isActive: "active" },
      { name: "0W-20", sortOrder: 2, isActive: "active" },
      { name: "0W-30", sortOrder: 3, isActive: "active" },
      { name: "0W-40", sortOrder: 4, isActive: "active" },
      { name: "5W-20", sortOrder: 5, isActive: "active" },
      { name: "5W-30", sortOrder: 6, isActive: "active" },
      { name: "5W-40", sortOrder: 7, isActive: "active" },
      { name: "5W-50", sortOrder: 8, isActive: "active" },
      { name: "10W-30", sortOrder: 9, isActive: "active" },
      { name: "10W-40", sortOrder: 10, isActive: "active" },
      { name: "10W-50", sortOrder: 11, isActive: "active" },
      { name: "10W-60", sortOrder: 12, isActive: "active" },
      { name: "15W-40", sortOrder: 13, isActive: "active" },
      { name: "15W-50", sortOrder: 14, isActive: "active" },
      { name: "20W-50", sortOrder: 15, isActive: "active" },
      { name: "75W-80", sortOrder: 16, isActive: "active" },
      { name: "75W-90", sortOrder: 17, isActive: "active" },
      { name: "80W-90", sortOrder: 18, isActive: "active" },
      { name: "85W-90", sortOrder: 19, isActive: "active" },
      { name: "ATF", sortOrder: 20, isActive: "active" },
      { name: "CVT Fluid", sortOrder: 21, isActive: "active" },
    ]);
    console.log("[Seed] Viscosity classes: 21 rows");
  }

  // ─── Liquid Categories ───
  const lc = await db.select().from(liquidCategories).limit(1);
  if (lc.length === 0) {
    await db.insert(liquidCategories).values([
      { name: "Моторное масло", parentId: null, sortOrder: 1, isActive: "active" },
      { name: "Трансмиссионное масло", parentId: null, sortOrder: 2, isActive: "active" },
      { name: "Тормозная жидкость", parentId: null, sortOrder: 3, isActive: "active" },
      { name: "Охлаждающая жидкость", parentId: null, sortOrder: 4, isActive: "active" },
      { name: "Жидкость ГУР", parentId: null, sortOrder: 5, isActive: "active" },
      { name: "Синтетическое", parentId: 1, sortOrder: 6, isActive: "active" },
      { name: "Полусинтетическое", parentId: 1, sortOrder: 7, isActive: "active" },
      { name: "Минеральное", parentId: 1, sortOrder: 8, isActive: "active" },
    ]);
    console.log("[Seed] Liquid categories: 8 rows");
  }

  // ─── Aggregation Trees ───
  const at = await db.select().from(aggregationTrees).limit(1);
  if (at.length === 0) {
    await db.insert(aggregationTrees).values([
      { name: "Двигатель", parentId: null, sortOrder: 1, isActive: "active" },
      { name: "Картер двигателя", parentId: 1, sortOrder: 2, isActive: "active" },
      { name: "Головка блока цилиндров", parentId: 1, sortOrder: 3, isActive: "active" },
      { name: "Турбокомпрессор", parentId: 1, sortOrder: 4, isActive: "active" },
      { name: "Трансмиссия", parentId: null, sortOrder: 5, isActive: "active" },
      { name: "Коробка передач", parentId: 5, sortOrder: 6, isActive: "active" },
      { name: "Раздаточная коробка", parentId: 5, sortOrder: 7, isActive: "active" },
      { name: "Дифференциал", parentId: 5, sortOrder: 8, isActive: "active" },
      { name: "Система охлаждения", parentId: null, sortOrder: 9, isActive: "active" },
      { name: "Радиатор", parentId: 9, sortOrder: 10, isActive: "active" },
      { name: "Помпа", parentId: 9, sortOrder: 11, isActive: "active" },
      { name: "Тормозная система", parentId: null, sortOrder: 12, isActive: "active" },
      { name: "Тормозные суппорта", parentId: 12, sortOrder: 13, isActive: "active" },
      { name: "Тормозные диски", parentId: 12, sortOrder: 14, isActive: "active" },
      { name: "ГУР / ЭГУ", parentId: null, sortOrder: 15, isActive: "active" },
    ]);
    console.log("[Seed] Aggregation trees: 15 rows");
  }

  console.log("[Seed] Done! All reference tables filled.");
}

seed().catch((e) => { console.error("[Seed] Error:", e); process.exit(1); });
