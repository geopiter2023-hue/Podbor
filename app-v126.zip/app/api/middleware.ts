import { ErrorMessages } from "@contracts/constants";
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const createRouter = t.router;
export const publicQuery = t.procedure;

// ─── Require Authentication ───
const requireAuth = t.middleware(async (opts) => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: ErrorMessages.unauthenticated,
    });
  }

  return next({ ctx: { ...ctx, user: ctx.user } });
});

// ─── Require Admin Role ───
function requireAdmin() {
  return t.middleware(async (opts) => {
    const { ctx, next } = opts;

    if (!ctx.user || ctx.user.role !== "admin") {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: ErrorMessages.insufficientRole,
      });
    }

    return next({ ctx: { ...ctx, user: ctx.user } });
  });
}

// ─── Require Company Membership ───
// This middleware requires authentication and checks company membership
// Company ID is read from input, validation happens in resolver
const requireCompanyAccess = t.middleware(async (opts) => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: ErrorMessages.unauthenticated,
    });
  }

  // Admins bypass company checks
  if (ctx.user.role === "admin") {
    return next({ ctx: { ...ctx, user: ctx.user } });
  }

  // For non-admins, we check membership in the resolver using ctx.user.id
  return next({ ctx: { ...ctx, user: ctx.user } });
});

// Procedure types
export const authedQuery = t.procedure.use(requireAuth);
export const adminQuery = authedQuery.use(requireAdmin());

// Company procedures: authed + company access check
// Actual membership validation happens in resolvers via companyId param
export const companyViewerProcedure = t.procedure.use(requireAuth).use(requireCompanyAccess);
export const companyManagerProcedure = t.procedure.use(requireAuth).use(requireCompanyAccess);
