import { drizzle } from "drizzle-orm/mysql2";
import { env } from "../lib/env";
import * as schema from "@db/schema";
import * as relations from "@db/relations";

const fullSchema = { ...schema, ...relations };

let instance: ReturnType<typeof drizzle<typeof fullSchema>>;
let dbError: string | null = null;

export function getDb() {
  if (!instance) {
    try {
      instance = drizzle(env.databaseUrl, {
        mode: "planetscale",
        schema: fullSchema,
      });
    } catch (e: any) {
      dbError = e.message;
      console.error("[DB] Failed to connect:", e.message);
      throw new Error("Database connection failed: " + e.message);
    }
  }
  return instance;
}

export function getDbStatus() {
  return { connected: !!instance, error: dbError };
}
