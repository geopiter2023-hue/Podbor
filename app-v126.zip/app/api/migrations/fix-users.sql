-- Fix users table - add missing columns
-- Run this on your MySQL database:
-- mysql -u root -p oilpodbor < fix-users.sql

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS unionId VARCHAR(255) AFTER id,
  ADD COLUMN IF NOT EXISTS username VARCHAR(255) UNIQUE AFTER unionId,
  ADD COLUMN IF NOT EXISTS passwordHash VARCHAR(255) AFTER username,
  ADD COLUMN IF NOT EXISTS name VARCHAR(255) AFTER passwordHash,
  ADD COLUMN IF NOT EXISTS email VARCHAR(320) AFTER name,
  ADD COLUMN IF NOT EXISTS avatar TEXT AFTER email,
  ADD COLUMN IF NOT EXISTS role ENUM('user','admin') DEFAULT 'user' NOT NULL AFTER avatar,
  ADD COLUMN IF NOT EXISTS lastSignInAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER updatedAt;

-- Ensure admin user exists with correct role
UPDATE users SET role = 'admin' WHERE username = 'admin';

-- If users table doesn't exist at all, create it:
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  unionId VARCHAR(255),
  username VARCHAR(255) UNIQUE,
  passwordHash VARCHAR(255),
  name VARCHAR(255),
  email VARCHAR(320),
  avatar TEXT,
  role ENUM('user','admin') DEFAULT 'user' NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  lastSignInAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add aiAgentResults table
CREATE TABLE IF NOT EXISTS aiAgentResults (
  id INT AUTO_INCREMENT PRIMARY KEY,
  make VARCHAR(255) NOT NULL,
  model VARCHAR(255) NOT NULL,
  generation VARCHAR(500),
  modification VARCHAR(500),
  engineCode VARCHAR(100),
  agentName VARCHAR(100) NOT NULL,
  agentProvider VARCHAR(50) NOT NULL,
  filledFields JSON,
  filledCount INT DEFAULT 0,
  rawResponse TEXT,
  parsedJson JSON,
  tokensInput INT DEFAULT 0,
  tokensOutput INT DEFAULT 0,
  tokensTotal INT DEFAULT 0,
  status ENUM('success','error','empty') DEFAULT 'success' NOT NULL,
  errorMessage TEXT,
  durationMs INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  INDEX idx_car (make, model),
  INDEX idx_agent (agentProvider),
  INDEX idx_created (createdAt)
);
