import type { Hono } from "hono";
import type { HttpBindings } from "@hono/node-server";
import { serveStatic } from "@hono/node-server/serve-static";
import fs from "fs";
import path from "path";

type App = Hono<{ Bindings: HttpBindings }>;

export function serveStaticFiles(app: App) {
  // Absolute path to dist/public (works regardless of cwd)
  const distPath = path.resolve(import.meta.dirname, "../dist/public");

  console.log("[serveStatic] distPath:", distPath);
  console.log("[serveStatic] index.html exists:", fs.existsSync(path.join(distPath, "index.html")));

  // 1. Serve actual static files (JS, CSS, images, etc.)
  // These have dots in their path and exist on disk
  app.use("*", serveStatic({ root: distPath }));

  // 2. SPA fallback: for non-API routes without file extensions,
  // serve index.html so React Router can handle the route
  app.notFound((c) => {
    const url = c.req.url;
    const reqPath = new URL(url).pathname;

    // Never interfere with API
    if (reqPath.startsWith("/api/")) {
      return c.json({ error: "API Not Found" }, 404);
    }

    // If it's a file request (has extension), let it 404 naturally
    if (path.extname(reqPath) && reqPath !== "/") {
      return c.json({ error: "Not Found" }, 404);
    }

    // SPA fallback: serve index.html for all page routes
    const indexPath = path.join(distPath, "index.html");
    if (fs.existsSync(indexPath)) {
      return c.html(fs.readFileSync(indexPath, "utf-8"));
    }

    return c.json({ error: "index.html not found at " + indexPath }, 500);
  });
}
