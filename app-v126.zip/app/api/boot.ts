// Polyfill for AbortSignal.timeout (not available in older Node.js)
if (typeof (AbortSignal as any).timeout !== "function") {
  (AbortSignal as any).timeout = function(ms: number) {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(new DOMException("Timeout", "AbortError")), ms);
    return ctrl.signal;
  };
}

import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { createOAuthCallbackHandler } from "./kimi/auth";
import { Paths } from "@contracts/constants";

const app = new Hono<{ Bindings: HttpBindings }>();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.get(Paths.oauthCallback, createOAuthCallbackHandler());
// Serve uploaded PDF manuals
import fs from "fs";
import path from "path";

app.use("/uploads/manuals/*", async (c) => {
  const filePath = path.join(process.cwd(), "uploads", "manuals", c.req.path.replace("/uploads/manuals/", ""));
  if (fs.existsSync(filePath)) {
    const buffer = fs.readFileSync(filePath);
    return c.body(buffer, 200, { "Content-Type": "application/pdf" });
  }
  return c.json({ error: "PDF not found" }, 404);
});

app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

// ─── Health check endpoint ───
app.get("/health", async (c) => {
  // Check DB
  let dbStatus = "unknown";
  try {
    const { getDbStatus } = await import("./queries/connection");
    const status = getDbStatus();
    dbStatus = status.connected ? "connected" : "disconnected";
  } catch {
    dbStatus = "error";
  }

  return c.json({
    status: "ok",
    version: "v115",
    time: new Date().toISOString(),
    uptime: process.uptime(),
    db: dbStatus,
  });
});

// ─── Global error handler ───
app.onError((err, c) => {
  console.error(`[Server Error] ${c.req.method} ${c.req.path}:`, err);
  return c.json({ error: "Internal server error", message: env.isProduction ? undefined : err.message }, 500);
});

// ─── Start server ───
if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);

    // Start background drom.ru monitoring
    try {
      const { startBackgroundMonitoring } = require("./agents/dromParser");
      startBackgroundMonitoring();
    } catch (e: any) {
      console.warn("[Boot] Could not start drom monitoring:", e.message);
    }
  });
} else {
  // Dev mode — just export app for Vite plugin
  console.log("[Boot] Dev mode — server handled by Vite plugin");
}
