import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import type { User } from "@db/schema";
import { authenticateRequest } from "./kimi/auth";
import { verifyLocalToken } from "./routers/localAuth";
import { getDb } from "./queries/connection";
import { users } from "@db/schema";
import { eq } from "drizzle-orm";

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user?: User;
};

async function getLocalUser(headers: Headers): Promise<User | undefined> {
  const token =
    headers.get("x-local-auth-token") ||
    headers.get("X-Local-Auth-Token");

  if (!token) return undefined;

  const payload = await verifyLocalToken(token);
  if (!payload) return undefined;

  const db = getDb();
  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.id, payload.userId))
    .limit(1);

  return user || undefined;
}

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const ctx: TrpcContext = { req: opts.req, resHeaders: opts.resHeaders };

  // Try OAuth first
  try {
    ctx.user = await authenticateRequest(opts.req.headers);
  } catch {
    // OAuth failed, try local auth
  }

  // If no OAuth user, try local auth
  if (!ctx.user) {
    try {
      ctx.user = await getLocalUser(opts.req.headers);
    } catch {
      // Local auth also failed
    }
  }

  return ctx;
}
