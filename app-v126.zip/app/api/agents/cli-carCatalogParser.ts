#!/usr/bin/env tsx
import { runCarCatalogParser } from "./carCatalogParser";

const args = process.argv.slice(2);
const makeId = args.find(a => a.startsWith("--make-id="))?.split("=")[1];
const limit = args.find(a => a.startsWith("--limit="))?.split("=")[1];
const dryRun = args.includes("--dry-run");

runCarCatalogParser({
  makeId: makeId ? parseInt(makeId) : undefined,
  limit: limit ? parseInt(limit) : undefined,
  dryRun,
}).then(() => process.exit(0)).catch(e => {
  console.error(e);
  process.exit(1);
});
