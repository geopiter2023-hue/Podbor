/**
 * Drom.ru Deep Catalog Parser
 * Full traversal: Brand → Model → Generation → Modification → Specs
 * Human-like behavior with delays
 */

import { getDb } from "../queries/connection";
import { marketCars, marketSyncLog } from "@db/schema";
import { eq, and, sql, desc } from "drizzle-orm";
import iconv from "iconv-lite";
import * as cheerio from "cheerio";

const USER_AGENTS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
];

let uaIndex = 0;
function getUA() { uaIndex = (uaIndex + 1) % USER_AGENTS.length; return USER_AGENTS[uaIndex]; }

function sleep(ms: number) { return new Promise((r) => setTimeout(r, ms)); }
function randomDelay(min: number, max: number) { return sleep(Math.floor(Math.random() * (max - min) + min)); }

async function fetchHumanLike(url: string, retries = 3): Promise<string> {
  for (let i = 0; i <= retries; i++) {
    try {
      await randomDelay(2000, 5000);
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 30000);
      const resp = await fetch(url, {
        headers: {
          "User-Agent": getUA(),
          "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
          "Referer": "https://www.drom.ru/catalog/",
          "DNT": "1",
          "Connection": "keep-alive",
          "Upgrade-Insecure-Requests": "1",
          "Sec-Fetch-Dest": "document",
          "Sec-Fetch-Mode": "navigate",
          "Sec-Fetch-Site": "same-origin",
          "Cache-Control": "max-age=0",
        },
        redirect: "follow",
        signal: controller.signal,
      });
      clearTimeout(timeout);

      if (!resp.ok) {
        if (resp.status === 429 || resp.status === 503) { await sleep(5000 * (i + 1)); continue; }
        if (resp.status === 403) { await randomDelay(5000, 10000); continue; }
        throw new Error(`HTTP ${resp.status}`);
      }

      const buf = Buffer.from(await resp.arrayBuffer());
      let text = buf.toString("utf-8");
      if (text.includes("\uFFFD") || /[�ЌЋЏђ�]/g.test(text)) text = iconv.decode(buf, "windows-1251");
      const $meta = cheerio.load(text);
      const metaCharset = $meta('meta[charset]').attr('charset') || '';
      const metaContentType = $meta('meta[http-equiv="Content-Type"]').attr('content') || '';
      if ((metaCharset.includes("1251") || metaContentType.includes("1251")) && !(resp.headers.get("content-type") || "").includes("1251")) text = iconv.decode(buf, "windows-1251");
      return text;
    } catch (e: any) { if (i === retries) throw e; await randomDelay(3000, 8000); }
  }
  throw new Error(`All retries failed for ${url}`);
}

// ─── Extract links from page using tile patterns ───
function extractLinks($: cheerio.CheerioAPI, pattern: RegExp): Array<{ name: string; slug: string; url: string; years?: string }> {
  const results: Array<{ name: string; slug: string; url: string; years?: string }> = [];
  const seen = new Set<string>();
  const selectors = ['.b-tile a', '.e-title a', '[class*="tile"] a', '[class*="model"] a', '[class*="item"] a', 'a[href*="/catalog/"]'];
  for (const sel of selectors) {
    $(sel).each((_, el) => {
      const href = $(el).attr("href") || "";
      const m = href.match(pattern);
      if (!m) return;
      const slug = m[1];
      const text = $(el).text().trim();
      if (!slug || !text || text.length < 2 || text.length > 80) return;
      if (seen.has(slug)) return;
      // Filter out non-content slugs
      if (/\.(js|css|png|jpg|svg)$|^~|^api$|^search$/i.test(slug)) return;
      seen.add(slug);
      const yearMatch = text.match(/(\d{4}[\s–—-]+\d{4}?|\d{4}\s*-\s*н\.в\.)/);
      const name = text.replace(/\d{4}[\s–—-]+\d{4}?/g, "").replace(/каталог/gi, "").trim();
      results.push({ name: name || text, slug, url: href.startsWith("http") ? href : `https://www.drom.ru${href}`, years: yearMatch ? yearMatch[1] : undefined });
    });
  }
  return results;
}

// ─── Parse brands ───
export async function fetchDromBrands(): Promise<Array<{ name: string; slug: string; url: string }>> {
  const html = await fetchHumanLike("https://www.drom.ru/catalog/");
  const $ = cheerio.load(html);
  const brands = extractLinks($, /\/catalog\/([^\/]+)\/?$/);
  // Filter: must be actual car brands, not pages like lcv, chinese, etc.
  const excludeSlugs = new Set(["lcv", "chinese", "catalog", "search", "~search", "avto", "auto"]);
  const filtered = brands.filter((b) => !excludeSlugs.has(b.slug.toLowerCase()) && b.name.length > 1 && b.name.length < 40);
  console.log(`[DromParser] Found ${filtered.length} brands`);
  return filtered;
}

// ─── Parse models for a brand ───
export async function fetchDromModels(brandSlug: string): Promise<Array<{ name: string; slug: string; url: string }>> {
  const html = await fetchHumanLike(`https://www.drom.ru/catalog/${brandSlug}/`);
  const $ = cheerio.load(html);
  const models = extractLinks($, new RegExp(`/catalog/${brandSlug}/([^/]+)/?$`));
  console.log(`[DromParser] ${brandSlug}: ${models.length} models`);
  return models;
}

// ─── Parse generations for a model ───
export async function fetchDromGenerations(brandSlug: string, modelSlug: string): Promise<Array<{ name: string; slug: string; url: string; years: string }>> {
  const html = await fetchHumanLike(`https://www.drom.ru/catalog/${brandSlug}/${modelSlug}/`);
  const $ = cheerio.load(html);
  const gens = extractLinks($, new RegExp(`/catalog/${brandSlug}/${modelSlug}/([^/]+)/?$`));
  const result = gens.map((g) => {
    const yearMatch = g.name.match(/(\d{4}[\s–—-]+\d{4}?|\d{4}\s*-\s*н\.в\.)/);
    return { ...g, years: yearMatch ? yearMatch[1] : (g.years || "") };
  });
  console.log(`[DromParser] ${brandSlug}/${modelSlug}: ${result.length} generations`);
  return result;
}

// ─── Parse modifications for a generation ───
export async function fetchDromModifications(brandSlug: string, modelSlug: string, genSlug: string): Promise<Array<{ name: string; url: string; engineCode?: string; power?: string; fuel?: string }>> {
  const html = await fetchHumanLike(`https://www.drom.ru/catalog/${brandSlug}/${modelSlug}/${genSlug}/`);
  const $ = cheerio.load(html);
  const mods: Array<{ name: string; url: string; engineCode?: string; power?: string; fuel?: string }> = [];
  const seen = new Set<string>();

  // Method 1: modification list items
  $('.b-tile a, .e-title a, [class*="modif"] a, [class*="engine"] a, a[href*="/catalog/"]').each((_, el) => {
    const href = $(el).attr("href") || "";
    // Match: /catalog/audi/a4/8k/12345/
    const m = href.match(new RegExp(`/catalog/${brandSlug}/${modelSlug}/${genSlug}/([0-9]+)/?$`));
    if (!m) return;
    const modId = m[1];
    if (seen.has(modId)) return;
    seen.add(modId);

    const container = $(el).closest('div, li, tr, [class*="tile"], [class*="item"], [class*="modif"]');
    let name = $(el).text().trim();
    let engineCode = "";
    let power = "";
    let fuel = "";

    // Try to extract from container text
    const containerText = container.text();
    const engineMatch = containerText.match(/([A-Z][A-Z0-9]+\s+[A-Z0-9]+)/);
    if (engineMatch) engineCode = engineMatch[1];
    const powerMatch = containerText.match(/(\d+)\s*л\.\s*с/);
    if (powerMatch) power = `${powerMatch[1]} л.с.`;
    const fuelKeywords = ["бензин", "дизель", "электро", "гибрид", "газ"];
    for (const f of fuelKeywords) { if (containerText.toLowerCase().includes(f)) { fuel = f.charAt(0).toUpperCase() + f.slice(1); break; } }

    // Clean name
    name = name.replace(/\s+/g, " ").trim();
    if (name.length < 2) name = containerText.substring(0, 60).trim();

    mods.push({ name, url: href.startsWith("http") ? href : `https://www.drom.ru${href}`, engineCode, power, fuel });
  });

  // Method 2: look for table rows with specs
  if (mods.length === 0) {
    $('table tr, [class*="spec"] tr, [class*="tech"] tr').each((_, el) => {
      const tds = $(el).find('td, [class*="cell"]');
      if (tds.length >= 2) {
        const name = $(tds[0]).text().trim();
        const detailText = $(el).text();
        const engineMatch = detailText.match(/([A-Z][A-Z0-9]+\s*[A-Z0-9]*)/);
        const powerMatch = detailText.match(/(\d+)\s*л\.\s*с/);
        let fuel = "";
        for (const f of ["бензин", "дизель", "электро", "гибрид"]) { if (detailText.toLowerCase().includes(f)) { fuel = f.charAt(0).toUpperCase() + f.slice(1); break; } }
        if (name.length > 2 && name.length < 60) {
          const key = name.substring(0, 30);
          if (!seen.has(key)) {
            seen.add(key);
            mods.push({ name, url: `https://www.drom.ru/catalog/${brandSlug}/${modelSlug}/${genSlug}/`, engineCode: engineMatch ? engineMatch[1] : "", power: powerMatch ? `${powerMatch[1]} л.с.` : "", fuel });
          }
        }
      }
    });
  }

  console.log(`[DromParser] ${brandSlug}/${modelSlug}/${genSlug}: ${mods.length} modifications`);
  return mods;
}

// ─── Deep parse: modification card page ───
export async function fetchDromModificationSpecs(url: string): Promise<Record<string, string>> {
  const html = await fetchHumanLike(url);
  const $ = cheerio.load(html);
  const specs: Record<string, string> = {};

  // Parse all spec tables
  const specSelectors = [
    'table tr', '.techspec__row', '.b-table tr',
    '[class*="spec"] tr', '[class*="char"] tr',
    '[class*="parameter"] tr', '[class*="property"] tr',
  ];
  for (const sel of specSelectors) {
    $(sel).each((_, el) => {
      const cells = $(el).find('td, th, [class*="name"], [class*="value"], [class*="label"], [class*="data"]');
      if (cells.length >= 2) {
        const label = $(cells[0]).text().trim().toLowerCase().replace(/[:\s]+$/g, "");
        const value = $(cells[1]).text().trim();
        if (label && value && value.length > 0 && value.length < 200) {
          specs[label] = value;
        }
      }
    });
  }

  // Also try definition lists
  $('dl dt, dl dd').each((i, el) => {
    if (i % 2 === 0) {
      const label = $(el).text().trim().toLowerCase().replace(/[:\s]+$/g, "");
      const dd = $(el).next('dd');
      if (dd.length) {
        const value = dd.text().trim();
        if (label && value) specs[label] = value;
      }
    }
  });

  // Parse from page title for fallback
  const title = $('title').text();
  const titleEngineMatch = title.match(/([A-Z]\d+[A-Z]*)/);
  if (titleEngineMatch && !Object.keys(specs).some((k) => k.includes("двиг"))) {
    specs["код двигателя"] = titleEngineMatch[1];
  }

  return specs;
}

// ─── Extract structured data from raw specs ───
function extractStructuredSpecs(rawSpecs: Record<string, string>) {
  const result: any = {};
  for (const [key, value] of Object.entries(rawSpecs)) {
    const k = key.toLowerCase();
    if (k.includes("объём") && k.includes("двиг")) result.engineCapacity = value;
    else if (k.includes("мощност")) result.enginePower = value;
    else if ((k.includes("тип") || k.includes("располож")) && k.includes("двиг")) result.engineType = value;
    else if (k.includes("топлив")) result.fuel = value;
    else if (k.includes("короб")) result.transmission = value;
    else if (k.includes("привод")) result.drive = value;
    else if (k.includes("кузов") || k.includes("тип кузова")) result.body = value;
    else if (k.includes("код") && k.includes("двиг")) result.engineCode = value;
    else if (k.includes("объём") && k.includes("масл")) result.oilVolume = value;
    else if (k.includes("вязкост") || k.includes("sae") || k.includes("класс вязкости")) result.oilSae = value;
    else if (k.includes("охлаждающ") || k.includes("антифриз") || k.includes("тосол")) result.coolantVolume = value;
    else if (k.includes("тормозн") || k.includes("тормозная жидк")) result.brakeFluid = value;
    else if (k.includes("трансмисс") && k.includes("масл")) result.transmissionOil = value;
    else if (k.includes("дверей")) result.doors = value;
    else if (k.includes("мест")) result.seats = value;
    else if (k.includes("крутящ") || k.includes("момент")) result.torque = value;
    else if (k.includes("цилиндр")) result.cylinders = value;
    else if (k.includes("клапан")) result.valves = value;
    else if (k.includes("компресс")) result.compression = value;
    else if (k.includes("масса") || k.includes("вес")) result.weight = value;
    else if (k.includes("разгон")) result.acceleration = value;
    else if (k.includes("скорост")) result.maxSpeed = value;
    else if (k.includes("расход")) result.fuelConsumption = value;
    else if (k.includes("ёмкост") && k.includes("бак")) result.fuelTank = value;
    else if (k.includes("клиренс") || k.includes("дорожный просвет")) result.groundClearance = value;
  }
  return result;
}

// ─── Main deep scan ───
export async function scanDromCatalog(options: {
  brandLimit?: number;
  modelLimit?: number;
  deepParse?: boolean;
  syncId?: number;
  onProgress?: (msg: string) => void;
} = {}) {
  const db = getDb();
  const deepParse = options.deepParse !== false;

  let syncId = options.syncId || 0;
  if (!syncId) {
    const [syncLog] = await db.insert(marketSyncLog).values({ source: "drom.ru", status: "running" }).$returningId();
    syncId = syncLog.id;
  }

  try {
    options.onProgress?.("Получаем список марок...");
    const brands = await fetchDromBrands();
    if (brands.length === 0) {
      options.onProgress?.("Марки не найдены");
      await db.update(marketSyncLog).set({ status: "failed", error: "No brands found", completedAt: new Date() }).where(eq(marketSyncLog.id, syncId));
      return { syncId, totalFound: 0, totalNew: 0, duration: 0 };
    }
    options.onProgress?.(`Найдено ${brands.length} марок`);

    let totalFound = 0;
    let totalNew = 0;
    const scannedBrands = options.brandLimit ? brands.slice(0, options.brandLimit) : brands;

    for (let bi = 0; bi < scannedBrands.length; bi++) {
      const brand = scannedBrands[bi];
      options.onProgress?.(`[${bi + 1}/${scannedBrands.length}] ${brand.name} — модели...`);

      try {
        const models = await fetchDromModels(brand.slug);
        const scannedModels = options.modelLimit ? models.slice(0, options.modelLimit) : models;
        await randomDelay(1000, 3000);

        for (const model of scannedModels) {
          try {
            // Step 1: Get generations
            const generations = await fetchDromGenerations(brand.slug, model.slug);
            await randomDelay(800, 2000);

            if (generations.length === 0) {
              // No generations — save model-level entry
              await saveMarketCar(db, brand.name, model.name, "", "", {}, null, null, totalFound);
              totalFound++;
              continue;
            }

            for (const gen of generations) {
              try {
                // Step 2: Get modifications
                const modifications = await fetchDromModifications(brand.slug, model.slug, gen.slug);
                await randomDelay(800, 2000);

                // Parse year range
                let yearFrom: number | null = null;
                let yearTo: number | null = null;
                if (gen.years) {
                  const ym = gen.years.match(/(\d{4})/g);
                  if (ym) { yearFrom = parseInt(ym[0]); if (ym[1]) yearTo = parseInt(ym[1]); }
                }

                if (modifications.length === 0) {
                  // No modifications — save generation-level entry
                  await saveMarketCar(db, brand.name, model.name, gen.name, "", {}, yearFrom, yearTo, totalFound);
                  totalFound++;
                  continue;
                }

                for (const mod of modifications) {
                  try {
                    let fullSpecs: Record<string, string> = {};

                    // Step 3: Deep parse modification page
                    if (deepParse) {
                      try {
                        fullSpecs = await fetchDromModificationSpecs(mod.url);
                        await randomDelay(1000, 2500);
                      } catch (e: any) {
                        console.warn(`[DromParser] Deep parse failed: ${mod.url}: ${e.message}`);
                      }
                    }

                    const structured = extractStructuredSpecs(fullSpecs);

                    // Merge data from listing + deep parse
                    const finalSpecs = {
                      ...structured,
                      engineCode: mod.engineCode || structured.engineCode,
                      enginePower: mod.power || structured.enginePower,
                      fuel: mod.fuel || structured.fuel,
                      rawSpecs: fullSpecs,
                    };

                    const isNew = await saveMarketCar(
                      db, brand.name, model.name, gen.name, mod.name,
                      finalSpecs, yearFrom, yearTo, totalFound,
                    );
                    if (isNew) totalNew++;
                    totalFound++;

                    // Progress update every 10 cars
                    if (totalFound % 10 === 0) {
                      options.onProgress?.(`Обработано ${totalFound} авто (${brand.name} ${model.name})...`);
                    }
                  } catch (e: any) {
                    console.warn(`[DromParser] Mod error: ${e.message}`);
                  }
                }
              } catch (e: any) {
                console.warn(`[DromParser] Gen error: ${e.message}`);
              }
            }
          } catch (e: any) {
            console.warn(`[DromParser] Model error: ${e.message}`);
          }
        }
      } catch (e: any) {
        options.onProgress?.(`Ошибка марки ${brand.name}: ${e.message}`);
      }

      await randomDelay(2000, 5000);
    }

    await db.update(marketSyncLog).set({ status: "completed", carsFound: totalFound, carsNew: totalNew, completedAt: new Date() }).where(eq(marketSyncLog.id, syncId));
    const duration = Math.round((Date.now() - (await db.select().from(marketSyncLog).where(eq(marketSyncLog.id, syncId)).limit(1))[0].startedAt.getTime()) / 1000);
    options.onProgress?.(`Готово! ${totalFound} найдено, ${totalNew} новых`);
    return { syncId, totalFound, totalNew, duration };
  } catch (e: any) {
    await db.update(marketSyncLog).set({ status: "failed", error: e.message, completedAt: new Date() }).where(eq(marketSyncLog.id, syncId));
    throw e;
  }
}

// ─── Save market car with full data ───
async function saveMarketCar(
  db: any, make: string, model: string, generation: string, modification: string,
  specs: any, yearFrom: number | null, yearTo: number | null, index: number,
): Promise<boolean> {
  // Check if exists
  const existing = await db.select().from(marketCars).where(
    and(
      sql`LOWER(${marketCars.make}) = LOWER(${make})`,
      sql`LOWER(${marketCars.model}) = LOWER(${model})`,
      generation ? sql`LOWER(${marketCars.generation}) = LOWER(${generation})` : sql`1=1`,
      modification ? sql`LOWER(${marketCars.modification}) = LOWER(${modification})` : sql`1=1`,
    )
  ).limit(1);

  const rawData = JSON.stringify({
    engineType: specs.engineType,
    engineCapacity: specs.engineCapacity,
    enginePower: specs.enginePower,
    engineCode: specs.engineCode,
    fuel: specs.fuel,
    transmission: specs.transmission,
    drive: specs.drive,
    body: specs.body,
    oilVolume: specs.oilVolume,
    oilSae: specs.oilSae,
    coolantVolume: specs.coolantVolume,
    brakeFluid: specs.brakeFluid,
    transmissionOil: specs.transmissionOil,
    doors: specs.doors,
    seats: specs.seats,
    torque: specs.torque,
    cylinders: specs.cylinders,
    valves: specs.valves,
    compression: specs.compression,
    weight: specs.weight,
    acceleration: specs.acceleration,
    maxSpeed: specs.maxSpeed,
    fuelConsumption: specs.fuelConsumption,
    fuelTank: specs.fuelTank,
    groundClearance: specs.groundClearance,
    rawSpecs: specs.rawSpecs,
  });

  if (existing.length === 0) {
    await db.insert(marketCars).values({
      source: "drom.ru",
      sourceUrl: specs.rawSpecs ? "deep-parsed" : "",
      make, model, generation: generation || null, modification: modification || null,
      yearFrom, yearTo,
      engineCode: specs.engineCode || null,
      engineCapacity: specs.engineCapacity || null,
      enginePower: specs.enginePower || null,
      fuel: specs.fuel || null,
      transmission: specs.transmission || null,
      drive: specs.drive || null,
      body: specs.body || null,
      status: "new",
      rawData,
    });
    return true;
  } else {
    await db.update(marketCars).set({
      yearFrom, yearTo,
      engineCode: specs.engineCode || existing[0].engineCode,
      engineCapacity: specs.engineCapacity || existing[0].engineCapacity,
      enginePower: specs.enginePower || existing[0].enginePower,
      fuel: specs.fuel || existing[0].fuel,
      transmission: specs.transmission || existing[0].transmission,
      drive: specs.drive || existing[0].drive,
      body: specs.body || existing[0].body,
      rawData,
      status: "updated",
    }).where(eq(marketCars.id, existing[0].id));
    return false;
  }
}

// ─── Stats ───
export async function getMarketStats() {
  const db = getDb();
  const statuses = ["new", "pending", "approved", "rejected", "updated", "merged"];
  const result: Record<string, number> = {};
  for (const s of statuses) {
    const r = await db.select({ count: sql<number>`COUNT(*)` }).from(marketCars).where(eq(marketCars.status, s as any));
    result[s] = Number(r[0]?.count || 0);
  }
  const total = await db.select({ count: sql<number>`COUNT(*)` }).from(marketCars);
  result.total = Number(total[0]?.count || 0);
  return result;
}

// ─── Approve ───
export async function approveMarketCar(marketCarId: number, userId?: number) {
  const db = getDb();
  const [mc] = await db.select().from(marketCars).where(eq(marketCars.id, marketCarId)).limit(1);
  if (!mc) throw new Error("Market car not found");
  let specs: any = {};
  try { specs = JSON.parse(mc.rawData || "{}"); } catch { /* ignore */ }
  const [existing] = await db.select().from(sql.raw("carFluidSpecs")).where(
    and(sql`LOWER(make) = LOWER(${mc.make})`, sql`LOWER(model) = LOWER(${mc.model})`)
  ).limit(1);
  if (existing) {
    await db.update(sql.raw("carFluidSpecs")).set({
      engineCode: specs.engineCode || mc.engineCode || existing.engineCode,
      engineFillVolume: specs.oilVolume || existing.engineFillVolume,
      prefOilSae: specs.oilSae || existing.prefOilSae,
      coolantFillVolume: specs.coolantVolume || existing.coolantFillVolume,
      brakeFluidType: specs.brakeFluid || existing.brakeFluidType,
      transmissionType: mc.transmission || specs.transmission || existing.transmissionType,
      body: mc.body || specs.body || existing.body,
      fuel: mc.fuel || specs.fuel || existing.fuel,
      updatedAt: new Date(),
    }).where(eq(sql.raw("carFluidSpecs.id"), existing.id));
  }
  await db.update(marketCars).set({ status: "approved", reviewedBy: userId, reviewedAt: new Date() }).where(eq(marketCars.id, marketCarId));
  return { ok: true };
}

// ─── Background scheduler ───
let cronJob: any = null;
export function startBackgroundMonitoring() {
  if (cronJob) return;
  try {
    const { schedule } = require("node-cron");
    cronJob = schedule("0 */6 * * *", async () => {
      console.log("[DromMonitor] Scheduled scan at", new Date().toISOString());
      try {
        const db = getDb();
        const running = await db.select().from(marketSyncLog).where(and(eq(marketSyncLog.source, "drom.ru"), eq(marketSyncLog.status, "running" as any))).limit(1);
        if (running.length > 0) { console.log("[DromMonitor] Already running, skip"); return; }
        await scanDromCatalog({ onProgress: (msg) => console.log(`[DromMonitor] ${msg}`) });
      } catch (e: any) { console.error("[DromMonitor] Error:", e.message); }
    });
    console.log("[DromMonitor] Started (every 6h)");
  } catch (e: any) { console.warn("[DromMonitor] Could not start:", e.message); }
}
export function stopBackgroundMonitoring() {
  if (cronJob) { cronJob.stop(); cronJob = null; console.log("[DromMonitor] Stopped"); }
}
