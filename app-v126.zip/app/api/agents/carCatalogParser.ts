/**
 * AI Agent: Car Catalog Parser
 * Parses car data from external catalog APIs
 * Usage: npx tsx api/agents/carCatalogParser.ts [--make-id=11351] [--limit=100]
 */
import { getDb } from "../queries/connection";
import { cars, brands, models, modifications } from "@db/schema";
import { sql, eq, like } from "drizzle-orm";

interface ParseOptions {
  makeId?: number;
  modelId?: number;
  limit?: number;
  dryRun?: boolean;
}

// ─── Parse modifications and create cars ───
export async function runCarCatalogParser(options: ParseOptions = {}) {
  const db = getDb();
  const results = {
    created: 0,
    updated: 0,
    skipped: 0,
    errors: [] as string[],
  };

  console.log("[CarCatalogParser] Starting...", options);

  // Get modifications to process
  let modQuery = db.select().from(modifications);
  if (options.makeId) {
    modQuery = modQuery.where(eq(modifications.makeId, options.makeId)) as any;
  }
  if (options.limit) {
    modQuery = (modQuery as any).limit(options.limit);
  }

  const allMods = await modQuery;
  console.log(`[CarCatalogParser] Found ${allMods.length} modifications to process`);

  for (const mod of allMods) {
    try {
      const carId = `${mod.makeId}_${mod.modelId}_${mod.id}`;

      // Check if car already exists
      const [existing] = await db.select().from(cars).where(eq(cars.id, carId)).limit(1);

      if (existing) {
        results.skipped++;
        continue;
      }

      if (options.dryRun) {
        console.log(`[DRY-RUN] Would create car: ${carId}`);
        results.created++;
        continue;
      }

      // Get brand and model info
      const [brand] = await db.select().from(brands).where(eq(brands.id, mod.makeId)).limit(1);
      const [model] = await db.select().from(models)
        .where(sql`${models.makeId} = ${mod.makeId} AND ${models.modelId} = ${mod.modelId}`)
        .limit(1);

      // Extract year
      function extractYear(dateStr: string | null): number | null {
        if (!dateStr) return null;
        const match = dateStr.match(/(\d{4})/);
        return match ? parseInt(match[1]) : null;
      }

      // Map fuel
      function mapFuel(fuel: string | null): number | null {
        if (!fuel) return null;
        const f = fuel.toLowerCase();
        if (f.includes("бензин")) return 1;
        if (f.includes("дизель")) return 2;
        if (f.includes("гибрид")) return 3;
        if (f.includes("электро")) return 4;
        if (f.includes("газ")) return 5;
        return null;
      }

      // Insert car
      await db.insert(cars).values({
        id: carId,
        vehicleTypeId: 1, // Легковые
        make: brand?.name || "Unknown",
        model: model?.modelName || "Unknown",
        modification: (mod.name || "") + (mod.engineCode ? ` (${mod.engineCode})` : ""),
        yearFrom: extractYear(mod.startDate),
        yearTo: extractYear(mod.endDate),
        engineCapacity: mod.engineCapacity || null,
        fuelTypeId: mapFuel(mod.fuel),
        engineCode: mod.engineCode || null,
        engineName: mod.fullName || null,
        horsePower: mod.horsePower || null,
      });

      results.created++;

      if (results.created % 100 === 0) {
        console.log(`[CarCatalogParser] Progress: ${results.created} created, ${results.skipped} skipped`);
      }
    } catch (e: any) {
      results.errors.push(`${mod.id}: ${e.message}`);
      if (results.errors.length <= 5) {
        console.error(`[CarCatalogParser] Error processing ${mod.id}:`, e.message);
      }
    }
  }

  console.log("[CarCatalogParser] Done:", results);
  return results;
}

// ─── CLI usage ───
// NOTE: CLI code moved to api/agents/cli-carCatalogParser.ts
