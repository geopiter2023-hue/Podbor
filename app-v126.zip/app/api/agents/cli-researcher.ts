#!/usr/bin/env tsx
/**
 * CLI wrapper for researcher agent
 * Usage:
 *   npx tsx api/agents/cli-researcher.ts --make=BMW --model=X5 --engine=N55 --year=2015
 *   npx tsx api/agents/cli-researcher.ts --limit=10
 */
import { runResearcher, runBatchResearch } from "./researcher";

const args = process.argv.slice(2);
const make = args.find((a) => a.startsWith("--make="))?.split("=")[1];
const model = args.find((a) => a.startsWith("--model="))?.split("=")[1];
const engineCode = args.find((a) => a.startsWith("--engine="))?.split("=")[1];
const year = args.find((a) => a.startsWith("--year="))?.split("=")[1];
const limit = args.find((a) => a.startsWith("--limit="))?.split("=")[1];

if (make && model) {
  runResearcher({ make, model, engineCode, year: year ? parseInt(year) : undefined })
    .then((result) => {
      console.log(JSON.stringify(result, null, 2));
      process.exit(0);
    })
    .catch((e) => {
      console.error(e);
      process.exit(1);
    });
} else if (limit) {
  runBatchResearch({ limit: parseInt(limit) })
    .then((result) => {
      console.log(JSON.stringify(result, null, 2));
      process.exit(0);
    })
    .catch((e) => {
      console.error(e);
      process.exit(1);
    });
} else {
  console.log(`
Usage:
  Single research:  npx tsx api/agents/cli-researcher.ts --make=BMW --model=X5 --engine=N55 --year=2015
  Batch research:   npx tsx api/agents/cli-researcher.ts --limit=10

Environment variables required:
  ANTHROPIC_API_KEY or OPENAI_API_KEY - for AI research
`);
  process.exit(1);
}
