#!/usr/bin/env tsx
import { runManualFinder, runBatchManualFinder } from "./manualFinder";

const args = process.argv.slice(2);
const make = args.find((a) => a.startsWith("--make="))?.split("=")[1];
const model = args.find((a) => a.startsWith("--model="))?.split("=")[1];
const year = args.find((a) => a.startsWith("--year="))?.split("=")[1];
const engine = args.find((a) => a.startsWith("--engine="))?.split("=")[1];
const limit = args.find((a) => a.startsWith("--limit="))?.split("=")[1];

if (make && model) {
  runManualFinder({ make, model, year: year ? parseInt(year) : undefined, engineCode: engine })
    .then((r) => { console.log(JSON.stringify(r, null, 2)); process.exit(0); })
    .catch((e) => { console.error(e); process.exit(1); });
} else if (limit) {
  runBatchManualFinder({ limit: parseInt(limit) })
    .then((r) => { console.log(JSON.stringify(r, null, 2)); process.exit(0); })
    .catch((e) => { console.error(e); process.exit(1); });
} else {
  console.log(`
Usage:
  Single:  npx tsx api/agents/cli-manualFinder.ts --make=VW --model="TOUAREG" --year=2020 --engine=CASA
  Batch:   npx tsx api/agents/cli-manualFinder.ts --limit=10
`);
  process.exit(1);
}
