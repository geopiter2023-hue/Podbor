#!/usr/bin/env tsx
import { runLiquidFiller } from "./liquidFiller";

const args = process.argv.slice(2);
const category = args.find(a => a.startsWith("--category="))?.split("=")[1];
const limit = args.find(a => a.startsWith("--limit="))?.split("=")[1];
const dryRun = args.includes("--dry-run");

runLiquidFiller({ category, limit: limit ? parseInt(limit) : undefined, dryRun })
  .then(() => process.exit(0))
  .catch(e => { console.error(e); process.exit(1); });
