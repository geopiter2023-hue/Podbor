import { z } from "zod";
import { TRPCError } from "@trpc/server";
import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { users } from "@db/schema";
import { eq } from "drizzle-orm";

const JWT_SECRET = new TextEncoder().encode(
  process.env.APP_SECRET || "motornaya-local-secret-key-2025"
);

async function createToken(userId: number): Promise<string> {
  return new SignJWT({ userId, type: "local" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(JWT_SECRET);
}

export async function verifyLocalToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET, {
      clockTolerance: 60,
    });
    return payload as { userId: number; type: string };
  } catch {
    return null;
  }
}

export const localAuthRouter = createRouter({
  login: publicQuery
    .input(
      z.object({
        username: z.string().min(1),
        password: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.username, input.username))
        .limit(1);

      if (!user || !user.passwordHash) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Неверный логин или пароль",
        });
      }

      const valid = await bcrypt.compare(input.password, user.passwordHash);
      if (!valid) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Неверный логин или пароль",
        });
      }

      const token = await createToken(user.id);

      // Update last sign in
      await db
        .update(users)
        .set({ lastSignInAt: new Date() })
        .where(eq(users.id, user.id));

      return {
        token,
        user: {
          id: user.id,
          name: user.name,
          username: user.username,
          role: user.role,
        },
      };
    }),

  me: publicQuery.query(async ({ ctx }) => {
    const authHeader =
      ctx.req.headers.get("x-local-auth-token") ||
      ctx.req.headers.get("X-Local-Auth-Token");

    if (!authHeader) {
      return null;
    }

    const payload = await verifyLocalToken(authHeader);
    if (!payload) {
      return null;
    }

    const db = getDb();
    const [user] = await db
      .select({
        id: users.id,
        name: users.name,
        username: users.username,
        email: users.email,
        avatar: users.avatar,
        role: users.role,
        createdAt: users.createdAt,
      })
      .from(users)
      .where(eq(users.id, payload.userId))
      .limit(1);

    return user || null;
  }),

  register: publicQuery
    .input(
      z.object({
        username: z.string().min(3).max(50),
        password: z.string().min(6),
        name: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Check if username exists
      const [existing] = await db
        .select()
        .from(users)
        .where(eq(users.username, input.username))
        .limit(1);

      if (existing) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "Пользователь с таким логином уже существует",
        });
      }

      // First user or username "admin" gets admin role
      const allUsers = await db.select({ id: users.id }).from(users).limit(1);
      const isAdmin = allUsers.length === 0 || input.username === "admin";

      const hash = await bcrypt.hash(input.password, 12);
      const result = await db.insert(users).values({
        username: input.username,
        passwordHash: hash,
        name: input.name || input.username,
        unionId: `local_${input.username}`,
        role: isAdmin ? "admin" : "user",
      }).$returningId();

      const userId = Number(result[0].id);
      const token = await createToken(userId);

      return {
        token,
        user: {
          id: userId,
          name: input.name || input.username,
          username: input.username,
          role: isAdmin ? "admin" as const : "user" as const,
        },
      };
    }),
});
