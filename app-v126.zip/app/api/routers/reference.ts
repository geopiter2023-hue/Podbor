import { z } from "zod";
import { createRouter, adminQuery, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import {
  vehicleTypes, steeringPositions, carBodyTypes, fuelTypes,
  transmissionTypes, viscosityClasses, liquidCategories, aggregationTrees,
} from "@db/schema";
import { eq, desc, asc } from "drizzle-orm";

// ─── Generic CRUD for reference tables ───
function createRefRouter<T extends { id: number }>(
  tableName: string,
  table: any,
  nameValidator: z.ZodString,
) {
  return createRouter({
    list: adminQuery.query(async () => {
      return getDb().select().from(table).orderBy(asc(table.sortOrder));
    }),
    create: adminQuery
      .input(z.object({ name: nameValidator, sortOrder: z.number().optional() }))
      .mutation(async ({ input }) => {
        const [result] = await getDb().insert(table).values({
          name: input.name,
          sortOrder: input.sortOrder ?? 0,
        }).$returningId();
        return { id: result.id };
      }),
    update: adminQuery
      .input(z.object({ id: z.number(), name: nameValidator, sortOrder: z.number().optional(), isActive: z.enum(["active", "inactive"]).optional() }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await getDb().update(table).set(data).where(eq(table.id, id));
        return { success: true };
      }),
    delete: adminQuery
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await getDb().delete(table).where(eq(table.id, input.id));
        return { success: true };
      }),
  });
}

// ─── Reference Routers ───
export const vehicleTypeRouter = createRefRouter("vehicleTypes", vehicleTypes, z.string().min(1).max(255));
export const steeringPositionRouter = createRefRouter("steeringPositions", steeringPositions, z.string().min(1).max(100));
export const carBodyTypeRouter = createRefRouter("carBodyTypes", carBodyTypes, z.string().min(1).max(255));
export const fuelTypeRouter = createRefRouter("fuelTypes", fuelTypes, z.string().min(1).max(100));
export const transmissionTypeRouter = createRefRouter("transmissionTypes", transmissionTypes, z.string().min(1).max(255));
export const viscosityClassRouter = createRefRouter("viscosityClasses", viscosityClasses, z.string().min(1).max(50));

// ─── Liquid Categories (with parent) ───
export const liquidCategoryRouter = createRouter({
  list: adminQuery.query(async () => {
    return getDb().select().from(liquidCategories).orderBy(asc(liquidCategories.sortOrder));
  }),
  create: adminQuery
    .input(z.object({
      name: z.string().min(1),
      displayName: z.string().optional(),
      parentId: z.number().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const [result] = await getDb().insert(liquidCategories).values({
        name: input.name,
        displayName: input.displayName || input.name,
        parentId: input.parentId || null,
        sortOrder: input.sortOrder ?? 0,
      }).$returningId();
      return { id: result.id };
    }),
  update: adminQuery
    .input(z.object({
      id: z.number(),
      name: z.string().min(1).optional(),
      displayName: z.string().optional(),
      parentId: z.number().nullable().optional(),
      sortOrder: z.number().optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await getDb().update(liquidCategories).set(data).where(eq(liquidCategories.id, id));
      return { success: true };
    }),
  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(liquidCategories).where(eq(liquidCategories.id, input.id));
      return { success: true };
    }),
});

// ─── Aggregation Trees ───
export const aggregationTreeRouter = createRouter({
  list: adminQuery.query(async () => {
    return getDb().select().from(aggregationTrees).orderBy(asc(aggregationTrees.sortOrder));
  }),
  create: adminQuery
    .input(z.object({
      name: z.string().min(1),
      parentId: z.number().optional(),
      liquidCategoryId: z.number().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const [result] = await getDb().insert(aggregationTrees).values({
        name: input.name,
        parentId: input.parentId || null,
        liquidCategoryId: input.liquidCategoryId || null,
        sortOrder: input.sortOrder ?? 0,
      }).$returningId();
      return { id: result.id };
    }),
  update: adminQuery
    .input(z.object({
      id: z.number(),
      name: z.string().min(1).optional(),
      parentId: z.number().nullable().optional(),
      liquidCategoryId: z.number().nullable().optional(),
      sortOrder: z.number().optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await getDb().update(aggregationTrees).set(data).where(eq(aggregationTrees.id, id));
      return { success: true };
    }),
  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(aggregationTrees).where(eq(aggregationTrees.id, input.id));
      return { success: true };
    }),
});

// ─── Unified reference router ───
export const referenceRouter = createRouter({
  all: adminQuery.query(async () => {
    const db = getDb();
    const [
      vehicleTypesList,
      steeringPositionsList,
      carBodyTypesList,
      fuelTypesList,
      transmissionTypesList,
      viscosityClassesList,
      liquidCategoriesList,
      aggregationTreesList,
    ] = await Promise.all([
      db.select().from(vehicleTypes).where(eq(vehicleTypes.isActive, "active")).orderBy(asc(vehicleTypes.sortOrder)),
      db.select().from(steeringPositions).where(eq(steeringPositions.isActive, "active")).orderBy(asc(steeringPositions.sortOrder)),
      db.select().from(carBodyTypes).where(eq(carBodyTypes.isActive, "active")).orderBy(asc(carBodyTypes.sortOrder)),
      db.select().from(fuelTypes).where(eq(fuelTypes.isActive, "active")).orderBy(asc(fuelTypes.sortOrder)),
      db.select().from(transmissionTypes).where(eq(transmissionTypes.isActive, "active")).orderBy(asc(transmissionTypes.sortOrder)),
      db.select().from(viscosityClasses).where(eq(viscosityClasses.isActive, "active")).orderBy(asc(viscosityClasses.sortOrder)),
      db.select().from(liquidCategories).where(eq(liquidCategories.isActive, "active")).orderBy(asc(liquidCategories.sortOrder)),
      db.select().from(aggregationTrees).where(eq(aggregationTrees.isActive, "active")).orderBy(asc(aggregationTrees.sortOrder)),
    ]);

    return {
      vehicleTypes: vehicleTypesList,
      steeringPositions: steeringPositionsList,
      carBodyTypes: carBodyTypesList,
      fuelTypes: fuelTypesList,
      transmissionTypes: transmissionTypesList,
      viscosityClasses: viscosityClassesList,
      liquidCategories: liquidCategoriesList,
      aggregationTrees: aggregationTreesList,
    };
  }),

  // ─── Seed all reference tables ───
  seedAll: adminQuery.mutation(async () => {
    const db = getDb();
    const counts: Record<string, number> = {};

    // Vehicle Types
    const vt = await db.select().from(vehicleTypes).limit(1);
    if (vt.length === 0) {
      const r = await db.insert(vehicleTypes).values([
        { name: "Легковой автомобиль", sortOrder: 1, isActive: "active" },
        { name: "Внедорожник / SUV", sortOrder: 2, isActive: "active" },
        { name: "Минивэн", sortOrder: 3, isActive: "active" },
        { name: "Пикап", sortOrder: 4, isActive: "active" },
        { name: "Легкий коммерческий", sortOrder: 5, isActive: "active" },
        { name: "Грузовой автомобиль", sortOrder: 6, isActive: "active" },
        { name: "Автобус", sortOrder: 7, isActive: "active" },
        { name: "Мотоцикл", sortOrder: 8, isActive: "active" },
      ]);
      counts.vehicleTypes = 8;
    }

    // Steering Positions
    const sp = await db.select().from(steeringPositions).limit(1);
    if (sp.length === 0) {
      await db.insert(steeringPositions).values([
        { name: "Левый руль (LHD)", sortOrder: 1, isActive: "active" },
        { name: "Правый руль (RHD)", sortOrder: 2, isActive: "active" },
      ]);
      counts.steeringPositions = 2;
    }

    // Car Body Types
    const bt = await db.select().from(carBodyTypes).limit(1);
    if (bt.length === 0) {
      await db.insert(carBodyTypes).values([
        { name: "Седан", sortOrder: 1, isActive: "active" },
        { name: "Хэтчбек", sortOrder: 2, isActive: "active" },
        { name: "Универсал", sortOrder: 3, isActive: "active" },
        { name: "Купе", sortOrder: 4, isActive: "active" },
        { name: "Кабриолет", sortOrder: 5, isActive: "active" },
        { name: "Внедорожник 3 дв.", sortOrder: 6, isActive: "active" },
        { name: "Внедорожник 5 дв.", sortOrder: 7, isActive: "active" },
        { name: "Минивэн", sortOrder: 8, isActive: "active" },
        { name: "Пикап", sortOrder: 9, isActive: "active" },
        { name: "Лифтбэк", sortOrder: 10, isActive: "active" },
        { name: "Кроссовер", sortOrder: 11, isActive: "active" },
        { name: "Фургон", sortOrder: 12, isActive: "active" },
      ]);
      counts.carBodyTypes = 12;
    }

    // Fuel Types
    const ft = await db.select().from(fuelTypes).limit(1);
    if (ft.length === 0) {
      await db.insert(fuelTypes).values([
        { name: "Бензин", sortOrder: 1, isActive: "active" },
        { name: "Дизель", sortOrder: 2, isActive: "active" },
        { name: "Гибрид", sortOrder: 3, isActive: "active" },
        { name: "Электро", sortOrder: 4, isActive: "active" },
        { name: "Газ (ГБО)", sortOrder: 5, isActive: "active" },
        { name: "Гибрид (Plugin)", sortOrder: 6, isActive: "active" },
      ]);
      counts.fuelTypes = 6;
    }

    // Transmission Types
    const tt = await db.select().from(transmissionTypes).limit(1);
    if (tt.length === 0) {
      await db.insert(transmissionTypes).values([
        { name: "Механическая (MT)", sortOrder: 1, isActive: "active" },
        { name: "Автоматическая (AT)", sortOrder: 2, isActive: "active" },
        { name: "Роботизированная (AMT)", sortOrder: 3, isActive: "active" },
        { name: "Вариатор (CVT)", sortOrder: 4, isActive: "active" },
        { name: "Двойное сцепление (DCT)", sortOrder: 5, isActive: "active" },
      ]);
      counts.transmissionTypes = 5;
    }

    // Viscosity Classes
    const vc = await db.select().from(viscosityClasses).limit(1);
    if (vc.length === 0) {
      await db.insert(viscosityClasses).values([
        { name: "0W-16", sortOrder: 1, isActive: "active" },
        { name: "0W-20", sortOrder: 2, isActive: "active" },
        { name: "0W-30", sortOrder: 3, isActive: "active" },
        { name: "0W-40", sortOrder: 4, isActive: "active" },
        { name: "5W-20", sortOrder: 5, isActive: "active" },
        { name: "5W-30", sortOrder: 6, isActive: "active" },
        { name: "5W-40", sortOrder: 7, isActive: "active" },
        { name: "5W-50", sortOrder: 8, isActive: "active" },
        { name: "10W-30", sortOrder: 9, isActive: "active" },
        { name: "10W-40", sortOrder: 10, isActive: "active" },
        { name: "10W-50", sortOrder: 11, isActive: "active" },
        { name: "10W-60", sortOrder: 12, isActive: "active" },
        { name: "15W-40", sortOrder: 13, isActive: "active" },
        { name: "15W-50", sortOrder: 14, isActive: "active" },
        { name: "20W-50", sortOrder: 15, isActive: "active" },
        { name: "75W-80", sortOrder: 16, isActive: "active" },
        { name: "75W-90", sortOrder: 17, isActive: "active" },
        { name: "80W-90", sortOrder: 18, isActive: "active" },
        { name: "85W-90", sortOrder: 19, isActive: "active" },
        { name: "ATF", sortOrder: 20, isActive: "active" },
        { name: "CVT Fluid", sortOrder: 21, isActive: "active" },
      ]);
      counts.viscosityClasses = 21;
    }

    // Liquid Categories
    const lc = await db.select().from(liquidCategories).limit(1);
    if (lc.length === 0) {
      await db.insert(liquidCategories).values([
        { name: "Моторное масло", parentId: null, sortOrder: 1, isActive: "active" },
        { name: "Трансмиссионное масло", parentId: null, sortOrder: 2, isActive: "active" },
        { name: "Тормозная жидкость", parentId: null, sortOrder: 3, isActive: "active" },
        { name: "Охлаждающая жидкость", parentId: null, sortOrder: 4, isActive: "active" },
        { name: "Жидкость ГУР", parentId: null, sortOrder: 5, isActive: "active" },
        { name: "Синтетическое", parentId: 1, sortOrder: 6, isActive: "active" },
        { name: "Полусинтетическое", parentId: 1, sortOrder: 7, isActive: "active" },
        { name: "Минеральное", parentId: 1, sortOrder: 8, isActive: "active" },
      ]);
      counts.liquidCategories = 8;
    }

    // Aggregation Trees
    const at = await db.select().from(aggregationTrees).limit(1);
    if (at.length === 0) {
      await db.insert(aggregationTrees).values([
        { name: "Двигатель", parentId: null, sortOrder: 1, isActive: "active" },
        { name: "Картер двигателя", parentId: 1, sortOrder: 2, isActive: "active" },
        { name: "Головка блока цилиндров", parentId: 1, sortOrder: 3, isActive: "active" },
        { name: "Турбокомпрессор", parentId: 1, sortOrder: 4, isActive: "active" },
        { name: "Трансмиссия", parentId: null, sortOrder: 5, isActive: "active" },
        { name: "Коробка передач", parentId: 5, sortOrder: 6, isActive: "active" },
        { name: "Раздаточная коробка", parentId: 5, sortOrder: 7, isActive: "active" },
        { name: "Дифференциал", parentId: 5, sortOrder: 8, isActive: "active" },
        { name: "Система охлаждения", parentId: null, sortOrder: 9, isActive: "active" },
        { name: "Радиатор", parentId: 9, sortOrder: 10, isActive: "active" },
        { name: "Помпа", parentId: 9, sortOrder: 11, isActive: "active" },
        { name: "Тормозная система", parentId: null, sortOrder: 12, isActive: "active" },
        { name: "Тормозные суппорта", parentId: 12, sortOrder: 13, isActive: "active" },
        { name: "Тормозные диски", parentId: 12, sortOrder: 14, isActive: "active" },
        { name: "ГУР / ЭГУ", parentId: null, sortOrder: 15, isActive: "active" },
      ]);
      counts.aggregationTrees = 15;
    }

    return { success: true, counts, message: `Заполнено таблиц: ${Object.keys(counts).length}` };
  }),

  vehicleType: vehicleTypeRouter,
  steeringPosition: steeringPositionRouter,
  carBodyType: carBodyTypeRouter,
  fuelType: fuelTypeRouter,
  transmissionType: transmissionTypeRouter,
  viscosityClass: viscosityClassRouter,
  liquidCategory: liquidCategoryRouter,
  aggregationTree: aggregationTreeRouter,
});
