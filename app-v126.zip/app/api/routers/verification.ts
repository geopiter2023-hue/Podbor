import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { aiVerifications, aiVerificationAgents, aiVerificationFields, carFluidSpecs } from "@db/schema";
import { eq, desc, and, sql } from "drizzle-orm";

// Parse JSON fields from MySQL (returns strings for JSON columns)
function parseJson(val: any): Record<string, string> {
  if (!val) return {};
  if (typeof val === "string") {
    try { return JSON.parse(val); } catch { return {}; }
  }
  if (typeof val === "object") return val as Record<string, string>;
  return {};
}

// Field keys that we verify across agents
const VERIFIABLE_FIELDS = [
  { key: "prefOilSae", label: "SAE", section: "Моторное масло" },
  { key: "prefOilApi", label: "API", section: "Моторное масло" },
  { key: "prefOilAcea", label: "ACEA", section: "Моторное масло" },
  { key: "prefOilOe", label: "OEM", section: "Моторное масло" },
  { key: "engineFillVolume", label: "Объём масла (л)", section: "Двигатель" },
  { key: "engineName", label: "Название двигателя", section: "Двигатель" },
  { key: "engineCode", label: "Код ДВС", section: "Двигатель" },
  { key: "horsePower", label: "Мощность (л.с.)", section: "Двигатель" },
  { key: "engineReplaceInterval", label: "Регламент замены", section: "Двигатель" },
  { key: "transmissionType", label: "Тип КПП", section: "КПП" },
  { key: "transmissionGears", label: "Кол-во передач", section: "КПП" },
  { key: "transmissionFillVolume", label: "Объём масла КПП (л)", section: "КПП" },
  { key: "transmissionPrefOil", label: "Масло КПП", section: "КПП" },
  { key: "transmissionCode", label: "Код КПП", section: "КПП" },
  { key: "transferCaseFillVolume", label: "Объём РКП (л)", section: "Раздатка" },
  { key: "transferCaseOil", label: "Масло РКП", section: "Раздатка" },
  { key: "frontDiffFillVolume", label: "Объём перед. дифф. (л)", section: "Дифференциалы" },
  { key: "frontDiffOil", label: "Масло перед. дифф.", section: "Дифференциалы" },
  { key: "rearDiffFillVolume", label: "Объём задн. дифф. (л)", section: "Дифференциалы" },
  { key: "rearDiffOil", label: "Масло задн. дифф.", section: "Дифференциалы" },
  { key: "coolantFillVolume", label: "Объём антифриза (л)", section: "Охлаждение" },
  { key: "coolantType", label: "Тип антифриза", section: "Охлаждение" },
  { key: "brakeFluidVolume", label: "Объём торм. жидкости (л)", section: "Тормоза" },
  { key: "brakeFluidType", label: "Тип торм. жидкости", section: "Тормоза" },
  { key: "oilFilter", label: "Масляный фильтр", section: "Фильтры" },
  { key: "airFilter", label: "Воздушный фильтр", section: "Фильтры" },
  { key: "cabinFilter", label: "Салонный фильтр", section: "Фильтры" },
  { key: "fuelFilter", label: "Топливный фильтр", section: "Фильтры" },
  { key: "psFluidType", label: "Тип ГУР", section: "ГУР" },
  { key: "suspFluidType", label: "Тип подвески", section: "Подвеска" },
  { key: "adblueVolume", label: "Объём AdBlue (л)", section: "AdBlue" },
];

// 8 agent providers for verification (5 international + 3 Russian)
const AGENT_CONFIGS = [
  // International
  { id: "perplexity", provider: "perplexity" as const, model: "sonar" },
  { id: "anthropic", provider: "anthropic" as const, model: "claude-3-haiku-20240307" },
  { id: "deepseek", provider: "deepseek" as const, model: "deepseek-chat" },
  // Russian (work from Russia without VPN)
  { id: "yandex", provider: "yandex" as const, model: "yandexgpt-lite" },
  { id: "gigachat", provider: "gigachat" as const, model: "GigaChat" },
  { id: "vsegpt", provider: "vsegpt" as const, model: "meta-llama/llama-3.1-70b-instruct" },
  // Fallback
  { id: "groq", provider: "groq" as const, model: "llama3-8b-8192" },
  { id: "gemini", provider: "gemini" as const, model: "gemini-1.5-flash" },
];

function normalizeValue(v: any): string {
  if (v === null || v === undefined) return "";
  return String(v).trim().toLowerCase().replace(/\s+/g, " ");
}

function computeConsensus(
  agentValues: Record<string, string>,
  totalAgents: number
): { consensusValue: string; confidence: number; agreeingAgents: number; status: string } {
  const nonEmpty: Record<string, string> = {};
  Object.entries(agentValues).forEach(([agent, val]) => {
    if (val && String(val).trim()) nonEmpty[agent] = String(val).trim();
  });

  const filledCount = Object.keys(nonEmpty).length;
  if (filledCount === 0) {
    return { consensusValue: "", confidence: 0, agreeingAgents: 0, status: "empty" };
  }

  const voteMap: Record<string, { count: number; agents: string[]; value: string }> = {};
  Object.entries(nonEmpty).forEach(([agent, val]) => {
    const norm = normalizeValue(val);
    if (!voteMap[norm]) voteMap[norm] = { count: 0, agents: [], value: val };
    voteMap[norm].count++;
    voteMap[norm].agents.push(agent);
  });

  let best = { count: 0, agents: [] as string[], value: "" };
  Object.values(voteMap).forEach((v) => {
    if (v.count > best.count) best = v;
  });

  const confidence = Math.round((best.count / totalAgents) * 100);
  let status: string;
  if (best.count === totalAgents) status = "consensus";
  else if (best.count >= Math.ceil(totalAgents / 2)) status = "partial";
  else status = "conflict";

  return { consensusValue: best.value, confidence, agreeingAgents: best.count, status };
}

// Extract all verifiable fields from a carFluidSpecs record
function extractFields(record: any): Record<string, string> {
  const result: Record<string, string> = {};
  for (const f of VERIFIABLE_FIELDS) {
    const val = record?.[f.key];
    if (val !== null && val !== undefined && String(val).trim()) {
      result[f.key] = String(val).trim();
    }
  }
  return result;
}

export const verificationRouter = createRouter({
  // ─── Run single agent (for live progress) ───
  runAgent: adminQuery
    .input(z.object({
      verificationId: z.number(),
      agentId: z.string(),
      make: z.string().min(1),
      model: z.string().min(1),
      engineCode: z.string().optional(),
      modification: z.string().optional(),
      year: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const agentStart = Date.now();

      // Save agent record as "running"
      const [agentRec] = await db.insert(aiVerificationAgents).values({
        verificationId: input.verificationId,
        agentId: input.agentId,
        provider: AGENT_CONFIGS.find((c) => c.id === input.agentId)?.provider || "unknown",
        model: AGENT_CONFIGS.find((c) => c.id === input.agentId)?.model || "",
        filledFields: {},
        sources: {},
        filledCount: 0,
        durationMs: 0,
        error: null,
      }).$returningId();

      try {
        const { runFlexibleResearch } = await import("../agents/flexibleResearcher");

        const result = await runFlexibleResearch({
          make: input.make,
          model: input.model,
          engineCode: input.engineCode,
          year: input.year,
          modification: input.modification,
          agentId: input.agentId,
        });

        // Read the actual data from carFluidSpecs
        let extractedFields: Record<string, string> = {};
        if (result.recordId) {
          const [record] = await db.select().from(carFluidSpecs).where(eq(carFluidSpecs.id, result.recordId)).limit(1);
          if (record) {
            extractedFields = extractFields(record);
          }
        }

        // Build sources from raw response
        const sources: Record<string, string> = {};
        if (result.rawResponse) {
          const urlMatches = String(result.rawResponse).match(/https?:\/\/[^\s"'<>{}|\^`[\]]+/g);
          const uniqueUrls = urlMatches ? [...new Set(urlMatches)].slice(0, 5) : [];
          Object.keys(extractedFields).forEach((key, idx) => {
            sources[key] = uniqueUrls[idx] || `${input.agentId} AI`;
          });
        }

        // Update agent record
        await db.update(aiVerificationAgents)
          .set({
            filledFields: extractedFields,
            sources,
            filledCount: Object.keys(extractedFields).length,
            durationMs: Date.now() - agentStart,
            tokensInput: result.tokensUsed?.input || 0,
            tokensOutput: result.tokensUsed?.output || 0,
            rawResponse: result.rawResponse?.substring?.(0, 3000) || null,
            error: result.error || null,
          })
          .where(eq(aiVerificationAgents.id, agentRec.id));

        return {
          success: true,
          agentId: input.agentId,
          filledCount: Object.keys(extractedFields).length,
          fields: extractedFields,
          error: result.error || null,
        };
      } catch (e: any) {
        await db.update(aiVerificationAgents)
          .set({
            durationMs: Date.now() - agentStart,
            error: e.message,
          })
          .where(eq(aiVerificationAgents.id, agentRec.id));

        return { success: false, agentId: input.agentId, error: e.message, filledCount: 0, fields: {} };
      }
    }),

  // ─── Run all 5 agents for a verification session ───
  run: adminQuery
    .input(z.object({
      make: z.string().min(1),
      model: z.string().min(1),
      modification: z.string().optional(),
      engineCode: z.string().optional(),
      year: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const startTime = Date.now();

      // 1. Create verification record
      const [verif] = await db.insert(aiVerifications).values({
        make: input.make,
        model: input.model,
        modification: input.modification,
        engineCode: input.engineCode,
        year: input.year,
        status: "running",
        agentCount: AGENT_CONFIGS.length, // 8 agents
        totalFields: VERIFIABLE_FIELDS.length,
      }).$returningId();
      const verificationId = verif.id;

      // 2. Run agents sequentially (better for API rate limits)
      for (const cfg of AGENT_CONFIGS) {
        try {
          // Call runAgent internally
          const { runAgent } = verificationRouter._def.procedures;
          // We can't call it directly, so inline the logic
          const agentStart = Date.now();

          // Save as running first
          const [agentRec] = await db.insert(aiVerificationAgents).values({
            verificationId,
            agentId: cfg.id,
            provider: cfg.provider,
            model: cfg.model,
            filledFields: {},
            sources: {},
            filledCount: 0,
            durationMs: 0,
            error: null,
          }).$returningId();

          try {
            const { runFlexibleResearch } = await import("../agents/flexibleResearcher");

            const result = await runFlexibleResearch({
              make: input.make,
              model: input.model,
              engineCode: input.engineCode,
              year: input.year,
              modification: input.modification,
              agentId: cfg.id,
            });

            // Read actual data from carFluidSpecs
            let extractedFields: Record<string, string> = {};
            if (result.recordId) {
              const [record] = await db.select().from(carFluidSpecs).where(eq(carFluidSpecs.id, result.recordId)).limit(1);
              if (record) {
                extractedFields = extractFields(record);
              }
            }

            // Build sources
            const sources: Record<string, string> = {};
            if (result.rawResponse) {
              const urlMatches = String(result.rawResponse).match(/https?:\/\/[^\s"'<>{}|\^`[\]]+/g);
              const uniqueUrls = urlMatches ? [...new Set(urlMatches)].slice(0, 5) : [];
              Object.keys(extractedFields).forEach((key, idx) => {
                sources[key] = uniqueUrls[idx] || `${cfg.id} AI`;
              });
            }

            await db.update(aiVerificationAgents)
              .set({
                filledFields: extractedFields,
                sources,
                filledCount: Object.keys(extractedFields).length,
                durationMs: Date.now() - agentStart,
                tokensInput: result.tokensUsed?.input || 0,
                tokensOutput: result.tokensUsed?.output || 0,
                rawResponse: result.rawResponse?.substring?.(0, 3000) || null,
                error: result.error || null,
              })
              .where(eq(aiVerificationAgents.id, agentRec.id));
          } catch (e: any) {
            await db.update(aiVerificationAgents)
              .set({
                durationMs: Date.now() - agentStart,
                error: e.message,
              })
              .where(eq(aiVerificationAgents.id, agentRec.id));
          }

          // Small delay between agents
          await new Promise((r) => setTimeout(r, 500));
        } catch (e: any) {
          console.error(`[Verification] Agent ${cfg.id} failed:`, e.message);
        }
      }

      // 3. Run majority voting
      const agentRecords = await db
        .select()
        .from(aiVerificationAgents)
        .where(eq(aiVerificationAgents.verificationId, verificationId));

      const fieldAgentValues: Record<string, Record<string, string>> = {};
      const fieldAgentSources: Record<string, Record<string, string>> = {};

      VERIFIABLE_FIELDS.forEach((f) => {
        fieldAgentValues[f.key] = {};
        fieldAgentSources[f.key] = {};
      });

      agentRecords.forEach((ar) => {
        const fields = (ar.filledFields || {}) as Record<string, string>;
        const sources = (ar.sources || {}) as Record<string, string>;
        Object.entries(fields).forEach(([fieldKey, value]) => {
          if (fieldAgentValues[fieldKey]) {
            fieldAgentValues[fieldKey][ar.agentId] = value;
          }
        });
        Object.entries(sources).forEach(([fieldKey, url]) => {
          if (fieldAgentSources[fieldKey]) {
            fieldAgentSources[fieldKey][ar.agentId] = url;
          }
        });
      });

      let consensusCount = 0;
      let totalConfidence = 0;

      for (const fieldDef of VERIFIABLE_FIELDS) {
        const values = fieldAgentValues[fieldDef.key] || {};
        const sources = fieldAgentSources[fieldDef.key] || {};
        const consensus = computeConsensus(values, AGENT_CONFIGS.length);

        if (consensus.status === "consensus") consensusCount++;
        totalConfidence += consensus.confidence;

        await db.insert(aiVerificationFields).values({
          verificationId,
          fieldKey: fieldDef.key,
          fieldLabel: fieldDef.label,
          section: fieldDef.section,
          agentValues: values,
          agentSources: sources,
          consensusValue: consensus.consensusValue,
          confidence: consensus.confidence,
          agreeingAgents: consensus.agreeingAgents,
          totalAgents: AGENT_CONFIGS.length,
          status: consensus.status as any,
        });
      }

      // 4. Update verification
      const overallConfidence = Math.round(totalConfidence / VERIFIABLE_FIELDS.length);
      const needsReview = consensusCount < VERIFIABLE_FIELDS.length ? "yes" : "no";

      await db.update(aiVerifications)
        .set({
          status: "completed",
          overallConfidence,
          consensusFields: consensusCount,
          needsHumanReview: needsReview as any,
          completedAt: new Date(),
        })
        .where(eq(aiVerifications.id, verificationId));

      return {
        verificationId,
        overallConfidence,
        consensusFields: consensusCount,
        totalFields: VERIFIABLE_FIELDS.length,
        needsHumanReview: needsReview === "yes",
        durationMs: Date.now() - startTime,
      };
    }),

  // ─── List verifications with agents ───
  list: adminQuery
    .input(z.object({
      make: z.string().optional(),
      model: z.string().optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input?.make) {
        conditions.push(sql`${aiVerifications.make} LIKE ${"%" + input.make + "%"}`);
      }
      if (input?.model) {
        conditions.push(sql`${aiVerifications.model} LIKE ${"%" + input.model + "%"}`);
      }

      const where = conditions.length > 0 ? and(...conditions) : undefined;

      const items = await db
        .select()
        .from(aiVerifications)
        .where(where)
        .orderBy(desc(aiVerifications.startedAt))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);

      // Get agents for each verification
      const allAgents = await db.select().from(aiVerificationAgents);
      const agentsByVerif: Record<number, any[]> = {};
      allAgents.forEach((a) => {
        if (!agentsByVerif[a.verificationId]) agentsByVerif[a.verificationId] = [];
        // Deduplicate by agentId
        if (!agentsByVerif[a.verificationId].find((x) => x.agentId === a.agentId)) {
          agentsByVerif[a.verificationId].push(a);
        }
      });

      const itemsWithAgents = items.map((v) => ({
        ...v,
        agents: agentsByVerif[v.id] || [],
      }));

      const countResult = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(aiVerifications)
        .where(where);

      return { items: itemsWithAgents, total: Number(countResult[0]?.count || 0) };
    }),

  // ─── Get verification with agents and fields ───
  getById: adminQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();

      const [verification] = await db
        .select()
        .from(aiVerifications)
        .where(eq(aiVerifications.id, input.id))
        .limit(1);

      if (!verification) return null;

      // Get agents — deduplicate by agentId (keep latest)
      const allAgents = await db
        .select()
        .from(aiVerificationAgents)
        .where(eq(aiVerificationAgents.verificationId, input.id))
        .orderBy(desc(aiVerificationAgents.id));

      // Deduplicate: keep only the latest entry per agentId
      const seenAgents = new Set<string>();
      const agents = allAgents.filter((a) => {
        if (seenAgents.has(a.agentId)) return false;
        seenAgents.add(a.agentId);
        return true;
      });

      // Get fields
      const rawFields = await db
        .select()
        .from(aiVerificationFields)
        .where(eq(aiVerificationFields.verificationId, input.id))
        .orderBy(aiVerificationFields.section, aiVerificationFields.fieldKey);

      // Parse JSON fields (MySQL returns JSON as strings)
      const fields = rawFields.map((f) => ({
        ...f,
        agentValues: parseJson(f.agentValues),
        agentSources: parseJson(f.agentSources),
      }));

      return { verification, agents, fields };
    }),

  // ─── Human review ───
  humanReview: adminQuery
    .input(z.object({
      fieldId: z.number(),
      value: z.string(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userId = ctx.user?.id || 0;

      await db.update(aiVerificationFields)
        .set({
          humanValue: input.value,
          humanReviewerId: userId,
          humanReviewNotes: input.notes,
          reviewedAt: new Date(),
          status: "consensus",
          consensusValue: input.value,
          confidence: 100,
        })
        .where(eq(aiVerificationFields.id, input.fieldId));

      const [field] = await db
        .select()
        .from(aiVerificationFields)
        .where(eq(aiVerificationFields.id, input.fieldId))
        .limit(1);

      if (field) {
        const allFields = await db
          .select()
          .from(aiVerificationFields)
          .where(eq(aiVerificationFields.verificationId, field.verificationId));

        const allConsensus = allFields.every((f) => f.status === "consensus");
        const avgConfidence = Math.round(
          allFields.reduce((s, f) => s + (f.confidence || 0), 0) / allFields.length
        );

        await db.update(aiVerifications)
          .set({
            needsHumanReview: allConsensus ? "no" : "yes",
            overallConfidence: avgConfidence,
            consensusFields: allFields.filter((f) => f.status === "consensus").length,
          })
          .where(eq(aiVerifications.id, field.verificationId));
      }

      return { ok: true };
    }),

  // ─── Apply consensus to carFluidSpecs ───
  applyConsensus: adminQuery
    .input(z.object({ verificationId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();

      const [verif] = await db
        .select()
        .from(aiVerifications)
        .where(eq(aiVerifications.id, input.verificationId))
        .limit(1);

      if (!verif) throw new Error("Verification not found");

      const fields = await db
        .select()
        .from(aiVerificationFields)
        .where(eq(aiVerificationFields.verificationId, input.verificationId));

      const updateData: Record<string, any> = {};
      fields.forEach((f) => {
        const val = f.humanValue || f.consensusValue;
        if (val) updateData[f.fieldKey] = val;
      });

      const existing = await db
        .select()
        .from(carFluidSpecs)
        .where(
          and(
            sql`${carFluidSpecs.make} LIKE ${"%" + verif.make + "%"}`,
            sql`${carFluidSpecs.model} LIKE ${"%" + verif.model + "%"}`,
          )
        )
        .limit(1);

      if (existing.length > 0) {
        await db.update(carFluidSpecs)
          .set({ ...updateData, updatedAt: new Date() })
          .where(eq(carFluidSpecs.id, existing[0].id));
      } else {
        await db.insert(carFluidSpecs).values({
          make: verif.make,
          model: verif.model,
          modification: verif.modification,
          engineCode: verif.engineCode,
          ...updateData,
        });
      }

      await db.update(aiVerifications)
        .set({ status: "completed" })
        .where(eq(aiVerifications.id, input.verificationId));

      return { ok: true, appliedFields: Object.keys(updateData).length };
    }),

  // ─── Stats ───
  stats: adminQuery.query(async () => {
    const db = getDb();

    const total = await db.select({ count: sql<number>`COUNT(*)` }).from(aiVerifications);
    const completed = await db.select({ count: sql<number>`COUNT(*)` }).from(aiVerifications).where(eq(aiVerifications.status, "completed"));
    const needsReview = await db.select({ count: sql<number>`COUNT(*)` }).from(aiVerifications).where(eq(aiVerifications.needsHumanReview, "yes"));
    const consensus100 = await db.select({ count: sql<number>`COUNT(*)` }).from(aiVerifications).where(eq(aiVerifications.overallConfidence, 100));

    return {
      total: Number(total[0]?.count || 0),
      completed: Number(completed[0]?.count || 0),
      needsReview: Number(needsReview[0]?.count || 0),
      consensus100: Number(consensus100[0]?.count || 0),
    };
  }),
});
