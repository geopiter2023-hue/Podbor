import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { sql, and, eq } from "drizzle-orm";

// pdfmake is a server-side library — initialized lazily
let printer: any = null;
function getPrinter() {
  if (!printer) {
    const PdfPrinter = require("pdfmake");
    const fonts = {
      Roboto: {
        normal: "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        bold: "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        italics: "/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf",
        bolditalics: "/usr/share/fonts/truetype/dejavu/DejaVuSans-BoldOblique.ttf",
      },
    };
    printer = new PdfPrinter(fonts);
  }
  return printer;
}

/**
 * Generate lubrication card PDF
 * Filename: {VIN}_{Make}_{Model}.pdf
 */
export const pdfRouter = createRouter({
  generateLubricationCard: publicQuery
    .input(z.object({
      make: z.string(),
      model: z.string(),
      vin: z.string().optional(),
      generation: z.string().optional(),
      modification: z.string().optional(),
      year: z.string().optional(),
      engineCapacity: z.string().optional(),
      power: z.string().optional(),
      fuel: z.string().optional(),
      transmission: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const now = new Date().toLocaleDateString("ru-RU");

      // Get car specs from DB — SAFE parameterized query
      const { carFluidSpecs, products: productsTable } = await import("@db/schema");
      const [carSpecs] = await db
        .select()
        .from(carFluidSpecs)
        .where(
          and(
            sql`${carFluidSpecs.make} LIKE ${"%" + input.make + "%"}`,
            sql`${carFluidSpecs.model} LIKE ${"%" + input.model + "%"}`,
          )
        )
        .limit(1);
      const specs = carSpecs || {};

      // Get matching products — SAFE parameterized query
      const products = await db
        .select()
        .from(productsTable)
        .where(eq(productsTable.brand, "ЛУКОЙЛ"))
        .limit(20);

      // Build filename
      const safeVin = input.vin ? input.vin.replace(/[^a-zA-Z0-9]/g, "_") : "NOVIN";
      const safeMake = input.make.replace(/[^a-zA-Z0-9а-яА-Я]/g, "_");
      const safeModel = input.model.replace(/[^a-zA-Z0-9а-яА-Я]/g, "_");
      const filename = `${safeVin}_${safeMake}_${safeModel}.pdf`;

      // Build PDF document
      const docDefinition: any = {
        pageSize: "A4",
        pageMargins: [40, 40, 40, 60],
        info: {
          title: `Карта смазок - ${input.make} ${input.model}`,
          author: "oilpodbor.ru",
          subject: "Результат подбора технических жидкостей",
        },
        defaultStyle: {
          font: "Roboto",
          fontSize: 10,
          color: "#333",
        },
        footer: (currentPage: number, pageCount: number) => ({
          columns: [
            { text: "oilpodbor.ru", alignment: "left", margin: [40, 0], fontSize: 8, color: "#999" },
            { text: `${currentPage} / ${pageCount}`, alignment: "right", margin: [0, 0, 40, 0], fontSize: 8, color: "#999" },
          ],
        }),
        content: [],
      };

      // ===== COVER PAGE =====
      docDefinition.content.push(
        {
          text: "РЕЗУЛЬТАТ ПОДБОРА",
          fontSize: 24,
          bold: true,
          alignment: "center",
          color: "#1a1a1a",
          margin: [0, 40, 0, 5],
        },
        {
          text: "ТЕХНИЧЕСКИХ ЖИДКОСТЕЙ",
          fontSize: 18,
          bold: true,
          alignment: "center",
          color: "#d32f2f",
          margin: [0, 0, 0, 20],
        },
        {
          text: now,
          fontSize: 12,
          alignment: "center",
          color: "#666",
          margin: [0, 0, 0, 30],
        },
        // Car info table
        {
          table: {
            widths: ["30%", "70%"],
            body: [
              [{ text: "АВТОМОБИЛЬ", bold: true, fontSize: 14, colSpan: 2, fillColor: "#f5f5f5" }, {}],
              [{ text: "Марка:", bold: true }, input.make],
              [{ text: "Модель:", bold: true }, input.model],
              [{ text: "Поколение:", bold: true }, input.generation || "—"],
              [{ text: "Модификация:", bold: true }, input.modification || "—"],
              [{ text: "Объём ДВС:", bold: true }, input.engineCapacity || specs.engineOilCapacity || "—"],
              [{ text: "Мощность:", bold: true }, input.power || "—"],
              [{ text: "Тип топлива:", bold: true }, input.fuel || "—"],
              [{ text: "VIN:", bold: true }, input.vin || "—"],
            ],
          },
          layout: {
            hLineWidth: () => 1,
            vLineWidth: () => 1,
            hLineColor: () => "#ddd",
            vLineColor: () => "#ddd",
            paddingLeft: () => 10,
            paddingRight: () => 10,
            paddingTop: () => 6,
            paddingBottom: () => 6,
          },
          margin: [0, 0, 0, 20],
        }
      );

      // ===== ENGINE SECTION =====
      docDefinition.content.push(
        { text: "", pageBreak: "before" },
        {
          text: "ДВИГАТЕЛЬ",
          fontSize: 16,
          bold: true,
          color: "#1a1a1a",
          margin: [0, 10, 0, 5],
        },
        {
          columns: [
            { text: `Заправочный объём: ${specs.engineOilVolume || specs.engineOilCapacity || "—"}`, bold: true, fontSize: 11 },
            { text: "Уровень сложности замены: ★★☆☆☆", alignment: "right", fontSize: 10, color: "#666" },
          ],
          margin: [0, 0, 0, 15],
        }
      );

      // Engine oil products
      const engineProducts = (products || []).filter((p: any) => p.category === "Моторные масла");
      if (engineProducts.length > 0) {
        engineProducts.forEach((p: any, idx: number) => {
          const specs_json = typeof p.specs === "string" ? JSON.parse(p.specs || "{}") : (p.specs || {});
          docDefinition.content.push(
            {
              table: {
                widths: ["100%"],
                body: [[{
                  stack: [
                    { text: `Наименование:`, fontSize: 9, color: "#666", margin: [0, 0, 0, 2] },
                    { text: p.name, fontSize: 12, bold: true, color: "#d32f2f", margin: [0, 0, 0, 8] },
                    { text: `Описание:`, fontSize: 9, color: "#666", margin: [0, 0, 0, 2] },
                    { text: p.description || `Моторное масло ${p.brand} ${p.subcategory || ""}`, fontSize: 10, margin: [0, 0, 0, 8] },
                    { text: `Спецификации:`, fontSize: 9, color: "#666", margin: [0, 0, 0, 2] },
                    { text: `SAE: ${specs_json.sae || "—"} | API: ${specs_json.api || "—"} | ACEA: ${specs_json.acea || "—"} | OEM: ${specs_json.oem || "—"}`, fontSize: 9, margin: [0, 0, 0, 8] },
                    { text: `Фасовка: ${p.volume || "—"} | Цена: ${p.price ? (p.price / 100).toLocaleString("ru-RU") + " ₽" : "—"}`, fontSize: 9, color: "#666" },
                  ],
                  margin: [10, 10, 10, 10],
                }]],
              },
              layout: {
                hLineWidth: () => 1,
                vLineWidth: () => 1,
                hLineColor: () => "#e0e0e0",
                vLineColor: () => "#e0e0e0",
                fillColor: () => idx % 2 === 0 ? "#fafafa" : "#fff",
              },
              margin: [0, 0, 0, 10],
            }
          );
        });
      } else {
        docDefinition.content.push({ text: "Рекомендуемые продукты не найдены в базе. Данные обновляются.", italics: true, color: "#999", margin: [0, 10, 0, 10] });
      }

      // ===== COOLING SYSTEM =====
      docDefinition.content.push(
        { text: "", pageBreak: "before" },
        {
          text: "СИСТЕМА ОХЛАЖДЕНИЯ",
          fontSize: 16,
          bold: true,
          color: "#1a1a1a",
          margin: [0, 10, 0, 5],
        },
        {
          columns: [
            { text: `Заправочный объём: ${specs.coolantVolume || "—"}`, bold: true, fontSize: 11 },
            { text: "Уровень сложности замены: ★★★☆☆", alignment: "right", fontSize: 10, color: "#666" },
          ],
          margin: [0, 0, 0, 15],
        },
        {
          text: `Рекомендуемый тип антифриза: ${specs.coolantType || "—"}`,
          fontSize: 11,
          margin: [0, 0, 0, 15],
        }
      );

      // Coolant products
      const coolantProducts = (products || []).filter((p: any) => p.category === "Охлаждающие жидкости");
      if (coolantProducts.length > 0) {
        coolantProducts.forEach((p: any, idx: number) => {
          const specs_json = typeof p.specs === "string" ? JSON.parse(p.specs || "{}") : (p.specs || {});
          docDefinition.content.push({
            table: {
              widths: ["100%"],
              body: [[{
                stack: [
                  { text: `Наименование:`, fontSize: 9, color: "#666" },
                  { text: p.name, fontSize: 12, bold: true, color: "#d32f2f", margin: [0, 0, 0, 8] },
                  { text: `Спецификации: ${specs_json.oem || p.description || "—"}`, fontSize: 9 },
                  { text: `Фасовка: ${p.volume || "—"}`, fontSize: 9, color: "#666" },
                ],
                margin: [10, 10, 10, 10],
              }]],
            },
            layout: { hLineWidth: () => 1, vLineWidth: () => 1, hLineColor: () => "#e0e0e0", vLineColor: () => "#e0e0e0", fillColor: () => idx % 2 === 0 ? "#fafafa" : "#fff" },
            margin: [0, 0, 0, 10],
          });
        });
      }

      // ===== TRANSMISSION =====
      docDefinition.content.push(
        { text: "", pageBreak: "before" },
        {
          text: input.transmission?.toUpperCase().includes("ВАРИАТ") ? "ВАРИАТОРНАЯ КОРОБКА ПЕРЕДАЧ" :
               input.transmission?.toUpperCase().includes("АВТОМАТ") ? "АВТОМАТИЧЕСКАЯ КОРОБКА ПЕРЕДАЧ" :
               "КОРОБКА ПЕРЕДАЧ",
          fontSize: 16,
          bold: true,
          color: "#1a1a1a",
          margin: [0, 10, 0, 5],
        },
        {
          columns: [
            { text: `Заправочный объём: ${specs.transmissionOilVolume || "—"}`, bold: true, fontSize: 11 },
            { text: "Уровень сложности замены: ★★★★☆", alignment: "right", fontSize: 10, color: "#666" },
          ],
          margin: [0, 0, 0, 15],
        }
      );

      const transProducts = (products || []).filter((p: any) => p.category === "Трансмиссионные масла");
      if (transProducts.length > 0) {
        transProducts.forEach((p: any, idx: number) => {
          const specs_json = typeof p.specs === "string" ? JSON.parse(p.specs || "{}") : (p.specs || {});
          docDefinition.content.push({
            table: {
              widths: ["100%"],
              body: [[{
                stack: [
                  { text: `Наименование:`, fontSize: 9, color: "#666" },
                  { text: p.name, fontSize: 12, bold: true, color: "#d32f2f", margin: [0, 0, 0, 8] },
                  { text: `Спецификации: SAE: ${specs_json.sae || "—"} | OEM: ${specs_json.oem || "—"}`, fontSize: 9 },
                  { text: `Фасовка: ${p.volume || "—"}`, fontSize: 9, color: "#666" },
                ],
                margin: [10, 10, 10, 10],
              }]],
            },
            layout: { hLineWidth: () => 1, vLineWidth: () => 1, hLineColor: () => "#e0e0e0", vLineColor: () => "#e0e0e0", fillColor: () => idx % 2 === 0 ? "#fafafa" : "#fff" },
            margin: [0, 0, 0, 10],
          });
        });
      }

      // ===== BRAKES =====
      docDefinition.content.push(
        { text: "", pageBreak: "before" },
        {
          text: "ТОРМОЗНАЯ СИСТЕМА",
          fontSize: 16,
          bold: true,
          color: "#1a1a1a",
          margin: [0, 10, 0, 5],
        },
        {
          columns: [
            { text: `Заправочный объём: ${specs.brakeFluidVolume || "—"}`, bold: true, fontSize: 11 },
            { text: "Уровень сложности замены: ★☆☆☆☆", alignment: "right", fontSize: 10, color: "#666" },
          ],
          margin: [0, 0, 0, 15],
        },
        {
          text: `Рекомендуемый тип жидкости: ${specs.brakeFluidType || "DOT 4"}`,
          fontSize: 11,
          margin: [0, 0, 0, 15],
        }
      );

      const brakeProducts = (products || []).filter((p: any) => p.category === "Тормозные жидкости");
      if (brakeProducts.length > 0) {
        brakeProducts.forEach((p: any, idx: number) => {
          docDefinition.content.push({
            table: {
              widths: ["100%"],
              body: [[{
                stack: [
                  { text: `Наименование:`, fontSize: 9, color: "#666" },
                  { text: p.name, fontSize: 12, bold: true, color: "#d32f2f", margin: [0, 0, 0, 8] },
                  { text: `Фасовка: ${p.volume || "—"}`, fontSize: 9, color: "#666" },
                ],
                margin: [10, 10, 10, 10],
              }]],
            },
            layout: { hLineWidth: () => 1, vLineWidth: () => 1, hLineColor: () => "#e0e0e0", vLineColor: () => "#e0e0e0", fillColor: () => idx % 2 === 0 ? "#fafafa" : "#fff" },
            margin: [0, 0, 0, 10],
          });
        });
      }

      // ===== FINAL PAGE =====
      docDefinition.content.push(
        { text: "", pageBreak: "before" },
        {
          text: "oilpodbor.ru",
          fontSize: 28,
          bold: true,
          color: "#d32f2f",
          alignment: "center",
          margin: [0, 100, 0, 20],
        },
        {
          text: "Подобрать технические жидкости онлайн",
          fontSize: 14,
          color: "#666",
          alignment: "center",
          margin: [0, 0, 0, 40],
        },
        {
          text: "Данная карта смазок сформирована автоматически на основе технических данных производителя автомобиля.",
          fontSize: 10,
          color: "#999",
          alignment: "center",
          margin: [0, 0, 0, 10],
        },
        {
          text: "Перед использованием рекомендуем проверить данные в сервисной книжке автомобиля.",
          fontSize: 10,
          color: "#999",
          alignment: "center",
        }
      );

      // Generate PDF buffer
      const pdfDoc = getPrinter().createPdfKitDocument(docDefinition);
      const chunks: Buffer[] = [];

      return new Promise<{ pdfBase64: string; filename: string }>((resolve, reject) => {
        pdfDoc.on("data", (chunk: Buffer) => chunks.push(chunk));
        pdfDoc.on("end", () => {
          const pdfBuffer = Buffer.concat(chunks);
          resolve({
            pdfBase64: pdfBuffer.toString("base64"),
            filename,
          });
        });
        pdfDoc.on("error", reject);
        pdfDoc.end();
      });
    }),
});
