import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { brands, models, modifications } from "@db/schema";
import { eq, asc } from "drizzle-orm";

export const carRouter = createRouter({
  // ─── Get all brands directly from TObrands ───
  brands: publicQuery.query(async () => {
    const db = getDb();
    const result = await db
      .select({
        id: brands.id,
        name: brands.name,
      })
      .from(brands)
      .orderBy(asc(brands.name));
    return result.map((r) => ({
      id: Number(r.id),
      name: r.name,
    }));
  }),

  // ─── Get models for a brand with imageUrl ───
  models: publicQuery
    .input(z.object({ makeId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select({
          modelId: models.modelId,
          makeId: models.makeId,
          modelName: models.modelName,
          yearFrom: models.yearFrom,
          yearTo: models.yearTo,
          imageUrl: models.imageUrl,
        })
        .from(models)
        .where(eq(models.makeId, input.makeId))
        .orderBy(asc(models.modelName));
      return result.map((r) => ({
        modelId: Number(r.modelId),
        makeId: Number(r.makeId),
        modelName: r.modelName,
        yearFrom: r.yearFrom,
        yearTo: r.yearTo,
        imageUrl: r.imageUrl,
      }));
    }),

  // ─── Get modifications directly from TOmodifications ───
  modifications: publicQuery
    .input(z.object({ makeId: z.number(), modelId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select({
          id: modifications.id,
          name: modifications.name,
          engineCode: modifications.engineCode,
          fuel: modifications.fuel,
          horsePower: modifications.horsePower,
          startDate: modifications.startDate,
          endDate: modifications.endDate,
          engineCapacity: modifications.engineCapacity,
          constructionType: modifications.constructionType,
          motorType: modifications.motorType,
        })
        .from(modifications)
        .where(eq(modifications.makeId, input.makeId))
        .orderBy(asc(modifications.modelId), asc(modifications.name));
      return result.map((r) => ({
        id: Number(r.id),
        name: r.name,
        engineCode: r.engineCode,
        fuel: r.fuel,
        horsePower: r.horsePower,
        startDate: r.startDate,
        endDate: r.endDate,
        engineCapacity: r.engineCapacity,
        constructionType: r.constructionType,
        motorType: r.motorType,
      }));
    }),
});
