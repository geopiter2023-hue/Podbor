import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { backgroundJobs, cars, carFluidSpecs } from "@db/schema";
import { eq, desc, sql, and } from "drizzle-orm";

/**
 * Background AI Fill Engine
 * Runs on server independently of client connection.
 */

export const backgroundJobsRouter = createRouter({
  // ─── Create and start a background job ───
  start: adminQuery
    .input(z.object({
      makes: z.array(z.string()).optional(),
      models: z.array(z.string()).optional(),
      yearFrom: z.number().optional(),
      yearTo: z.number().optional(),
      delaySeconds: z.number().default(2),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();

      const makeList = input.makes || [];
      const modelList = input.models || [];

      // Create job record
      const [job] = await db.insert(backgroundJobs).values({
        type: "ai-fill",
        status: "queued",
        makes: makeList.length > 0 ? JSON.stringify(makeList) : null,
        models: modelList.length > 0 ? JSON.stringify(modelList) : null,
        yearFrom: input.yearFrom || null,
        yearTo: input.yearTo || null,
        delaySeconds: input.delaySeconds,
        totalCars: 0,
        processedCars: 0,
        shouldStop: "no",
      }).$returningId();

      const jobId = job.id;

      // Start processing in background (fire-and-forget)
      runBackgroundFillSafe(jobId, makeList, modelList, input.yearFrom, input.yearTo, input.delaySeconds);

      return { jobId, status: "queued" };
    }),

  // ─── Get job status ───
  status: adminQuery
    .input(z.object({ id: z.number() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.id) {
        const [job] = await db.select().from(backgroundJobs).where(eq(backgroundJobs.id, input.id)).limit(1);
        return job || null;
      }
      return db.select().from(backgroundJobs).orderBy(desc(backgroundJobs.createdAt)).limit(10);
    }),

  // ─── Stop a running job ───
  stop: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(backgroundJobs)
        .set({ shouldStop: "yes", status: "stopped" })
        .where(eq(backgroundJobs.id, input.id));
      return { success: true };
    }),

  // ─── List all jobs ───
  list: adminQuery
    .input(z.object({ limit: z.number().default(20) }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(backgroundJobs).orderBy(desc(backgroundJobs.createdAt)).limit(input?.limit || 20);
    }),
});

/**
 * Safe wrapper - catches ALL errors
 */
function runBackgroundFillSafe(
  jobId: number,
  makes: string[],
  models: string[],
  yearFrom?: number,
  yearTo?: number,
  delaySeconds: number = 2,
) {
  try {
    // Use Promise to run async without awaiting
    Promise.resolve().then(async () => {
      try {
        await doBackgroundFill(jobId, makes, models, yearFrom, yearTo, delaySeconds);
      } catch (e: any) {
        await markFailed(jobId, e.message || "Background fill error");
      }
    }).catch(async (e: any) => {
      await markFailed(jobId, e.message || "Promise error");
    });
  } catch (e: any) {
    markFailed(jobId, e.message || "Setup error").catch(() => {});
  }
}

/**
 * Mark job as failed
 */
async function markFailed(jobId: number, errorMsg: string) {
  try {
    const db = getDb();
    await db.update(backgroundJobs)
      .set({ status: "failed", lastError: errorMsg, completedAt: new Date() })
      .where(eq(backgroundJobs.id, jobId));
  } catch {
    // Even marking failed failed - nothing we can do
  }
}

/**
 * The actual background worker
 */
async function doBackgroundFill(
  jobId: number,
  makes: string[],
  models: string[],
  yearFrom?: number,
  yearTo?: number,
  delaySeconds: number = 2,
) {
  const db = getDb();

  // Mark as running
  await db.update(backgroundJobs)
    .set({ status: "running", startedAt: new Date() })
    .where(eq(backgroundJobs.id, jobId));

  // Build conditions
  const conditions: any[] = [eq(cars.isActive, "active")];

  if (makes.length > 0) {
    // Use IN with lowercase comparison
    const makePlaceholders = makes.map(() => sql`LOWER(${cars.make})`).join(",");
    const makeValues = makes.map(m => m.toLowerCase());
    conditions.push(sql`LOWER(${cars.make}) IN (${sql.join(makeValues.map(v => sql.raw(`'${v.replace(/'/g, "''")}'`)), sql`, `)})`);
  }

  if (yearFrom !== undefined && yearTo !== undefined) {
    conditions.push(sql`${cars.yearTo} >= ${yearFrom}`);
    conditions.push(sql`${cars.yearFrom} <= ${yearTo}`);
  }

  // Get cars using Drizzle ORM (safe)
  const allCars = await db
    .selectDistinct({
      make: cars.make,
      model: cars.model,
    })
    .from(cars)
    .where(and(...conditions));

  // Filter by specific models if provided
  let carsToProcess = allCars;
  if (models.length > 0) {
    const modelSet = new Set(models.map(m => m.toUpperCase()));
    carsToProcess = allCars.filter((c: any) => {
      const key = `${c.make}|${c.model}`.toUpperCase();
      return modelSet.has(key);
    });
  }

  if (carsToProcess.length === 0) {
    await db.update(backgroundJobs)
      .set({ status: "completed", completedAt: new Date(), lastError: "Нет авто для обработки" })
      .where(eq(backgroundJobs.id, jobId));
    return;
  }

  // Update total
  await db.update(backgroundJobs)
    .set({ totalCars: carsToProcess.length })
    .where(eq(backgroundJobs.id, jobId));

  // Process each car
  let processed = 0;
  let successCount = 0;
  let errorCount = 0;

  for (let i = 0; i < carsToProcess.length; i++) {
    const car = carsToProcess[i];

    // Check stop flag
    const [jobCheck] = await db.select({ shouldStop: backgroundJobs.shouldStop })
      .from(backgroundJobs)
      .where(eq(backgroundJobs.id, jobId))
      .limit(1);
    if (jobCheck?.shouldStop === "yes") {
      await db.update(backgroundJobs)
        .set({ status: "stopped", completedAt: new Date() })
        .where(eq(backgroundJobs.id, jobId));
      return;
    }

    // Update current
    await db.update(backgroundJobs)
      .set({
        currentMake: car.make,
        currentModel: car.model,
        processedCars: processed,
      })
      .where(eq(backgroundJobs.id, jobId));

    try {
      // Use inline research instead of importing runResearcher
      const result = await runInlineResearch({
        make: car.make || "",
        model: car.model || "",
      });

      if (result.success) {
        successCount++;
      } else {
        errorCount++;
      }
    } catch {
      errorCount++;
    }

    processed++;

    // Update progress
    await db.update(backgroundJobs)
      .set({ processedCars: processed, successCars: successCount, errorCars: errorCount })
      .where(eq(backgroundJobs.id, jobId));

    // Delay
    if (i < carsToProcess.length - 1) {
      await new Promise(r => setTimeout(r, delaySeconds * 1000));
    }
  }

  // Completed
  await db.update(backgroundJobs)
    .set({
      status: "completed",
      completedAt: new Date(),
      processedCars: processed,
      successCars: successCount,
      errorCars: errorCount,
      currentMake: null,
      currentModel: null,
    })
    .where(eq(backgroundJobs.id, jobId));
}

/**
 * Inline research to avoid import issues
 */
async function runInlineResearch(payload: { make: string; model: string }): Promise<{ success: boolean }> {
  try {
    // Dynamic import to avoid circular dependencies
    const { runResearcher } = await import("../agents/researcher");
    const result = await runResearcher(payload);
    return { success: result.success || false };
  } catch {
    return { success: false };
  }
}
