import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { products } from "@db/schema";
import { eq, desc, sql, like, and } from "drizzle-orm";

export const productsRouter = createRouter({
  // ─── List products (public) ───
  list: publicQuery
    .input(z.object({
      category: z.string().optional(),
      brand: z.string().optional(),
      search: z.string().optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const limit = input?.limit || 50;
      const offset = input?.offset || 0;

      let conditions = [];
      if (input?.category) conditions.push(eq(products.category, input.category));
      if (input?.brand) conditions.push(eq(products.brand, input.brand));
      if (input?.search) {
        conditions.push(sql`(${products.name} LIKE ${"%" + input.search + "%"} OR ${products.brand} LIKE ${"%" + input.search + "%"})`);
      }

      const where = conditions.length > 0 ? and(...conditions) : undefined;

      const items = where
        ? await db.select().from(products).where(where).limit(limit).offset(offset)
        : await db.select().from(products).limit(limit).offset(offset);

      const countResult = where
        ? await db.select({ count: sql<number>`COUNT(*)` }).from(products).where(where)
        : await db.select({ count: sql<number>`COUNT(*)` }).from(products);

      return { items, total: countResult[0]?.count || 0 };
    }),

  // ─── Get single product ───
  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [product] = await db.select().from(products).where(eq(products.slug, input.slug)).limit(1);
      return product || null;
    }),

  // ─── Get categories ───
  categories: publicQuery.query(async () => {
    const db = getDb();
    const result = await db.selectDistinct({ category: products.category }).from(products);
    return result.map((r) => r.category).filter(Boolean);
  }),

  // ─── Get brands ───
  brands: publicQuery.query(async () => {
    const db = getDb();
    const result = await db.selectDistinct({ brand: products.brand }).from(products);
    return result.map((r) => r.brand).filter(Boolean);
  }),

  // ─── Import many products (admin) ───
  importMany: adminQuery
    .input(z.object({
      items: z.array(z.object({
        name: z.string(),
        sku: z.string().optional(),
        brand: z.string().optional(),
        category: z.string().optional(),
        subcategory: z.string().optional(),
        description: z.string().optional(),
        price: z.number().optional(),
        oldPrice: z.number().optional(),
        volume: z.string().optional(),
        specs: z.any().optional(),
        imageUrl: z.string().optional(),
        inStock: z.string().optional(),
        badges: z.any().optional(),
        externalUrl: z.string().optional(),
      })),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      let inserted = 0;
      let errors = 0;

      for (const item of input.items) {
        try {
          const slug = item.name
            ?.toLowerCase()
            .replace(/[^a-z0-9\-]+/g, "-")
            .replace(/-+/g, "-")
            .substring(0, 255) || `product-${Date.now()}`;

          await db.insert(products).values({
            name: item.name,
            slug: slug + "-" + Math.random().toString(36).substring(2, 8),
            sku: item.sku || null,
            brand: item.brand || null,
            category: item.category || null,
            subcategory: item.subcategory || null,
            description: item.description || null,
            price: item.price || null,
            oldPrice: item.oldPrice || null,
            volume: item.volume || null,
            specs: item.specs || null,
            imageUrl: item.imageUrl || null,
            inStock: item.inStock || "yes",
            badges: item.badges || null,
            externalUrl: item.externalUrl || null,
            currency: "RUB",
            discountPercent: item.oldPrice && item.price
              ? Math.round(((item.oldPrice - item.price) / item.oldPrice) * 100)
              : null,
          });
          inserted++;
        } catch {
          errors++;
        }
      }

      return { inserted, errors };
    }),

  // ─── Delete all products (admin) ───
  clearAll: adminQuery.mutation(async () => {
    const db = getDb();
    await db.delete(products);
    return { success: true };
  }),
});
