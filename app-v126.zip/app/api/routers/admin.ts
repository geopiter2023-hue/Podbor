import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { companies, companyUsers, products, productAssignments, users } from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { generateApiKey } from "./widget";

export const adminRouter = createRouter({
  // ─── Companies ───
  listCompanies: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(companies).orderBy(desc(companies.createdAt));
  }),

  createCompany: adminQuery
    .input(z.object({
      name: z.string().min(1),
      slug: z.string().min(1),
      inn: z.string().optional(),
      ogrn: z.string().optional(),
      kpp: z.string().optional(),
      legalAddress: z.string().optional(),
      actualAddress: z.string().optional(),
      director: z.string().optional(),
      website: z.string().optional(),
      contactEmail: z.string().optional(),
      contactPhone: z.string().optional(),
      reportEmail: z.string().optional(),
      reportPeriod: z.enum(["daily", "weekly", "monthly"]).optional(),
      reportDay: z.number().optional(),
      reportTime: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const apiKey = generateApiKey();
      await db.insert(companies).values({
        name: input.name,
        slug: input.slug,
        apiKey,
        inn: input.inn || null,
        ogrn: input.ogrn || null,
        kpp: input.kpp || null,
        legalAddress: input.legalAddress || null,
        actualAddress: input.actualAddress || null,
        director: input.director || null,
        website: input.website || null,
        contactEmail: input.contactEmail || null,
        contactPhone: input.contactPhone || null,
        reportEmail: input.reportEmail || null,
        reportPeriod: input.reportPeriod || "weekly",
        reportDay: input.reportDay || 1,
        reportTime: input.reportTime || "09:00",
      });
      return { success: true, apiKey };
    }),

  updateCompany: adminQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      slug: z.string().optional(),
      inn: z.string().optional(),
      ogrn: z.string().optional(),
      kpp: z.string().optional(),
      legalAddress: z.string().optional(),
      actualAddress: z.string().optional(),
      director: z.string().optional(),
      website: z.string().optional(),
      contactEmail: z.string().optional(),
      contactPhone: z.string().optional(),
      reportEmail: z.string().optional(),
      reportPeriod: z.enum(["daily", "weekly", "monthly"]).optional(),
      reportDay: z.number().optional(),
      reportTime: z.string().optional(),
      isActive: z.enum(["active", "suspended", "archived"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(companies).set(data).where(eq(companies.id, id));
      return { success: true };
    }),

  // ─── Company Statistics ───
  getCompanyStats: adminQuery
    .input(z.object({ companyId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      // Search requests by make
      const makeRequests = await db
        .select({ makeName: sql<string>`COALESCE(${sql.raw('makeName')}, 'Неизвестно')`, count: sql<number>`COUNT(*)` })
        .from(sql.raw('searchLogs'))
        .where(eq(sql.raw('companyId'), input.companyId))
        .groupBy(sql.raw('makeName'))
        .orderBy(desc(sql<number>`COUNT(*)`))
        .limit(20);

      // Total requests
      const totalReq = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(sql.raw('searchLogs'))
        .where(eq(sql.raw('companyId'), input.companyId));

      // Requests today
      const todayReq = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(sql.raw('searchLogs'))
        .where(sql`${sql.raw('companyId')} = ${input.companyId} AND DATE(${sql.raw('createdAt')}) = CURDATE()`);

      // Requests this week
      const weekReq = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(sql.raw('searchLogs'))
        .where(sql`${sql.raw('companyId')} = ${input.companyId} AND ${sql.raw('createdAt')} >= DATE_SUB(NOW(), INTERVAL 7 DAY)`);

      return {
        totalRequests: Number(totalReq[0]?.count || 0),
        todayRequests: Number(todayReq[0]?.count || 0),
        weekRequests: Number(weekReq[0]?.count || 0),
        makeRequests: makeRequests.map((r: any) => ({ make: r.makeName || "—", count: Number(r.count) })),
      };
    }),

  // ─── Generate report ───
  generateReport: adminQuery
    .input(z.object({ companyId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [company] = await db.select().from(companies).where(eq(companies.id, input.companyId)).limit(1);
      if (!company) throw new Error("Company not found");

      // Get stats
      const stats = await db
        .select({
          totalRequests: sql<number>`COUNT(*)`,
          uniqueMakes: sql<number>`COUNT(DISTINCT makeName)`,
          uniqueModels: sql<number>`COUNT(DISTINCT modelName)`,
        })
        .from(sql.raw('searchLogs'))
        .where(eq(sql.raw('companyId'), input.companyId));

      // Top makes
      const topMakes = await db
        .select({ makeName: sql<string>`makeName`, count: sql<number>`COUNT(*)` })
        .from(sql.raw('searchLogs'))
        .where(eq(sql.raw('companyId'), input.companyId))
        .groupBy(sql.raw('makeName'))
        .orderBy(desc(sql<number>`COUNT(*)`))
        .limit(10);

      // Daily breakdown (last 30 days)
      const dailyStats = await db
        .select({
          date: sql<string>`DATE(createdAt)`,
          count: sql<number>`COUNT(*)`,
        })
        .from(sql.raw('searchLogs'))
        .where(sql`${sql.raw('companyId')} = ${input.companyId} AND createdAt >= DATE_SUB(NOW(), INTERVAL 30 DAY)`)
        .groupBy(sql.raw('DATE(createdAt)'))
        .orderBy(sql.raw('DATE(createdAt)'));

      const report = {
        companyName: company.name,
        generatedAt: new Date().toISOString(),
        period: "Последние 30 дней",
        summary: {
          totalRequests: Number(stats[0]?.totalRequests || 0),
          uniqueMakes: Number(stats[0]?.uniqueMakes || 0),
          uniqueModels: Number(stats[0]?.uniqueModels || 0),
        },
        topMakes: topMakes.map((m: any) => ({ make: m.makeName, requests: Number(m.count) })),
        dailyStats: dailyStats.map((d: any) => ({ date: d.date, requests: Number(d.count) })),
      };

      // Update lastReportSent
      await db.update(companies).set({ lastReportSent: new Date() }).where(eq(companies.id, input.companyId));

      return report;
    }),

  deleteCompany: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(companies).where(eq(companies.id, input.id));
      return { success: true };
    }),

  // ─── Users ───
  listUsers: adminQuery.query(async () => {
    const db = getDb();
    return db.select({
      id: users.id,
      name: users.name,
      email: users.email,
      role: users.role,
      createdAt: users.createdAt,
    }).from(users).orderBy(desc(users.createdAt));
  }),

  // ─── Company Users ───
  listCompanyMembers: adminQuery
    .input(z.object({ companyId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const members = await db
        .select({
          id: companyUsers.id,
          role: companyUsers.role,
          userId: companyUsers.userId,
          name: users.name,
          email: users.email,
        })
        .from(companyUsers)
        .innerJoin(users, eq(companyUsers.userId, users.id))
        .where(eq(companyUsers.companyId, input.companyId));
      return members;
    }),

  addCompanyMember: adminQuery
    .input(z.object({
      companyId: z.number(),
      userId: z.number(),
      role: z.enum(["owner", "manager", "viewer"]).default("viewer"),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(companyUsers).values(input).onDuplicateKeyUpdate({
        set: { role: input.role },
      });
      return { success: true };
    }),

  // ─── Products ───
  listProducts: adminQuery
    .input(z.object({ companyId: z.number() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.companyId) {
        return db.select().from(products)
          .where(eq(products.companyId, input.companyId))
          .orderBy(desc(products.createdAt));
      }
      return db.select().from(products).orderBy(desc(products.createdAt));
    }),

  createProduct: adminQuery
    .input(z.object({
      companyId: z.number(),
      name: z.string().min(1),
      sku: z.string().min(1),
      brand: z.string().optional(),
      category: z.string().optional(),
      description: z.string().optional(),
      price: z.number().optional(),
      currency: z.string().optional(),
      volume: z.string().optional(),
      specs: z.record(z.string(), z.any()).optional(),
      imageUrl: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(products).values({
        ...input,
        brand: input.brand || null,
        category: input.category || null,
        description: input.description || null,
        price: input.price || null,
        volume: input.volume || null,
        specs: input.specs || null,
        imageUrl: input.imageUrl || null,
      });
      return { success: true };
    }),

  updateProduct: adminQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      sku: z.string().optional(),
      brand: z.string().optional(),
      category: z.string().optional(),
      description: z.string().optional(),
      price: z.number().optional(),
      volume: z.string().optional(),
      specs: z.record(z.string(), z.any()).optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(products).set(data).where(eq(products.id, id));
      return { success: true };
    }),

  deleteProduct: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(products).where(eq(products.id, input.id));
      return { success: true };
    }),

  // ─── Product Assignments ───
  listAssignments: adminQuery
    .input(z.object({ companyId: z.number() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.companyId) {
        return db.select().from(productAssignments)
          .where(eq(productAssignments.companyId, input.companyId))
          .orderBy(desc(productAssignments.createdAt));
      }
      return db.select().from(productAssignments).orderBy(desc(productAssignments.createdAt));
    }),

  createAssignment: adminQuery
    .input(z.object({
      companyId: z.number(),
      productId: z.number(),
      makeId: z.number(),
      modelId: z.number(),
      modificationId: z.string(),
      notes: z.string().optional(),
      isRecommended: z.enum(["yes", "no"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(productAssignments).values({
        ...input,
        notes: input.notes || null,
        isRecommended: input.isRecommended || "no",
      }).onDuplicateKeyUpdate({
        set: { notes: input.notes || null, isRecommended: input.isRecommended || "no" },
      });
      return { success: true };
    }),

  deleteAssignment: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(productAssignments).where(eq(productAssignments.id, input.id));
      return { success: true };
    }),

  // ─── Assign Admin Role ───
  assignAdmin: adminQuery
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(users).set({ role: "admin" }).where(eq(users.id, input.userId));
      return { success: true };
    }),

  // ─── Stats ───
  stats: adminQuery.query(async () => {
    const db = getDb();
    const [companyCount] = await db.select({ count: sql<number>`COUNT(*)` }).from(companies);
    const [productCount] = await db.select({ count: sql<number>`COUNT(*)` }).from(products);
    const [assignmentCount] = await db.select({ count: sql<number>`COUNT(*)` }).from(productAssignments);
    const [userCount] = await db.select({ count: sql<number>`COUNT(*)` }).from(users);
    return {
      companies: companyCount.count,
      products: productCount.count,
      assignments: assignmentCount.count,
      users: userCount.count,
    };
  }),

  // ─── API Key Management ───
  generateApiKey: adminQuery
    .input(z.object({ companyId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const newKey = generateApiKey();
      await db
        .update(companies)
        .set({ apiKey: newKey })
        .where(eq(companies.id, input.companyId));
      return { apiKey: newKey };
    }),

  updateDomains: adminQuery
    .input(z.object({
      companyId: z.number(),
      domains: z.array(z.string()),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(companies)
        .set({ allowedDomains: JSON.stringify(input.domains) })
        .where(eq(companies.id, input.companyId));
      return { success: true };
    }),

  getEmbedCode: adminQuery
    .input(z.object({ companyId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [company] = await db
        .select()
        .from(companies)
        .where(eq(companies.id, input.companyId))
        .limit(1);

      if (!company || !company.apiKey) {
        return { error: "API key not generated yet. Generate it first." };
      }

      const widgetUrl = `${process.env.VITE_APP_URL || "https://your-domain.com"}/widget.js`;
      const embedCode = `<!-- Motornaya Oil Selector Widget -->
<script>
(function() {
  var script = document.createElement('script');
  script.src = "${widgetUrl}";
  script.setAttribute('data-api-key', '${company.apiKey}');
  script.async = true;
  document.head.appendChild(script);
})();
</script>
<div id="motornaya-widget"></div>`;

      return {
        apiKey: company.apiKey,
        allowedDomains: company.allowedDomains,
        embedCode,
        widgetUrl,
      };
    }),

  // ─── Plate Search API Settings ───
  updatePlateApiSettings: adminQuery
    .input(z.object({
      companyId: z.number(),
      plateApiUrl: z.string().optional(),
      plateApiKey: z.string().optional(),
      plateApiEnabled: z.enum(["yes", "no"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { companyId, ...settings } = input;
      await db.update(companies).set(settings).where(eq(companies.id, companyId));
      return { success: true };
    }),
});
