import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { products } from "@db/schema";
import { sql } from "drizzle-orm";

/**
 * Product Matching Engine
 * Matches car oil recommendations (SAE/API/ACEA/OEM) to actual products
 */

export const matchingRouter = createRouter({
  // ─── Find matching products for car recommendations ───
  findProducts: publicQuery
    .input(z.object({
      sae: z.string().optional(),
      api: z.string().optional(),
      acea: z.string().optional(),
      oem: z.string().optional(),
      category: z.string().optional(),
      brand: z.string().optional(),
      limit: z.number().default(10),
    }))
    .query(async ({ input }) => {
      const db = getDb();
      const conditions: string[] = [];

      // Build WHERE clause based on provided specs
      if (input.sae) {
        conditions.push(`JSON_EXTRACT(specs, '$.sae') LIKE '%${input.sae}%'`);
      }
      if (input.api) {
        // Match API class (e.g., "SN" matches "SN Plus", "SN/CF")
        conditions.push(`(JSON_EXTRACT(specs, '$.api') LIKE '%${input.api}%' OR JSON_EXTRACT(specs, '$.api') LIKE '%${input.api.split('/')[0]}%')`);
      }
      if (input.acea) {
        conditions.push(`JSON_EXTRACT(specs, '$.acea') LIKE '%${input.acea}%'`);
      }
      if (input.oem) {
        // Try to match OEM approval
        const oemParts = input.oem.split(/[,\/]/).map((s) => s.trim()).filter(Boolean);
        for (const part of oemParts) {
          if (part.length > 2) {
            conditions.push(`JSON_EXTRACT(specs, '$.oem') LIKE '%${part}%'`);
          }
        }
      }
      if (input.category) {
        conditions.push(`category = '${input.category}'`);
      }
      if (input.brand) {
        conditions.push(`brand = '${input.brand}'`);
      }

      if (conditions.length === 0) {
        return { items: [], total: 0, confidence: 0 };
      }

      const whereClause = conditions.join(" OR ");

      // Get matching products — order by relevance (more matched fields = higher rank)
      const results = await db.execute(
        sql.raw(`
          SELECT *,
            (
              ${input.sae ? `(CASE WHEN JSON_EXTRACT(specs, '$.sae') LIKE '%${input.sae}%' THEN 25 ELSE 0 END)` : "0"} +
              ${input.api ? `(CASE WHEN JSON_EXTRACT(specs, '$.api') LIKE '%${input.api}%' THEN 25 ELSE 0 END)` : "0"} +
              ${input.acea ? `(CASE WHEN JSON_EXTRACT(specs, '$.acea') LIKE '%${input.acea}%' THEN 25 ELSE 0 END)` : "0"} +
              ${input.oem ? `(CASE WHEN JSON_EXTRACT(specs, '$.oem') LIKE '%${input.oem}%' THEN 25 ELSE 0 END)` : "0"}
            ) as matchScore
          FROM products
          WHERE ${whereClause}
          ORDER BY matchScore DESC, price ASC
          LIMIT ${input.limit}
        `)
      );

      const items = results[0] as any[] || [];

      // Calculate overall confidence
      const maxScore = (input.sae ? 25 : 0) + (input.api ? 25 : 0) + (input.acea ? 25 : 0) + (input.oem ? 25 : 0);
      const bestScore = items.length > 0 ? (items[0].matchScore || 0) : 0;
      const confidence = maxScore > 0 ? Math.round((bestScore / maxScore) * 100) : 0;

      return { items, total: items.length, confidence };
    }),

  // ─── Get recommended products for a car (by carFluidSpecs) ───
  forCar: publicQuery
    .input(z.object({
      make: z.string(),
      model: z.string(),
      limit: z.number().default(5),
    }))
    .query(async ({ input }) => {
      const db = getDb();

      // Get car fluid specs
      const [specs] = await db.execute(
        sql.raw(`
          SELECT * FROM carFluidSpecs
          WHERE make = '${input.make.replace(/'/g, "''")}'
            AND model = '${input.model.replace(/'/g, "''")}'
          LIMIT 1
        `)
      ) as any[];

      if (!specs || specs.length === 0) {
        return { engineOil: [], transmissionOil: [], coolant: [], brakeFluid: [], confidence: 0, specs: null };
      }

      const s = specs[0];

      // Find matching products for each fluid type
      const findProducts = async (category: string, sae?: string, api?: string, acea?: string, oem?: string) => {
        const conditions: string[] = [`category = '${category}'`];
        if (sae) conditions.push(`JSON_EXTRACT(specs, '$.sae') LIKE '%${sae}%'`);
        if (api) conditions.push(`JSON_EXTRACT(specs, '$.api') LIKE '%${api}%'`);
        if (acea) conditions.push(`JSON_EXTRACT(specs, '$.acea') LIKE '%${acea}%'`);
        if (oem) {
          const oemParts = oem.split(/[,\/]/).map((p) => p.trim()).filter(Boolean);
          for (const part of oemParts) {
            if (part.length > 2) {
              conditions.push(`JSON_EXTRACT(specs, '$.oem') LIKE '%${part}%'`);
            }
          }
        }

        const results = await db.execute(
          sql.raw(`
            SELECT *,
              (
                ${sae ? `(CASE WHEN JSON_EXTRACT(specs, '$.sae') LIKE '%${sae}%' THEN 25 ELSE 0 END)` : "0"} +
                ${api ? `(CASE WHEN JSON_EXTRACT(specs, '$.api') LIKE '%${api}%' THEN 25 ELSE 0 END)` : "0"} +
                ${acea ? `(CASE WHEN JSON_EXTRACT(specs, '$.acea') LIKE '%${acea}%' THEN 25 ELSE 0 END)` : "0"} +
                ${oem ? `(CASE WHEN JSON_EXTRACT(specs, '$.oem') LIKE '%${oem}%' THEN 25 ELSE 0 END)` : "0"}
              ) as matchScore
            FROM products
            WHERE ${conditions.join(" OR ")}
            ORDER BY matchScore DESC, price ASC
            LIMIT ${input.limit}
          `)
        );
        return results[0] as any[] || [];
      };

      const [engineOil, transmissionOil, coolant, brakeFluid] = await Promise.all([
        findProducts("Моторные масла", s.prefOilSae, s.prefOilApi, s.prefOilAcea, s.prefOilOe),
        findProducts("Трансмиссионные масла", s.transmissionPrefOil, undefined, undefined, undefined),
        findProducts("Охлаждающие жидкости", undefined, undefined, undefined, s.coolantType),
        findProducts("Тормозные жидкости", undefined, undefined, undefined, s.brakeFluidType),
      ]);

      const totalMatches = engineOil.length + transmissionOil.length + coolant.length + brakeFluid.length;

      return {
        engineOil,
        transmissionOil,
        coolant,
        brakeFluid,
        confidence: totalMatches > 0 ? Math.min(100, totalMatches * 20) : 0,
        specs: {
          sae: s.prefOilSae,
          api: s.prefOilApi,
          acea: s.prefOilAcea,
          oem: s.prefOilOe,
          oilVolume: s.engineOilVolume,
          transmissionType: s.transmissionType,
          coolantType: s.coolantType,
          brakeFluidType: s.brakeFluidType,
        },
      };
    }),

  // ─── Quick search by SAE viscosity ───
  byViscosity: publicQuery
    .input(z.object({
      sae: z.string(),
      limit: z.number().default(10),
    }))
    .query(async ({ input }) => {
      const db = getDb();
      const results = await db.execute(
        sql.raw(`
          SELECT * FROM products
          WHERE JSON_EXTRACT(specs, '$.sae') LIKE '%${input.sae}%'
          ORDER BY price ASC
          LIMIT ${input.limit}
        `)
      );
      return results[0] as any[] || [];
    }),
});
