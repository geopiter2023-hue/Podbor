import { mysqlTable, mysqlSchema, AnyMySqlColumn, int, varchar, json, index, mysqlEnum, timestamp, bigint, text } from "drizzle-orm/mysql-core"
import { sql } from "drizzle-orm"

export const tobrands = mysqlTable("TObrands", {
	id: int(),
	name: varchar({ length: 255 }),
});

export const tomodels = mysqlTable("TOmodels", {
	makeId: int(),
	modelId: int(),
	modelName: varchar({ length: 255 }),
	yearFrom: varchar({ length: 255 }),
	yearTo: varchar({ length: 255 }),
});

export const tomodifications = mysqlTable("TOmodifications", {
	id: varchar({ length: 53 }),
	name: varchar({ length: 100 }),
	engineCode: varchar({ length: 100 }),
	constructionType: varchar({ length: 255 }),
	fuel: varchar({ length: 255 }),
	horsePower: varchar({ length: 255 }),
	startDate: varchar({ length: 25 }),
	endDate: varchar({ length: 25 }),
	engineCapacity: varchar({ length: 255 }),
	numberOfCylinders: varchar({ length: 255 }),
	valves: varchar({ length: 255 }),
	valvesTotal: varchar({ length: 255 }),
	motorType: varchar({ length: 255 }),
	fullName: varchar({ length: 255 }),
	brand: json(),
	model: json(),
	makeId: int(),
	modelId: int(),
});

export const tooils = mysqlTable("TOoils", {
	makeId: int(),
	modelId: int(),
	modificationId: int(),
	catalogId: int(),
	catalogItemId: int(),
	orderPosition: int(),
	artNumber: varchar({ length: 255 }),
	originalName: varchar({ length: 255 }),
	volume: varchar({ length: 255 }),
	commentName: varchar({ length: 255 }),
});

export const toparts = mysqlTable("TOparts", {
	makeId: int(),
	modelId: int(),
	modificationId: varchar({ length: 255 }),
	manufacturerId: int(),
	manufacturerName: varchar({ length: 255 }),
	itemName: varchar({ length: 100 }),
	partNumber: varchar({ length: 255 }),
	quantity: int(),
	comment: varchar({ length: 255 }),
	id: int().autoincrement().notNull(),
});

export const topartsCrosses = mysqlTable("TOpartsCrosses", {
	manufacturerName: varchar({ length: 255 }),
	partNumber: varchar({ length: 255 }),
	crossBrand: varchar({ length: 100 }),
	crossNumber: varchar({ length: 50 }),
	id: int().autoincrement().notNull(),
});

export const companies = mysqlTable("companies", {
	id: int({ unsigned: true }).autoincrement().notNull(),
	name: varchar({ length: 255 }).notNull(),
	slug: varchar({ length: 255 }).notNull(),
	logo: varchar({ length: 500 }),
	contactEmail: varchar({ length: 320 }),
	contactPhone: varchar({ length: 50 }),
	isActive: mysqlEnum(['active','suspended','archived']).default('active').notNull(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
},
(table) => [
	index("companies_slug_idx").on(table.slug),
	index("companies_active_idx").on(table.isActive),
]);

export const companyUsers = mysqlTable("companyUsers", {
	id: int({ unsigned: true }).autoincrement().notNull(),
	companyId: int({ unsigned: true }).notNull(),
	userId: int({ unsigned: true }).notNull(),
	role: mysqlEnum(['owner','manager','viewer']).default('viewer').notNull(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
},
(table) => [
	index("companyUsers_company_idx").on(table.companyId),
	index("companyUsers_user_idx").on(table.userId),
]);

export const mapping = mysqlTable("mapping", {
	newMakeId: bigint({ mode: "number", unsigned: true }).notNull(),
	newModelId: bigint({ mode: "number", unsigned: true }).notNull(),
	newTypeId: bigint({ mode: "number", unsigned: true }).notNull(),
	seoType: varchar({ length: 512 }),
	makeId: int(),
	modelId: int(),
	typeId: varchar({ length: 53 }),
	id: int().autoincrement().notNull(),
});

export const productAssignments = mysqlTable("productAssignments", {
	id: int({ unsigned: true }).autoincrement().notNull(),
	companyId: int({ unsigned: true }).notNull(),
	productId: int({ unsigned: true }).notNull(),
	makeId: int({ unsigned: true }).notNull(),
	modelId: int({ unsigned: true }).notNull(),
	modificationId: varchar({ length: 53 }).notNull(),
	notes: varchar({ length: 500 }),
	isRecommended: mysqlEnum(['yes','no']).default('no').notNull(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
},
(table) => [
	index("productAssignments_company_idx").on(table.companyId),
	index("productAssignments_product_idx").on(table.productId),
	index("productAssignments_car_idx").on(table.makeId, table.modelId),
]);

export const products = mysqlTable("products", {
	id: int({ unsigned: true }).autoincrement().notNull(),
	companyId: int({ unsigned: true }).notNull(),
	name: varchar({ length: 255 }).notNull(),
	sku: varchar({ length: 100 }).notNull(),
	brand: varchar({ length: 255 }),
	category: varchar({ length: 255 }),
	description: text(),
	price: int(),
	currency: varchar({ length: 3 }).default('RUB'),
	volume: varchar({ length: 50 }),
	specs: json(),
	imageUrl: varchar({ length: 500 }),
	isActive: mysqlEnum(['active','inactive']).default('active').notNull(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
},
(table) => [
	index("products_company_idx").on(table.companyId),
	index("products_active_idx").on(table.isActive),
	index("products_category_idx").on(table.category),
]);

export const users = mysqlTable("users", {
	id: int({ unsigned: true }).autoincrement().notNull(),
	unionId: varchar({ length: 255 }),
	username: varchar({ length: 255 }),
	name: varchar({ length: 255 }),
	email: varchar({ length: 320 }),
	avatar: text(),
	role: mysqlEnum(['user','admin']).default('user').notNull(),
	createdAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	updatedAt: timestamp({ mode: 'string' }).defaultNow().onUpdateNow().notNull(),
	lastSignInAt: timestamp({ mode: 'string' }).default('CURRENT_TIMESTAMP').notNull(),
	passwordHash: varchar({ length: 255 }),
});
