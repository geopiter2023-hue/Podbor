/**
 * Fill TOmodels.imageUrl based on available images
 * Run: npx tsx db/fill-model-images.ts
 *
 * Logic:
 * 1. Check if /models/{modelId}.jpg exists → use it
 * 2. Otherwise use first modification image: /models/{modificationId}.jpg
 * 3. Leave NULL if no image found
 */
import { createConnection } from "mysql2/promise";
import { existsSync } from "fs";
import { join } from "path";

const url = process.env.DATABASE_URL || "";
const MODELS_DIR = process.env.MODELS_DIR || "./public/models";

async function main() {
  const m = url.match(/mysql:\/\/([^:]+):([^@]+)@([^:]+):(\d+)\/(.+)/);
  if (!m) {
    console.error("Invalid DATABASE_URL");
    process.exit(1);
  }
  const [, user, password, host, port, database] = m;

  const conn = await createConnection({
    host,
    port: parseInt(port),
    user,
    password,
    database,
    connectTimeout: 60000,
    ssl: { rejectUnauthorized: true },
  });

  console.log("Connected to database");
  console.log("Models directory:", MODELS_DIR);

  // Get all models
  const [allModels] = await conn.execute(
    "SELECT makeId, modelId, modelName FROM TOmodels ORDER BY makeId, modelId"
  );
  console.log("Total models:", (allModels as any[]).length);

  // Get all modification IDs grouped by model
  const [allMods] = await conn.execute(
    "SELECT makeId, modelId, id as modificationId FROM TOmodifications ORDER BY makeId, modelId"
  );

  // Build modification lookup: key = "makeId_modelId" → first modificationId
  const modMap: Record<string, string> = {};
  for (const mod of allMods as any[]) {
    const key = `${mod.makeId}_${mod.modelId}`;
    if (!modMap[key]) {
      modMap[key] = String(mod.modificationId);
    }
  }
  console.log("Unique model-mod mappings:", Object.keys(modMap).length);

  let filled = 0;
  let skipped = 0;
  const BATCH_SIZE = 100;

  for (let i = 0; i < (allModels as any[]).length; i++) {
    const model = (allModels as any[])[i];
    const modelId = String(model.modelId);

    // Check 1: direct model image
    const modelImagePath = join(MODELS_DIR, `${modelId}.jpg`);
    if (existsSync(modelImagePath)) {
      const imageUrl = `/models/${modelId}.jpg`;
      await conn.execute(
        "UPDATE TOmodels SET imageUrl = ? WHERE makeId = ? AND modelId = ?",
        [imageUrl, model.makeId, model.modelId]
      );
      filled++;
      continue;
    }

    // Check 2: modification image
    const modKey = `${model.makeId}_${model.modelId}`;
    const modId = modMap[modKey];
    if (modId) {
      const modImagePath = join(MODELS_DIR, `${modId}.jpg`);
      if (existsSync(modImagePath)) {
        const imageUrl = `/models/${modId}.jpg`;
        await conn.execute(
          "UPDATE TOmodels SET imageUrl = ? WHERE makeId = ? AND modelId = ?",
          [imageUrl, model.makeId, model.modelId]
        );
        filled++;
        continue;
      }
    }

    skipped++;

    if ((i + 1) % BATCH_SIZE === 0) {
      console.log(`Progress: ${i + 1}/${(allModels as any[]).length}, filled=${filled}, skipped=${skipped}`);
    }
  }

  console.log("\n=== DONE ===");
  console.log("Filled:", filled);
  console.log("Skipped (no image):", skipped);

  // Show sample
  const [sample] = await conn.execute(
    "SELECT makeId, modelId, modelName, imageUrl FROM TOmodels WHERE imageUrl IS NOT NULL LIMIT 10"
  );
  console.log("\nSample:");
  (sample as any[]).forEach((r) => console.log(`  ${r.modelName}: ${r.imageUrl}`));

  await conn.end();
}

main().catch((e) => {
  console.error("Fatal:", e);
  process.exit(1);
});
