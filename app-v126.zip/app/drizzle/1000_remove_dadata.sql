-- Remove DaData settings (no longer needed)
DELETE FROM systemSettings WHERE `key` LIKE '%dadata%';

-- Add Russian AI provider settings if not exists
INSERT IGNORE INTO systemSettings (`key`, `value`, `label`, `category`, `isSecret`, `description`) VALUES
('yandex_api_key', '', 'Yandex GPT API Key — РОССИЙСКИЙ AI', 'api_keys', 'yes', 'Работает из России без VPN. Получить: yandex.cloud/ru/docs/foundation-models/ -> создать сервисный аккаунт -> API ключ'),
('yandex_folder_id', '', 'Yandex Folder ID', 'api_keys', 'yes', 'ID каталога Yandex Cloud. Находится в консоли Yandex Cloud (b1g...)'),
('gigachat_client_id', '', 'GigaChat Client ID — СБЕР AI', 'api_keys', 'yes', 'Работает из России без VPN. Получить: developers.sber.ru/studio -> создать проект -> GigaChat API'),
('gigachat_client_secret', '', 'GigaChat Client Secret — СБЕР AI', 'api_keys', 'yes', 'Секретный ключ из проекта GigaChat в developers.sber.ru'),
('vsegpt_api_key', '', 'VseGPT API Key — АГРЕГАТОР AI', 'api_keys', 'yes', 'Работает из России. Агрегатор: GigaChat, Yandex, Llama, Mistral. Получить: vsegpt.ru -> API -> Создать ключ');
