-- Remove old GigaChat Client ID setting (no longer needed)
-- GigaChat now uses only Authorization Key (client_secret field)
DELETE FROM systemSettings WHERE `key` = 'gigachat_client_id';

-- Add new GigaChat Authorization Key if not exists
INSERT IGNORE INTO systemSettings (`key`, `value`, `label`, `category`, `isSecret`, `description`) VALUES
('gigachat_client_secret', '', 'GigaChat Authorization Key — СБЕР AI', 'api_keys', 'yes', 'Работает из России без VPN. Получить: developers.sber.ru/studio -> проект -> Настройки проекта -> Authorization key (НЕ Client Secret!)');
