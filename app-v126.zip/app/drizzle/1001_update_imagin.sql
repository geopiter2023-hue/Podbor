-- Update imagin setting: api_key -> customer_name
-- Images are loaded straight from IMAGIN.studio CDN, never downloaded

DELETE FROM systemSettings WHERE `key` = 'imagin_api_key';

INSERT IGNORE INTO systemSettings (`key`, `value`, `label`, `category`, `isSecret`, `description`) VALUES
('imagin_customer_name', '', 'Imagin Studio Customer Name — ФОТО АВТО', 'api_keys', 'no', 'Имя клиента в Imagin Studio (не API ключ!). Изображения загружаются ПРЯМО с CDN. Получить: imagin.studio -> Регистрация -> Customer Name');
