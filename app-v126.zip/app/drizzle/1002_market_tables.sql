-- Market Monitor tables: drom.ru catalog sync
-- Run: mysql -u root -p oilpodbor < drizzle/1002_market_tables.sql

CREATE TABLE IF NOT EXISTS `marketCars` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `source` varchar(50) NOT NULL DEFAULT 'drom.ru',
  `sourceUrl` text,
  `make` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `generation` varchar(500),
  `modification` varchar(500),
  `yearFrom` int,
  `yearTo` int,
  `engineCode` varchar(100),
  `engineCapacity` varchar(50),
  `enginePower` varchar(50),
  `fuel` varchar(50),
  `transmission` varchar(100),
  `body` varchar(100),
  `status` enum('new','pending','approved','rejected','merged') NOT NULL DEFAULT 'new',
  `matchedCarId` int,
  `foundAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewedBy` int,
  `reviewedAt` timestamp,
  `notes` text,
  INDEX `marketCars_status_idx` (`status`),
  INDEX `marketCars_make_model_idx` (`make`, `model`),
  INDEX `marketCars_found_idx` (`foundAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `marketSyncLog` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `source` varchar(50) NOT NULL DEFAULT 'drom.ru',
  `status` enum('running','completed','failed') NOT NULL DEFAULT 'running',
  `carsFound` int DEFAULT 0,
  `carsNew` int DEFAULT 0,
  `carsUpdated` int DEFAULT 0,
  `carsMerged` int DEFAULT 0,
  `error` text,
  `startedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completedAt` timestamp,
  INDEX `marketSyncLog_status_idx` (`status`),
  INDEX `marketSyncLog_started_idx` (`startedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
