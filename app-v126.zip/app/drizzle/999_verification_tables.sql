-- AI Multi-Agent Verification Tables
-- Run this migration to create tables for the verification system

CREATE TABLE IF NOT EXISTS `aiVerifications` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `make` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `modification` varchar(500),
  `engineCode` varchar(100),
  `year` int,
  `overallConfidence` int DEFAULT 0,
  `status` enum('running','completed','failed','needs_review') NOT NULL DEFAULT 'running',
  `agentCount` int DEFAULT 0,
  `consensusFields` int DEFAULT 0,
  `totalFields` int DEFAULT 0,
  `needsHumanReview` enum('yes','no') NOT NULL DEFAULT 'no',
  `humanReviewerId` int,
  `humanReviewNotes` text,
  `reviewedAt` timestamp,
  `startedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completedAt` timestamp,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `aiVerif_make_model_idx` (`make`, `model`),
  INDEX `aiVerif_status_idx` (`status`),
  INDEX `aiVerif_created_idx` (`startedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `aiVerificationAgents` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `verificationId` int NOT NULL,
  `agentId` varchar(50) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `model` varchar(100),
  `filledFields` json,
  `sources` json,
  `filledCount` int DEFAULT 0,
  `durationMs` int DEFAULT 0,
  `tokensInput` int DEFAULT 0,
  `tokensOutput` int DEFAULT 0,
  `rawResponse` text,
  `error` text,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `aiVerifAgent_verification_idx` (`verificationId`),
  INDEX `aiVerifAgent_agent_idx` (`agentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `aiVerificationFields` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `verificationId` int NOT NULL,
  `fieldKey` varchar(100) NOT NULL,
  `fieldLabel` varchar(200),
  `section` varchar(100),
  `agentValues` json,
  `agentSources` json,
  `consensusValue` varchar(500),
  `confidence` int DEFAULT 0,
  `agreeingAgents` int DEFAULT 0,
  `totalAgents` int DEFAULT 0,
  `status` enum('consensus','conflict','partial','empty') NOT NULL DEFAULT 'empty',
  `humanValue` varchar(500),
  `humanReviewerId` int,
  `humanReviewNotes` text,
  `reviewedAt` timestamp,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `aiVerifField_verification_idx` (`verificationId`),
  INDEX `aiVerifField_key_idx` (`fieldKey`),
  INDEX `aiVerifField_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
