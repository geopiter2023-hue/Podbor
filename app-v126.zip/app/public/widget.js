/**
 * Motornaya Oil Selector Widget
 * Embed code:
 * <script src="https://your-domain.com/widget.js" data-api-key="mk_..."></script>
 * <div id="motornaya-widget"></div>
 */
(function () {
  "use strict";

  // Find current script
  const currentScript = document.currentScript ||
    document.querySelector('script[data-api-key]');

  if (!currentScript) {
    console.error('[Motornaya] Widget script not found. Add data-api-key attribute.');
    return;
  }

  const apiKey = currentScript.getAttribute('data-api-key');
  if (!apiKey) {
    console.error('[Motornaya] data-api-key attribute is required');
    return;
  }

  // Get base URL from script src
  const scriptSrc = currentScript.src;
  const baseUrl = scriptSrc.replace(/\/widget\.js$/, '') || window.location.origin;

  // Find or create container
  let container = document.getElementById('motornaya-widget');
  if (!container) {
    container = document.createElement('div');
    container.id = 'motornaya-widget';
    currentScript.parentNode.insertBefore(container, currentScript.nextSibling);
  }

  // Styles
  container.style.width = '100%';
  container.style.maxWidth = '900px';
  container.style.margin = '0 auto';

  // Create iframe
  const iframe = document.createElement('iframe');
  iframe.src = baseUrl + '/embed?apiKey=' + encodeURIComponent(apiKey);
  iframe.style.width = '100%';
  iframe.style.height = '600px';
  iframe.style.border = 'none';
  iframe.style.borderRadius = '12px';
  iframe.style.overflow = 'hidden';
  iframe.setAttribute('allowtransparency', 'true');
  iframe.title = 'Motornaya Oil Selector';

  container.appendChild(iframe);

  // Handle resize messages from iframe
  window.addEventListener('message', function (event) {
    // Verify origin
    const expectedOrigin = new URL(baseUrl).origin;
    if (event.origin !== expectedOrigin) return;

    if (event.data && event.data.type === 'motornaya-resize') {
      const height = event.data.height;
      if (height && height > 0) {
        iframe.style.height = height + 'px';
      }
    }
  });

  console.log('[Motornaya] Widget initialized with API key:', apiKey.substring(0, 10) + '...');
})();
