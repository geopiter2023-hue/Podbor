/**
 * API endpoint to import heavy equipment data from Excel
 * POST /api/import-heavy-equipment
 */

import { Hono } from "hono";
import { getDb } from "./queries/connection";
import { heavyEquipmentTypes, heavyEquipmentBrands, heavyEquipmentModels, heavyEquipmentSpecs, heavyEquipmentFluids, heavyEquipmentOilSpecs } from "@db/schema";
import xlsx from "xlsx";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = new Hono();

// Helper to clean string values
function clean(val: any): string | null {
  if (val === null || val === undefined) return null;
  const s = String(val).trim();
  return s === "" || s === "nan" ? null : s;
}

function slugify(name: string): string {
  return name.toLowerCase().trim()
    .replace(/[^a-z0-9а-я\s]/gi, "")
    .replace(/\s+/g, "-")
    .substring(0, 60) || "unnamed";
}

app.post("/", async (c) => {
  const results: Record<string, number> = {};
  const errors: string[] = [];

  try {
    const db = getDb();
    const uploadDir = path.join(__dirname, "..", "upload");

    // Check files exist
    const enrichedPath = path.join(uploadDir, "excapedia_enriched.xlsx");
    const oilPath = path.join(uploadDir, "excapedia_oil_selection.xlsx");

    if (!fs.existsSync(enrichedPath)) {
      return c.json({ error: `File not found: ${enrichedPath}` }, 400);
    }

    // Read Excel files
    const enrichedBook = xlsx.readFile(enrichedPath);
    const typesSheet = enrichedBook.Sheets["Сводка по типам"];
    const modelsSheet = enrichedBook.Sheets["Модели"];
    const specsSheet = enrichedBook.Sheets["Офиц_характеристики"];
    const fluidsSheet = enrichedBook.Sheets["Жидкости_и_допуски"];

    // 1. Import Types
    const typesData = xlsx.utils.sheet_to_json(typesSheet);
    let typesCount = 0;
    for (const row of typesData as any[]) {
      const name = clean(row["type_ru"]);
      if (!name) continue;
      try {
        await db.insert(heavyEquipmentTypes).values({
          name,
          slug: slugify(name),
        }).onDuplicateKeyUpdate({ set: { name } });
        typesCount++;
      } catch (e: any) { errors.push(`Type ${name}: ${e.message}`); }
    }
    results.types = typesCount;

    // 2. Import Brands (from models data)
    const modelsData = xlsx.utils.sheet_to_json(modelsSheet);
    const brandSet = new Map<string, string>();
    for (const row of modelsData as any[]) {
      const bs = clean(row["brands"]);
      if (!bs) continue;
      const name = bs.replace(/_/g, " ").replace(/\b\w/g, (c: string) => c.toUpperCase());
      brandSet.set(bs, name);
    }
    let brandsCount = 0;
    for (const [slug, name] of brandSet) {
      try {
        await db.insert(heavyEquipmentBrands).values({ name, slug }).onDuplicateKeyUpdate({ set: { name } });
        brandsCount++;
      } catch (e: any) { errors.push(`Brand ${name}: ${e.message}`); }
    }
    results.brands = brandsCount;

    // 3. Import Models (in batches of 200)
    const BATCH = 200;
    let modelsCount = 0;
    for (let i = 0; i < modelsData.length; i += BATCH) {
      const batch = (modelsData as any[]).slice(i, i + BATCH);
      const values = [];
      for (const row of batch) {
        const slug = clean(row["slug"]);
        const title = clean(row["title"]);
        const brandSlug = clean(row["brands"]);
        const typeName = clean(row["type_ru"]) || "";
        if (!slug || !title || !brandSlug) continue;

        values.push({
          slug,
          title,
          brandSlug,
          brandName: brandSlug.replace(/_/g, " ").replace(/\b\w/g, (c: string) => c.toUpperCase()),
          typeSlug: slugify(typeName),
          typeName,
          description: clean(row["description"]),
          url: clean(row["url"]),
          photoUrl: clean(row["photos"]),
          isEnriched: clean(row["enriched"]) === "да" ? "yes" as const : "no" as const,
          sourceType: clean(row["source_type"]),
          sourceUrl: clean(row["source_url"]),
          nOfficialSpecs: parseInt(row["n_official_specs"]) || 0,
          nFluids: parseInt(row["n_fluids"]) || 0,
          enrichNotes: clean(row["enrich_notes"]),
        });
      }
      if (values.length > 0) {
        try {
          await db.insert(heavyEquipmentModels).values(values as any).onDuplicateKeyUpdate({
            set: {
              title: (v: any) => v.title,
              description: (v: any) => v.description,
            },
          });
          modelsCount += values.length;
        } catch (e: any) {
          // Fallback: insert one by one
          for (const v of values) {
            try {
              await db.insert(heavyEquipmentModels).values(v as any).onDuplicateKeyUpdate({
                set: { title: v.title, description: v.description },
              });
              modelsCount++;
            } catch (e2: any) { /* skip duplicates */ }
          }
        }
      }
    }
    results.models = modelsCount;

    // 4. Import Specs (in batches of 500)
    const specsData = xlsx.utils.sheet_to_json(specsSheet);
    let specsCount = 0;
    for (let i = 0; i < specsData.length; i += 500) {
      const batch = (specsData as any[]).slice(i, i + 500);
      for (const row of batch) {
        const slug = clean(row["slug"]);
        const param = clean(row["param"]);
        if (!slug || !param) continue;
        try {
          await db.insert(heavyEquipmentSpecs).values({
            modelSlug: slug,
            param,
            value: clean(row["value"]),
            sourceType: clean(row["source_type"]),
          });
          specsCount++;
        } catch (e: any) { /* skip */ }
      }
    }
    results.specs = specsCount;

    // 5. Import Fluids (in batches of 500)
    const fluidsData = xlsx.utils.sheet_to_json(fluidsSheet);
    let fluidsCount = 0;
    for (let i = 0; i < fluidsData.length; i += 500) {
      const batch = (fluidsData as any[]).slice(i, i + 500);
      for (const row of batch) {
        const slug = clean(row["slug"]);
        const fluid = clean(row["fluid"]);
        if (!slug || !fluid) continue;
        try {
          await db.insert(heavyEquipmentFluids).values({
            modelSlug: slug,
            modelTitle: clean(row["title"]),
            fluidType: fluid,
            value: clean(row["value"]),
            sourceType: clean(row["source_type"]),
            sourceUrl: clean(row["source_url"]),
          });
          fluidsCount++;
        } catch (e: any) { /* skip */ }
      }
    }
    results.fluids = fluidsCount;

    // 6. Import Oil Specs
    if (fs.existsSync(oilPath)) {
      const oilBook = xlsx.readFile(oilPath);
      const oilSheet = oilBook.Sheets["Допуски по брендам"];
      const oilData = xlsx.utils.sheet_to_json(oilSheet);
      let oilCount = 0;

      for (const row of oilData as any[]) {
        const brandSlug = clean(row["brand"]);
        if (!brandSlug) continue;
        const brandName = brandSlug.replace(/_/g, " ").replace(/\b\w/g, (c: string) => c.toUpperCase());

        for (const fluidType of ["engine_oil", "hydraulic", "coolant", "transmission", "axle"]) {
          const spec = clean(row[fluidType]);
          if (!spec) continue;

          const oemMatch = spec.match(/oem_spec:\s*([^;]+)/);
          const viscMatch = spec.match(/viscosity:\s*([^;]+)/);
          const apiMatch = spec.match(/api_acea:\s*([^;]+)/);
          const intervalMatch = spec.match(/change_interval:\s*([^;]+)/);

          try {
            await db.insert(heavyEquipmentOilSpecs).values({
              brandSlug,
              brandName,
              fluidType,
              oemSpec: oemMatch ? oemMatch[1].trim() : null,
              viscosity: viscMatch ? viscMatch[1].trim() : null,
              apiAce: apiMatch ? apiMatch[1].trim() : null,
              changeInterval: intervalMatch ? intervalMatch[1].trim() : null,
              notes: spec.substring(0, 500),
            }).onDuplicateKeyUpdate({
              set: {
                oemSpec: oemMatch ? oemMatch[1].trim() : null,
                viscosity: viscMatch ? viscMatch[1].trim() : null,
                apiAce: apiMatch ? apiMatch[1].trim() : null,
                changeInterval: intervalMatch ? intervalMatch[1].trim() : null,
                notes: spec.substring(0, 500),
              },
            });
            oilCount++;
          } catch (e: any) { /* skip */ }
        }
      }
      results.oilSpecs = oilCount;
    }

    return c.json({ success: true, results, errors: errors.slice(0, 10) });

  } catch (e: any) {
    return c.json({ error: e.message, stack: e.stack?.substring(0, 200) }, 500);
  }
});

export default app;
