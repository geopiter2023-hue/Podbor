import { useState, useMemo } from "react";
import { trpc } from "@/providers/trpc";
import {
  Shield, Play, CheckCircle, AlertTriangle, Search,
  ChevronDown, ChevronUp, UserCheck, Loader2, Car,
  Zap, X, BookOpen, XCircle, Clock, ChevronRight,
  Square, CheckSquare, Filter,
} from "lucide-react";

const AGENT_INFO: Record<string, { name: string; color: string; bg: string }> = {
  perplexity: { name: "Perplexity", color: "text-purple-700", bg: "bg-purple-100 border-purple-300" },
  anthropic: { name: "Anthropic", color: "text-amber-700", bg: "bg-amber-100 border-amber-300" },
  deepseek: { name: "DeepSeek", color: "text-sky-700", bg: "bg-sky-100 border-sky-300" },
  yandex: { name: "Yandex GPT", color: "text-yellow-700", bg: "bg-yellow-100 border-yellow-300" },
  gigachat: { name: "GigaChat", color: "text-green-700", bg: "bg-green-100 border-green-300" },
  vsegpt: { name: "VseGPT", color: "text-indigo-700", bg: "bg-indigo-100 border-indigo-300" },
  groq: { name: "Groq", color: "text-emerald-700", bg: "bg-emerald-100 border-emerald-300" },
  gemini: { name: "Gemini", color: "text-rose-700", bg: "bg-rose-100 border-rose-300" },
};

const STATUS_STYLES: Record<string, string> = {
  consensus: "bg-green-100 text-green-700",
  partial: "bg-amber-100 text-amber-700",
  conflict: "bg-red-100 text-red-700",
  empty: "bg-gray-100 text-gray-500",
};

interface VerificationPanelProps {
  onNavigatePdf?: (make: string, model: string) => void;
}

export default function VerificationPanel({ onNavigatePdf }: VerificationPanelProps) {
  const utils = trpc.useUtils();
  const [selectedVerifId, setSelectedVerifId] = useState<number | null>(null);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set());
  const [humanReviewField, setHumanReviewField] = useState<number | null>(null);
  const [humanValue, setHumanValue] = useState("");
  const [humanNotes, setHumanNotes] = useState("");

  // Car list
  const [carSearch, setCarSearch] = useState("");
  const [carMakeFilter, setCarMakeFilter] = useState("");
  const [carPage, setCarPage] = useState(0);
  const [selectedCars, setSelectedCars] = useState<Set<number>>(new Set());
  const carPageSize = 50;

  const { data: carsData, isLoading: carsLoading } = trpc.cars.list.useQuery({
    make: carMakeFilter || undefined,
    limit: carPageSize,
    offset: carPage * carPageSize,
  });
  const { data: totalCarsCount } = trpc.cars.count.useQuery({ make: carMakeFilter || undefined });
  const { data: allMakes } = trpc.cars.getMakes.useQuery();
  const { data: verifList } = trpc.verification.list.useQuery({ limit: 500 });
  const { data: stats } = trpc.verification.stats.useQuery();
  const { data: detailData } = trpc.verification.getById.useQuery(
    { id: selectedVerifId! },
    { enabled: !!selectedVerifId }
  );

  const [runningAgents, setRunningAgents] = useState<Record<string, { status: string; filled: number; error?: string }>>({});

  const runAgentMut = trpc.verification.runAgent.useMutation({
    onSuccess: (data, vars) => {
      const key = `${vars.verificationId}_${vars.agentId}`;
      setRunningAgents((prev) => ({ ...prev, [key]: { status: data.success ? "completed" : "error", filled: data.filledCount, error: data.error || undefined } }));
      utils.verification.getById.invalidate({ id: vars.verificationId });
      utils.verification.list.invalidate();
    },
    onError: (err, vars) => {
      const key = `${vars.verificationId}_${vars.agentId}`;
      setRunningAgents((prev) => ({ ...prev, [key]: { status: "error", filled: 0, error: err.message } }));
    },
  });

  const runVerif = trpc.verification.run.useMutation({
    onSuccess: (result) => {
      setSelectedVerifId(result.verificationId);
      utils.verification.list.invalidate();
      utils.verification.stats.invalidate();
    },
  });

  const applyVerif = trpc.verification.apply.useMutation({
    onSuccess: () => { alert("Данные применены!"); utils.excel.getByCar.invalidate(); },
  });

  const humanReview = trpc.verification.humanReview.useMutation({
    onSuccess: () => {
      setHumanReviewField(null); setHumanValue(""); setHumanNotes("");
      utils.verification.getById.invalidate({ id: selectedVerifId! });
      utils.verification.stats.invalidate();
    },
  });

  const verifMap = useMemo(() => {
    const map: Record<string, any> = {};
    verifList?.items?.forEach((v: any) => {
      const key = `${v.make}|${v.model}`;
      if (!map[key] || new Date(v.startedAt) > new Date(map[key].startedAt)) map[key] = v;
    });
    return map;
  }, [verifList]);

  const totalCarPages = Math.ceil((totalCarsCount || 0) / carPageSize);

  const filteredCars = useMemo(() => {
    if (!carsData?.items) return [];
    if (!carSearch) return carsData.items;
    const q = carSearch.toLowerCase();
    return carsData.items.filter((car: any) =>
      (car.make || "").toLowerCase().includes(q) ||
      (car.model || "").toLowerCase().includes(q) ||
      (car.modification || "").toLowerCase().includes(q) ||
      (car.engineCode || "").toLowerCase().includes(q)
    );
  }, [carsData, carSearch]);

  const allSelected = filteredCars.length > 0 && filteredCars.every((c: any) => selectedCars.has(c.id));

  const toggleSelectAll = () => {
    if (allSelected) {
      setSelectedCars((prev) => {
        const next = new Set(prev);
        filteredCars.forEach((c: any) => next.delete(c.id));
        return next;
      });
    } else {
      setSelectedCars((prev) => {
        const next = new Set(prev);
        filteredCars.forEach((c: any) => next.add(c.id));
        return next;
      });
    }
  };

  const toggleCar = (id: number) => {
    setSelectedCars((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const handleRunSelected = async () => {
    const cars = filteredCars.filter((c: any) => selectedCars.has(c.id));
    if (cars.length === 0) { alert("Выберите автомобили"); return; }
    for (const car of cars) {
      await handleRunAllAgents(car);
      await new Promise((r) => setTimeout(r, 1000));
    }
  };

  const handleRunAllAgents = async (car: any) => {
    const result = await runVerif.mutateAsync({
      make: car.make || "", model: car.model || "",
      engineCode: car.engineCode || undefined,
      modification: car.modification || undefined,
    });
    if (result?.verificationId) {
      for (const cfg of Object.keys(AGENT_INFO)) {
        const key = `${result.verificationId}_${cfg}`;
        setRunningAgents((prev) => ({ ...prev, [key]: { status: "running", filled: 0 } }));
        runAgentMut.mutate({
          verificationId: result.verificationId, agentId: cfg,
          make: car.make || "", model: car.model || "",
          engineCode: car.engineCode || undefined,
          modification: car.modification || undefined,
        });
        await new Promise((r) => setTimeout(r, 600));
      }
    }
  };

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => {
      const next = new Set(prev);
      if (next.has(section)) next.delete(section); else next.add(section);
      return next;
    });
  };

  const groupedFields = detailData?.fields?.reduce((acc: Record<string, any[]>, f: any) => {
    const section = f.section || "Другое";
    if (!acc[section]) acc[section] = [];
    acc[section].push(f);
    return acc;
  }, {}) || {};

  const getAgentStatus = (verifId: number, agentId: string) => {
    return runningAgents[`${verifId}_${agentId}`];
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Всего проверок", value: stats?.total || 0, color: "text-gray-800" },
          { label: "100% совпадений", value: stats?.consensus100 || 0, color: "text-green-600" },
          { label: "Требует проверки", value: stats?.needsReview || 0, color: "text-amber-600" },
          { label: "Авто в базе", value: totalCarsCount?.toLocaleString("ru") || 0, color: "text-gray-800" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-lg border border-gray-200 p-4">
            <p className="text-gray-500 text-xs uppercase">{s.label}</p>
            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Detail View */}
      {detailData && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h3 className="text-gray-800 font-semibold text-lg">
                  {detailData.verification.make} {detailData.verification.model}
                  <span className={`ml-2 text-sm px-2 py-0.5 rounded-full ${
                    detailData.verification.overallConfidence === 100 ? "bg-green-100 text-green-700" :
                    detailData.verification.overallConfidence >= 70 ? "bg-amber-100 text-amber-700" :
                    "bg-red-100 text-red-700"
                  }`}>{detailData.verification.overallConfidence}% ({detailData.verification.agentCount} агентов)</span>
                </h3>
                <p className="text-gray-500 text-xs">
                  ID #{detailData.verification.id} | {new Date(detailData.verification.startedAt).toLocaleString("ru-RU")}
                  {detailData.verification.needsHumanReview === "yes" && <span className="ml-2 text-amber-600 font-medium">⚠ Требует проверки</span>}
                </p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => applyVerif.mutate({ verificationId: detailData.verification.id })} disabled={applyVerif.isPending}
                  className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700 disabled:opacity-50 flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" /> Применить
                </button>
                {onNavigatePdf && (
                  <button onClick={() => onNavigatePdf(detailData.verification.make, detailData.verification.model)}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 flex items-center gap-1">
                    <BookOpen className="w-4 h-4" /> PDF
                  </button>
                )}
                <button onClick={() => setSelectedVerifId(null)} className="text-gray-400 hover:text-gray-600 p-2"><X className="w-5 h-5" /></button>
              </div>
            </div>

            {/* Agent Cards — deduplicated */}
            <div className="grid grid-cols-8 gap-2 mt-4">
              {Object.keys(AGENT_INFO).map((agentId) => {
                const dbAgent = detailData.agents.find((a: any) => a.agentId === agentId);
                const info = AGENT_INFO[agentId];
                const live = getAgentStatus(detailData.verification.id, agentId);
                const filled = live?.filled ?? dbAgent?.filledCount ?? 0;
                const hasErr = live?.error ?? dbAgent?.error;
                const isRun = live?.status === "running";
                const isDone = filled > 0 && !hasErr;

                return (
                  <div key={agentId} className={`rounded-lg border p-3 ${info.bg} ${isRun ? "ring-2 ring-blue-400 animate-pulse" : ""}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-xs font-bold ${info.color}`}>{info.name}</span>
                      {isRun ? <Loader2 className="w-3 h-3 animate-spin text-blue-600" /> :
                       isDone ? <CheckCircle className="w-3 h-3 text-green-600" /> :
                       hasErr ? <XCircle className="w-3 h-3 text-red-600" /> :
                       <Clock className="w-3 h-3 text-gray-400" />}
                    </div>
                    <p className="text-lg font-bold text-gray-800">{filled}</p>
                    <p className="text-[10px] text-gray-500">полей</p>
                    {hasErr && <p className="text-[10px] text-red-600 mt-1 truncate" title={hasErr}>{hasErr}</p>}
                    {dbAgent?.durationMs > 0 && <p className="text-[10px] text-gray-400">{Math.round(dbAgent.durationMs / 1000)}с</p>}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Comparison Table */}
          <div className="p-4">
            {Object.entries(groupedFields).map(([section, fields]: [string, any[]]) => (
              <div key={section} className="mb-3">
                <button onClick={() => toggleSection(section)}
                  className="w-full flex items-center justify-between py-2 px-3 bg-gray-50 rounded-lg hover:bg-gray-100 mb-1">
                  <span className="text-sm font-semibold text-gray-700">{section}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">
                      {fields.filter((f) => f.status === "consensus").length}/{fields.length} совпадений
                    </span>
                    {expandedSections.has(section) ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>
                {expandedSections.has(section) && (
                  <div className="overflow-x-auto border rounded-lg">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="border-b bg-gray-50 text-left">
                          <th className="p-2 text-gray-500 font-medium w-36">Поле</th>
                          {Object.keys(AGENT_INFO).map((id) => (
                            <th key={id} className={`p-2 text-center w-20 text-[10px] ${AGENT_INFO[id].color}`}>{AGENT_INFO[id].name}</th>
                          ))}
                          <th className="p-2 text-green-600 font-medium text-center w-24">Консенсус</th>
                          <th className="p-2 text-gray-500 font-medium text-center w-14">%</th>
                          <th className="p-2 w-8"></th>
                        </tr>
                      </thead>
                      <tbody>
                        {fields.map((field) => {
                          const agentValues = (field.agentValues || {}) as Record<string, string>;
                          const consensusVal = field.humanValue || field.consensusValue;
                          const hasData = Object.keys(agentValues).length > 0;
                          return (
                            <tr key={field.id} className={`border-b border-gray-50 hover:bg-gray-50 ${!hasData ? "opacity-50" : ""}`}>
                              <td className="p-2 text-gray-700 font-medium">{field.fieldLabel}</td>
                              {Object.keys(AGENT_INFO).map((id) => {
                                const val = agentValues[id];
                                const match = val && consensusVal && normalizeValue(val) === normalizeValue(consensusVal);
                                return (
                                  <td key={id} className={`p-2 text-center ${match ? "text-green-600 font-bold bg-green-50" : val ? "text-gray-700" : "text-gray-300"}`}>
                                    {val || "—"}
                                  </td>
                                );
                              })}
                              <td className="p-2 text-center font-bold text-green-700 bg-green-50">{consensusVal || "—"}</td>
                              <td className="p-2 text-center">
                                <span className={`px-1.5 py-0.5 rounded-full text-[10px] ${STATUS_STYLES[field.status || "empty"]}`}>
                                  {field.confidence}%
                                </span>
                              </td>
                              <td className="p-2">
                                {field.status !== "consensus" && (
                                  <button onClick={() => { setHumanReviewField(field.id); setHumanValue(field.consensusValue || ""); setHumanNotes(""); }}
                                    className="text-purple-600 hover:text-purple-800" title="Проверить">
                                    <UserCheck className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Human Review Modal */}
      {humanReviewField && detailData && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6">
            <h3 className="text-gray-800 font-semibold text-lg mb-3 flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-purple-600" /> Ручная проверка
            </h3>
            {detailData.fields.find((f: any) => f.id === humanReviewField) && (
              <div className="mb-3 bg-gray-50 rounded-lg p-3 space-y-1 max-h-40 overflow-y-auto">
                <p className="text-xs text-gray-500 font-medium">Значения агентов:</p>
                {Object.entries((detailData.fields.find((f: any) => f.id === humanReviewField)!).agentValues || {}).map(([agent, val]: [string, any]) => (
                  <div key={agent} className="flex justify-between text-xs">
                    <span className="text-gray-600">{AGENT_INFO[agent]?.name || agent}:</span>
                    <span className="font-medium">{val || "—"}</span>
                  </div>
                ))}
              </div>
            )}
            <div className="space-y-3">
              <input type="text" value={humanValue} onChange={(e) => setHumanValue(e.target.value)} placeholder="Ваше значение" className="w-full border rounded-md px-3 py-2 text-sm" />
              <textarea value={humanNotes} onChange={(e) => setHumanNotes(e.target.value)} placeholder="Примечания / источник" className="w-full border rounded-md px-3 py-2 text-sm resize-none" rows={2} />
              <div className="flex gap-2">
                <button onClick={() => { if (!humanValue.trim()) return; humanReview.mutate({ fieldId: humanReviewField, value: humanValue.trim(), notes: humanNotes.trim() || undefined }); }} disabled={humanReview.isPending}
                  className="flex-1 bg-purple-600 text-white py-2 rounded-lg text-sm font-medium disabled:opacity-50">{humanReview.isPending ? "Сохранение..." : "Сохранить"}</button>
                <button onClick={() => { setHumanReviewField(null); setHumanValue(""); setHumanNotes(""); }}
                  className="flex-1 border text-gray-600 py-2 rounded-lg text-sm">Отмена</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cars Table */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
            <h2 className="text-gray-800 font-semibold flex items-center gap-2">
              <Car className="w-5 h-5 text-[#d32f2f]" />
              База автомобилей ({totalCarsCount?.toLocaleString("ru") || 0})
            </h2>
            {selectedCars.size > 0 && (
              <button onClick={handleRunSelected} disabled={runVerif.isPending}
                className="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-purple-700 disabled:opacity-50 flex items-center gap-1">
                <Zap className="w-4 h-4" />
                Запустить выбранные ({selectedCars.size})
              </button>
            )}
          </div>
          <div className="flex gap-2 flex-wrap">
            <div className="relative flex-1 min-w-48">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input type="text" value={carSearch} onChange={(e) => { setCarSearch(e.target.value); setCarPage(0); }}
                placeholder="Поиск по марке, модели, модификации, двигателю..." className="w-full border rounded-md pl-9 pr-3 py-2 text-sm" />
            </div>
            <select value={carMakeFilter} onChange={(e) => { setCarMakeFilter(e.target.value); setCarPage(0); setCarSearch(""); }} className="border rounded-md px-3 py-2 text-sm">
              <option value="">Все марки</option>
              {allMakes?.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
        </div>

        {carsLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-purple-600" /></div>
        ) : !filteredCars?.length ? (
          <p className="text-gray-400 text-sm text-center py-12">Нет автомобилей</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 text-left bg-gray-50">
                  <th className="p-3 w-8">
                    <button onClick={toggleSelectAll} className="text-gray-500 hover:text-purple-600">
                      {allSelected ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                    </button>
                  </th>
                  <th className="p-3 text-gray-500 text-xs font-medium w-10">#</th>
                  <th className="p-3 text-gray-500 text-xs font-medium">Марка</th>
                  <th className="p-3 text-gray-500 text-xs font-medium">Модель</th>
                  <th className="p-3 text-gray-500 text-xs font-medium max-w-32">Модификация</th>
                  <th className="p-3 text-gray-500 text-xs font-medium w-20">Годы</th>
                  <th className="p-3 text-gray-500 text-xs font-medium w-20 text-center">%</th>
                  <th className="p-3 text-gray-500 text-xs font-medium text-center w-72">8 агентов</th>
                  <th className="p-3 text-gray-500 text-xs font-medium w-16 text-center">Действие</th>
                </tr>
              </thead>
              <tbody>
                {filteredCars.map((car: any, idx: number) => {
                  const vKey = `${car.make}|${car.model}`;
                  const v = verifMap[vKey];
                  const isSel = selectedCars.has(car.id);
                  return (
                    <tr key={car.id} className={`border-b border-gray-50 hover:bg-gray-50 ${isSel ? "bg-purple-50" : ""}`}>
                      <td className="p-3">
                        <button onClick={() => toggleCar(car.id)} className="text-gray-500 hover:text-purple-600">
                          {isSel ? <CheckSquare className="w-4 h-4 text-purple-600" /> : <Square className="w-4 h-4" />}
                        </button>
                      </td>
                      <td className="p-3 text-gray-400 text-xs">{carPage * carPageSize + idx + 1}</td>
                      <td className="p-3 text-gray-800 font-medium text-sm">{car.make}</td>
                      <td className="p-3 text-gray-700 text-sm">{car.model}</td>
                      <td className="p-3 text-gray-600 text-xs max-w-32 truncate" title={car.modification}>{car.modification || "—"}</td>
                      <td className="p-3 text-gray-500 text-xs">{car.yearFrom}{car.yearTo ? `-${car.yearTo}` : "+"}</td>
                      <td className="p-3 text-center">
                        {v ? (
                          <button onClick={() => setSelectedVerifId(v.id)}
                            className={`text-xs px-2 py-1 rounded-full font-bold ${
                              v.overallConfidence === 100 ? "bg-green-100 text-green-700" :
                              v.overallConfidence >= 70 ? "bg-amber-100 text-amber-700" :
                              v.overallConfidence > 0 ? "bg-orange-100 text-orange-700" :
                              "bg-gray-100 text-gray-500"
                            }`}>{v.overallConfidence}%</button>
                        ) : <span className="text-xs text-gray-300">—</span>}
                      </td>
                      <td className="p-3">
                        <div className="flex gap-0.5 justify-center">
                          {Object.keys(AGENT_INFO).map((agentId) => {
                            const agent = v?.agents?.find((a: any) => a.agentId === agentId);
                            const filled = agent?.filledCount ?? 0;
                            const hasErr = agent?.error;
                            if (hasErr) return <div key={agentId} className="w-6 h-6 rounded-full bg-red-100 border border-red-300 flex items-center justify-center" title={`${AGENT_INFO[agentId].name}: ошибка`}><XCircle className="w-3 h-3 text-red-500" /></div>;
                            if (filled > 0) return <div key={agentId} className={`w-6 h-6 rounded-full ${AGENT_INFO[agentId].bg} flex items-center justify-center text-[9px] font-bold ${AGENT_INFO[agentId].color}`} title={`${AGENT_INFO[agentId].name}: ${filled} полей`}>{filled}</div>;
                            return <div key={agentId} className="w-6 h-6 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center" title={`${AGENT_INFO[agentId].name}: не запущен`}><span className="text-gray-300 text-[8px]">{AGENT_INFO[agentId].name[0]}</span></div>;
                          })}
                        </div>
                      </td>
                      <td className="p-3 text-center">
                        <button onClick={() => v ? setSelectedVerifId(v.id) : handleRunAllAgents(car)}
                          disabled={runVerif.isPending}
                          className={`p-2 rounded-lg transition-colors ${v ? "text-blue-600 hover:bg-blue-50" : "bg-purple-600 text-white hover:bg-purple-700 disabled:opacity-50"}`}
                          title={v ? "Показать результат" : "Запустить 5 агентов"}>
                          {runVerif.isPending && !v ? <Loader2 className="w-4 h-4 animate-spin" /> : v ? <ChevronRight className="w-4 h-4" /> : <Zap className="w-4 h-4" />}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {totalCarPages > 1 && (
              <div className="flex items-center justify-between p-4 border-t border-gray-200">
                <span className="text-gray-500 text-xs">Страница {carPage + 1} из {totalCarPages} | Выбрано: {selectedCars.size}</span>
                <div className="flex gap-1">
                  <button onClick={() => setCarPage(0)} disabled={carPage === 0} className="px-2 py-1 text-xs border rounded disabled:opacity-30">«</button>
                  <button onClick={() => setCarPage((p) => Math.max(0, p - 1))} disabled={carPage === 0} className="px-2 py-1 text-xs border rounded disabled:opacity-30">‹</button>
                  {Array.from({ length: Math.min(5, totalCarPages) }, (_, i) => {
                    let pg: number;
                    if (totalCarPages <= 5) pg = i;
                    else if (carPage <= 2) pg = i;
                    else if (carPage >= totalCarPages - 3) pg = totalCarPages - 5 + i;
                    else pg = carPage - 2 + i;
                    return (
                      <button key={pg} onClick={() => setCarPage(pg)} className={`px-2.5 py-1 text-xs rounded border ${carPage === pg ? "bg-purple-600 text-white border-purple-600" : "border-gray-300 hover:bg-gray-50"}`}>{pg + 1}</button>
                    );
                  })}
                  <button onClick={() => setCarPage((p) => Math.min(totalCarPages - 1, p + 1))} disabled={carPage >= totalCarPages - 1} className="px-2 py-1 text-xs border rounded disabled:opacity-30">›</button>
                  <button onClick={() => setCarPage(totalCarPages - 1)} disabled={carPage >= totalCarPages - 1} className="px-2 py-1 text-xs border rounded disabled:opacity-30">»</button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function normalizeValue(v: any): string {
  if (v === null || v === undefined) return "";
  return String(v).trim().toLowerCase().replace(/\s+/g, " ");
}
