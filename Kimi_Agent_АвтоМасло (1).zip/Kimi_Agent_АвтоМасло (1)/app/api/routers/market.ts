import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { marketCars, marketSyncLog } from "@db/schema";
import { eq, desc, and, sql } from "drizzle-orm";

export const marketRouter = createRouter({
  // ─── Stats ───
  stats: adminQuery.query(async () => {
    const { getMarketStats } = await import("../agents/dromParser");
    return getMarketStats();
  }),

  // ─── Scan drom.ru catalog ───
  scan: adminQuery
    .input(z.object({
      brandLimit: z.number().optional(),
      modelLimit: z.number().optional(),
    }).optional())
    .mutation(async ({ input }) => {
      const db = getDb();
      const { scanDromCatalog } = await import("../agents/dromParser");

      // 1. Create sync log entry FIRST to get the ID
      const [syncLog] = await db.insert(marketSyncLog).values({
        source: "drom.ru",
        status: "running",
      }).$returningId();
      const syncId = syncLog.id;

      // 2. For test mode (small limit) — wait for result
      // For full scan — fire and forget
      const isTest = (input?.brandLimit || 0) > 0;

      if (isTest) {
        // Test mode: run synchronously and return results
        try {
          const result = await scanDromCatalog({
            brandLimit: input?.brandLimit,
            modelLimit: input?.modelLimit,
            syncId,
            onProgress: (msg) => console.log(`[MarketScan] ${msg}`),
          });
          return {
            started: true,
            syncId,
            ...result,
            message: `Найдено ${result.totalFound}, новых ${result.totalNew}`,
          };
        } catch (e: any) {
          await db.update(marketSyncLog)
            .set({ status: "failed", error: e.message, completedAt: new Date() })
            .where(eq(marketSyncLog.id, syncId));
          throw new Error(`Ошибка сканирования: ${e.message}`);
        }
      }

      // 3. Full scan: fire and forget
      scanDromCatalog({
        brandLimit: input?.brandLimit,
        modelLimit: input?.modelLimit,
        syncId,
        onProgress: (msg) => console.log(`[MarketScan] ${msg}`),
      }).catch(async (e) => {
        console.error("[MarketScan] Failed:", e.message);
        await db.update(marketSyncLog)
          .set({ status: "failed", error: e.message, completedAt: new Date() })
          .where(eq(marketSyncLog.id, syncId));
      });

      return {
        started: true,
        syncId,
        message: "Сканирование drom.ru запущено в фоне",
      };
    }),

  // ─── Get scan progress ───
  scanStatus: adminQuery
    .input(z.object({ syncId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [log] = await db.select().from(marketSyncLog).where(eq(marketSyncLog.id, input.syncId)).limit(1);
      return log || null;
    }),

  // ─── List market cars ───
  list: adminQuery
    .input(z.object({
      status: z.string().optional(),
      make: z.string().optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input?.status) conditions.push(eq(marketCars.status, input.status as any));
      if (input?.make) conditions.push(sql`LOWER(${marketCars.make}) = LOWER(${input.make})`);

      const where = conditions.length > 0 ? and(...conditions) : undefined;

      const items = await db
        .select()
        .from(marketCars)
        .where(where)
        .orderBy(desc(marketCars.foundAt))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);

      const countResult = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(marketCars)
        .where(where);

      return { items, total: Number(countResult[0]?.count || 0) };
    }),

  // ─── Approve market car → add to DB ───
  approve: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const { approveMarketCar } = await import("../agents/dromParser");
      const userId = ctx.user?.id;
      return approveMarketCar(input.id, userId);
    }),

  // ─── Reject market car ───
  reject: adminQuery
    .input(z.object({ id: z.number(), notes: z.string().optional() }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      await db.update(marketCars)
        .set({
          status: "rejected",
          reviewedBy: ctx.user?.id,
          reviewedAt: new Date(),
          notes: input.notes,
        })
        .where(eq(marketCars.id, input.id));
      return { ok: true };
    }),

  // ─── Sync log history ───
  syncHistory: adminQuery
    .input(z.object({ limit: z.number().default(20) }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(marketSyncLog).orderBy(desc(marketSyncLog.startedAt)).limit(input?.limit || 20);
    }),

  // ─── Get unique makes from market cars ───
  getMakes: adminQuery.query(async () => {
    const db = getDb();
    const result = await db
      .selectDistinct({ make: marketCars.make })
      .from(marketCars)
      .orderBy(marketCars.make);
    return result.map((r) => r.make);
  }),
});
