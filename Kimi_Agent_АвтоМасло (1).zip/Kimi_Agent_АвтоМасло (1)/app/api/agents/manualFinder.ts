/**
 * AI Agent: Smart Owner Manual Finder + PDF Parser
 * Ищет РЕАЛЬНЫЕ PDF руководства по эксплуатации для КОНКРЕТНОЙ модификации
 * Скачивает PDF, извлекает текст, парсит данные по маслам/жидкостям
 * 
 * Usage:
 * npx tsx api/agents/manualFinder.ts --make=BMW --model=X5 --year=2015 --engine=N55
 */

import { getDb } from "../queries/connection";
import { ownerManuals, aiTasks, carFluidSpecs } from "@db/schema";
import { eq, and, like, sql } from "drizzle-orm";
import { env } from "../lib/env";
import * as fs from "fs";
import * as path from "path";

// ─── Types ───
interface ManualPayload {
  make: string;
  model: string;
  year?: number;
  generation?: string;
  modification?: string;
  engineCode?: string;
  transmissionType?: string;
}

interface ManualResult {
  title: string;
  pdfUrl: string;
  pdfOriginalUrl: string;
  source: string;
  language: string;
  isOfficial: "yes" | "no";
  pdfSize?: string;
  pdfPages?: number;
  yearFrom?: number;
  yearTo?: number;
  modification?: string;
  engineCode?: string;
  filePath?: string;
  extractedData?: Record<string, string>;
}

const PDF_DIR = path.join(process.cwd(), "uploads", "manuals");

// Ensure PDF directory exists
if (!fs.existsSync(PDF_DIR)) {
  fs.mkdirSync(PDF_DIR, { recursive: true });
}

// ─── Build precise search queries for the exact modification ───
function buildSearchQueries(payload: ManualPayload): string[] {
  const { make, model, year, engineCode, modification, transmissionType } = payload;
  const queries: string[] = [];

  // Query 1: Exact modification search with PDF requirement
  const modParts: string[] = [make, model];
  if (modification) modParts.push(modification);
  if (engineCode) modParts.push(engineCode);
  if (year) modParts.push(String(year));
  queries.push(`${modParts.join(" ")} owner manual filetype:pdf`);
  queries.push(`${modParts.join(" ")} service manual pdf download`);

  // Query 2: Russian search
  queries.push(`${make} ${model} ${engineCode || ""} руководство по эксплуатации pdf`);
  queries.push(`${make} ${model} руководство по техническому обслуживанию pdf скачать`);

  // Query 3: Specific to engine/transmission
  if (engineCode) {
    queries.push(`${make} ${model} ${engineCode} engine oil capacity specification pdf`);
    queries.push(`${make} ${model} ${engineCode} werkstatthandbuch pdf`);
  }

  // Query 4: Manufacturer-specific
  queries.push(`site:${make.toLowerCase()}.com ${model} owner manual pdf`);
  queries.push(`site:${make.toLowerCase()}-publications.com ${model} pdf`);

  // Query 5: Direct manual sites
  queries.push(`${make} ${model} ${year || ""} owners-manual.com pdf`);
  queries.push(`${make} ${model} ${year || ""} onlymanuals.com pdf`);

  return queries.filter((q) => q.trim().length > 0);
}

// ─── AI-powered real URL discovery via search APIs ───
async function discoverRealUrls(payload: ManualPayload): Promise<ManualResult[]> {
  const results: ManualResult[] = [];
  const { make, model, year, engineCode, modification } = payload;
  const seenUrls = new Set<string>();

  // Strategy 1: Perplexity search (best for real-time web search)
  if (env.perplexityApiKey) {
    try {
      const searchQuery = buildSearchQueries(payload).slice(0, 3).join(" OR ");
      const response = await fetch("https://api.perplexity.ai/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${env.perplexityApiKey}`,
        },
        body: JSON.stringify({
          model: "sonar",
          messages: [
            {
              role: "system",
              content: "You are a research assistant. Find direct PDF download links for car owner/service manuals. Return only valid URLs that point to .pdf files."
            },
            {
              role: "user",
              content: `Find direct PDF download links for ${make} ${model}${modification ? ` ${modification}` : ""}${engineCode ? ` engine ${engineCode}` : ""}${year ? ` ${year}` : ""} owner manual or service manual. 
Search for filetype:pdf. Return ONLY a JSON array like [{"title":"...","url":"https://...pdf","source":"site.com","language":"ru|en","isOfficial":"yes|no"}]. No markdown.`
            }
          ],
          max_tokens: 2000,
        }),
        signal: (() => { const c = new AbortController(); setTimeout(() => c.abort(), 30000); return c.signal; })(),
      });

      if (response.ok) {
        const data = await response.json();
        const text = data.choices?.[0]?.message?.content || "";
        const jsonMatch = text.match(/\[[\s\S]*?\]/);
        if (jsonMatch) {
          const items = JSON.parse(jsonMatch[0]);
          for (const item of items) {
            if (item.url && item.url.includes(".pdf") && !seenUrls.has(item.url)) {
              seenUrls.add(item.url);
              results.push({
                title: item.title || `${make} ${model} Manual`,
                pdfUrl: item.url,
                pdfOriginalUrl: item.url,
                source: item.source || "Perplexity",
                language: item.language || "en",
                isOfficial: item.isOfficial === "yes" ? "yes" : "no",
                modification: payload.modification,
                engineCode: payload.engineCode,
              });
            }
          }
        }
        // Also extract citations
        if (data.citations) {
          for (const cite of data.citations) {
            if (cite.includes(".pdf") && !seenUrls.has(cite)) {
              seenUrls.add(cite);
              results.push({
                title: `${make} ${model} Manual`,
                pdfUrl: cite,
                pdfOriginalUrl: cite,
                source: new URL(cite).hostname,
                language: "en",
                isOfficial: "no",
                modification: payload.modification,
                engineCode: payload.engineCode,
              });
            }
          }
        }
      }
    } catch (e: any) {
      console.error("[ManualFinder] Perplexity error:", e.message);
    }
  }

  // Strategy 2: Anthropic search
  if (results.length < 3 && env.anthropicApiKey) {
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": env.anthropicApiKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-3-haiku-20240307",
          max_tokens: 2000,
          messages: [{
            role: "user",
            content: `Find REAL working PDF download URLs for ${make} ${model}${engineCode ? ` engine ${engineCode}` : ""}${year ? ` ${year}` : ""} owner manual or workshop manual. 
Only return URLs ending in .pdf that are likely to work. Format: JSON array [{"title":"...","url":"...","source":"...","language":"ru|en"}]`
          }],
        }),
        signal: (() => { const c = new AbortController(); setTimeout(() => c.abort(), 25000); return c.signal; })(),
      });

      if (response.ok) {
        const data = await response.json();
        const text = data.content?.[0]?.text || "";
        const jsonMatch = text.match(/\[[\s\S]*?\]/);
        if (jsonMatch) {
          const items = JSON.parse(jsonMatch[0]);
          for (const item of items) {
            if (item.url && !seenUrls.has(item.url)) {
              seenUrls.add(item.url);
              results.push({
                title: item.title || `${make} ${model} Manual`,
                pdfUrl: item.url,
                pdfOriginalUrl: item.url,
                source: item.source || "AI Search",
                language: item.language || "en",
                isOfficial: "no",
                modification: payload.modification,
                engineCode: payload.engineCode,
              });
            }
          }
        }
      }
    } catch (e: any) {
      console.error("[ManualFinder] Anthropic error:", e.message);
    }
  }

  // Strategy 3: Google Programmable Search if API key available
  if (results.length < 2 && env.googleSearchApiKey && env.googleSearchEngineId) {
    try {
      const query = `${make} ${model}${engineCode ? ` "${engineCode}"` : ""} owner manual filetype:pdf`;
      const url = `https://www.googleapis.com/customsearch/v1?key=${env.googleSearchApiKey}&cx=${env.googleSearchEngineId}&q=${encodeURIComponent(query)}&num=5`;
      const response = await fetch(url, { signal: (() => { const c = new AbortController(); setTimeout(() => c.abort(), 20000); return c.signal; })() });

      if (response.ok) {
        const data = await response.json();
        for (const item of data.items || []) {
          const pdfUrl = item.link;
          if (pdfUrl && pdfUrl.includes(".pdf") && !seenUrls.has(pdfUrl)) {
            seenUrls.add(pdfUrl);
            results.push({
              title: item.title || `${make} ${model} Manual`,
              pdfUrl,
              pdfOriginalUrl: pdfUrl,
              source: new URL(pdfUrl).hostname,
              language: item.title?.match(/[а-яА-Я]/) ? "ru" : "en",
              isOfficial: "no",
              modification: payload.modification,
              engineCode: payload.engineCode,
            });
          }
        }
      }
    } catch (e: any) {
      console.error("[ManualFinder] Google search error:", e.message);
    }
  }

  // Strategy 4: Direct manufacturer URLs (always add, will be verified later)
  const manufacturerUrls = getManufacturerUrls(make, model, year);
  for (const murl of manufacturerUrls) {
    if (!seenUrls.has(murl.url)) {
      seenUrls.add(murl.url);
      results.push({
        ...murl,
        modification: payload.modification,
        engineCode: payload.engineCode,
      });
    }
  }

  return results;
}

// ─── Get manufacturer-specific manual URLs ───
function getManufacturerUrls(make: string, model: string, year?: number): ManualResult[] {
  const m = make.toLowerCase();
  const modSlug = model.toLowerCase().replace(/\s+/g, "-");
  const yearStr = year ? `-${year}` : "";
  const urls: ManualResult[] = [];

  const add = (title: string, url: string, source: string, lang: string, official: "yes" | "no") => {
    urls.push({ title, pdfUrl: url, pdfOriginalUrl: url, source, language: lang, isOfficial: official });
  };

  if (m === "volkswagen" || m === "vw") {
    add(`${make} ${model} Owner Manual`, `https://www.vw.com/en/owners/manuals.html`, "vw.com", "en", "yes");
    add(`${make} ${model} Werkstatthandbuch`, `https://www.volkswagen-commercial.com/en/service/manuals.html`, "volkswagen.com", "de", "yes");
  } else if (m === "bmw") {
    add(`${make} ${model} Owner's Manual`, `https://www.bmw.com/en/services/manuals/${modSlug}.html`, "bmw.com", "en", "yes");
    add(`${make} ${model} Werkstatthandbuch`, `https://www.bmw-grouparchiv.de/`, "bmw-grouparchiv.de", "de", "yes");
  } else if (m === "mercedes" || m === "mercedes-benz") {
    add(`${make} ${model} Betriebsanleitung`, `https://www.mercedes-benz.com/en/owners/manuals/`, "mercedes-benz.com", "en", "yes");
  } else if (m === "audi") {
    add(`${make} ${model} Owner Manual`, `https://www.audi.com/en/service-and-accessories/owner-s-manual.html`, "audi.com", "en", "yes");
  } else if (m === "toyota") {
    add(`${make} ${model} Owner Manual`, `https://www.toyota.com/owners/manuals/`, "toyota.com", "en", "yes");
  } else if (m === "ford") {
    add(`${make} ${model} Owner Manual`, `https://www.ford.com/support/owner-manuals/`, "ford.com", "en", "yes");
  }

  // Generic manual sites
  add(`${make} ${model} Manual - carmanuals.org`, `https://carmanuals.org/${m}/${modSlug}${yearStr}/`, "carmanuals.org", "ru", "no");
  add(`${make} ${model} Manual - manuals.co`, `https://www.manuals.co/${m}/${modSlug}/owner-manual`, "manuals.co", "en", "no");

  return urls;
}

// ─── Verify and download PDF ───
async function verifyAndDownloadPdf(result: ManualResult, make: string, model: string): Promise<ManualResult | null> {
  try {
    // HEAD request to check if URL works
    const headRes = await fetch(result.pdfUrl, {
      method: "HEAD",
      redirect: "follow",
      signal: (() => { const c = new AbortController(); setTimeout(() => c.abort(), 15000); return c.signal; })(),
    });

    if (!headRes.ok) {
      // Try GET instead of HEAD (some servers don't support HEAD)
      const getRes = await fetch(result.pdfUrl, {
        method: "GET",
        redirect: "follow",
        signal: (() => { const c = new AbortController(); setTimeout(() => c.abort(), 15000); return c.signal; })(),
      });
      if (!getRes.ok) return null;
    }

    const contentType = headRes.headers.get("content-type") || "";
    const contentLength = headRes.headers.get("content-length");

    // Check if it's actually a PDF
    const isPdf = contentType.includes("pdf") || contentType.includes("octet-stream") || result.pdfUrl.endsWith(".pdf");

    if (isPdf && contentLength && parseInt(contentLength) > 1000) {
      // Try to download the PDF
      const safeMake = make.replace(/[^a-zA-Z0-9]/g, "_");
      const safeModel = model.replace(/[^a-zA-Z0-9]/g, "_");
      const safeEngine = result.engineCode ? `_${result.engineCode}` : "";
      const filename = `${safeMake}_${safeModel}${safeEngine}_${Date.now()}.pdf`;
      const filePath = path.join(PDF_DIR, filename);

      // Download PDF
      const downloadRes = await fetch(result.pdfUrl, {
        redirect: "follow",
        signal: (() => { const c = new AbortController(); setTimeout(() => c.abort(), 30000); return c.signal; })(),
      });

      if (downloadRes.ok) {
        const buffer = Buffer.from(await downloadRes.arrayBuffer());
        if (buffer.length > 1000) {
          fs.writeFileSync(filePath, buffer);

          // Parse PDF size
          const sizeMB = (buffer.length / (1024 * 1024)).toFixed(1);

          return {
            ...result,
            pdfSize: `${sizeMB} MB`,
            filePath: `/uploads/manuals/${filename}`,
          };
        }
      }
    }

    // URL works but we couldn't download — still keep it
    return result;
  } catch (e: any) {
    console.error(`[ManualFinder] Verify failed for ${result.pdfUrl}:`, e.message);
    return null;
  }
}

// ─── Extract text from PDF using AI ───
async function extractDataFromPdf(filePath: string, payload: ManualPayload): Promise<Record<string, string>> {
  const extracted: Record<string, string> = {};

  try {
    // Read PDF as base64
    const buffer = fs.readFileSync(filePath);
    const base64 = buffer.toString("base64").substring(0, 50000); // First 50KB for analysis

    if (!env.anthropicApiKey) return extracted;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": env.anthropicApiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-3-haiku-20240307",
        max_tokens: 3000,
        messages: [{
          role: "user",
          content: `You are parsing a car owner/service manual PDF. Extract the following technical data:

Car: ${payload.make} ${payload.model}${payload.engineCode ? ` engine ${payload.engineCode}` : ""}${payload.year ? ` year ${payload.year}` : ""}

Extract these fields and return ONLY as JSON:
{
  "engineFillVolume": "oil capacity in liters (e.g. 7.5)",
  "prefOilSae": "recommended SAE grade (e.g. 5W-30)",
  "prefOilApi": "API specification (e.g. SN/CF)",
  "prefOilAcea": "ACEA specification (e.g. C3)",
  "prefOilOe": "OEM approval (e.g. VW 507.00)",
  "engineReplaceInterval": "oil change interval in km (e.g. 15000)",
  "coolantFillVolume": "coolant capacity in liters",
  "coolantType": "coolant type (e.g. G12, G13)",
  "transmissionFillVolume": "transmission oil capacity",
  "transmissionPrefOil": "transmission oil specification",
  "brakeFluidType": "brake fluid type (e.g. DOT4)",
  "transferCaseOil": "transfer case oil spec",
  "transferCaseFillVolume": "transfer case oil capacity",
  "frontDiffOil": "front diff oil spec",
  "frontDiffFillVolume": "front diff oil capacity",
  "rearDiffOil": "rear diff oil spec",
  "rearDiffFillVolume": "rear diff oil capacity",
  "psFluidType": "power steering fluid type",
  "adblueVolume": "AdBlue tank volume"
}

If a field is not found, use empty string. Be precise with numbers and specifications.`,
        }],
      }),
      signal: (() => { const c = new AbortController(); setTimeout(() => c.abort(), 45000); return c.signal; })(),
    });

    if (response.ok) {
      const data = await response.json();
      const text = data.content?.[0]?.text || "";
      const jsonMatch = text.match(/\{[\s\S]*?\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        Object.entries(parsed).forEach(([key, val]) => {
          if (val && String(val).trim()) extracted[key] = String(val).trim();
        });
      }
    }
  } catch (e: any) {
    console.error("[ManualFinder] PDF extraction error:", e.message);
  }

  return extracted;
}

// ─── Save results to database ───
async function saveResults(payload: ManualPayload, results: ManualResult[]) {
  const db = getDb();
  const saved = [];

  for (const result of results) {
    try {
      const [inserted] = await db.insert(ownerManuals).values({
        make: payload.make,
        model: payload.model,
        yearFrom: result.yearFrom || payload.year || undefined,
        yearTo: result.yearTo || undefined,
        modification: result.modification || payload.modification || undefined,
        title: result.title,
        pdfUrl: result.pdfUrl,
        pdfOriginalUrl: result.pdfOriginalUrl,
        pdfSize: result.pdfSize || undefined,
        pdfPages: result.pdfPages || undefined,
        source: result.source,
        language: result.language,
        isOfficial: result.isOfficial,
        isActive: "active",
      }).$returningId();
      saved.push({ id: inserted.id, ...result });

      // If we extracted data from PDF, save to carFluidSpecs
      if (result.extractedData && Object.keys(result.extractedData).length > 0) {
        await saveExtractedData(payload, result.extractedData);
      }
    } catch (e: any) {
      console.error("[ManualFinder] Save error:", e.message);
    }
  }

  return saved;
}

// ─── Save extracted PDF data to carFluidSpecs ───
async function saveExtractedData(payload: ManualPayload, data: Record<string, string>) {
  try {
    const db = getDb();

    // Check if carFluidSpecs record exists
    const existing = await db
      .select()
      .from(carFluidSpecs)
      .where(
        and(
          sql`${carFluidSpecs.make} LIKE ${"%" + payload.make + "%"}`,
          sql`${carFluidSpecs.model} LIKE ${"%" + payload.model + "%"}`,
        )
      )
      .limit(1);

    if (existing.length > 0) {
      // Merge new data with existing
      const updateData: Record<string, any> = {};
      Object.entries(data).forEach(([key, val]) => {
        if (val && !existing[0][key as keyof typeof existing[0]]) {
          updateData[key] = val;
        }
      });

      if (Object.keys(updateData).length > 0) {
        await db.update(carFluidSpecs)
          .set({ ...updateData, updatedAt: new Date() })
          .where(eq(carFluidSpecs.id, existing[0].id));
        console.log("[ManualFinder] Updated carFluidSpecs with", Object.keys(updateData).join(", "));
      }
    } else {
      // Create new record
      await db.insert(carFluidSpecs).values({
        make: payload.make,
        model: payload.model,
        modification: payload.modification,
        engineCode: payload.engineCode,
        ...data,
      });
      console.log("[ManualFinder] Created new carFluidSpecs record");
    }
  } catch (e: any) {
    console.error("[ManualFinder] saveExtractedData error:", e.message);
  }
}

// ─── Main function ───
export async function runManualFinder(payload: ManualPayload, taskId?: number) {
  console.log("[ManualFinder] Searching for:", payload);
  const startTime = Date.now();

  try {
    // 1. Discover real URLs
    const results = await discoverRealUrls(payload);
    console.log(`[ManualFinder] Discovered ${results.length} potential URLs`);

    if (results.length === 0) {
      return { success: false, error: "No URLs found", found: 0, saved: 0 };
    }

    // 2. Verify and download each PDF
    const verifiedResults: ManualResult[] = [];
    for (const result of results) {
      const verified = await verifyAndDownloadPdf(result, payload.make, payload.model);
      if (verified) {
        // 3. If PDF downloaded, try to extract data
        if (verified.filePath) {
          const localPath = path.join(process.cwd(), verified.filePath);
          if (fs.existsSync(localPath)) {
            const extracted = await extractDataFromPdf(localPath, payload);
            verified.extractedData = extracted;
            console.log(`[ManualFinder] Extracted ${Object.keys(extracted).length} fields from PDF`);
          }
        }
        verifiedResults.push(verified);
      }
      // Small delay between requests
      await new Promise((r) => setTimeout(r, 500));
    }

    console.log(`[ManualFinder] Verified ${verifiedResults.length} URLs`);

    // 4. Save to database
    const saved = await saveResults(payload, verifiedResults);

    // 5. Update task
    if (taskId) {
      const db = getDb();
      await db.update(aiTasks).set({
        status: "completed",
        result: JSON.stringify({ found: results.length, verified: verifiedResults.length, saved: saved.length }),
        completedAt: new Date(),
        itemsProcessed: saved.length,
      }).where(eq(aiTasks.id, taskId));
    }

    const duration = Date.now() - startTime;
    const totalExtracted = verifiedResults.reduce((sum, r) => sum + (r.extractedData ? Object.keys(r.extractedData).length : 0), 0);

    return {
      success: true,
      found: results.length,
      verified: verifiedResults.length,
      saved: saved.length,
      items: saved,
      extractedFields: totalExtracted,
      duration,
    };
  } catch (e: any) {
    console.error("[ManualFinder] Error:", e.message);

    if (taskId) {
      const db = getDb();
      await db.update(aiTasks).set({
        status: "failed",
        errorMessage: e.message,
        completedAt: new Date(),
      }).where(eq(aiTasks.id, taskId));
    }

    return { success: false, error: e.message };
  }
}

// ─── Batch: process cars that have no manuals ───
export async function runBatchManualFinder(options: { limit?: number; make?: string; model?: string } = {}) {
  const db = getDb();
  const limit = options.limit || 10;

  // Get cars from database that don't have verified manuals
  let cars;
  if (options.make && options.model) {
    // Specific car
    cars = [{ make: options.make, model: options.model, engineCode: undefined, modification: undefined }];
  } else {
    // Get from TOcars
    cars = await db
      .selectDistinct({
        make: sql<string>`make`,
        model: sql<string>`model`,
        engineCode: sql<string>`engine_code`,
        modification: sql<string>`name`,
      })
      .from(sql`TOcars`)
      .limit(limit);
  }

  const results = [];
  for (const car of cars) {
    const res = await runManualFinder({
      make: car.make || "",
      model: car.model || "",
      engineCode: car.engineCode || undefined,
      modification: car.modification || undefined,
    });
    results.push({ make: car.make, model: car.model, ...res });
    await new Promise((r) => setTimeout(r, 2000));
  }

  return { processed: results.length, results };
}

// ─── CLI ───
if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  const make = args.find((a) => a.startsWith("--make="))?.split("=")[1];
  const model = args.find((a) => a.startsWith("--model="))?.split("=")[1];
  const year = args.find((a) => a.startsWith("--year="))?.split("=")[1];
  const engine = args.find((a) => a.startsWith("--engine="))?.split("=")[1];
  const limit = args.find((a) => a.startsWith("--limit="))?.split("=")[1];

  if (make && model) {
    runManualFinder({ make, model, year: year ? parseInt(year) : undefined, engineCode: engine })
      .then((r) => { console.log(JSON.stringify(r, null, 2)); process.exit(0); })
      .catch((e) => { console.error(e); process.exit(1); });
  } else if (limit) {
    runBatchManualFinder({ limit: parseInt(limit) })
      .then((r) => { console.log(JSON.stringify(r, null, 2)); process.exit(0); })
      .catch((e) => { console.error(e); process.exit(1); });
  } else {
    console.log(`
Usage:
  Single:  npx tsx api/agents/manualFinder.ts --make=VW --model="TOUAREG" --year=2020 --engine=CASA
  Batch:   npx tsx api/agents/manualFinder.ts --limit=10
`);
    process.exit(1);
  }
}
