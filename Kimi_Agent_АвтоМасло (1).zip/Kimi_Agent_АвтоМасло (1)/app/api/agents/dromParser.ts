/**
 * Drom.ru Catalog Parser
 * Scans drom.ru/catalog for new/updated cars and syncs with our database
 * 
 * Strategy:
 * 1. Fetch brand list from drom.ru
 * 2. For each brand → fetch model list
 * 3. For each model → fetch generations
 * 4. For each generation → fetch modifications (engine, transmission, specs)
 * 5. Compare with our DB → flag new/updated cars
 */

import { getDb } from "../queries/connection";
import { marketCars, marketSyncLog, cars } from "@db/schema";
import { eq, and, like, sql } from "drizzle-orm";

interface DromCar {
  make: string;
  model: string;
  generation?: string;
  modification?: string;
  yearFrom?: number;
  yearTo?: number;
  engineCode?: string;
  engineCapacity?: string;
  enginePower?: string;
  fuel?: string;
  transmission?: string;
  body?: string;
  sourceUrl?: string;
}

// ─── Fetch with retry and delay ───
async function fetchWithDelay(url: string, retries = 2): Promise<string> {
  for (let i = 0; i <= retries; i++) {
    try {
      console.log(`[DromParser] Fetching: ${url} (attempt ${i + 1})`);
      const resp = await fetch(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
          "Accept-Encoding": "gzip, deflate, br",
          "Cache-Control": "no-cache",
        },
        redirect: "follow",
        signal: (() => { const c = new AbortController(); setTimeout(() => c.abort(), 20000); return c.signal; })(),
      });
      console.log(`[DromParser] Response: ${resp.status} ${resp.statusText} for ${url}`);
      if (resp.ok) {
        const text = await resp.text();
        console.log(`[DromParser] Got ${text.length} bytes from ${url}`);
        if (text.length < 100) {
          console.warn(`[DromParser] Response too short (${text.length} chars): ${text.substring(0, 200)}`);
          if (i < retries) {
            await new Promise((r) => setTimeout(r, 2000 * (i + 1)));
            continue;
          }
        }
        return text;
      }
      if (resp.status === 429 || resp.status === 503) {
        console.warn(`[DromParser] Rate limited, waiting...`);
        await new Promise((r) => setTimeout(r, 5000 * (i + 1)));
        continue;
      }
      throw new Error(`HTTP ${resp.status}: ${resp.statusText}`);
    } catch (e: any) {
      console.error(`[DromParser] Attempt ${i + 1} failed for ${url}: ${e.message}`);
      if (i === retries) throw e;
      await new Promise((r) => setTimeout(r, 2000 * (i + 1)));
    }
  }
  throw new Error(`All retries failed for ${url}`);
}

// ─── Parse brand list from drom.ru/catalog ───
export async function fetchDromBrands(): Promise<Array<{ name: string; slug: string; url: string }>> {
  const html = await fetchWithDelay("https://www.drom.ru/catalog/");
  const brands: Array<{ name: string; slug: string; url: string }> = [];
  const seen = new Set<string>();

  // Method 1: Parse brand links from catalog grid
  // drom.ru uses structure like: <a href="/catalog/audi/">Audi</a>
  const linkRegex = /href="\/catalog\/([^\/"]+)\/"[^>]*>([^<]+)<\/a>/gi;
  let match;
  while ((match = linkRegex.exec(html)) !== null) {
    const slug = match[1].toLowerCase();
    const name = match[2].trim();
    if (!seen.has(slug) && name.length > 1 && !slug.match(/\.(js|css|png|jpg)/)) {
      seen.add(slug);
      brands.push({ name, slug, url: `https://www.drom.ru/catalog/${slug}/` });
    }
  }

  // Method 2: Parse from JSON data embedded in page
  if (brands.length === 0) {
    const jsonMatch = html.match(/window\.__INITIAL_STATE__\s*=\s*(\{.+?\});?<\/script>/s);
    if (jsonMatch) {
      try {
        const data = JSON.parse(jsonMatch[1]);
        const brandList = data?.entities?.brands || data?.brands || data?.catalog?.brands || [];
        if (Array.isArray(brandList)) {
          brandList.forEach((b: any) => {
            const slug = b.slug || b.code || b.id;
            if (slug && !seen.has(slug)) {
              seen.add(slug);
              brands.push({
                name: b.name || b.title || b.russianName || b.cyrillicName || slug,
                slug,
                url: `https://www.drom.ru/catalog/${slug}/`,
              });
            }
          });
        }
      } catch (e) {
        console.error("[DromParser] JSON parse error:", (e as Error).message);
      }
    }
  }

  // Method 3: Parse from any /catalog/XXXX/ pattern in the HTML
  if (brands.length === 0) {
    const allMatches = html.matchAll(/\/catalog\/([a-z0-9_-]+)\//gi);
    for (const m of allMatches) {
      const slug = m[1].toLowerCase();
      if (!seen.has(slug) && slug.length > 1 && !['js', 'css', 'img', 'api'].includes(slug)) {
        // Try to find name near the link
        const nameMatch = html.match(new RegExp(`href="/catalog/${slug}/"[^>]*>([^<]+)<`, 'i'));
        const name = nameMatch ? nameMatch[1].trim() : slug;
        if (name.length > 1) {
          seen.add(slug);
          brands.push({ name, slug, url: `https://www.drom.ru/catalog/${slug}/` });
        }
      }
    }
  }

  console.log(`[DromParser] Found ${brands.length} brands`);
  if (brands.length > 0) {
    console.log(`[DromParser] First 5 brands: ${brands.slice(0, 5).map(b => b.name).join(', ')}`);
  } else {
    console.warn("[DromParser] No brands found! HTML preview:", html.substring(0, 500));
  }

  return brands;
}

// ─── Parse models for a brand ───
export async function fetchDromModels(brandSlug: string): Promise<Array<{ name: string; slug: string; url: string }>> {
  const html = await fetchWithDelay(`https://www.drom.ru/catalog/${brandSlug}/`);
  const models: Array<{ name: string; slug: string; url: string }> = [];
  const seen = new Set<string>();

  // Parse model links: /catalog/{brand}/{model}/
  const regex = new RegExp(`<a[^>]*href="/catalog/${brandSlug}/([^/"]+)/"[^>]*>([^<]+)</a>`, "g");
  let match;

  while ((match = regex.exec(html)) !== null) {
    const slug = match[1];
    const name = match[2].trim();
    if (!seen.has(slug) && name.length > 1) {
      seen.add(slug);
      models.push({ name, slug, url: `https://www.drom.ru/catalog/${brandSlug}/${slug}/` });
    }
  }

  return models;
}

// ─── Parse generations for a model ───
export async function fetchDromGenerations(brandSlug: string, modelSlug: string): Promise<Array<{ name: string; years: string; url: string }>> {
  const html = await fetchWithDelay(`https://www.drom.ru/catalog/${brandSlug}/${modelSlug}/`);
  const generations: Array<{ name: string; years: string; url: string }> = [];

  // Parse generation cards
  const regex = /<a[^>]*href="\/catalog\/[^"]+\/[^"]+\/([^"]+)\/"[^>]*>\s*<[^>]*>\s*([^<]+(?:поколение|рестайлинг)?)\s*<[^>]*>\s*(?:<[^>]*>\s*(\d{4}[\s\-–]+\d{4}?)\s*<\/[^>]*>)?/gi;
  let match;

  while ((match = regex.exec(html)) !== null) {
    const name = (match[2] || "").trim();
    const years = (match[3] || "").trim();
    if (name.length > 1) {
      generations.push({ name, years, url: `https://www.drom.ru/catalog/${brandSlug}/${modelSlug}/` });
    }
  }

  // If no generations found, treat the model page itself as the only generation
  if (generations.length === 0) {
    const titleMatch = html.match(/<title>([^<]+)<\/title>/);
    if (titleMatch) {
      const title = titleMatch[1].replace("каталог", "").replace("— Дром", "").trim();
      generations.push({ name: title, years: "", url: `https://www.drom.ru/catalog/${brandSlug}/${modelSlug}/` });
    }
  }

  return generations;
}

// ─── Full scan: iterate all brands/models ───
export async function scanDromCatalog(options: {
  brandLimit?: number;
  modelLimit?: number;
  syncId?: number;
  onProgress?: (msg: string) => void;
} = {}) {
  const db = getDb();
  const startTime = Date.now();
  const brandLimit = options.brandLimit || 0;
  const modelLimit = options.modelLimit || 0;

  // Use provided syncId or create new
  let syncId = options.syncId || 0;
  if (!syncId) {
    const [syncLog] = await db.insert(marketSyncLog).values({
      source: "drom.ru",
      status: "running",
    }).$returningId();
    syncId = syncLog.id;
  }

  try {
    options.onProgress?.("Получаем список марок с drom.ru...");
    let brands: Array<{ name: string; slug: string; url: string }> = [];
    try {
      brands = await fetchDromBrands();
    } catch (e: any) {
      options.onProgress?.(`Ошибка получения марок: ${e.message}`);
      // Update sync log as failed
      await db.update(marketSyncLog)
        .set({ status: "failed", error: `fetchDromBrands: ${e.message}`, completedAt: new Date() })
        .where(eq(marketSyncLog.id, syncId));
      return { syncId, totalFound: 0, totalNew: 0, duration: Math.round((Date.now() - startTime) / 1000) };
    }

    options.onProgress?.(`Найдено ${brands.length} марок`);

    if (brands.length === 0) {
      options.onProgress?.("Марки не найдены. Возможно drom.ru заблокировал доступ.");
      await db.update(marketSyncLog)
        .set({ status: "completed", carsFound: 0, carsNew: 0, completedAt: new Date() })
        .where(eq(marketSyncLog.id, syncId));
      return { syncId, totalFound: 0, totalNew: 0, duration: Math.round((Date.now() - startTime) / 1000) };
    }

    let totalFound = 0;
    let totalNew = 0;
    const scannedBrands = brandLimit > 0 ? brands.slice(0, brandLimit) : brands;

    for (let bi = 0; bi < scannedBrands.length; bi++) {
      const brand = scannedBrands[bi];
      options.onProgress?.(`[${bi + 1}/${scannedBrands.length}] ${brand.name} — получаем модели...`);

      try {
        const models = await fetchDromModels(brand.slug);
        const scannedModels = modelLimit > 0 ? models.slice(0, modelLimit) : models;

        for (const model of scannedModels) {
          try {
            // Check if we already have this make+model
            const existing = await db
              .select({ count: sql<number>`COUNT(*)` })
              .from(cars)
              .where(
                and(
                  sql`LOWER(${cars.make}) = LOWER(${brand.name})`,
                  sql`LOWER(${cars.model}) = LOWER(${model.name})`,
                )
              );

            const exists = Number(existing[0]?.count || 0) > 0;

            // Check if already in marketCars
            const existingMarket = await db
              .select()
              .from(marketCars)
              .where(
                and(
                  eq(marketCars.source, "drom.ru"),
                  sql`LOWER(${marketCars.make}) = LOWER(${brand.name})`,
                  sql`LOWER(${marketCars.model}) = LOWER(${model.name})`,
                )
              )
              .limit(1);

            if (existingMarket.length === 0) {
              // New car found on drom.ru
              await db.insert(marketCars).values({
                source: "drom.ru",
                sourceUrl: model.url,
                make: brand.name,
                model: model.name,
                status: exists ? "merged" : "new",
                matchedCarId: exists ? undefined : undefined,
              });
              totalNew++;
            }

            totalFound++;

            // Small delay to be polite
            await new Promise((r) => setTimeout(r, 300));
          } catch (e: any) {
            options.onProgress?.(`  Ошибка модели ${model.name}: ${e.message}`);
          }
        }
      } catch (e: any) {
        options.onProgress?.(`Ошибка марки ${brand.name}: ${e.message}`);
      }

      // Delay between brands
      await new Promise((r) => setTimeout(r, 500));
    }

    // Update sync log
    await db.update(marketSyncLog)
      .set({
        status: "completed",
        carsFound: totalFound,
        carsNew: totalNew,
        completedAt: new Date(),
      })
      .where(eq(marketSyncLog.id, syncId));

    const duration = Math.round((Date.now() - startTime) / 1000);
    options.onProgress?.(`Готово! Найдено ${totalFound}, новых ${totalNew} за ${duration}с`);

    return { syncId, totalFound, totalNew, duration };
  } catch (e: any) {
    await db.update(marketSyncLog)
      .set({
        status: "failed",
        error: e.message,
        completedAt: new Date(),
      })
      .where(eq(marketSyncLog.id, syncId));

    throw e;
  }
}

// ─── Get stats ───
export async function getMarketStats() {
  const db = getDb();

  const newCars = await db.select({ count: sql<number>`COUNT(*)` }).from(marketCars).where(eq(marketCars.status, "new"));
  const pending = await db.select({ count: sql<number>`COUNT(*)` }).from(marketCars).where(eq(marketCars.status, "pending"));
  const approved = await db.select({ count: sql<number>`COUNT(*)` }).from(marketCars).where(eq(marketCars.status, "approved"));
  const merged = await db.select({ count: sql<number>`COUNT(*)` }).from(marketCars).where(eq(marketCars.status, "merged"));
  const total = await db.select({ count: sql<number>`COUNT(*)` }).from(marketCars);

  return {
    new: Number(newCars[0]?.count || 0),
    pending: Number(pending[0]?.count || 0),
    approved: Number(approved[0]?.count || 0),
    merged: Number(merged[0]?.count || 0),
    total: Number(total[0]?.count || 0),
  };
}

// ─── Approve market car → add to cars DB ───
export async function approveMarketCar(marketCarId: number, userId?: number) {
  const db = getDb();

  const [mc] = await db.select().from(marketCars).where(eq(marketCars.id, marketCarId)).limit(1);
  if (!mc) throw new Error("Market car not found");

  // Check if already in cars
  const existing = await db
    .select()
    .from(cars)
    .where(
      and(
        sql`LOWER(${cars.make}) = LOWER(${mc.make})`,
        sql`LOWER(${cars.model}) = LOWER(${mc.model})`,
      )
    )
    .limit(1);

  let carId: number;

  if (existing.length > 0) {
    // Update existing
    carId = existing[0].id;
    await db.update(cars)
      .set({
        modification: mc.modification || existing[0].modification,
        yearFrom: mc.yearFrom || existing[0].yearFrom,
        yearTo: mc.yearTo || existing[0].yearTo,
        engineCode: mc.engineCode || existing[0].engineCode,
        engineCapacity: mc.engineCapacity || existing[0].engineCapacity,
      })
      .where(eq(cars.id, carId));
  } else {
    // Insert new
    const [result] = await db.insert(cars).values({
      make: mc.make,
      model: mc.model,
      modification: mc.modification,
      yearFrom: mc.yearFrom,
      yearTo: mc.yearTo,
      engineCode: mc.engineCode,
      engineCapacity: mc.engineCapacity,
      body: mc.body,
    }).$returningId();
    carId = result.id;
  }

  // Update market car
  await db.update(marketCars)
    .set({
      status: "approved",
      matchedCarId: carId,
      reviewedBy: userId,
      reviewedAt: new Date(),
    })
    .where(eq(marketCars.id, marketCarId));

  return { carId };
}
