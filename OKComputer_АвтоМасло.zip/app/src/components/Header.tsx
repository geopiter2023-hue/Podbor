import { useEffect, useState } from "react";

export default function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-black/80 backdrop-blur-md border-b border-[#262626]"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[#f59e0b]" />
          <span className="font-mono-tech text-xs tracking-[0.1em] text-[#a3a3a3] uppercase">
            Motornaya
          </span>
        </div>
        <div className="flex items-center gap-6">
          <div className="hidden sm:flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse-dot" />
            <span className="font-mono-tech text-[11px] text-[#a3a3a3] uppercase tracking-wider">
              Система: Активна
            </span>
          </div>
          <div className="hidden md:flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-[#f59e0b] animate-pulse-dot" />
            <span className="font-mono-tech text-[11px] text-[#a3a3a3] uppercase tracking-wider">
              API: Подключено
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
