import { z } from "zod";
import { createRouter, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { products, productAssignments, companies, companyUsers } from "@db/schema";
import { eq, and, desc } from "drizzle-orm";

export const companyRouter = createRouter({
  // Get current user's companies
  myCompanies: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user.id;
    const result = await db
      .select({
        id: companies.id,
        name: companies.name,
        slug: companies.slug,
        logo: companies.logo,
        role: companyUsers.role,
        isActive: companies.isActive,
      })
      .from(companyUsers)
      .innerJoin(companies, eq(companyUsers.companyId, companies.id))
      .where(eq(companyUsers.userId, userId));
    return result;
  }),

  // Get products for a company
  listProducts: authedQuery
    .input(z.object({ companyId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = getDb();
      // Verify user is member of this company
      const [membership] = await db
        .select()
        .from(companyUsers)
        .where(
          and(
            eq(companyUsers.companyId, input.companyId),
            eq(companyUsers.userId, ctx.user.id)
          )
        );
      if (!membership) throw new Error("Access denied");

      return db.select().from(products)
        .where(eq(products.companyId, input.companyId))
        .orderBy(desc(products.createdAt));
    }),

  // Get assignments for a company
  listAssignments: authedQuery
    .input(z.object({ companyId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = getDb();
      const [membership] = await db
        .select()
        .from(companyUsers)
        .where(
          and(
            eq(companyUsers.companyId, input.companyId),
            eq(companyUsers.userId, ctx.user.id)
          )
        );
      if (!membership) throw new Error("Access denied");

      return db.select().from(productAssignments)
        .where(eq(productAssignments.companyId, input.companyId))
        .orderBy(desc(productAssignments.createdAt));
    }),

  // Create product (manager/owner only)
  createProduct: authedQuery
    .input(z.object({
      companyId: z.number(),
      name: z.string().min(1),
      sku: z.string().min(1),
      brand: z.string().optional(),
      category: z.string().optional(),
      description: z.string().optional(),
      price: z.number().optional(),
      volume: z.string().optional(),
      specs: z.record(z.any()).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      // Verify user is manager or owner
      const [membership] = await db
        .select()
        .from(companyUsers)
        .where(
          and(
            eq(companyUsers.companyId, input.companyId),
            eq(companyUsers.userId, ctx.user.id)
          )
        );
      if (!membership || membership.role === "viewer") {
        throw new Error("Permission denied");
      }

      const result = await db.insert(products).values({
        companyId: input.companyId,
        name: input.name,
        sku: input.sku,
        brand: input.brand || null,
        category: input.category || null,
        description: input.description || null,
        price: input.price || null,
        volume: input.volume || null,
        specs: input.specs || null,
      }).$returningId();
      return result[0];
    }),

  // Assign product to car
  assignProduct: authedQuery
    .input(z.object({
      companyId: z.number(),
      productId: z.number(),
      makeId: z.number(),
      modelId: z.number(),
      modificationId: z.string(),
      notes: z.string().optional(),
      isRecommended: z.enum(["yes", "no"]).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const [membership] = await db
        .select()
        .from(companyUsers)
        .where(
          and(
            eq(companyUsers.companyId, input.companyId),
            eq(companyUsers.userId, ctx.user.id)
          )
        );
      if (!membership || membership.role === "viewer") {
        throw new Error("Permission denied");
      }

      await db.insert(productAssignments).values({
        companyId: input.companyId,
        productId: input.productId,
        makeId: input.makeId,
        modelId: input.modelId,
        modificationId: input.modificationId,
        notes: input.notes || null,
        isRecommended: input.isRecommended || "no",
      }).onDuplicateKeyUpdate({
        set: { notes: input.notes || null, isRecommended: input.isRecommended || "no" },
      });
      return { success: true };
    }),
});
