import { useState, useCallback, useMemo } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import {
  ChevronRight, ChevronDown, Search, X, Car, Truck,
  ArrowLeft, Droplets, Settings2, Calendar, Fuel, Gauge,
} from "lucide-react";

type Step = "brands" | "models" | "generations" | "result";
type VehicleTab = "car" | "truck";
type SearchMode = "plate" | "vin";

// Get first letter of brand name for placeholder
function getFirstLetter(name: string): string {
  return name ? name.charAt(0).toUpperCase() : "?";
}

export default function Home() {
  const [vehicleTab, setVehicleTab] = useState<VehicleTab>("car");
  const [step, setStep] = useState<Step>("brands");
  const [selectedMake, setSelectedMake] = useState<string | null>(null);
  const [selectedMakeName, setSelectedMakeName] = useState("");
  const [selectedModel, setSelectedModel] = useState<string | null>(null);
  const [selectedModelName, setSelectedModelName] = useState("");
  const [selectedGen, setSelectedGen] = useState<string | null>(null);
  const [selectedGenName, setSelectedGenName] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAllMakes, setShowAllMakes] = useState(false);

  // Plate/VIN search
  const [plateNumber, setPlateNumber] = useState("");
  const [vinNumber, setVinNumber] = useState("");
  const [searchMode, setSearchMode] = useState<SearchMode>("plate");
  const [plateError, setPlateError] = useState("");

  // Modification dropdown
  const [modOpen, setModOpen] = useState(false);

  // Data
  const { data: makes, isLoading: makesLoading } = trpc.car.brands.useQuery();
  const { data: models } = trpc.car.models.useQuery(
    { makeId: selectedMake ? parseInt(selectedMake) : 0 },
    { enabled: !!selectedMake && step === "models" }
  );
  const { data: mods } = trpc.car.modifications.useQuery(
    { makeId: selectedMake ? parseInt(selectedMake) : 0, modelId: selectedModel ? parseInt(selectedModel) : 0 },
    { enabled: !!selectedMake && !!selectedModel && (step === "generations" || step === "result") }
  );
  const { data: oils } = trpc.oil.results.useQuery(
    { makeId: selectedMake ? parseInt(selectedMake) : 0, modelId: selectedModel ? parseInt(selectedModel) : 0, modificationId: selectedGen ? parseInt(selectedGen) : 0 },
    { enabled: !!selectedMake && !!selectedModel && !!selectedGen && step === "result" }
  );

  // Plate search API
  const plateSearch = trpc.plateSearch.search.useQuery(
    { plate: plateNumber, vin: vinNumber || undefined },
    { enabled: false }
  );

  const filteredMakes = useMemo(() => {
    if (!makes) return [];
    if (!searchQuery) return makes;
    const q = searchQuery.toLowerCase();
    return makes.filter((m: any) => (m.name || "").toLowerCase().includes(q));
  }, [makes, searchQuery]);

  const displayedMakes = showAllMakes || searchQuery ? filteredMakes : filteredMakes.slice(0, 10);

  const handleSelectMake = useCallback((id: string, name: string) => {
    setSelectedMake(id);
    setSelectedMakeName(name);
    setStep("models");
    setSearchQuery("");
    setShowAllMakes(false);
  }, []);

  const handleSelectModel = useCallback((id: string, name: string) => {
    setSelectedModel(id);
    setSelectedModelName(name);
    setStep("generations");
  }, []);

  const handleSelectGen = useCallback((id: string, name: string) => {
    setSelectedGen(id);
    setSelectedGenName(name);
    setStep("result");
    setModOpen(false);
  }, []);

  const handleBack = useCallback(() => {
    if (step === "result") { setStep("generations"); setSelectedGen(null); setSelectedGenName(""); }
    else if (step === "generations") { setStep("models"); setSelectedModel(null); setSelectedModelName(""); }
    else if (step === "models") { setStep("brands"); setSelectedMake(null); setSelectedMakeName(""); setShowAllMakes(false); }
  }, [step]);

  const handlePlateSearch = async () => {
    setPlateError("");
    const query = searchMode === "plate" ? plateNumber : vinNumber;
    if (!query.trim()) {
      setPlateError(searchMode === "plate" ? "Введите номер" : "Введите VIN");
      return;
    }
    try {
      const result = await plateSearch.refetch();
      if (result.data?.found && result.data.localMatch) {
        const match = result.data.localMatch;
        if (match.brand) {
          handleSelectMake(String(match.brand.id), match.brand.name);
        }
      } else {
        setPlateError("Автомобиль не найден");
      }
    } catch (e: any) {
      setPlateError("Ошибка поиска");
    }
  };

  // Breadcrumb data
  const currentMods = mods || [];
  const selectedModData = currentMods.find((m: any) => String(m.id) === selectedGen);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#1a1a1a] sticky top-0 z-30">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#f59e0b]" />
            <span className="text-[#a3a3a3] text-sm font-medium tracking-[0.2em] uppercase">oilpodbor</span>
          </div>
          <Link to="/login" className="text-[#f59e0b] text-sm flex items-center gap-1 hover:opacity-80">
            <ArrowLeft className="w-4 h-4 rotate-180" />
            Войти
          </Link>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-4">
        {/* Title */}
        {step === "brands" && (
          <h1 className="text-[#1a1a1a] text-xl sm:text-2xl font-bold mb-4 leading-tight">
            Подбор моторного масла и других технических жидкостей
          </h1>
        )}

        {/* Vehicle type tabs */}
        <div className="flex mb-4 bg-[#1a1a1a] rounded-lg overflow-hidden">
          <button
            onClick={() => setVehicleTab("car")}
            className={`flex-1 py-3 text-sm font-medium transition-colors ${
              vehicleTab === "car" ? "text-[#f59e0b] border-2 border-[#f59e0b] rounded-lg" : "text-white"
            }`}
          >
            Легковой
          </button>
          <button
            onClick={() => setVehicleTab("truck")}
            className={`flex-1 py-3 text-sm font-medium transition-colors ${
              vehicleTab === "truck" ? "text-[#f59e0b] border-2 border-[#f59e0b] rounded-lg" : "text-white"
            }`}
          >
            Грузовой
          </button>
        </div>

        {/* Plate & VIN inputs - always visible */}
        <div className="mb-4 space-y-2">
          {/* Plate number */}
          <div className="flex gap-2">
            <div className="flex-1 flex border border-[#d4d4d4] rounded-lg overflow-hidden">
              <input
                type="text"
                value={plateNumber}
                onChange={(e) => setPlateNumber(e.target.value.toUpperCase())}
                placeholder="A 000 AA"
                className="flex-1 px-3 py-2.5 text-sm text-[#1a1a1a] uppercase placeholder:text-[#a3a3a3] focus:outline-none"
              />
              <div className="border-l border-[#d4d4d4] flex items-center gap-1 px-2 bg-white">
                <span className="text-[#a3a3a3] text-xs">000</span>
                <span className="text-[#a3a3a3] text-xs">RUS</span>
                <span className="text-lg">🇷🇺</span>
              </div>
            </div>
            <button className="p-2.5 border border-[#d4d4d4] rounded-lg hover:bg-gray-50">
              <svg className="w-5 h-5 text-[#737373]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
            </button>
          </div>

          {/* VIN */}
          <input
            type="text"
            value={vinNumber}
            onChange={(e) => setVinNumber(e.target.value.toUpperCase())}
            placeholder="Поиск по VIN/Frame номеру"
            className="w-full border border-[#d4d4d4] rounded-lg px-3 py-2.5 text-sm text-[#1a1a1a] placeholder:text-[#a3a3a3] focus:outline-none focus:border-[#f59e0b]"
          />

          {/* Buttons */}
          <div className="flex gap-2">
            <button
              onClick={() => { setPlateNumber(""); setVinNumber(""); setPlateError(""); }}
              className="flex-1 py-2.5 border border-[#d4d4d4] rounded-lg text-sm font-medium text-[#1a1a1a] hover:bg-gray-50 flex items-center justify-center gap-1"
            >
              <X className="w-4 h-4" /> Сбросить
            </button>
            <button
              onClick={handlePlateSearch}
              disabled={plateSearch.isFetching}
              className="flex-1 py-2.5 bg-[#f59e0b] text-[#1a1a1a] rounded-lg text-sm font-medium hover:bg-[#fbbf24] flex items-center justify-center gap-1 disabled:opacity-50"
            >
              {plateSearch.isFetching ? (
                <div className="w-4 h-4 border-2 border-[#1a1a1a]/30 border-t-[#1a1a1a] rounded-full animate-spin" />
              ) : (
                <Search className="w-4 h-4" />
              )}
              Поиск
            </button>
          </div>

          {plateError && (
            <p className="text-red-500 text-xs">{plateError}</p>
          )}
        </div>

        {/* ═══ BLACK BLOCK: Vehicle Search ═══ */}
        <div className="bg-[#1a1a1a] rounded-lg p-4 mb-4">
          {/* Title */}
          {step === "brands" && (
            <>
              <h2 className="text-white text-lg font-bold mb-1">Поиск транспортного средства</h2>
              <p className="text-[#a3a3a3] text-sm mb-4">
                Вы можете найти необходимый продукт по марке, модели транспортного средства и коду двигателя
              </p>
            </>
          )}

          {/* Breadcrumb + Back */}
          {step !== "brands" && (
            <div className="mb-4">
              {/* Breadcrumb row */}
              <div className="grid grid-cols-3 gap-2 mb-3">
                <div className="bg-[#262626] border border-[#404040] rounded-lg p-2">
                  <p className="text-[#a3a3a3] text-xs">Марка авто</p>
                  <p className="text-white text-sm font-medium truncate">{selectedMakeName}</p>
                </div>
                <div className="bg-[#262626] border border-[#404040] rounded-lg p-2">
                  <p className="text-[#a3a3a3] text-xs">Модель авто</p>
                  <p className="text-white text-sm font-medium truncate">{selectedModelName || "—"}</p>
                </div>
                <button
                  onClick={handleBack}
                  className="bg-[#262626] border border-[#f59e0b] text-[#f59e0b] rounded-lg p-2 text-sm font-medium hover:bg-[#333] flex items-center justify-center gap-1"
                >
                  <ArrowLeft className="w-3 h-3" /> Назад
                </button>
              </div>

              {/* Generation/Mod row */}
              {(step === "generations" || step === "result") && (
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-[#262626] border border-[#404040] rounded-lg p-2">
                    <p className="text-[#a3a3a3] text-xs">Поколение</p>
                    <p className="text-white text-sm font-medium truncate">{selectedGenName || "—"}</p>
                  </div>
                  <div className="col-span-2 relative">
                    <button
                      onClick={() => setModOpen(!modOpen)}
                      className="w-full bg-[#262626] border border-[#404040] rounded-lg p-2 text-left flex items-center justify-between hover:border-[#f59e0b] transition-colors"
                    >
                      <div>
                        <p className="text-[#a3a3a3] text-xs">Модификация</p>
                        <p className="text-white text-sm truncate">
                          {selectedModData?.name || "Выберите"}
                          {selectedModData?.engineCode && ` (${selectedModData.engineCode})`}
                        </p>
                      </div>
                      <ChevronDown className={`w-4 h-4 text-[#a3a3a3] transition-transform ${modOpen ? "rotate-180" : ""}`} />
                    </button>

                    {modOpen && (
                      <div className="absolute z-20 w-full mt-1 bg-[#262626] border border-[#404040] rounded-lg shadow-xl max-h-60 overflow-auto">
                        {currentMods.map((mod: any) => (
                          <button
                            key={mod.id}
                            onClick={() => {
                              setSelectedGen(String(mod.id));
                              setSelectedGenName(mod.name || "");
                              setModOpen(false);
                            }}
                            className={`w-full text-left px-3 py-2.5 text-sm hover:bg-[#333] transition-colors ${
                              String(mod.id) === selectedGen ? "bg-[#f59e0b]/10 text-[#f59e0b]" : "text-white"
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span>{mod.name || "—"}</span>
                              {mod.engineCode && <span className="text-[#f59e0b] text-xs">{mod.engineCode}</span>}
                            </div>
                            <div className="flex gap-2 mt-0.5 text-[10px] text-[#737373]">
                              {mod.horsePower && <span>{mod.horsePower} л.с.</span>}
                              {mod.fuel && <span>{mod.fuel}</span>}
                            </div>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Quick search (step 1 only) */}
          {step === "brands" && (
            <div className="flex gap-2 mb-4">
              <div className="flex-1 relative">
                <Search className="w-4 h-4 text-[#737373] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Быстрый поиск..."
                  className="w-full bg-[#0a0a0a] border border-[#404040] rounded-lg pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-[#525252] focus:outline-none focus:border-[#f59e0b]"
                />
              </div>
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="px-3 bg-[#262626] border border-[#404040] rounded-lg text-[#737373] hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          )}

          {/* Content inside black block */}
          {/* STEP 1: Brands */}
          {step === "brands" && (
            <div>
              {makesLoading ? (
                <div className="flex justify-center py-8">
                  <div className="w-8 h-8 border-2 border-[#f59e0b] border-t-transparent rounded-full animate-spin" />
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    {displayedMakes.map((make: any) => (
                      <button
                        key={make.id}
                        onClick={() => handleSelectMake(String(make.id), make.name || "")}
                        className="bg-[#262626] border border-[#404040] rounded-lg p-4 flex flex-col items-center gap-2 hover:border-[#f59e0b] transition-all active:scale-[0.98]"
                      >
                        <div className="w-12 h-12 rounded-full bg-[#1a1a1a] border border-[#404040] flex items-center justify-center">
                          <span className="text-[#f59e0b] text-lg font-bold">{getFirstLetter(make.name || "")}</span>
                        </div>
                        <span className="text-white text-xs font-medium text-center">{make.name}</span>
                      </button>
                    ))}
                  </div>

                  {!showAllMakes && !searchQuery && filteredMakes.length > 10 && (
                    <button
                      onClick={() => setShowAllMakes(true)}
                      className="w-full mt-3 py-2.5 border border-[#404040] rounded-lg text-sm text-[#a3a3a3] hover:border-[#f59e0b] hover:text-[#f59e0b] transition-colors"
                    >
                      Показать все марки ({filteredMakes.length})
                    </button>
                  )}
                </>
              )}
            </div>
          )}

          {/* STEP 2: Models */}
          {step === "models" && (
            <div className="grid grid-cols-2 gap-2">
              {models?.map((model: any) => (
                <button
                  key={model.modelId}
                  onClick={() => handleSelectModel(String(model.modelId), model.modelName || "")}
                  className="bg-white rounded-lg overflow-hidden hover:opacity-90 transition-all active:scale-[0.98]"
                >
                  <div className="bg-white h-24 flex items-center justify-center overflow-hidden">
                    {model.imageUrl ? (
                      <img
                        src={model.imageUrl}
                        alt={model.modelName || ""}
                        className="w-full h-full object-cover"
                        loading="lazy"
                        onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                      />
                    ) : (
                      <Car className="w-12 h-12 text-[#d4d4d4]" />
                    )}
                  </div>
                  <div className="bg-[#262626] p-2">
                    <p className="text-white text-xs font-medium text-center">{model.modelName}</p>
                  </div>
                </button>
              ))}
              {(!models || models.length === 0) && (
                <div className="col-span-full text-center py-8 text-[#737373] text-sm">Модели не найдены</div>
              )}
            </div>
          )}

          {/* STEP 3: Generations */}
          {step === "generations" && (
            <div className="grid grid-cols-2 gap-2">
              {currentMods.map((mod: any) => {
                const years = [];
                if (mod.startDate) { const m = mod.startDate.match(/(\d{4})/); if (m) years.push(m[1]); }
                if (mod.endDate) { const m = mod.endDate.match(/(\d{4})/); if (m) years.push(m[1]); }
                else if (years.length > 0) years.push("н.в.");
                const yearStr = years.join(" — ");

                return (
                  <button
                    key={mod.id}
                    onClick={() => handleSelectGen(String(mod.id), mod.name || "")}
                    className="bg-white rounded-lg overflow-hidden hover:opacity-90 transition-all active:scale-[0.98]"
                  >
                    <div className="bg-white h-24 flex items-center justify-center">
                      <Car className="w-12 h-12 text-[#d4d4d4]" />
                    </div>
                    <div className="bg-[#262626] p-2">
                      <p className="text-white text-xs font-medium text-center">{mod.name || "—"}</p>
                      {yearStr && <p className="text-[#737373] text-[10px] text-center">{yearStr}</p>}
                    </div>
                  </button>
                );
              })}
              {currentMods.length === 0 && (
                <div className="col-span-full text-center py-8 text-[#737373] text-sm">Поколения не найдены</div>
              )}
            </div>
          )}

          {/* STEP 4: Result */}
          {step === "result" && (
            <div className="space-y-3">
              {/* Car card */}
              <div className="bg-white rounded-lg p-3 flex items-center gap-3">
                <div className="w-14 h-14 rounded-full bg-[#f5f5f5] flex items-center justify-center flex-shrink-0">
                  <span className="text-[#f59e0b] text-xl font-bold">{getFirstLetter(selectedMakeName)}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[#1a1a1a] font-bold text-sm">{selectedMakeName} {selectedModelName}</p>
                  <p className="text-[#737373] text-xs">{selectedGenName}</p>
                  {selectedModData?.engineCode && (
                    <p className="text-[#f59e0b] text-xs font-mono">{selectedModData.engineCode}</p>
                  )}
                </div>
              </div>

              {/* Oils */}
              <div>
                <h3 className="text-white font-bold text-sm mb-2 flex items-center gap-2">
                  <Droplets className="w-4 h-4 text-[#f59e0b]" />
                  Рекомендуемые масла
                </h3>
                {oils && oils.length > 0 ? (
                  <div className="space-y-2">
                    {oils.map((oil: any, i: number) => (
                      <div key={oil.id || i} className="bg-[#262626] border border-[#404040] rounded-lg p-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="text-white text-sm font-medium">{oil.originalName || oil.name || "—"}</p>
                            <div className="flex items-center gap-3 mt-1">
                              {oil.artNumber && <span className="text-[#737373] text-xs font-mono">{oil.artNumber}</span>}
                              {oil.volume && <span className="text-[#f59e0b] text-xs font-medium">{oil.volume}</span>}
                            </div>
                          </div>
                          <span className="text-[#525252] text-xs flex-shrink-0">#{i + 1}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-[#262626] border border-[#404040] rounded-lg p-6 text-center">
                    <Droplets className="w-8 h-8 mx-auto mb-2 text-[#525252]" />
                    <p className="text-[#737373] text-sm">Данные не найдены</p>
                  </div>
                )}
              </div>

              {/* Back button */}
              <button
                onClick={handleBack}
                className="w-full py-3 rounded-lg text-sm font-medium bg-[#262626] border border-[#f59e0b] text-[#f59e0b] hover:bg-[#333] transition-colors"
              >
                <ArrowLeft className="w-4 h-4 inline mr-2" />
                Назад
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <footer className="mt-8 py-4 text-center text-[#a3a3a3] text-xs border-t border-[#e5e5e5]">
          oilpodbor — система подбора технических жидкостей
        </footer>
      </main>
    </div>
  );
}
