import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { brands, models, modifications } from "@db/schema";
import { sql, eq, like } from "drizzle-orm";

/**
 * Plate Search Router
 * Searches car by license plate number via external API
 * Fallback: search in local database by plate patterns
 */

// ─── External API configuration ───
// These can be configured per-company via environment variables
const PLATE_API_URL = process.env.PLATE_API_URL || "";
const PLATE_API_KEY = process.env.PLATE_API_KEY || "";

interface PlateSearchResult {
  found: boolean;
  make?: string;
  model?: string;
  year?: number;
  engineCode?: string;
  engineCapacity?: string;
  fuel?: string;
  vin?: string;
  bodyType?: string;
  power?: string;
  transmission?: string;
  source: "api" | "local" | "none";
  raw?: any;
}

export const plateSearchRouter = createRouter({
  // ─── Search by plate number ───
  search: publicQuery
    .input(z.object({
      plate: z.string().min(3).max(20),
      vin: z.string().optional(),
    }))
    .query(async ({ input }) => {
      const plate = input.plate.toUpperCase().trim().replace(/\s+/g, " ");
      const result: PlateSearchResult = { found: false, source: "none" };

      // ── Try external API if configured ──
      if (PLATE_API_URL && PLATE_API_KEY) {
        try {
          const apiUrl = `${PLATE_API_URL}?plate=${encodeURIComponent(plate)}&apiKey=${PLATE_API_KEY}`;
          const response = await fetch(apiUrl, {
            method: "GET",
            headers: { "Content-Type": "application/json" },
            signal: AbortSignal.timeout(10000),
          });

          if (response.ok) {
            const data = await response.json();
            if (data && (data.make || data.brand)) {
              result.found = true;
              result.source = "api";
              result.make = data.make || data.brand;
              result.model = data.model;
              result.year = data.year ? parseInt(data.year) : undefined;
              result.engineCode = data.engineCode || data.engine;
              result.engineCapacity = data.engineCapacity || data.volume;
              result.fuel = data.fuel;
              result.vin = data.vin;
              result.power = data.power || data.horsePower;
              result.transmission = data.transmission;
              result.raw = data;

              // Try to find matching car in our database
              const match = await findInLocalDb(result);
              if (match) {
                return { ...result, localMatch: match };
              }

              return result;
            }
          }
        } catch (e: any) {
          console.log("External API error:", e.message);
          // Continue to local search
        }
      }

      // ── Fallback: local search by plate patterns ──
      // This is a placeholder - in production you'd have a plate-to-car mapping table
      return result;
    }),

  // ─── Find car in local DB by make/model/engineCode ───
  findLocal: publicQuery
    .input(z.object({
      make: z.string(),
      model: z.string().optional(),
      engineCode: z.string().optional(),
      year: z.number().optional(),
    }))
    .query(async ({ input }) => {
      return findInLocalDb({
        make: input.make,
        model: input.model,
        engineCode: input.engineCode,
        year: input.year,
      });
    }),
});

// ─── Helper: find matching car in local database ───
async function findInLocalDb(data: {
  make?: string;
  model?: string;
  engineCode?: string;
  year?: number;
}): Promise<any | null> {
  const db = getDb();
  if (!data.make) return null;

  // Find brand by name
  const [brand] = await db
    .select()
    .from(brands)
    .where(like(brands.name, `%${data.make}%`))
    .limit(1);

  if (!brand) return null;

  // Find models for this brand
  const modelFilter = data.model
    ? like(models.modelName, `%${data.model}%`)
    : undefined;

  const modelsList = await db
    .select()
    .from(models)
    .where(
      modelFilter
        ? sql`${models.makeId} = ${brand.id} AND ${modelFilter}`
        : eq(models.makeId, brand.id)
    )
    .limit(5);

  if (modelsList.length === 0) return null;

  // Find modifications
  const modelIds = modelsList.map((m) => m.modelId);
  const mods = await db
    .select()
    .from(modifications)
    .where(
      sql`${modifications.makeId} = ${brand.id} AND ${modifications.modelId} IN (${sql.join(modelIds, sql`, `)})`
    )
    .limit(10);

  // Filter by engine code if provided
  let matchedMods = mods;
  if (data.engineCode) {
    const exactMatch = mods.filter((m) =>
      m.engineCode?.toUpperCase().includes(data.engineCode!.toUpperCase())
    );
    if (exactMatch.length > 0) {
      matchedMods = exactMatch;
    }
  }

  return {
    brand: { id: brand.id, name: brand.name },
    models: modelsList.map((m) => ({
      modelId: m.modelId,
      modelName: m.modelName,
      yearFrom: m.yearFrom,
      yearTo: m.yearTo,
    })),
    modifications: matchedMods.map((m) => ({
      id: m.id,
      name: m.name,
      engineCode: m.engineCode,
      fuel: m.fuel,
      horsePower: m.horsePower,
      startDate: m.startDate,
      endDate: m.endDate,
      engineCapacity: m.engineCapacity,
    })),
  };
}
