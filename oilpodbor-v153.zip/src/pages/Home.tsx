import { useState, useCallback, useMemo, useEffect } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import ResultCard from "@/components/ResultCard";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronRight, ChevronDown, Search, X, Car, Truck,
  ArrowLeft, Droplets, Settings2, Cog, Wind, CircleDot, Wrench,
  Shield, LogOut, BookOpen, ExternalLink, Download, SlidersHorizontal,
} from "lucide-react";

// Animation variants
const fadeInUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const staggerContainer = { hidden: {}, visible: { transition: { staggerChildren: 0.05 } } };
const scaleIn = { hidden: { opacity: 0, scale: 0.95 }, visible: { opacity: 1, scale: 1 } };

type Step = "brands" | "models" | "generations" | "result";
type VehicleTab = "car" | "truck";
type AggrTab = "engine" | "cooling" | "transmission" | "differential" | "steering" | "brakes";
type SubFilter = "all" | "no_dpf" | "no_gpf" | "with_gpf";

function getFirstLetter(name: string): string {
  return name ? name.charAt(0).toUpperCase() : "?";
}

const AGGR_TABS: { key: AggrTab; label: string; count: number; icon: any }[] = [
  { key: "engine", label: "Двигатель", count: 10, icon: Settings2 },
  { key: "cooling", label: "Система охлаждения", count: 1, icon: Wind },
  { key: "transmission", label: "АКПП", count: 2, icon: Cog },
  { key: "differential", label: "Задний дифференциал", count: 2, icon: CircleDot },
  { key: "steering", label: "Рулевое управление", count: 2, icon: Wrench },
  { key: "brakes", label: "Тормозная система", count: 1, icon: CircleDot },
];

const SUB_FILTERS: { key: SubFilter; label: string }[] = [
  { key: "all", label: "Все" },
  { key: "no_dpf", label: "Без DPF" },
  { key: "no_gpf", label: "Без GPF" },
  { key: "with_gpf", label: "С GPF" },
];

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const [vehicleTab, setVehicleTab] = useState<VehicleTab>("car");
  const [step, setStep] = useState<Step>("brands");
  const [selectedMake, setSelectedMake] = useState<string | null>(null);
  const [selectedMakeName, setSelectedMakeName] = useState("");
  const [selectedModel, setSelectedModel] = useState<string | null>(null);
  const [selectedModelName, setSelectedModelName] = useState("");
  const [selectedModelImage, setSelectedModelImage] = useState("");
  const [selectedGen, setSelectedGen] = useState<string | null>(null);
  const [selectedGenName, setSelectedGenName] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAllMakes, setShowAllMakes] = useState(false);
  const [plateNumber, setPlateNumber] = useState("");
  const [vinNumber, setVinNumber] = useState("");
  const [plateError, setPlateError] = useState("");
  const [searchResultCar, setSearchResultCar] = useState<{
    make: string; model: string; year?: string; vin?: string;
    generation?: string; modification?: string;
    engineCapacity?: string; powerHp?: string; fuel?: string; transmission?: string;
  } | null>(null);
  const [modOpen, setModOpen] = useState(false);
  const [aggrTab, setAggrTab] = useState<AggrTab>("engine");
  const [subFilter, setSubFilter] = useState<SubFilter>("all");

  // Filters for modifications
  const [bodyFilter, setBodyFilter] = useState("");
  const [fuelFilter, setFuelFilter] = useState("");
  const [transmissionFilter, setTransmissionFilter] = useState("");
  const [yearFromFilter, setYearFromFilter] = useState("");
  const [yearToFilter, setYearToFilter] = useState("");

  const { data: makes, isLoading: makesLoading, error: makesError } = trpc.car.brands.useQuery();
  const { data: brandLogosData } = trpc.brandLogos.list.useQuery();
  const { data: settingsData } = trpc.settings.publicList.useQuery();

  // Get featured makes from settings
  const featuredMakesSetting = settingsData?.find((s: any) => s.key === "featured_makes")?.value;
  const featuredMakes: string[] = (() => {
    try {
      return JSON.parse(featuredMakesSetting || '[]');
    } catch { return []; }
  })();

  // Filter makes to show only featured (if not showing all)
  const displayedMakes = showAllMakes ? makes : (makes || []).filter((m: any) => featuredMakes.includes(m.name));

  // Build logo lookup map
  const logoMap = new Map<string, string>();
  if (brandLogosData) {
    for (const b of brandLogosData) {
      if (b.logoUrl) logoMap.set(b.name?.toLowerCase() || "", b.logoUrl);
    }
  }
  const { data: models } = trpc.car.models.useQuery(
    { makeId: selectedMake ? parseInt(selectedMake) : 0 },
    { enabled: !!selectedMake && step === "models" }
  );
  const { data: mods } = trpc.car.modifications.useQuery(
    { makeId: selectedMake ? parseInt(selectedMake) : 0, modelId: selectedModel ? parseInt(selectedModel) : 0 },
    { enabled: !!selectedMake && !!selectedModel && (step === "generations" || step === "result") }
  );
  const { data: manuals } = trpc.manuals.findByCar.useQuery(
    { make: selectedMakeName, model: selectedModelName },
    { enabled: step === "result" && !!selectedMakeName && !!selectedModelName }
  );

  const { data: oils } = trpc.oil.results.useQuery(
    { makeId: selectedMake ? parseInt(selectedMake) : 0, modelId: selectedModel ? parseInt(selectedModel) : 0, modificationId: selectedGen ? parseInt(selectedGen) : 0 },
    { enabled: !!selectedMake && !!selectedModel && !!selectedGen && step === "result" }
  );

  const plateSearch = trpc.plateSearch.search.useQuery(
    { plate: plateNumber, vin: vinNumber || undefined },
    { enabled: false }
  );

  // Fetch fluid specs for the found car (plate/VIN search result)
  const { data: searchFluidSpecs } = trpc.excel.getByCar.useQuery(
    { make: searchResultCar?.make || "", model: searchResultCar?.model || "" },
    { enabled: !!(searchResultCar?.make && searchResultCar?.model) }
  );

  // Fetch modifications to find best match for the found car
  const searchMakeId = plateSearch.data?.localMatch?.brand?.id || 0;
  const searchModelId = plateSearch.data?.localMatch?.models?.[0]?.modelId || 0;
  const { data: searchMods } = trpc.car.modifications.useQuery(
    { makeId: Number(searchMakeId), modelId: Number(searchModelId) },
    { enabled: !!(searchMakeId && searchModelId) }
  );

  const filteredMakes = useMemo(() => {
    if (!makes) return [];
    if (!searchQuery) return makes;
    const q = searchQuery.toLowerCase();
    return makes.filter((m: any) => (m.name || "").toLowerCase().includes(q));
  }, [makes, searchQuery]);

  const handleSelectMake = useCallback((id: string, name: string) => {
    setSelectedMake(id);
    setSelectedMakeName(name);
    setStep("models");
    setSearchQuery("");
    setShowAllMakes(false);
  }, []);

  const handleSelectModel = useCallback((id: string, name: string, imageUrl?: string) => {
    setSelectedModel(id);
    setSelectedModelName(name);
    setSelectedModelImage(imageUrl || "");
    setStep("generations");
  }, []);

  const handleSelectGen = useCallback((id: string, name: string) => {
    setSelectedGen(id);
    setSelectedGenName(name);
    setStep("result");
    setModOpen(false);
  }, []);

  const handleBack = useCallback(() => {
    if (step === "result") { setStep("generations"); setSelectedGen(null); setSelectedGenName(""); }
    else if (step === "generations") { setStep("models"); setSelectedModel(null); setSelectedModelName(""); setSelectedModelImage(""); }
    else if (step === "models") { setStep("brands"); setSelectedMake(null); setSelectedMakeName(""); setShowAllMakes(false); }
  }, [step]);

  // Enrich search result with modification details when mods load
  useEffect(() => {
    if (searchResultCar && searchMods && searchMods.length > 0) {
      const bestMod = searchMods[0];
      setSearchResultCar((prev) => prev ? {
        ...prev,
        generation: bestMod.startDate || "",
        modification: bestMod.name || "",
        engineCapacity: bestMod.engineCapacity || "",
        powerHp: bestMod.horsePower ? String(bestMod.horsePower) : "",
        fuel: bestMod.fuel || "",
        transmission: bestMod.transmission || "",
      } : null);
    }
  }, [searchMods]);

  const handlePlateSearch = async () => {
    setPlateError("");
    setSearchResultCar(null);
    const query = plateNumber || vinNumber;
    if (!query.trim()) { setPlateError("Введите госномер или VIN"); return; }
    try {
      const result = await plateSearch.refetch();
      if (result.data?.error && !result.data?.found) {
        setPlateError(result.data.error);
        return;
      }
      if (result.data?.found) {
        // Set search result car data for ResultCard display
        setSearchResultCar({
          make: result.data.make || "",
          model: result.data.model || "",
          year: result.data.year ? String(result.data.year) : undefined,
          vin: result.data.vin || vinNumber || undefined,
        });
      }
    } catch { setPlateError("Ошибка поиска"); }
  };

  const currentMods = mods || [];

  // Apply filters to modifications
  const filteredMods = currentMods.filter((mod: any) => {
    if (bodyFilter && mod.body && !mod.body.toLowerCase().includes(bodyFilter.toLowerCase())) return false;
    if (fuelFilter && mod.fuel && !mod.fuel.toLowerCase().includes(fuelFilter.toLowerCase())) return false;
    if (transmissionFilter && mod.transmission && !mod.transmission.toLowerCase().includes(transmissionFilter.toLowerCase())) return false;
    if (yearFromFilter) {
      const startYear = mod.startDate ? parseInt(mod.startDate.match(/(\d{4})/)?.[1] || "0") : 0;
      if (startYear && startYear < parseInt(yearFromFilter)) return false;
    }
    if (yearToFilter) {
      const endYear = mod.endDate ? parseInt(mod.endDate.match(/(\d{4})/)?.[1] || "9999") : 9999;
      if (endYear && endYear > parseInt(yearToFilter)) return false;
    }
    return true;
  });

  const selectedModData = currentMods.find((m: any) => String(m.id) === selectedGen);

  return (
    <div className="min-h-screen bg-[#f0f0f0]">
      {/* HEADER */}
      <header className="bg-white sticky top-0 z-30">
        <div className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="oilpodbor" className="w-8 h-8" />
            <span className="text-gray-900 text-base font-bold tracking-wider uppercase">oilpodbor</span>
            <span className="text-[#737373] text-xs hidden sm:inline">|</span>
            <span className="text-gray-500 text-xs hidden sm:inline">подбор масел и технических жидкостей</span>
          </div>
          <div className="flex items-center gap-3">
            {/* Магазин интегрирован в результат подбора масел */}
            {isAuthenticated && user?.role === "admin" ? (
              <>
                <Link to="/admin" className="text-[#d32f2f] text-sm flex items-center gap-1 hover:opacity-80 font-medium">
                  <Shield className="w-4 h-4" />Админ
                </Link>
                <button onClick={logout} className="text-[#737373] text-sm flex items-center gap-1 hover:text-gray-900 transition-colors">
                  <LogOut className="w-4 h-4" />
                </button>
              </>
            ) : (
              <Link to="/login" className="text-[#d32f2f] text-sm flex items-center gap-1 hover:opacity-80 font-medium">
                <ArrowLeft className="w-4 h-4 rotate-180" />Войти
              </Link>
            )}
          </div>
        </div>
      </header>

      <main className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 py-4 sm:py-6">
        {step === "brands" && (
          <h1 className="text-[#1a1a1a] text-xl sm:text-2xl lg:text-3xl font-bold mb-4 sm:mb-6 leading-tight">
            Подбор моторного масла и других технических жидкостей
          </h1>
        )}

        {/* Vehicle Tabs */}
        <div className="flex mb-4 sm:mb-6 bg-white rounded-lg overflow-hidden">
          <button onClick={() => setVehicleTab("car")} className={`flex-1 py-3 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${vehicleTab === "car" ? "text-[#d32f2f] border-2 border-[#d32f2f] rounded-lg" : "text-gray-900 hover:text-[#d32f2f]"}`}><Car className="w-4 h-4" />Легковой</button>
          <button onClick={() => setVehicleTab("truck")} className={`flex-1 py-3 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${vehicleTab === "truck" ? "text-[#d32f2f] border-2 border-[#d32f2f] rounded-lg" : "text-gray-900 hover:text-[#d32f2f]"}`}><Truck className="w-4 h-4" />Грузовой</button>
        </div>

        {/* Plate / VIN Search — RED HIGHLIGHT BLOCK */}
        <div className="mb-4 sm:mb-6 border-2 border-[#d32f2f] rounded-xl p-4 bg-red-50/50 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-full bg-[#d32f2f] flex items-center justify-center">
              <Search className="w-4 h-4 text-gray-900" />
            </div>
            <div>
              <span className="text-sm font-bold text-[#1a1a1a]">Поиск по госномеру или VIN</span>
              <p className="text-[11px] text-[#737373]">Введите номер — найдем авто в базе</p>
            </div>
          </div>
          <div className="flex border-2 border-[#d32f2f] rounded-lg overflow-hidden bg-white mb-2">
            <input type="text" value={plateNumber} onChange={(e) => setPlateNumber(e.target.value.toUpperCase())} placeholder="Госномер: А000АА 777" className="flex-1 px-3 py-2.5 text-sm text-[#1a1a1a] placeholder:text-gray-500 focus:outline-none font-medium" />
          </div>
          <div className="flex border-2 border-[#d32f2f] rounded-lg overflow-hidden bg-white mb-3">
            <input type="text" value={vinNumber} onChange={(e) => setVinNumber(e.target.value.toUpperCase())} placeholder="VIN: XTA21090000000000" className="flex-1 px-3 py-2.5 text-sm text-[#1a1a1a] placeholder:text-gray-500 focus:outline-none font-medium" />
          </div>
          <div className="flex gap-2">
            <button onClick={() => { setPlateNumber(""); setVinNumber(""); setPlateError(""); setSearchResultCar(null); }} className="flex-1 py-2.5 border border-[#d4d4d4] rounded-lg text-sm font-medium text-[#1a1a1a] hover:bg-gray-50 flex items-center justify-center gap-1 bg-white"><X className="w-4 h-4" />Сбросить</button>
            <button onClick={handlePlateSearch} disabled={plateSearch.isFetching} className="flex-1 py-2.5 bg-[#d32f2f] text-white rounded-lg text-sm font-medium hover:bg-[#b71c1c] flex items-center justify-center gap-1 disabled:opacity-50">
              {plateSearch.isFetching ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Search className="w-4 h-4" />}Найти авто
            </button>
          </div>
          {plateError && <p className="text-red-500 text-xs font-medium mt-2">{plateError}</p>}

          {/* Search results — Full ResultCard with car parameters */}
          {searchResultCar && (
            <div className="mt-4 space-y-3">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                  <Search className="w-3 h-3 text-green-600" />
                </div>
                <p className="text-[#1a1a1a] text-sm font-medium">Автомобиль найден</p>
              </div>

              <ResultCard
                car={{
                  make: searchResultCar.make,
                  model: searchResultCar.model,
                  generation: searchResultCar.generation,
                  modification: searchResultCar.modification,
                  year: searchResultCar.year,
                  engineCapacity: searchResultCar.engineCapacity,
                  powerHp: searchResultCar.powerHp,
                  fuel: searchResultCar.fuel,
                  transmission: searchResultCar.transmission,
                  vin: searchResultCar.vin,
                }}
                specs={searchFluidSpecs || {}}
              />

              {/* Navigate to oil selection */}
              {plateSearch.data?.localMatch?.brand && (
                <button
                  onClick={() => {
                    const m = plateSearch.data!.localMatch;
                    if (m?.brand) handleSelectMake(String(m.brand.id), m.brand.name);
                  }}
                  className="w-full py-2.5 bg-white text-gray-900 rounded-lg text-sm font-medium hover:bg-gray-900 transition-colors flex items-center justify-center gap-2"
                >
                  <ChevronRight className="w-4 h-4" />
                  Перейти к подбору масел
                </button>
              )}
            </div>
          )}
        </div>

        {/* BLACK BLOCK */}
        <div className="bg-white rounded-xl p-4 sm:p-6">
          {step === "brands" && (<><h2 className="text-gray-900 text-lg sm:text-xl font-bold mb-1">Поиск транспортного средства</h2><p className="text-gray-500 text-sm mb-4 sm:mb-6">Выберите марку, модель и поколение автомобиля для подбора технических жидкостей</p></>)}

          {/* Breadcrumb */}
          {step !== "brands" && (
            <div className="mb-4 sm:mb-6">
              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 mb-4">
                <div className="w-full sm:w-40 h-28 rounded-lg overflow-hidden bg-gray-50 border border-gray-200 flex-shrink-0 flex items-center justify-center">
                  {selectedModelImage ? <img src={selectedModelImage} alt="" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} /> : <Car className="w-12 h-12 text-[#525252]" />}
                </div>
                <div className="flex-1 grid grid-cols-2 gap-2">
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-2.5"><p className="text-[#737373] text-[10px] uppercase tracking-wider">Марка авто</p><p className="text-gray-900 text-sm font-medium truncate">{selectedMakeName}</p></div>
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-2.5"><p className="text-[#737373] text-[10px] uppercase tracking-wider">Модель авто</p><p className="text-gray-900 text-sm font-medium truncate">{selectedModelName || "—"}</p></div>
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-2.5"><p className="text-[#737373] text-[10px] uppercase tracking-wider">Поколение</p><p className="text-gray-900 text-sm font-medium truncate">{selectedGenName || "—"}</p></div>
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-2.5"><p className="text-[#737373] text-[10px] uppercase tracking-wider">Модификация</p><p className="text-gray-900 text-sm font-medium truncate">{selectedModData?.name || "—"}{selectedModData?.engineCode && ` (${selectedModData.engineCode})`}</p></div>
                </div>
                <button onClick={handleBack} className="bg-gray-50 border border-[#d32f2f] text-[#d32f2f] rounded-lg px-4 py-2 text-sm font-medium hover:bg-gray-100 flex items-center justify-center gap-1 flex-shrink-0 self-start sm:self-auto"><ArrowLeft className="w-4 h-4" />Назад</button>
              </div>
              {step === "generations" && (
                <div className="relative">
                  <button onClick={() => setModOpen(!modOpen)} className="w-full bg-gray-50 border border-gray-200 rounded-lg p-3 text-left flex items-center justify-between hover:border-[#d32f2f] transition-colors">
                    <div><p className="text-[#737373] text-xs">Модификация</p><p className="text-gray-900 text-sm">{selectedModData?.name || "Выберите модификацию"}{selectedModData?.engineCode && ` (${selectedModData.engineCode})`}</p></div>
                    <ChevronDown className={`w-5 h-5 text-[#737373] transition-transform ${modOpen ? "rotate-180" : ""}`} />
                  </button>
                  {modOpen && (
                    <div className="absolute z-20 w-full mt-1 bg-gray-50 border border-gray-200 rounded-lg shadow-2xl max-h-72 overflow-auto">
                      {currentMods.map((mod: any) => (
                        <button key={mod.id} onClick={() => { setSelectedGen(String(mod.id)); setSelectedGenName(mod.name || ""); setModOpen(false); }} className={`w-full text-left px-4 py-3 text-sm hover:bg-gray-100 transition-colors border-b border-gray-200 last:border-0 ${String(mod.id) === selectedGen ? "bg-[#d32f2f]/10 text-[#d32f2f]" : "text-gray-900"}`}>
                          <div className="flex items-center justify-between"><span className="font-medium">{mod.name || "—"}</span>{mod.engineCode && <span className="text-[#d32f2f] text-xs font-mono">{mod.engineCode}</span>}</div>
                          <div className="flex gap-3 mt-1 text-[11px] text-[#737373]">{mod.horsePower && <span>{mod.horsePower} л.с.</span>}{mod.fuel && <span>{mod.fuel}</span>}{mod.cylinder && <span>{mod.cylinder} цил.</span>}</div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Quick search */}
          {step === "brands" && (
            <div className="flex gap-2 mb-4 sm:mb-6">
              <div className="flex-1 relative">
                <Search className="w-4 h-4 text-[#737373] absolute left-3 top-1/2 -translate-y-1/2" />
                <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Быстрый поиск марки..." className="w-full bg-white border border-gray-300 rounded-lg pl-9 pr-3 py-2.5 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:border-[#d32f2f] focus:ring-1 focus:ring-[#d32f2f]" />
              </div>
              {searchQuery && <button onClick={() => setSearchQuery("")} className="px-3 bg-gray-50 border border-gray-200 rounded-lg text-[#737373] hover:text-gray-900"><X className="w-4 h-4" /></button>}
            </div>
          )}

          {/* STEP 1: BRANDS */}
          {step === "brands" && (
            <div>
              {makesError ? (
                <div className="text-center py-8">
                  <p className="text-red-400 text-sm mb-2">Ошибка загрузки: сервер недоступен</p>
                  <button onClick={() => window.location.reload()} className="bg-[#d32f2f] text-white px-4 py-2 rounded-lg text-sm">Обновить</button>
                </div>
              ) : makesLoading ? (
                <div className="flex justify-center py-12"><div className="w-8 h-8 border-2 border-[#d32f2f] border-t-transparent rounded-full animate-spin" /></div>
              ) : (
                <>
                  <div className="grid grid-cols-3 gap-2 sm:gap-3">
                    {(showAllMakes || searchQuery ? filteredMakes : displayedMakes).map((make: any) => (
                      <button key={make.id} onClick={() => handleSelectMake(String(make.id), make.name || "")} className={`rounded-xl p-3 sm:p-4 flex flex-col items-center gap-2 sm:gap-3 border transition-all active:scale-[0.97] group ${selectedMake === String(make.id) ? "bg-[#d32f2f] border-[#d32f2f] text-white" : "bg-white border-gray-200 hover:border-[#d32f2f] hover:bg-[#fff0f0]"}`}>
                        <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full border flex items-center justify-center transition-colors overflow-hidden ${selectedMake === String(make.id) ? "bg-white border-white" : "bg-gray-50 border-gray-200 group-hover:border-[#d32f2f]/50"}`}>
                          {logoMap.get((make.name || "").toLowerCase()) ? (
                            <img
                              src={logoMap.get((make.name || "").toLowerCase())!}
                              alt={make.name || ""}
                              className="w-3/4 h-3/4 object-contain"
                              loading="lazy"
                              onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                            />
                          ) : (
                            <span className={`text-lg sm:text-xl font-bold ${selectedMake === String(make.id) ? "text-[#d32f2f]" : "text-[#d32f2f]"}`}>{getFirstLetter(make.name || "")}</span>
                          )}
                        </div>
                        <span className={`text-xs sm:text-sm font-medium text-center leading-tight ${selectedMake === String(make.id) ? "text-white" : "text-gray-900"}`}>{make.name}</span>
                      </button>
                    ))}
                  </div>
                  {!showAllMakes && !searchQuery && (
                    <button onClick={() => setShowAllMakes(true)} className="w-full mt-4 py-3 border border-gray-200 rounded-lg text-sm text-gray-500 hover:border-[#d32f2f] hover:text-[#d32f2f] transition-colors">Показать все марки ({makes?.length || 0})</button>
                  )}
                  {showAllMakes && !searchQuery && (
                    <button onClick={() => setShowAllMakes(false)} className="w-full mt-4 py-3 border border-gray-200 rounded-lg text-sm text-gray-500 hover:border-[#d32f2f] hover:text-[#d32f2f] transition-colors">Показать избранные (9)</button>
                  )}
                </>
              )}
            </div>
          )}

          {/* STEP 2: MODELS */}
          {step === "models" && (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 sm:gap-3">
              {models?.map((model: any) => (
                <button key={model.modelId} onClick={() => handleSelectModel(String(model.modelId), model.modelName || "", model.imageUrl)} className="bg-white rounded-xl overflow-hidden hover:shadow-lg hover:scale-[1.02] transition-all active:scale-[0.98]">
                  <div className="h-20 sm:h-24 bg-white flex items-center justify-center overflow-hidden">
                    {model.imageUrl ? <img src={model.imageUrl} alt={model.modelName || ""} className="w-full h-full object-cover" loading="lazy" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} /> : <Car className="w-10 h-10 sm:w-12 sm:h-12 text-gray-600" />}
                  </div>
                  <div className="bg-gray-50 px-2 py-2"><p className="text-gray-900 text-[11px] sm:text-xs font-medium text-center truncate">{model.modelName}</p></div>
                </button>
              ))}
              {(!models || models.length === 0) && <div className="col-span-full text-center py-12 text-[#737373] text-sm">Модели не найдены</div>}
            </div>
          )}

          {/* STEP 3: GENERATIONS */}
          {step === "generations" && (
            <div className="space-y-3">
              {/* Filters */}
              <div className="bg-white rounded-xl p-3 space-y-2">
                <p className="text-xs text-gray-500 font-medium flex items-center gap-1"><SlidersHorizontal className="w-3 h-3" />Фильтры</p>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  <select value={bodyFilter} onChange={(e) => setBodyFilter(e.target.value)} className="border border-gray-200 rounded-lg px-2 py-1.5 text-xs text-gray-700 focus:outline-none focus:border-[#d32f2f]">
                    <option value="">Кузов</option>
                    <option value="Седан">Седан</option>
                    <option value="Хэтчбек">Хэтчбек</option>
                    <option value="Универсал">Универсал</option>
                    <option value="Внедорожник">Внедорожник</option>
                    <option value="Кроссовер">Кроссовер</option>
                    <option value="Купе">Купе</option>
                    <option value="Кабриолет">Кабриолет</option>
                    <option value="Минивэн">Минивэн</option>
                    <option value="Пикап">Пикап</option>
                  </select>
                  <select value={fuelFilter} onChange={(e) => setFuelFilter(e.target.value)} className="border border-gray-200 rounded-lg px-2 py-1.5 text-xs text-gray-700 focus:outline-none focus:border-[#d32f2f]">
                    <option value="">Топливо</option>
                    <option value="Бензин">Бензин</option>
                    <option value="Дизель">Дизель</option>
                    <option value="Гибрид">Гибрид</option>
                    <option value="Электро">Электро</option>
                    <option value="ГБО">ГБО</option>
                  </select>
                  <select value={transmissionFilter} onChange={(e) => setTransmissionFilter(e.target.value)} className="border border-gray-200 rounded-lg px-2 py-1.5 text-xs text-gray-700 focus:outline-none focus:border-[#d32f2f]">
                    <option value="">КПП</option>
                    <option value="АКПП">АКПП</option>
                    <option value="МКПП">МКПП</option>
                    <option value="Вариатор">Вариатор</option>
                    <option value="Робот">Робот</option>
                  </select>
                  <input type="number" placeholder="Год от" value={yearFromFilter} onChange={(e) => setYearFromFilter(e.target.value)} className="border border-gray-200 rounded-lg px-2 py-1.5 text-xs text-gray-700 focus:outline-none focus:border-[#d32f2f]" />
                  <input type="number" placeholder="Год до" value={yearToFilter} onChange={(e) => setYearToFilter(e.target.value)} className="border border-gray-200 rounded-lg px-2 py-1.5 text-xs text-gray-700 focus:outline-none focus:border-[#d32f2f]" />
                </div>
                {(bodyFilter || fuelFilter || transmissionFilter || yearFromFilter || yearToFilter) && (
                  <button onClick={() => { setBodyFilter(""); setFuelFilter(""); setTransmissionFilter(""); setYearFromFilter(""); setYearToFilter(""); }} className="text-xs text-[#d32f2f] hover:underline">Сбросить фильтры</button>
                )}
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 sm:gap-3">
                {filteredMods.map((mod: any) => {
                  const years = [];
                  if (mod.startDate) { const m = mod.startDate.match(/(\d{4})/); if (m) years.push(m[1]); }
                  if (mod.endDate) { const m = mod.endDate.match(/(\d{4})/); if (m) years.push(m[1]); }
                  else if (years.length > 0) years.push("н.в.");
                  const yearStr = years.join(" — ");
                  return (
                    <button key={mod.id} onClick={() => handleSelectGen(String(mod.id), mod.name || "")} className="bg-white rounded-xl overflow-hidden hover:shadow-lg hover:scale-[1.02] transition-all active:scale-[0.98]">
                      <div className="h-20 sm:h-24 bg-[#f5f5f5] flex items-center justify-center relative">
                        <Car className="w-10 h-10 sm:w-12 sm:h-12 text-gray-600" />
                        {mod.body && <span className="absolute bottom-1 right-1 text-[9px] bg-gray-800/60 text-gray-900 px-1 rounded">{mod.body}</span>}
                      </div>
                      <div className="bg-gray-50 px-2 py-2">
                        <p className="text-gray-900 text-[11px] sm:text-xs font-medium text-center truncate">{mod.name || "—"}</p>
                        {yearStr && <p className="text-[#737373] text-[10px] text-center">{yearStr}</p>}
                        <div className="flex justify-center gap-1 mt-1">
                          {mod.fuel && <span className="text-[9px] bg-[#404040] text-gray-500 px-1 rounded">{mod.fuel}</span>}
                          {mod.transmission && <span className="text-[9px] bg-[#404040] text-gray-500 px-1 rounded">{mod.transmission}</span>}
                        </div>
                      </div>
                    </button>
                  );
                })}
                {filteredMods.length === 0 && <div className="col-span-full text-center py-12 text-[#737373] text-sm">Нет авто по фильтрам — сбросьте фильтры</div>}
              </div>
            </div>
          )}

          {/* STEP 4: RESULT */}
          {step === "result" && (
            <div className="space-y-4">
              <div className="bg-white rounded-xl p-4 flex items-center gap-4">
                <div className="w-16 h-16 rounded-xl bg-[#f5f5f5] flex items-center justify-center flex-shrink-0 overflow-hidden border border-[#e5e5e5]">
                  {selectedModelImage ? <img src={selectedModelImage} alt="" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} /> : <span className="text-[#d32f2f] text-2xl font-bold">{getFirstLetter(selectedMakeName)}</span>}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[#1a1a1a] font-bold text-base">{selectedMakeName} {selectedModelName}</p>
                  <p className="text-[#737373] text-sm">{selectedGenName}</p>
                  <div className="flex flex-wrap gap-x-3 gap-y-1 mt-1 text-xs text-[#525252]">
                    {selectedModData?.engineCode && <span className="text-[#d32f2f] font-mono font-medium">{selectedModData.engineCode}</span>}
                    {selectedModData?.horsePower && <span>{selectedModData.horsePower} л.с.</span>}
                    {selectedModData?.cylinder && <span>{selectedModData.cylinder} цил.</span>}
                    {selectedModData?.fuel && <span>{selectedModData.fuel}</span>}
                  </div>
                </div>
              </div>

              {/* Aggregation Tabs */}
              <div className="bg-gray-50 rounded-xl overflow-hidden">
                <div className="flex overflow-x-auto scrollbar-hide border-b border-gray-200">
                  {AGGR_TABS.map((tab) => { const Icon = tab.icon; return (
                    <button key={tab.key} onClick={() => setAggrTab(tab.key)} className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap ${aggrTab === tab.key ? "text-[#d32f2f] border-b-2 border-[#d32f2f] bg-[#d32f2f]/10" : "text-gray-500 hover:text-gray-900"}`}>
                      <Icon className="w-4 h-4" />{tab.label}<span className={`text-xs ml-0.5 ${aggrTab === tab.key ? "text-[#d32f2f]" : "text-[#737373]"}`}>({tab.count})</span>
                    </button>
                  ); })}
                </div>
                <div className="flex items-center gap-2 px-4 py-3 border-b border-gray-200 overflow-x-auto">
                  {SUB_FILTERS.map((f) => (
                    <button key={f.key} onClick={() => setSubFilter(f.key)} className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${subFilter === f.key ? "bg-[#d32f2f] text-white" : "bg-white text-gray-500 border border-gray-200 hover:border-[#d32f2f] hover:text-gray-900"}`}>{f.label}</button>
                  ))}
                </div>
                <div className="p-4">
                  {oils && oils.length > 0 ? (
                    <div className="space-y-2">
                      {oils.map((oil: any, i: number) => (
                        <div key={oil.id || i} className="bg-white border border-gray-200 rounded-lg p-4 hover:border-[#d32f2f]/50 transition-colors">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1"><Droplets className="w-4 h-4 text-[#d32f2f] flex-shrink-0" /><p className="text-gray-900 text-sm font-medium truncate">{oil.originalName || oil.name || "—"}</p></div>
                              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-[#737373]">
                                {oil.artNumber && <span className="font-mono text-gray-500">{oil.artNumber}</span>}
                                {oil.volume && <span className="text-[#d32f2f] font-medium">{oil.volume}</span>}
                                {oil.specifications && <span>{oil.specifications}</span>}
                              </div>
                              {oil.oemApproval && (
                                <div className="mt-1 flex flex-wrap gap-1">
                                  {oil.oemApproval.split(/[,;]/).map((o: string, idx: number) => (
                                    <span key={idx} className="text-[10px] bg-gray-50 text-gray-500 px-1.5 py-0.5 rounded border border-gray-200">{o.trim()}</span>
                                  ))}
                                </div>
                              )}
                            </div>
                            <span className="text-[#525252] text-xs flex-shrink-0">#{i + 1}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-12 text-center"><Droplets className="w-10 h-10 mx-auto mb-3 text-[#525252]" /><p className="text-[#737373] text-sm">Данные не найдены для выбранного фильтра</p><p className="text-[#525252] text-xs mt-1">Попробуйте изменить агрегацию или сбросить фильтры</p></div>
                  )}
                </div>
              </div>

              {/* Owner Manuals */}
              {manuals && manuals.length > 0 && (
                <div className="bg-gray-50 rounded-xl overflow-hidden">
                  <div className="flex items-center gap-2 px-4 py-3 border-b border-gray-200">
                    <BookOpen className="w-4 h-4 text-[#d32f2f]" />
                    <h3 className="text-gray-900 text-sm font-medium">Руководства по эксплуатации</h3>
                    <span className="text-[#737373] text-xs ml-1">({manuals.length})</span>
                  </div>
                  <div className="p-4 space-y-2">
                    {manuals.map((manual: any) => (
                      <a
                        key={manual.id}
                        href={manual.pdfUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 bg-white border border-gray-200 rounded-lg p-3 hover:border-[#d32f2f]/50 transition-colors group"
                      >
                        <div className="w-10 h-10 rounded-lg bg-[#333] flex items-center justify-center flex-shrink-0">
                          <BookOpen className="w-5 h-5 text-[#737373] group-hover:text-[#d32f2f] transition-colors" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-gray-900 text-sm font-medium truncate">{manual.title || `Руководство ${manual.make} ${manual.model}`}</p>
                          <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-[#737373]">
                            {manual.source && <span>{manual.source}</span>}
                            <span className="text-gray-500">{manual.language === "ru" ? "Русский" : manual.language === "en" ? "English" : manual.language}</span>
                            {manual.isOfficial === "yes" && <span className="text-[#d32f2f] font-medium">Официальное</span>}
                            {manual.yearFrom && <span>{manual.yearFrom}{manual.yearTo ? `-${manual.yearTo}` : "+"}</span>}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <ExternalLink className="w-4 h-4 text-[#525252] group-hover:text-[#d32f2f] transition-colors" />
                        </div>
                      </a>
                    ))}
                  </div>
                </div>
              )}

              <button onClick={handleBack} className="w-full py-3 rounded-xl text-sm font-medium bg-gray-50 border border-[#d32f2f] text-[#d32f2f] hover:bg-[#d32f2f]/10 transition-colors"><ArrowLeft className="w-4 h-4 inline mr-2" />Назад к выбору</button>
            </div>
          )}
        </div>

        <footer className="mt-8 sm:mt-12 py-6 text-center text-gray-500 text-xs border-t border-[#d4d4d4]">
          <p className="font-medium text-[#737373]">oilpodbor — система подбора технических жидкостей</p>
          <p className="mt-1">2025 Все права защищены</p>
        </footer>
      </main>
    </div>
  );
}