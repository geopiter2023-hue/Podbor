import type { Hono } from "hono";
import type { HttpBindings } from "@hono/node-server";
import { serveStatic } from "@hono/node-server/serve-static";
import fs from "fs";
import path from "path";

type App = Hono<{ Bindings: HttpBindings }>;

export function serveStaticFiles(app: App) {
  // Absolute path to dist/public (works regardless of cwd)
  const distPath = path.resolve(import.meta.dirname, "../dist/public");

  console.log("[serveStatic] distPath:", distPath);
  console.log("[serveStatic] index.html exists:", fs.existsSync(path.join(distPath, "index.html")));

  // SPA-aware static file serving:
  // - API routes go through unchanged
  // - File requests (with extensions) are served from disk
  // - All other routes (SPA routes like /admin, /login) get index.html
  app.use("*", serveStatic({
    root: distPath,
    rewriteRequestPath: (reqPath) => {
      // API routes — don't rewrite, let them pass through
      if (reqPath.startsWith("/api/")) return reqPath;

      // Static assets (files with extensions) — serve as-is
      if (reqPath.includes(".") && !reqPath.endsWith("/")) return reqPath;

      // SPA routes (/admin, /login, etc.) — serve index.html
      return "/index.html";
    },
  }));
}
