import { getDb } from "../queries/connection";
import { carFluidSpecs, aiLogs, systemSettings } from "@db/schema";
import { eq, like, and, desc } from "drizzle-orm";
import { getSetting } from "../lib/env";

export interface AgentConfig {
  name: string;
  provider: "anthropic" | "openai" | "perplexity" | "gemini" | "groq" | "deepseek" | "mistral" | "cohere" | "yandex" | "gigachat" | "vsegpt" | "manual";
  model: string;
  prompt: string;
  enabled: boolean;
}

const BASE_PROMPT = `Car: {make} {model} {engine}. Return ONLY JSON:
{"engine":{"oilVolume":"X","oilSae":"5W-30","oilApi":"SN","oilAcea":"C3","oilOem":"","replaceInterval":""},"transmission":{"type":"","code":"","oilVolume":"","oilSpec":"","replaceInterval":""},"cooling":{"coolantVolume":"","coolantType":"","replaceInterval":""},"brakes":{"fluidVolume":"","fluidType":"","replaceInterval":""},"differentials":{"front":{"volume":"","oil":""},"rear":{"volume":"","oil":""}},"filters":{"oil":"","air":"","cabin":"","fuel":""}}
All values as strings. oilVolume/coolantVolume in liters.`;

// Default agent configs — ALL providers
export const DEFAULT_AGENTS: Record<string, AgentConfig> = {
  "perplexity": {
    name: "Perplexity ($50)",
    provider: "perplexity",
    model: "sonar",
    prompt: BASE_PROMPT,
    enabled: true,
  },
  "anthropic": {
    name: "Anthropic Claude",
    provider: "anthropic",
    model: "claude-3-5-haiku-20241022",
    prompt: BASE_PROMPT,
    enabled: true,
  },
  "openai": {
    name: "OpenAI GPT",
    provider: "openai",
    model: "gpt-3.5-turbo",
    prompt: BASE_PROMPT,
    enabled: true,
  },
  "gemini": {
    name: "Google Gemini (бесплатно)",
    provider: "gemini",
    model: "gemini-2.0-flash-lite",
    prompt: BASE_PROMPT,
    enabled: true,
  },
  "groq": {
    name: "Groq (бесплатно)",
    provider: "groq",
    model: "llama3-8b-8192",
    prompt: BASE_PROMPT,
    enabled: true,
  },
  "deepseek": {
    name: "DeepSeek (дешёвый)",
    provider: "deepseek",
    model: "deepseek-chat",
    prompt: BASE_PROMPT,
    enabled: true,
  },
  "mistral": {
    name: "Mistral AI",
    provider: "mistral",
    model: "mistral-tiny",
    prompt: BASE_PROMPT,
    enabled: true,
  },
  "cohere": {
    name: "Cohere",
    provider: "cohere",
    model: "command-r",
    prompt: BASE_PROMPT,
    enabled: true,
  },
  "yandex": {
    name: "Yandex GPT",
    provider: "yandex",
    model: "yandexgpt-lite",
    prompt: BASE_PROMPT,
    enabled: true,
  },
  "gigachat": {
    name: "GigaChat (Сбер)",
    provider: "gigachat",
    model: "GigaChat",
    prompt: BASE_PROMPT,
    enabled: true,
  },
  "vsegpt": {
    name: "VseGPT.ru (RuLLM)",
    provider: "vsegpt",
    model: "meta-llama/llama-3.1-70b-instruct",
    prompt: BASE_PROMPT,
    enabled: true,
  },
  "manual": {
    name: "Ручной ввод",
    provider: "manual",
    model: "",
    prompt: "",
    enabled: true,
  },
};

/**
 * Run research with flexible agent configuration
 */
export async function runFlexibleResearch(payload: {
  make: string;
  model: string;
  engineCode?: string;
  year?: number;
  modification?: string;
  agentId?: string;
}) {
  const startTime = Date.now();
  const v = payload;

  // Get agent config
  const agentConfig = await getAgentConfig(payload.agentId || "oil-master");

  console.log(`[FlexibleResearch] Agent: ${agentConfig.name}, Provider: ${agentConfig.provider}, Mod: ${v.modification || "none"}`);

  // If manual mode — just create empty record
  if (agentConfig.provider === "manual") {
    return createEmptyRecord(v);
  }

  // Build prompt with modification context
  const modContext = v.modification ? `Modification/Trim: ${v.modification}. ` : "";
  const prompt = agentConfig.prompt
    .replace(/{make}/g, v.make)
    .replace(/{model}/g, v.model)
    .replace(/{engine}/g, v.engineCode || "")
    .replace(/{year}/g, String(v.year || ""))
    .replace(/{modification}/g, v.modification || "");

  // Append modification context for more precise search
  const enhancedPrompt = prompt.includes("{modification}") ? prompt : `${modContext}${prompt}`;

  // Call API based on provider
  let aiText = "";
  let tokensUsed = { input: 0, output: 0 };
  let source = "none";

  try {
    switch (agentConfig.provider) {
      case "anthropic":
        ({ text: aiText, tokens: tokensUsed, source } = await callAnthropic(prompt, agentConfig.model));
        break;
      case "openai":
        ({ text: aiText, tokens: tokensUsed, source } = await callOpenAI(prompt, agentConfig.model));
        break;
      case "perplexity":
        ({ text: aiText, tokens: tokensUsed, source } = await callPerplexity(prompt, agentConfig.model));
        break;
      case "gemini":
        ({ text: aiText, tokens: tokensUsed, source } = await callGemini(prompt, agentConfig.model));
        break;
      case "groq":
        ({ text: aiText, tokens: tokensUsed, source } = await callGroq(prompt, agentConfig.model));
        break;
      case "deepseek":
        ({ text: aiText, tokens: tokensUsed, source } = await callDeepSeek(prompt, agentConfig.model));
        break;
      case "mistral":
        ({ text: aiText, tokens: tokensUsed, source } = await callMistral(prompt, agentConfig.model));
        break;
      case "cohere":
        ({ text: aiText, tokens: tokensUsed, source } = await callCohere(prompt, agentConfig.model));
        break;
      case "yandex":
        ({ text: aiText, tokens: tokensUsed, source } = await callYandex(prompt, agentConfig.model));
        break;
      case "gigachat":
        ({ text: aiText, tokens: tokensUsed, source } = await callGigaChat(prompt, agentConfig.model));
        break;
      case "vsegpt":
        ({ text: aiText, tokens: tokensUsed, source } = await callVseGPT(prompt, agentConfig.model));
        break;
    }
  } catch (e: any) {
    console.error(`[FlexibleResearch] ${agentConfig.provider} error:`, e.message);
    return { error: e.message, source: "none", recordId: 0, filledFields: [] as string[], tokensUsed };
  }

  // Parse response
  const parsed = parseAIResponse(aiText);

  // Build filled fields list
  const filledFields: string[] = [];
  const d = parsed;

  const addField = (val: any, name: string) => {
    if (val && String(val).trim() !== "" && String(val).trim() !== "X") {
      filledFields.push(name);
    }
  };

  addField(d.engine?.oilVolume, "Объём масла");
  addField(d.engine?.oilSae, "SAE");
  addField(d.engine?.oilApi, "API");
  addField(d.engine?.oilAcea, "ACEA");
  addField(d.engine?.oilOem, "OEM");
  addField(d.transmission?.type, "Тип КПП");
  addField(d.transmission?.oilVolume, "Объём КПП");
  addField(d.transmission?.oilSpec, "Масло КПП");
  addField(d.cooling?.coolantVolume, "Объём антифриза");
  addField(d.cooling?.coolantType, "Тип антифриза");
  addField(d.brakes?.fluidType, "Тормозная жидкость");
  addField(d.differentials?.front?.volume, "Дифф. передний");
  addField(d.differentials?.rear?.volume, "Дифф. задний");
  addField(d.filters?.oil, "Фильтр масляный");

  // Save to DB
  const db = getDb();
  const mod = v.modification || `${v.make} ${v.model} ${v.engineCode || ""}`.trim();

  const [existing] = await db
    .select()
    .from(carFluidSpecs)
    .where(and(like(carFluidSpecs.make, `%${v.make}%`), like(carFluidSpecs.model, `%${v.model}%`)))
    .limit(1);

  let recordId: number;

  const updateData = {
    vehicleType: "Легковой автомобиль" as const,
    modification: mod,
    engineCode: v.engineCode || existing?.engineCode,
    engineFillVolume: d.engine?.oilVolume || existing?.engineFillVolume,
    prefOilSae: d.engine?.oilSae || existing?.prefOilSae,
    prefOilApi: d.engine?.oilApi || existing?.prefOilApi,
    prefOilAcea: d.engine?.oilAcea || existing?.prefOilAcea,
    prefOilOe: d.engine?.oilOem || existing?.prefOilOe,
    transmissionType: d.transmission?.type || existing?.transmissionType,
    transmissionFillVolume: d.transmission?.oilVolume || existing?.transmissionFillVolume,
    transmissionPrefOil: d.transmission?.oilSpec || existing?.transmissionPrefOil,
    coolantFillVolume: d.cooling?.coolantVolume || existing?.coolantFillVolume,
    coolantType: d.cooling?.coolantType || existing?.coolantType,
    brakeFluidType: d.brakes?.fluidType || existing?.brakeFluidType,
    frontDiffFillVolume: d.differentials?.front?.volume || existing?.frontDiffFillVolume,
    frontDiffOil: d.differentials?.front?.oil || existing?.frontDiffOil,
    rearDiffFillVolume: d.differentials?.rear?.volume || existing?.rearDiffFillVolume,
    rearDiffOil: d.differentials?.rear?.oil || existing?.rearDiffOil,
    oilFilter: d.filters?.oil || existing?.oilFilter,
    airFilter: d.filters?.air || existing?.airFilter,
    cabinFilter: d.filters?.cabin || existing?.cabinFilter,
    fuelFilter: d.filters?.fuel || existing?.fuelFilter,
    importBatch: `ai_${source}`,
    updatedAt: new Date(),
  };

  if (existing) {
    await db.update(carFluidSpecs).set(updateData).where(eq(carFluidSpecs.id, existing.id));
    recordId = existing.id;
  } else {
    const [inserted] = await db.insert(carFluidSpecs).values({
      make: v.make,
      model: v.model,
      ...updateData,
    }).$returningId();
    recordId = inserted.id;
  }

  // Log
  try {
    await db.insert(aiLogs).values({
      make: v.make,
      model: v.model,
      query: prompt.substring(0, 300),
      rawResponse: aiText.substring(0, 2000),
      parsedJson: parsed,
      filledFields,
      tokensInput: tokensUsed.input,
      tokensOutput: tokensUsed.output,
      source,
      durationMs: Date.now() - startTime,
    });
  } catch { /* ignore */ }

  return {
    recordId,
    source,
    confidence: filledFields.length > 5 ? "high" : filledFields.length > 0 ? "medium" : "low",
    tokensUsed,
    filledFields,
    rawResponse: aiText.substring(0, 5000),
    error: filledFields.length === 0 ? "AI вернул пустой ответ" : undefined,
  };
}

// ─── API Callers ───

async function callAnthropic(prompt: string, model: string) {
  const apiKey = await getSetting("anthropic_api_key");
  if (!apiKey) throw new Error("Anthropic API key not configured");

  // Clean key: remove sk-ant-api03- prefix if present for validation
  const cleanKey = apiKey.startsWith("sk-ant") ? apiKey : apiKey;

  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": cleanKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: model || "claude-3-5-haiku-20241022",
      max_tokens: 2000,
      messages: [{ role: "user", content: prompt + "\n\nReturn ONLY JSON. No markdown." }],
    }),
    // @ts-ignore
    dispatcher: undefined, // use default
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Anthropic ${resp.status}: ${err.substring(0, 300)}`);
  }

  const data = await resp.json();
  return {
    text: data.content?.[0]?.text || "",
    tokens: { input: data.usage?.input_tokens || 0, output: data.usage?.output_tokens || 0 },
    source: "claude",
  };
}

async function callOpenAI(prompt: string, model: string) {
  const apiKey = await getSetting("openai_api_key");
  if (!apiKey) throw new Error("OpenAI API key not configured");

  const resp = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: "Return ONLY JSON. No markdown, no explanation." },
        { role: "user", content: prompt },
      ],
      temperature: 0.1,
      max_tokens: 1500,
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`OpenAI ${resp.status}: ${err.substring(0, 200)}`);
  }

  const data = await resp.json();
  return {
    text: data.choices?.[0]?.message?.content || "",
    tokens: { input: data.usage?.prompt_tokens || 0, output: data.usage?.completion_tokens || 0 },
    source: "openai",
  };
}

async function callPerplexity(prompt: string, model: string) {
  const apiKey = await getSetting("perplexity_api_key");
  if (!apiKey) throw new Error("Perplexity API key not configured");

  const resp = await fetch("https://api.perplexity.ai/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: model || "sonar",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1500,
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Perplexity ${resp.status}: ${err.substring(0, 200)}`);
  }

  const data = await resp.json();
  return {
    text: data.choices?.[0]?.message?.content || "",
    tokens: { input: data.usage?.prompt_tokens || 0, output: data.usage?.completion_tokens || 0 },
    source: "perplexity",
  };
}

async function callGroq(prompt: string, model: string) {
  const apiKey = await getSetting("groq_api_key");
  if (!apiKey) throw new Error("Groq API key not configured");

  // Use llama-3.1-8b-instant as default (reliable, fast)
  const resp = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: model || "llama-3.1-8b-instant",
      messages: [
        { role: "system", content: "Return ONLY JSON. No markdown, no explanation." },
        { role: "user", content: prompt + "\n\nReturn ONLY JSON. No markdown." },
      ],
      temperature: 0.1,
      max_tokens: 1500,
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Groq ${resp.status}: ${err.substring(0, 300)}`);
  }

  const data = await resp.json();
  return {
    text: data.choices?.[0]?.message?.content || "",
    tokens: { input: data.usage?.prompt_tokens || 0, output: data.usage?.completion_tokens || 0 },
    source: "groq",
  };
}

async function callDeepSeek(prompt: string, model: string) {
  const apiKey = await getSetting("deepseek_api_key");
  if (!apiKey) throw new Error("DeepSeek API key not configured");

  const resp = await fetch("https://api.deepseek.com/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: model || "deepseek-chat",
      messages: [
        { role: "system", content: "Return ONLY JSON. No markdown, no explanation." },
        { role: "user", content: prompt },
      ],
      temperature: 0.1,
      max_tokens: 1500,
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`DeepSeek ${resp.status}: ${err.substring(0, 200)}`);
  }

  const data = await resp.json();
  return {
    text: data.choices?.[0]?.message?.content || "",
    tokens: { input: data.usage?.prompt_tokens || 0, output: data.usage?.completion_tokens || 0 },
    source: "deepseek",
  };
}

async function callMistral(prompt: string, model: string) {
  const apiKey = await getSetting("mistral_api_key");
  if (!apiKey) throw new Error("Mistral API key not configured");

  const resp = await fetch("https://api.mistral.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: model || "mistral-tiny",
      messages: [
        { role: "system", content: "Return ONLY JSON. No markdown." },
        { role: "user", content: prompt },
      ],
      temperature: 0.1,
      max_tokens: 1500,
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Mistral ${resp.status}: ${err.substring(0, 200)}`);
  }

  const data = await resp.json();
  return {
    text: data.choices?.[0]?.message?.content || "",
    tokens: { input: data.usage?.prompt_tokens || 0, output: data.usage?.completion_tokens || 0 },
    source: "mistral",
  };
}

async function callCohere(prompt: string, model: string) {
  const apiKey = await getSetting("cohere_api_key");
  if (!apiKey) throw new Error("Cohere API key not configured");

  const resp = await fetch("https://api.cohere.ai/v1/chat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: model || "command-r",
      message: prompt + "\n\nReturn ONLY JSON. No markdown.",
      temperature: 0.1,
      max_tokens: 1500,
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Cohere ${resp.status}: ${err.substring(0, 200)}`);
  }

  const data = await resp.json();
  return {
    text: data.text || "",
    tokens: { input: 0, output: 0 }, // Cohere v1 doesn't always return tokens
    source: "cohere",
  };
}

async function callGemini(prompt: string, model: string) {
  const apiKey = await getSetting("gemini_api_key");
  if (!apiKey) throw new Error("Gemini API key not configured");

  const m = model || "gemini-2.0-flash-lite";
  const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt + "\n\nReturn ONLY JSON. No markdown." }] }],
      generationConfig: { temperature: 0.1, maxOutputTokens: 1500 },
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Gemini ${resp.status}: ${err.substring(0, 300)}`);
  }

  const data = await resp.json();
  // Handle both old and new response formats
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text
    || data.candidates?.[0]?.content?.text
    || "";
  return {
    text,
    tokens: {
      input: data.usageMetadata?.promptTokenCount || 0,
      output: data.usageMetadata?.candidatesTokenCount || 0,
    },
    source: "gemini",
  };
}

// ─── Russian AI Providers ───

async function callYandex(prompt: string, model: string) {
  const apiKey = await getSetting("yandex_api_key");
  const folderId = await getSetting("yandex_folder_id");
  if (!apiKey) throw new Error("Yandex API key not configured");
  if (!folderId) throw new Error("Yandex Folder ID not configured");

  // Use completion API (synchronous, non-streaming)
  const modelUri = `gpt://${folderId}/${model || "yandexgpt-lite"}`;

  const resp = await fetch("https://llm.api.cloud.yandex.net/foundationModels/v1/completion", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Api-Key ${apiKey}`,
      "x-folder-id": folderId,
    },
    body: JSON.stringify({
      modelUri,
      completionOptions: {
        stream: false,
        temperature: 0.1,
        maxTokens: "2000",
      },
      messages: [
        { role: "system", text: "You are a car technical data assistant. Return ONLY valid JSON with car fluid specifications. All values must be strings." },
        { role: "user", text: prompt + "\n\nReturn ONLY JSON. No markdown." },
      ],
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Yandex ${resp.status}: ${err.substring(0, 300)}`);
  }

  const data = await resp.json();
  const text = data.result?.alternatives?.[0]?.message?.text
    || data.result?.alternatives?.[0]?.text
    || "";
  const tokensInput = data.result?.usage?.inputTextTokens || 0;
  const tokensOutput = data.result?.usage?.completionTokens || 0;

  return { text, tokens: { input: tokensInput, output: tokensOutput }, source: "yandex" };
}

async function callGigaChat(prompt: string, model: string) {
  // Use VseGPT as proxy for GigaChat (avoids Sber SSL issues)
  const vsegptKey = await getSetting("vsegpt_api_key");
  if (vsegptKey) {
    try {
      return await callVseGPT(prompt, "openai/gigachat", vsegptKey);
    } catch { /* fallback to direct */ }
  }

  const clientSecret = await getSetting("gigachat_client_secret");
  if (!clientSecret) throw new Error("GigaChat: no key configured");

  // Use axios to bypass SSL cert issues with Sber endpoints
  const { default: axios } = await import("axios");
  const https = await import("https");
  const agent = new https.Agent({ rejectUnauthorized: false });

  // Step 1: Get access token
  const tokenResp = await axios.post(
    "https://ngw.devices.sberbank.ru:9443/api/v2/oauth",
    "scope=GIGACHAT_API_PERS",
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
        "RqUID": crypto.randomUUID(),
        "Authorization": `Bearer ${clientSecret}`,
      },
      httpsAgent: agent,
      timeout: 15000,
    }
  );

  const accessToken = tokenResp.data.access_token;

  // Step 2: Send completion
  const resp = await axios.post(
    "https://gigachat.devices.sberbank.ru/api/v1/chat/completions",
    {
      model: model || "GigaChat",
      messages: [
        { role: "system", content: "You are a car technical data assistant. Return ONLY valid JSON with car fluid specifications. All values must be strings." },
        { role: "user", content: prompt + "\n\nReturn ONLY JSON. No markdown." },
      ],
      temperature: 0.1,
      max_tokens: 1500,
    },
    {
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${accessToken}`,
      },
      httpsAgent: agent,
      timeout: 30000,
    }
  );

  const data = resp.data;
  return {
    text: data.choices?.[0]?.message?.content || "",
    tokens: {
      input: data.usage?.prompt_tokens || 0,
      output: data.usage?.completion_tokens || 0,
    },
    source: "gigachat",
  };
}

async function callVseGPT(prompt: string, model: string, externalKey?: string) {
  const apiKey = externalKey || await getSetting("vsegpt_api_key");
  if (!apiKey) throw new Error("VseGPT API key not configured");

  // Try models in order: requested, GigaChat (via VseGPT), Llama, Qwen
  const modelsToTry = [
    model || "",
    "openai/gigachat",
    "meta-llama/llama-3.1-70b-instruct",
    "qwen/qwen-2.5-72b-instruct",
  ].filter(Boolean);

  let lastError = "";
  for (const m of modelsToTry) {
    try {
      const resp = await fetch("https://api.vsegpt.ru/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: m,
          messages: [
            { role: "system", content: "You are a car technical data assistant. Return ONLY valid JSON. No markdown." },
            { role: "user", content: prompt + "\n\nReturn ONLY JSON. No markdown." },
          ],
          temperature: 0.1,
          max_tokens: 1500,
        }),
      });

      if (!resp.ok) {
        const err = await resp.text();
        lastError = `VseGPT(${m}) ${resp.status}: ${err.substring(0, 200)}`;
        console.log(`[FlexibleResearch] ${lastError}`);
        continue;
      }

      const data = await resp.json();
      return {
        text: data.choices?.[0]?.message?.content || "",
        tokens: {
          input: data.usage?.prompt_tokens || 0,
          output: data.usage?.completion_tokens || 0,
        },
        source: "vsegpt",
      };
    } catch (e: any) {
      lastError = `VseGPT(${m}): ${e.message}`;
      console.log(`[FlexibleResearch] ${lastError}`);
      continue;
    }
  }

  throw new Error(lastError || "VseGPT: all models failed");
}

// ─── Helpers ───

function parseAIResponse(text: string): any {
  try {
    let clean = text.trim();
    if (clean.startsWith("```")) {
      clean = clean.replace(/```[a-z]*\n?/, "").replace(/\n?```$/, "").trim();
    }
    const m = clean.match(/\{[\s\S]*\}/);
    if (!m) return {};
    return JSON.parse(m[0]);
  } catch {
    return {};
  }
}

async function createEmptyRecord(v: { make: string; model: string; engineCode?: string; modification?: string }) {
  const db = getDb();
  const mod = v.modification || `${v.make} ${v.model}`.trim();

  const [existing] = await db
    .select()
    .from(carFluidSpecs)
    .where(and(like(carFluidSpecs.make, `%${v.make}%`), like(carFluidSpecs.model, `%${v.model}%`)))
    .limit(1);

  if (existing) {
    return { recordId: existing.id, source: "manual", filledFields: [], tokensUsed: { input: 0, output: 0 } };
  }

  const [inserted] = await db.insert(carFluidSpecs).values({
    make: v.make,
    model: v.model,
    modification: mod,
    vehicleType: "Легковой автомобиль",
    engineCode: v.engineCode,
    importBatch: "manual",
  }).$returningId();

  return { recordId: inserted.id, source: "manual", filledFields: [], tokensUsed: { input: 0, output: 0 } };
}

async function getAgentConfig(agentId: string): Promise<AgentConfig> {
  // Try to get from DB first
  try {
    const db = getDb();
    const rows = await db.select().from(systemSettings).where(eq(systemSettings.key, `agent_config_${agentId}`)).limit(1);
    if (rows.length > 0 && rows[0].value) {
      return JSON.parse(rows[0].value) as AgentConfig;
    }
  } catch { /* ignore */ }

  // Fallback to defaults
  return DEFAULT_AGENTS[agentId] || DEFAULT_AGENTS["oil-master"];
}
