import {
  mysqlTable,
  serial,
  varchar,
  int,
  json,
  bigint,
  index,
  uniqueIndex,
  mysqlEnum,
  text,
  timestamp,
} from "drizzle-orm/mysql-core";

// ═══════════════════════════════════════════
//  AUTH & MULTI-TENANCY
// ═══════════════════════════════════════════

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }),
  username: varchar("username", { length: 255 }).unique(),
  passwordHash: varchar("passwordHash", { length: 255 }),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
}, (table) => [
  index("users_username_idx").on(table.username),
]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Companies (multi-tenant) ───
export const companies = mysqlTable("companies", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  apiKey: varchar("apiKey", { length: 64 }).unique(),
  allowedDomains: json("allowedDomains"),
  logo: varchar("logo", { length: 500 }),
  // Full company details
  inn: varchar("inn", { length: 12 }),
  ogrn: varchar("ogrn", { length: 15 }),
  kpp: varchar("kpp", { length: 9 }),
  legalAddress: varchar("legalAddress", { length: 500 }),
  actualAddress: varchar("actualAddress", { length: 500 }),
  director: varchar("director", { length: 255 }),
  website: varchar("website", { length: 255 }),
  contactEmail: varchar("contactEmail", { length: 320 }),
  contactPhone: varchar("contactPhone", { length: 50 }),
  // Report settings
  reportEmail: varchar("reportEmail", { length: 320 }),
  reportPeriod: mysqlEnum("reportPeriod", ["daily", "weekly", "monthly"]).default("weekly"),
  reportDay: int("reportDay").default(1), // day of week (1=Mon) or month (1-31)
  reportTime: varchar("reportTime", { length: 5 }).default("09:00"),
  lastReportSent: timestamp("lastReportSent"),
  isActive: mysqlEnum("isActive", ["active", "suspended", "archived"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
}, (table) => [
  index("companies_slug_idx").on(table.slug),
  index("companies_active_idx").on(table.isActive),
  index("companies_apiKey_idx").on(table.apiKey),
  index("companies_inn_idx").on(table.inn),
]);

// ─── Search Logs (widget requests) ───
export const searchLogs = mysqlTable("searchLogs", {
  id: serial("id").primaryKey(),
  companyId: int("companyId").notNull(),
  apiKey: varchar("apiKey", { length: 64 }).notNull(),
  domain: varchar("domain", { length: 255 }),
  makeId: int("makeId"),
  modelId: int("modelId"),
  modificationId: varchar("modificationId", { length: 53 }),
  makeName: varchar("makeName", { length: 255 }),
  modelName: varchar("modelName", { length: 255 }),
  modificationName: varchar("modificationName", { length: 255 }),
  engineCode: varchar("engineCode", { length: 100 }),
  clientIp: varchar("clientIp", { length: 45 }),
  userAgent: varchar("userAgent", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("searchLogs_company_idx").on(table.companyId),
  index("searchLogs_apiKey_idx").on(table.apiKey),
  index("searchLogs_createdAt_idx").on(table.createdAt),
  index("searchLogs_domain_idx").on(table.domain),
]);

// ─── Company Users (membership) ───
export const companyUsers = mysqlTable("companyUsers", {
  id: serial("id").primaryKey(),
  companyId: int("companyId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["owner", "manager", "viewer"]).default("viewer").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("companyUsers_unique_idx").on(table.companyId, table.userId),
  index("companyUsers_company_idx").on(table.companyId),
  index("companyUsers_user_idx").on(table.userId),
]);

// ─── Products (marketplace) ───
export const products = mysqlTable("products", {
  id: serial("id").primaryKey(),
  companyId: int("companyId").default(1),
  name: varchar("name", { length: 500 }).notNull(),
  slug: varchar("slug", { length: 255 }).unique(),
  sku: varchar("sku", { length: 100 }),
  brand: varchar("brand", { length: 255 }),
  category: varchar("category", { length: 255 }),
  subcategory: varchar("subcategory", { length: 100 }),
  description: text("description"),
  price: int("price"), // cents
  oldPrice: int("oldPrice"),
  discountPercent: int("discountPercent"),
  currency: varchar("currency", { length: 3 }).default("RUB"),
  volume: varchar("volume", { length: 50 }),
  specs: json("specs"), // { viscosity, api, acea, oemApprovals }
  // Images
  imageUrl: varchar("imageUrl", { length: 500 }),
  images: json("images"),
  // Rating & reviews
  rating: varchar("rating", { length: 10 }).default("0"),
  reviewsCount: int("reviewsCount").default(0),
  // Stock & delivery
  inStock: varchar("inStock", { length: 20 }).default("yes"),
  deliveryText: varchar("deliveryText", { length: 100 }).default("Завтра"),
  // Badges & attributes
  badges: json("badges"),
  sellerName: varchar("sellerName", { length: 255 }).default("OILPODBOR"),
  isOriginal: varchar("isOriginal", { length: 10 }).default("no"),
  // External link
  externalUrl: varchar("externalUrl", { length: 500 }),
  // Matching specs
  compatibleSae: json("compatibleSae"),
  compatibleApi: json("compatibleApi"),
  compatibleBrands: json("compatibleBrands"),
  isActive: mysqlEnum("isActive", ["active", "inactive", "hidden", "deleted"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
}, (table) => [
  uniqueIndex("products_slug_idx").on(table.slug),
  index("products_company_idx").on(table.companyId),
  index("products_active_idx").on(table.isActive),
  index("products_category_idx").on(table.category),
  index("products_brand_idx").on(table.brand),
  index("products_price_idx").on(table.price),
]);

// ─── Product-to-Car Assignments ───
export const productAssignments = mysqlTable("productAssignments", {
  id: serial("id").primaryKey(),
  companyId: int("companyId").notNull(),
  productId: int("productId").notNull(),
  makeId: int("makeId").notNull(),
  modelId: int("modelId").notNull(),
  modificationId: varchar("modificationId", { length: 53 }).notNull(),
  notes: varchar("notes", { length: 500 }),
  isRecommended: mysqlEnum("isRecommended", ["yes", "no"]).default("no").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("productAssignments_unique_idx").on(table.companyId, table.productId, table.makeId, table.modelId, table.modificationId),
  index("productAssignments_company_idx").on(table.companyId),
  index("productAssignments_product_idx").on(table.productId),
  index("productAssignments_car_idx").on(table.makeId, table.modelId),
]);

// ═══════════════════════════════════════════
//  ORIGINAL CATALOG TABLES (from SQL dumps)
// ═══════════════════════════════════════════

export const mapping = mysqlTable(
  "mapping",
  {
    id: serial("id").primaryKey(),
    newMakeId: bigint("newMakeId", { mode: "number", unsigned: true }).notNull().default(0),
    newModelId: bigint("newModelId", { mode: "number", unsigned: true }).notNull().default(0),
    newTypeId: bigint("newTypeId", { mode: "number", unsigned: true }).notNull().default(0),
    seoType: varchar("seoType", { length: 512 }),
    makeId: int("makeId"),
    modelId: int("modelId"),
    typeId: varchar("typeId", { length: 53 }),
  },
  (table) => [
    index("mapping_newMakeId_idx").on(table.newMakeId),
    index("mapping_newMakeModel_idx").on(table.newMakeId, table.newModelId),
    index("mapping_newMakeModelType_idx").on(table.newMakeId, table.newModelId, table.newTypeId),
    index("mapping_seoType_idx").on(table.seoType),
    index("mapping_makeId_idx").on(table.makeId),
    index("mapping_makeModel_idx").on(table.makeId, table.modelId),
    index("mapping_makeModelType_idx").on(table.makeId, table.modelId, table.typeId),
  ]
);

export const brands = mysqlTable("TObrands", {
  id: int("id"),
  name: varchar("name", { length: 255 }),
}, (table) => [
  uniqueIndex("TObrands_id_name_idx").on(table.id, table.name),
  index("TObrands_id_idx").on(table.id),
]);

export const models = mysqlTable("TOmodels", {
  makeId: int("makeId"),
  modelId: int("modelId"),
  modelName: varchar("modelName", { length: 255 }),
  yearFrom: varchar("yearFrom", { length: 255 }),
  yearTo: varchar("yearTo", { length: 255 }),
  imageUrl: varchar("imageUrl", { length: 255 }),
}, (table) => [
  uniqueIndex("TOmodels_unique_idx").on(table.makeId, table.modelId, table.modelName, table.yearFrom, table.yearTo),
  index("TOmodels_makeId_idx").on(table.makeId),
  index("TOmodels_modelId_idx").on(table.modelId),
]);

export const modifications = mysqlTable("TOmodifications", {
  id: varchar("id", { length: 53 }),
  name: varchar("name", { length: 100 }),
  engineCode: varchar("engineCode", { length: 100 }),
  constructionType: varchar("constructionType", { length: 255 }),
  fuel: varchar("fuel", { length: 255 }),
  horsePower: varchar("horsePower", { length: 255 }),
  startDate: varchar("startDate", { length: 25 }),
  endDate: varchar("endDate", { length: 25 }),
  engineCapacity: varchar("engineCapacity", { length: 255 }),
  numberOfCylinders: varchar("numberOfCylinders", { length: 255 }),
  valves: varchar("valves", { length: 255 }),
  valvesTotal: varchar("valvesTotal", { length: 255 }),
  motorType: varchar("motorType", { length: 255 }),
  fullName: varchar("fullName", { length: 255 }),
  brand: json("brand"),
  model: json("model"),
  makeId: int("makeId"),
  modelId: int("modelId"),
}, (table) => [
  uniqueIndex("TOmodifications_unique_idx").on(table.id, table.name, table.engineCode, table.fullName, table.makeId, table.modelId),
  index("TOmodifications_makeModel_idx").on(table.makeId, table.modelId),
  index("TOmodifications_modelId_idx").on(table.modelId),
  index("TOmodifications_id_idx").on(table.id),
]);

export const oils = mysqlTable("TOoils", {
  id: serial("id").primaryKey(),
  makeId: int("makeId"),
  modelId: int("modelId"),
  modificationId: int("modificationId"),
  catalogId: int("catalogId"),
  catalogItemId: int("catalogItemId"),
  orderPosition: int("orderPosition"),
  artNumber: varchar("artNumber", { length: 255 }),
  originalName: varchar("originalName", { length: 255 }),
  volume: varchar("volume", { length: 255 }),
  commentName: varchar("commentName", { length: 255 }),
}, (table) => [
  index("TOoils_makeModelMod_idx").on(table.makeId, table.modelId, table.modificationId),
  index("TOoils_modelId_idx").on(table.modelId),
  index("TOoils_modificationId_idx").on(table.modificationId),
]);

export const parts = mysqlTable("TOparts", {
  id: int("id"),
  makeId: int("makeId"),
  modelId: int("modelId"),
  modificationId: varchar("modificationId", { length: 255 }),
  manufacturerId: int("manufacturerId"),
  manufacturerName: varchar("manufacturerName", { length: 255 }),
  itemName: varchar("itemName", { length: 100 }),
  partNumber: varchar("partNumber", { length: 255 }),
  quantity: int("quantity"),
  comment: varchar("comment", { length: 255 }),
}, (table) => [
  uniqueIndex("TOparts_unique_idx").on(table.makeId, table.modelId, table.modificationId, table.manufacturerId, table.partNumber, table.quantity, table.itemName),
  index("TOparts_makeModelMod_idx").on(table.makeId, table.modelId, table.modificationId),
  index("TOparts_modelId_idx").on(table.modelId),
  index("TOparts_modificationId_idx").on(table.modificationId),
  index("TOparts_itemName_idx").on(table.itemName),
]);

export const partsCrosses = mysqlTable("TOpartsCrosses", {
  id: serial("id").primaryKey(),
  manufacturerName: varchar("manufacturerName", { length: 255 }),
  partNumber: varchar("partNumber", { length: 255 }),
  crossBrand: varchar("crossBrand", { length: 100 }),
  crossNumber: varchar("crossNumber", { length: 50 }),
}, (table) => [
  index("TOpartsCrosses_mfr_idx").on(table.manufacturerName, table.partNumber),
]);

// ═══════════════════════════════════════════
//  AI AGENTS SYSTEM
// ═══════════════════════════════════════════

export const aiAgents = mysqlTable("aiAgents", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  category: mysqlEnum("category", ["parser", "filler", "linker", "validator", "enricher"]).notNull(),
  dataSource: varchar("dataSource", { length: 500 }),
  config: json("config"),
  schedule: varchar("schedule", { length: 100 }),
  isActive: mysqlEnum("isActive", ["active", "paused", "error"]).default("paused").notNull(),
  lastRunAt: timestamp("lastRunAt"),
  lastRunStatus: mysqlEnum("lastRunStatus", ["success", "error", "running"]),
  lastRunResult: text("lastRunResult"),
  runsTotal: int("runsTotal").default(0),
  runsSuccess: int("runsSuccess").default(0),
  runsError: int("runsError").default(0),
  itemsProcessed: int("itemsProcessed").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
}, (table) => [
  index("aiAgents_category_idx").on(table.category),
  index("aiAgents_active_idx").on(table.isActive),
  index("aiAgents_slug_idx").on(table.slug),
]);

export const aiTasks = mysqlTable("aiTasks", {
  id: int("id").autoincrement().primaryKey(),
  agentId: int("agentId").notNull(),
  status: mysqlEnum("status", ["queued", "running", "completed", "failed", "cancelled"]).default("queued").notNull(),
  payload: json("payload"),
  result: json("result"),
  errorMessage: text("errorMessage"),
  itemsProcessed: int("itemsProcessed").default(0),
  itemsTotal: int("itemsTotal").default(0),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("aiTasks_agent_idx").on(table.agentId),
  index("aiTasks_status_idx").on(table.status),
  index("aiTasks_created_idx").on(table.createdAt),
]);

// ═══════════════════════════════════════════
//  OILPODBOR REFERENCE TABLES
// ═══════════════════════════════════════════

// ─── Vehicle Types (Легковые, Грузовые и т.д.) ───
export const vehicleTypes = mysqlTable("vehicleTypes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("vehicleTypes_active_idx").on(table.isActive),
]);

// ─── Steering Positions (Левое/Правое) ───
export const steeringPositions = mysqlTable("steeringPositions", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("steeringPositions_active_idx").on(table.isActive),
]);

// ─── Car Body Types (седан, хэтчбек, SUV и т.д.) ───
export const carBodyTypes = mysqlTable("carBodyTypes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("carBodyTypes_active_idx").on(table.isActive),
]);

// ─── Fuel Types (Бензин, Дизель, Гибрид и т.д.) ───
export const fuelTypes = mysqlTable("fuelTypes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("fuelTypes_active_idx").on(table.isActive),
]);

// ─── Transmission Types (МКПП, АКПП, Вариатор и т.д.) ───
export const transmissionTypes = mysqlTable("transmissionTypes", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("transmissionTypes_active_idx").on(table.isActive),
]);

// ─── Viscosity Classes (5W-30, 5W-40 и т.д.) ───
export const viscosityClasses = mysqlTable("viscosityClasses", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull(),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("viscosityClasses_active_idx").on(table.isActive),
]);

// ─── Liquid Categories (моторное масло, антифриз, тормозная и т.д.) ───
export const liquidCategories = mysqlTable("liquidCategories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  displayName: varchar("displayName", { length: 255 }),
  parentId: int("parentId"),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("liquidCategories_parent_idx").on(table.parentId),
  index("liquidCategories_active_idx").on(table.isActive),
]);

// ─── Aggregation Trees (дерево агрегатов) ───
export const aggregationTrees = mysqlTable("aggregationTrees", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  parentId: int("parentId"),
  liquidCategoryId: int("liquidCategoryId"),
  sortOrder: int("sortOrder").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("aggregationTrees_parent_idx").on(table.parentId),
  index("aggregationTrees_category_idx").on(table.liquidCategoryId),
]);

// ═══════════════════════════════════════════
//  MAIN JOURNAL: CARS (АВТОМОБИЛИ)
// ═══════════════════════════════════════════

export const cars = mysqlTable("cars", {
  id: varchar("id", { length: 50 }).primaryKey(),
  // General
  vehicleTypeId: int("vehicleTypeId"),
  steeringPositionId: int("steeringPositionId"),
  make: varchar("make", { length: 255 }).notNull(),
  model: varchar("model", { length: 255 }).notNull(),
  bodyTypeId: int("bodyTypeId"),
  modification: varchar("modification", { length: 255 }).notNull(),
  yearFrom: int("yearFrom"),
  yearTo: int("yearTo"),
  // Engine
  engineCapacity: varchar("engineCapacity", { length: 50 }),
  fuelTypeId: int("fuelTypeId"),
  engineCode: varchar("engineCode", { length: 100 }),
  engineName: varchar("engineName", { length: 255 }),
  horsePower: varchar("horsePower", { length: 50 }),
  // Transmission
  transmissionTypeId: int("transmissionTypeId"),
  transmissionGears: varchar("transmissionGears", { length: 50 }),
  transmissionCode: varchar("transmissionCode", { length: 100 }),
  // Transfer case
  transferCaseCode: varchar("transferCaseCode", { length: 100 }),
  // Differentials
  frontDifferentialCode: varchar("frontDifferentialCode", { length: 100 }),
  rearDifferentialCode: varchar("rearDifferentialCode", { length: 100 }),
  // Air conditioning
  refrigerantType: varchar("refrigerantType", { length: 100 }),
  // Images
  carPhotoUrl: varchar("carPhotoUrl", { length: 500 }),
  carVectorUrl: varchar("carVectorUrl", { length: 500 }),
  // Status
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
}, (table) => [
  index("cars_make_idx").on(table.make),
  index("cars_model_idx").on(table.model),
  index("cars_active_idx").on(table.isActive),
  index("cars_vehicleType_idx").on(table.vehicleTypeId),
  index("cars_fuelType_idx").on(table.fuelTypeId),
  index("cars_modification_idx").on(table.modification),
]);

// ═══════════════════════════════════════════
//  SYSTEM SETTINGS (API KEYS & CONFIG)
// ═══════════════════════════════════════════

export const systemSettings = mysqlTable("systemSettings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  label: varchar("label", { length: 255 }),
  category: varchar("category", { length: 50 }).default("general"),
  isSecret: mysqlEnum("isSecret", ["yes", "no"]).default("no").notNull(),
  description: text("description"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  updatedBy: varchar("updatedBy", { length: 100 }),
}, (table) => [
  index("systemSettings_key_idx").on(table.key),
  index("systemSettings_category_idx").on(table.category),
]);

// ═══════════════════════════════════════════
//  OWNER MANUALS (РУКОВОДСТВА ПО ЭКСПЛУАТАЦИИ)
// ═══════════════════════════════════════════

export const ownerManuals = mysqlTable("ownerManuals", {
  id: serial("id").primaryKey(),
  make: varchar("make", { length: 255 }).notNull(),
  model: varchar("model", { length: 255 }).notNull(),
  yearFrom: int("yearFrom"),
  yearTo: int("yearTo"),
  generation: varchar("generation", { length: 255 }),
  modification: varchar("modification", { length: 255 }),
  title: varchar("title", { length: 500 }),
  // PDF source
  pdfUrl: varchar("pdfUrl", { length: 1000 }),
  pdfOriginalUrl: varchar("pdfOriginalUrl", { length: 1000 }),
  pdfSize: varchar("pdfSize", { length: 50 }),
  pdfPages: int("pdfPages"),
  // Source info
  source: varchar("source", { length: 255 }),
  language: varchar("language", { length: 50 }).default("ru"),
  isOfficial: mysqlEnum("isOfficial", ["yes", "no"]).default("no"),
  // Metadata
  downloadCount: int("downloadCount").default(0),
  viewCount: int("viewCount").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active"),
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("ownerManuals_make_idx").on(table.make),
  index("ownerManuals_model_idx").on(table.model),
  index("ownerManuals_active_idx").on(table.isActive),
  index("ownerManuals_year_idx").on(table.yearFrom),
]);

// ═══════════════════════════════════════════
//  EXCEL IMPORT: CAR FLUID SPECS (ПОДБОРЩИК ФОРМА)
// ═══════════════════════════════════════════

export const carFluidSpecs = mysqlTable("carFluidSpecs", {
  id: serial("id").primaryKey(),
  // Vehicle identity
  vehicleType: varchar("vehicleType", { length: 100 }),
  steeringPosition: varchar("steeringPosition", { length: 100 }),
  make: varchar("make", { length: 255 }).notNull(),
  model: varchar("model", { length: 255 }).notNull(),
  body: varchar("body", { length: 500 }),
  modification: varchar("modification", { length: 500 }),
  // Engine
  engineVolume: varchar("engineVolume", { length: 50 }),
  fuelType: varchar("fuelType", { length: 100 }),
  engineCode: varchar("engineCode", { length: 100 }),
  engineReplaceInterval: varchar("engineReplaceInterval", { length: 255 }),
  engineFillVolume: varchar("engineFillVolume", { length: 50 }),
  // Engine oil (preferred)
  prefOilSae: varchar("prefOilSae", { length: 50 }),
  prefOilApi: varchar("prefOilApi", { length: 100 }),
  prefOilAcea: varchar("prefOilAcea", { length: 100 }),
  prefOilIlsac: varchar("prefOilIlsac", { length: 100 }),
  prefOilOe: varchar("prefOilOe", { length: 255 }),
  // Engine oil (alternative)
  altOilViscosities: varchar("altOilViscosities", { length: 255 }),
  altOilApi: varchar("altOilApi", { length: 100 }),
  altOilAcea: varchar("altOilAcea", { length: 100 }),
  altOilIlsac: varchar("altOilIlsac", { length: 100 }),
  altOilOe: varchar("altOilOe", { length: 255 }),
  // Transmission
  transmissionType: varchar("transmissionType", { length: 100 }),
  transmissionGears: varchar("transmissionGears", { length: 50 }),
  transmissionCode: varchar("transmissionCode", { length: 100 }),
  transmissionReplaceInterval: varchar("transmissionReplaceInterval", { length: 255 }),
  transmissionFillVolume: varchar("transmissionFillVolume", { length: 50 }),
  transmissionPrefOil: varchar("transmissionPrefOil", { length: 255 }),
  transmissionAltOil: varchar("transmissionAltOil", { length: 255 }),
  // Transfer case
  transferCaseCode: varchar("transferCaseCode", { length: 100 }),
  transferCaseInterval: varchar("transferCaseInterval", { length: 255 }),
  transferCaseFillVolume: varchar("transferCaseFillVolume", { length: 50 }),
  transferCaseOil: varchar("transferCaseOil", { length: 255 }),
  // Front differential
  frontDiffCode: varchar("frontDiffCode", { length: 100 }),
  frontDiffFillVolume: varchar("frontDiffFillVolume", { length: 50 }),
  frontDiffInterval: varchar("frontDiffInterval", { length: 255 }),
  frontDiffOil: varchar("frontDiffOil", { length: 255 }),
  // Rear differential
  rearDiffCode: varchar("rearDiffCode", { length: 100 }),
  rearDiffFillVolume: varchar("rearDiffFillVolume", { length: 50 }),
  rearDiffInterval: varchar("rearDiffInterval", { length: 255 }),
  rearDiffOil: varchar("rearDiffOil", { length: 255 }),
  // Cooling system
  coolantFillVolume: varchar("coolantFillVolume", { length: 50 }),
  coolantInterval: varchar("coolantInterval", { length: 255 }),
  coolantType: varchar("coolantType", { length: 255 }),
  // Brake system
  brakeFluidVolume: varchar("brakeFluidVolume", { length: 50 }),
  brakeFluidInterval: varchar("brakeFluidInterval", { length: 255 }),
  brakeFluidType: varchar("brakeFluidType", { length: 255 }),
  // Power steering
  psFluidVolume: varchar("psFluidVolume", { length: 50 }),
  psFluidType: varchar("psFluidType", { length: 255 }),
  // Suspension
  suspFluidVolume: varchar("suspFluidVolume", { length: 50 }),
  suspFluidType: varchar("suspFluidType", { length: 255 }),
  // AdBlue
  adblueVolume: varchar("adblueVolume", { length: 50 }),
  adblueType: varchar("adblueType", { length: 255 }),
  // Filters
  oilFilter: varchar("oilFilter", { length: 100 }),
  airFilter: varchar("airFilter", { length: 100 }),
  cabinFilter: varchar("cabinFilter", { length: 100 }),
  fuelFilter: varchar("fuelFilter", { length: 100 }),
  transmissionFilter: varchar("transmissionFilter", { length: 100 }),
  // Raw data backup
  rawData: json("rawData"),
  // Source tracking
  importBatch: varchar("importBatch", { length: 50 }),
  importDate: timestamp("importDate").defaultNow().notNull(),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
}, (table) => [
  index("carFluidSpecs_make_idx").on(table.make),
  index("carFluidSpecs_model_idx").on(table.model),
  index("carFluidSpecs_modification_idx").on(table.modification),
  index("carFluidSpecs_batch_idx").on(table.importBatch),
  index("carFluidSpecs_active_idx").on(table.isActive),
]);

// ═══════════════════════════════════════════
//  MAIN JOURNAL: LIQUIDS (ЖИДКОСТИ)
// ═══════════════════════════════════════════

export const liquids = mysqlTable("liquids", {
  id: varchar("id", { length: 50 }).primaryKey(),
  name: varchar("name", { length: 500 }).notNull(),
  // Category & priority
  categoryId: int("categoryId"),
  aggregationTreeId: int("aggregationTreeId"),
  priority: int("priority").default(0),
  isActive: mysqlEnum("isActive", ["active", "inactive"]).default("active").notNull(),
  // Product info
  volume: varchar("volume", { length: 50 }),
  sku: varchar("sku", { length: 100 }),
  // Viscosity
  viscosityClassId: int("viscosityClassId"),
  viscosityName: varchar("viscosityName", { length: 50 }),
  // Specs
  oilType: varchar("oilType", { length: 50 }), // синтетика / полусинт / минералка
  apiSpec: varchar("apiSpec", { length: 255 }),
  aceaSpec: varchar("aceaSpec", { length: 255 }),
  ilsacSpec: varchar("ilsacSpec", { length: 255 }),
  oemSpec: varchar("oemSpec", { length: 255 }),
  // Vehicle applicability
  applicableVehicleTypes: json("applicableVehicleTypes"),
  // Description
  description: text("description"),
  websiteUrl: varchar("websiteUrl", { length: 500 }),
  imageUrl: varchar("imageUrl", { length: 500 }),
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
}, (table) => [
  index("liquids_category_idx").on(table.categoryId),
  index("liquids_active_idx").on(table.isActive),
  index("liquids_priority_idx").on(table.priority),
  index("liquids_viscosity_idx").on(table.viscosityClassId),
]);

// ═══════════════════════════════════════════
//  AI RESEARCH LOGS (debug raw responses)
// ═══════════════════════════════════════════

export const aiLogs = mysqlTable("aiLogs", {
  id: serial("id").primaryKey(),
  make: varchar("make", { length: 100 }),
  model: varchar("model", { length: 100 }),
  engineCode: varchar("engineCode", { length: 100 }),
  query: text("query"),
  rawResponse: text("rawResponse"),
  parsedJson: json("parsedJson"),
  filledFields: json("filledFields"),
  tokensInput: int("tokensInput").default(0),
  tokensOutput: int("tokensOutput").default(0),
  source: varchar("source", { length: 20 }).default("unknown"),
  error: text("error"),
  durationMs: int("durationMs").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("aiLogs_make_model_idx").on(table.make, table.model),
  index("aiLogs_createdAt_idx").on(table.createdAt),
]);

// ═══════════════════════════════════════════
//  CAR ↔ LIQUID ASSIGNMENTS (СВЯЗЬ)
// ═══════════════════════════════════════════

export const carLiquidAssignments = mysqlTable("carLiquidAssignments", {
  id: serial("id").primaryKey(),
  carId: varchar("carId", { length: 50 }).notNull(),
  liquidId: varchar("liquidId", { length: 50 }).notNull(),
  aggregationTreeId: int("aggregationTreeId"),
  // For the assignment — volume, interval, priority
  fillVolume: varchar("fillVolume", { length: 50 }),
  replaceInterval: varchar("replaceInterval", { length: 255 }),
  isPrimary: mysqlEnum("isPrimary", ["yes", "no"]).default("yes").notNull(),
  // Notes
  notes: varchar("notes", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  uniqueIndex("carLiquid_unique_idx").on(table.carId, table.liquidId, table.aggregationTreeId),
  index("carLiquid_car_idx").on(table.carId),
  index("carLiquid_liquid_idx").on(table.liquidId),
  index("carLiquid_tree_idx").on(table.aggregationTreeId),
]);

// ═══════════════════════════════════════════
//  BACKGROUND JOBS (ФОНОВЫЕ ЗАДАНИЯ ИИ)
// ═══════════════════════════════════════════

export const backgroundJobs = mysqlTable("backgroundJobs", {
  id: serial("id").primaryKey(),
  type: varchar("type", { length: 50 }).notNull().default("ai-fill"),
  status: mysqlEnum("status", ["queued", "running", "paused", "completed", "failed", "stopped"]).default("queued").notNull(),
  // Selection criteria
  makes: text("makes"),
  models: text("models"),
  yearFrom: int("yearFrom"),
  yearTo: int("yearTo"),
  // Progress tracking
  totalCars: int("totalCars").default(0),
  processedCars: int("processedCars").default(0),
  successCars: int("successCars").default(0),
  errorCars: int("errorCars").default(0),
  // Current car being processed
  currentMake: varchar("currentMake", { length: 255 }),
  currentModel: varchar("currentModel", { length: 255 }),
  // Results summary
  filledFields: int("filledFields").default(0),
  tokensInput: int("tokensInput").default(0),
  tokensOutput: int("tokensOutput").default(0),
  totalCost: varchar("totalCost", { length: 50 }),
  // Error log
  lastError: text("lastError"),
  errorLog: text("errorLog"),
  // Settings
  delaySeconds: int("delaySeconds").default(2),
  // Control
  shouldStop: mysqlEnum("shouldStop", ["yes", "no"]).default("no").notNull(),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("bgJobs_status_idx").on(table.status),
  index("bgJobs_type_idx").on(table.type),
  index("bgJobs_created_idx").on(table.createdAt),
]);

// ─── (products table is defined above in AUTH & MULTI-TENANCY section) ───

// ═══════════════════════════════════════════
//  AI MULTI-AGENT VERIFICATION
// ═══════════════════════════════════════════

export const aiVerifications = mysqlTable("aiVerifications", {
  id: serial("id").primaryKey(),
  make: varchar("make", { length: 255 }).notNull(),
  model: varchar("model", { length: 255 }).notNull(),
  modification: varchar("modification", { length: 500 }),
  engineCode: varchar("engineCode", { length: 100 }),
  year: int("year"),
  overallConfidence: int("overallConfidence").default(0),
  status: mysqlEnum("status", ["running", "completed", "failed", "needs_review"]).default("running").notNull(),
  agentCount: int("agentCount").default(0),
  consensusFields: int("consensusFields").default(0),
  totalFields: int("totalFields").default(0),
  needsHumanReview: mysqlEnum("needsHumanReview", ["yes", "no"]).default("no").notNull(),
  humanReviewerId: int("humanReviewerId"),
  humanReviewNotes: text("humanReviewNotes"),
  reviewedAt: timestamp("reviewedAt"),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("aiVerif_make_model_idx").on(table.make, table.model),
  index("aiVerif_status_idx").on(table.status),
  index("aiVerif_created_idx").on(table.startedAt),
]);

export type AiVerification = typeof aiVerifications.$inferSelect;

export const aiVerificationAgents = mysqlTable("aiVerificationAgents", {
  id: serial("id").primaryKey(),
  verificationId: int("verificationId").notNull(),
  agentId: varchar("agentId", { length: 50 }).notNull(),
  provider: varchar("provider", { length: 50 }).notNull(),
  model: varchar("model", { length: 100 }),
  filledFields: json("filledFields"),
  sources: json("sources"),
  filledCount: int("filledCount").default(0),
  durationMs: int("durationMs").default(0),
  tokensInput: int("tokensInput").default(0),
  tokensOutput: int("tokensOutput").default(0),
  rawResponse: text("rawResponse"),
  error: text("error"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("aiVerifAgent_verification_idx").on(table.verificationId),
  index("aiVerifAgent_agent_idx").on(table.agentId),
]);

export const aiVerificationFields = mysqlTable("aiVerificationFields", {
  id: serial("id").primaryKey(),
  verificationId: int("verificationId").notNull(),
  fieldKey: varchar("fieldKey", { length: 100 }).notNull(),
  fieldLabel: varchar("fieldLabel", { length: 200 }),
  section: varchar("section", { length: 100 }),
  // Each agent's value stored as JSON map: { "perplexity": "5W-30", "anthropic": "5W-30", ... }
  agentValues: json("agentValues"),
  // Sources for each agent: { "perplexity": "https://...", ... }
  agentSources: json("agentSources"),
  // Consensus value (majority vote winner)
  consensusValue: varchar("consensusValue", { length: 500 }),
  // Confidence: 0-100 (agents agreeing / total agents * 100)
  confidence: int("confidence").default(0),
  // Number of agents that agreed on consensus
  agreeingAgents: int("agreeingAgents").default(0),
  totalAgents: int("totalAgents").default(0),
  // Status
  status: mysqlEnum("status", ["consensus", "conflict", "partial", "empty"]).default("empty").notNull(),
  // Human override
  humanValue: varchar("humanValue", { length: 500 }),
  humanReviewerId: int("humanReviewerId"),
  humanReviewNotes: text("humanReviewNotes"),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("aiVerifField_verification_idx").on(table.verificationId),
  index("aiVerifField_key_idx").on(table.fieldKey),
  index("aiVerifField_status_idx").on(table.status),
]);

export type AiVerificationField = typeof aiVerificationFields.$inferSelect;

// ═══════════════════════════════════════════
//  MARKET MONITOR — New car market tracking
//  ═══════════════════════════════════════════

// Cars found on drom.ru that are NOT yet in our database
export const marketCars = mysqlTable("marketCars", {
  id: serial("id").primaryKey(),
  // Source info
  source: varchar("source", { length: 50 }).default("drom.ru").notNull(),
  sourceUrl: text("sourceUrl"),
  // Car identity
  make: varchar("make", { length: 255 }).notNull(),
  model: varchar("model", { length: 255 }).notNull(),
  generation: varchar("generation", { length: 500 }),
  modification: varchar("modification", { length: 500 }),
  yearFrom: int("yearFrom"),
  yearTo: int("yearTo"),
  engineCode: varchar("engineCode", { length: 100 }),
  engineCapacity: varchar("engineCapacity", { length: 50 }),
  enginePower: varchar("enginePower", { length: 50 }),
  fuel: varchar("fuel", { length: 50 }),
  transmission: varchar("transmission", { length: 100 }),
  body: varchar("body", { length: 100 }),
  // Status: new | pending | approved | rejected | merged
  status: mysqlEnum("status", ["new", "pending", "approved", "rejected", "merged"]).default("new").notNull(),
  // Match with existing car in DB
  matchedCarId: int("matchedCarId"),
  // Metadata
  foundAt: timestamp("foundAt").defaultNow().notNull(),
  reviewedBy: int("reviewedBy"),
  reviewedAt: timestamp("reviewedAt"),
  notes: text("notes"),
}, (table) => [
  index("marketCars_status_idx").on(table.status),
  index("marketCars_make_model_idx").on(table.make, table.model),
  index("marketCars_found_idx").on(table.foundAt),
]);

export type MarketCar = typeof marketCars.$inferSelect;

// Sync log — tracks each drom.ru scan
export const marketSyncLog = mysqlTable("marketSyncLog", {
  id: serial("id").primaryKey(),
  source: varchar("source", { length: 50 }).default("drom.ru").notNull(),
  status: mysqlEnum("status", ["running", "completed", "failed"]).default("running").notNull(),
  carsFound: int("carsFound").default(0),
  carsNew: int("carsNew").default(0),
  carsUpdated: int("carsUpdated").default(0),
  carsMerged: int("carsMerged").default(0),
  error: text("error"),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
}, (table) => [
  index("marketSyncLog_status_idx").on(table.status),
  index("marketSyncLog_started_idx").on(table.startedAt),
]);

export type MarketSyncLog = typeof marketSyncLog.$inferSelect;
