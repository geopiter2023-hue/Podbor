import { useState, useRef } from "react";
import { Link } from "react-router";

const API_BASE = import.meta.env.VITE_API_URL || "";

export default function Partner() {
  const [form, setForm] = useState({ name: "", email: "", domain: "", website: "" });
  const [result, setResult] = useState<{
    success: boolean;
    apiKey?: string;
    domain?: string;
    message?: string;
    error?: string;
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const keyRef = useRef<HTMLDivElement>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (loading) return;
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch(`${API_BASE}/api/widget/v1/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name.trim(),
          email: form.email.trim(),
          domain: form.domain.trim(),
          website: form.website.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setResult({
          success: true,
          apiKey: data.apiKey,
          domain: data.domain,
          message: data.message,
        });
        setTimeout(() => keyRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
      } else {
        setResult({ success: false, error: data.error || "Unknown error" });
      }
    } catch (err: any) {
      setResult({ success: false, error: "Network error. Please try again." });
    } finally {
      setLoading(false);
    }
  }

  function copyKey(key: string) {
    navigator.clipboard.writeText(key).then(() => {
      alert("API key copied to clipboard!");
    });
  }

  return (
    <div style={{ minHeight: "100vh", background: "#F5F5F7", fontFamily: "-apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Segoe UI', sans-serif" }}>
      {/* Header */}
      <header style={{ background: "#fff", borderBottom: "1px solid #E5E5EA" }}>
        <div style={{ maxWidth: "800px", margin: "0 auto", padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Link to="/" style={{ textDecoration: "none", display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ width: "32px", height: "32px", background: "#E31E24", borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
              </svg>
            </div>
            <span style={{ fontSize: "18px", fontWeight: 700, color: "#1D1D1F" }}>OILPODBOR</span>
          </Link>
          <span style={{ fontSize: "13px", color: "#86868B", fontWeight: 500 }}>Widget API</span>
        </div>
      </header>

      <main style={{ maxWidth: "720px", margin: "0 auto", padding: "40px 24px 80px" }}>
        {/* Hero */}
        <div style={{ textAlign: "center", marginBottom: "48px" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: "8px", background: "#E31E2415", color: "#E31E24", padding: "6px 14px", borderRadius: "100px", fontSize: "13px", fontWeight: 600, marginBottom: "20px" }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M8 12l2.5 2.5L16 9"/></svg>
            Free for all platforms
          </div>
          <h1 style={{ fontSize: "clamp(28px, 5vw, 40px)", fontWeight: 800, color: "#1D1D1F", margin: "0 0 12px", lineHeight: 1.1, letterSpacing: "-0.02em" }}>
            Get Your API Key
          </h1>
          <p style={{ fontSize: "17px", color: "#86868B", margin: 0, lineHeight: 1.5, maxWidth: "520px", marginLeft: "auto", marginRight: "auto" }}>
            Integrate the oil selector widget into your website or app. Free, fast, no approval required.
          </p>
        </div>

        {/* Two-column layout on desktop */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "24px", alignItems: "start" }}>
          {/* Form Card */}
          <div style={{ background: "#fff", borderRadius: "20px", padding: "32px", boxShadow: "0 1px 3px rgba(0,0,0,0.04), 0 4px 16px rgba(0,0,0,0.04)" }}>
            <h2 style={{ fontSize: "20px", fontWeight: 700, color: "#1D1D1F", margin: "0 0 6px" }}>Register</h2>
            <p style={{ fontSize: "14px", color: "#86868B", margin: "0 0 24px" }}>Fill in your details and get your key instantly.</p>

            {result?.error && (
              <div style={{ background: "#FFF2F2", border: "1px solid #FFD6D6", borderRadius: "12px", padding: "12px 16px", marginBottom: "20px", color: "#D32F2F", fontSize: "14px", display: "flex", alignItems: "center", gap: "8px" }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>
                {result.error}
              </div>
            )}

            {result?.success && result.apiKey ? (
              <div ref={keyRef} style={{ animation: "fadeIn 0.4s ease" }}>
                <div style={{ background: "#F0FFF4", border: "1px solid #C6F6D5", borderRadius: "12px", padding: "16px", marginBottom: "20px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38A169" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M8 12l2.5 2.5L16 9"/></svg>
                    <span style={{ fontSize: "14px", fontWeight: 600, color: "#276749" }}>Your API key is ready!</span>
                  </div>
                  <p style={{ fontSize: "13px", color: "#68D391", margin: 0 }}>Domain: {result.domain}</p>
                </div>

                <label style={{ fontSize: "13px", fontWeight: 600, color: "#1D1D1F", marginBottom: "8px", display: "block" }}>API Key</label>
                <div style={{ display: "flex", gap: "8px", marginBottom: "20px" }}>
                  <code style={{ flex: 1, background: "#F5F5F7", padding: "12px 16px", borderRadius: "12px", fontSize: "13px", fontFamily: "'SF Mono', Monaco, monospace", color: "#1D1D1F", wordBreak: "break-all", border: "1px solid #E5E5EA" }}>
                    {result.apiKey}
                  </code>
                  <button
                    onClick={() => copyKey(result.apiKey!)}
                    style={{ background: "#1D1D1F", color: "#fff", border: "none", padding: "12px 18px", borderRadius: "12px", fontSize: "13px", fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" }}
                  >
                    Copy
                  </button>
                </div>

                <div style={{ background: "#F5F5F7", borderRadius: "12px", padding: "16px" }}>
                  <label style={{ fontSize: "13px", fontWeight: 600, color: "#1D1D1F", marginBottom: "10px", display: "block" }}>Quick Start Code</label>
                  <pre style={{ margin: 0, fontSize: "12px", fontFamily: "'SF Mono', Monaco, monospace", color: "#636366", lineHeight: 1.6, overflowX: "auto" }}>
{`<script src="${typeof window !== 'undefined' ? window.location.origin : ''}/widget.js"
  data-api-key="${result.apiKey}">
</script>
<div id="oilpodbor-widget"></div>`}
                  </pre>
                  <button
                    onClick={() => copyKey(`<script src="${typeof window !== 'undefined' ? window.location.origin : ''}/widget.js" data-api-key="${result.apiKey}"></script>\n<div id="oilpodbor-widget"></div>`)}
                    style={{ marginTop: "12px", background: "transparent", border: "1px solid #D1D1D6", color: "#636366", padding: "6px 12px", borderRadius: "8px", fontSize: "12px", cursor: "pointer" }}
                  >
                    Copy embed code
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
                <div>
                  <label style={{ fontSize: "13px", fontWeight: 600, color: "#1D1D1F", marginBottom: "6px", display: "block" }}>
                    Company or Project Name <span style={{ color: "#E31E24" }}>*</span>
                  </label>
                  <input
                    type="text"
                    required
                    minLength={2}
                    placeholder="e.g. AutoShop Pro"
                    value={form.name}
                    onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                    style={{ width: "100%", padding: "12px 14px", borderRadius: "12px", border: "1px solid #D1D1D6", fontSize: "15px", outline: "none", boxSizing: "border-box", transition: "border-color 0.2s", fontFamily: "inherit" }}
                    onFocus={(e) => (e.target.style.borderColor = "#E31E24")}
                    onBlur={(e) => (e.target.style.borderColor = "#D1D1D6")}
                  />
                </div>
                <div>
                  <label style={{ fontSize: "13px", fontWeight: 600, color: "#1D1D1F", marginBottom: "6px", display: "block" }}>
                    Email <span style={{ color: "#E31E24" }}>*</span>
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="you@company.com"
                    value={form.email}
                    onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                    style={{ width: "100%", padding: "12px 14px", borderRadius: "12px", border: "1px solid #D1D1D6", fontSize: "15px", outline: "none", boxSizing: "border-box", transition: "border-color 0.2s", fontFamily: "inherit" }}
                    onFocus={(e) => (e.target.style.borderColor = "#E31E24")}
                    onBlur={(e) => (e.target.style.borderColor = "#D1D1D6")}
                  />
                </div>
                <div>
                  <label style={{ fontSize: "13px", fontWeight: 600, color: "#1D1D1F", marginBottom: "6px", display: "block" }}>
                    Domain <span style={{ color: "#E31E24" }}>*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="example.com"
                    value={form.domain}
                    onChange={(e) => setForm((f) => ({ ...f, domain: e.target.value }))}
                    style={{ width: "100%", padding: "12px 14px", borderRadius: "12px", border: "1px solid #D1D1D6", fontSize: "15px", outline: "none", boxSizing: "border-box", transition: "border-color 0.2s", fontFamily: "inherit" }}
                    onFocus={(e) => (e.target.style.borderColor = "#E31E24")}
                    onBlur={(e) => (e.target.style.borderColor = "#D1D1D6")}
                  />
                  <p style={{ fontSize: "12px", color: "#86868B", margin: "4px 0 0" }}>The widget will only work on this domain.</p>
                </div>
                <div>
                  <label style={{ fontSize: "13px", fontWeight: 600, color: "#1D1D1F", marginBottom: "6px", display: "block" }}>
                    Website URL <span style={{ color: "#86868B", fontWeight: 400 }}>(optional)</span>
                  </label>
                  <input
                    type="url"
                    placeholder="https://example.com"
                    value={form.website}
                    onChange={(e) => setForm((f) => ({ ...f, website: e.target.value }))}
                    style={{ width: "100%", padding: "12px 14px", borderRadius: "12px", border: "1px solid #D1D1D6", fontSize: "15px", outline: "none", boxSizing: "border-box", transition: "border-color 0.2s", fontFamily: "inherit" }}
                    onFocus={(e) => (e.target.style.borderColor = "#E31E24")}
                    onBlur={(e) => (e.target.style.borderColor = "#D1D1D6")}
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    width: "100%",
                    padding: "14px",
                    borderRadius: "12px",
                    border: "none",
                    background: loading ? "#D1D1D6" : "#E31E24",
                    color: "#fff",
                    fontSize: "16px",
                    fontWeight: 700,
                    cursor: loading ? "not-allowed" : "pointer",
                    transition: "all 0.2s",
                    marginTop: "4px",
                  }}
                >
                  {loading ? (
                    <span style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" style={{ animation: "spin 1s linear infinite" }}><circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="3" strokeDasharray="31 15"/></svg>
                      Generating...
                    </span>
                  ) : (
                    "Get API Key"
                  )}
                </button>
              </form>
            )}
          </div>

          {/* Info Card */}
          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            <div style={{ background: "#fff", borderRadius: "20px", padding: "28px", boxShadow: "0 1px 3px rgba(0,0,0,0.04), 0 4px 16px rgba(0,0,0,0.04)" }}>
              <h3 style={{ fontSize: "17px", fontWeight: 700, color: "#1D1D1F", margin: "0 0 16px" }}>What you get</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
                {[
                  { icon: "🔑", title: "Instant API Key", desc: "No approval or waiting required." },
                  { icon: "🚗", title: "Full Car Database", desc: "131 car brands with all models and engines." },
                  { icon: "🛡️", title: "Domain Protection", desc: "Your key only works on your domain." },
                  { icon: "⚡", title: "Fast REST API", desc: "5 endpoints, JSON responses, CORS enabled." },
                  { icon: "📊", title: "Usage Analytics", desc: "Track searches and popular cars." },
                  { icon: "💰", title: "100% Free", desc: "No limits, no credit card required." },
                ].map((item) => (
                  <div key={item.title} style={{ display: "flex", gap: "12px", alignItems: "flex-start" }}>
                    <span style={{ fontSize: "20px", lineHeight: 1 }}>{item.icon}</span>
                    <div>
                      <div style={{ fontSize: "14px", fontWeight: 600, color: "#1D1D1F" }}>{item.title}</div>
                      <div style={{ fontSize: "13px", color: "#86868B", lineHeight: 1.4 }}>{item.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div style={{ background: "#fff", borderRadius: "20px", padding: "28px", boxShadow: "0 1px 3px rgba(0,0,0,0.04), 0 4px 16px rgba(0,0,0,0.04)" }}>
              <h3 style={{ fontSize: "17px", fontWeight: 700, color: "#1D1D1F", margin: "0 0 12px" }}>REST API Endpoints</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                {[
                  { method: "GET", path: "/brands", desc: "List all car brands" },
                  { method: "GET", path: "/models", desc: "Models by brand ID" },
                  { method: "GET", path: "/modifications", desc: "Engines by brand + model" },
                  { method: "GET", path: "/result", desc: "Oil + products by car" },
                  { method: "GET", path: "/validate", desc: "Check your API key" },
                ].map((ep) => (
                  <div key={ep.path} style={{ display: "flex", alignItems: "center", gap: "10px", fontSize: "13px", fontFamily: "'SF Mono', monospace" }}>
                    <span style={{ color: "#38A169", fontWeight: 600, minWidth: "44px" }}>{ep.method}</span>
                    <code style={{ color: "#636366", background: "#F5F5F7", padding: "3px 8px", borderRadius: "6px", fontSize: "12px" }}>{ep.path}</code>
                  </div>
                ))}
              </div>
              <p style={{ fontSize: "12px", color: "#86868B", margin: "12px 0 0", lineHeight: 1.5 }}>
                Base URL: <code style={{ color: "#E31E24" }}>/api/widget/v1</code>
              </p>
            </div>

            <div style={{ background: "#1D1D1F", borderRadius: "20px", padding: "28px", color: "#fff" }}>
              <h3 style={{ fontSize: "17px", fontWeight: 700, margin: "0 0 10px" }}>Need help?</h3>
              <p style={{ fontSize: "14px", color: "#86868B", margin: "0 0 16px", lineHeight: 1.5 }}>
                Contact us for custom integration, white-label solutions, or premium support.
              </p>
              <a
                href="mailto:widget@oilpodbor.ru"
                style={{ display: "inline-flex", alignItems: "center", gap: "6px", color: "#fff", fontSize: "14px", fontWeight: 600, textDecoration: "none", background: "#E31E24", padding: "10px 18px", borderRadius: "10px" }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                widget@oilpodbor.ru
              </a>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer style={{ textAlign: "center", padding: "24px", fontSize: "13px", color: "#86868B", borderTop: "1px solid #E5E5EA" }}>
        OILPODBOR Widget API &middot; <Link to="/" style={{ color: "#E31E24", textDecoration: "none" }}>oilpodbor.ru</Link>
      </footer>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
