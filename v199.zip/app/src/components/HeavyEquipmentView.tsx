import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Search, Filter, ChevronDown, ChevronRight,
  Droplets, Wrench, FileText, ExternalLink, Truck,
  Beaker, Database, BarChart3, CheckCircle2, XCircle, Clock
} from "lucide-react";

function StatsCard({ label, value, icon: Icon, color }: { label: string; value: number | string; icon: any; color: string }) {
  const colorMap: Record<string, string> = {
    blue: "bg-blue-50 text-blue-600",
    green: "bg-green-50 text-green-600",
    amber: "bg-amber-50 text-amber-600",
    purple: "bg-purple-50 text-purple-600",
    red: "bg-red-50 text-red-600",
  };
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 flex items-center gap-3">
      <div className={`w-10 h-10 rounded-lg ${colorMap[color] || colorMap.blue} flex items-center justify-center`}>
        <Icon size={20} />
      </div>
      <div>
        <div className="text-2xl font-bold text-gray-900">{value}</div>
        <div className="text-xs text-gray-500">{label}</div>
      </div>
    </div>
  );
}

export default function HeavyEquipmentView() {
  const [brandSlug, setBrandSlug] = useState("");
  const [typeSlug, setTypeSlug] = useState("");
  const [search, setSearch] = useState("");
  const [selectedSlug, setSelectedSlug] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 50;

  const { data: stats } = trpc.heavyEquipment.stats.useQuery();
  const { data: types } = trpc.heavyEquipment.listTypes.useQuery();
  const { data: brands } = trpc.heavyEquipment.listBrands.useQuery();
  const { data: modelsData } = trpc.heavyEquipment.listModels.useQuery(
    { brandSlug: brandSlug || undefined, typeSlug: typeSlug || undefined, limit: PAGE_SIZE, offset: page * PAGE_SIZE }
  );
  const { data: modelDetail } = trpc.heavyEquipment.getModel.useQuery(
    { slug: selectedSlug! },
    { enabled: !!selectedSlug }
  );

  const models = modelsData?.models || [];
  const total = modelsData?.total || 0;

  // Group models by brand for display
  const grouped = models.reduce((acc: Record<string, any[]>, m) => {
    if (!acc[m.brandName]) acc[m.brandName] = [];
    acc[m.brandName].push(m);
    return acc;
  }, {});

  return (
    <div className="space-y-4">
      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          <StatsCard label="Типов" value={stats.types} icon={Truck} color="blue" />
          <StatsCard label="Брендов" value={stats.brands} icon={Database} color="purple" />
          <StatsCard label="Моделей" value={stats.models} icon={BarChart3} color="green" />
          <StatsCard label="Обогащено" value={stats.enriched} icon={CheckCircle2} color="green" />
          <StatsCard label="Характеристик" value={stats.specs} icon={FileText} color="amber" />
          <StatsCard label="Жидкостей" value={stats.fluids} icon={Droplets} color="blue" />
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex flex-wrap gap-3 items-center">
          <div className="flex items-center gap-2 text-gray-500">
            <Filter size={16} />
            <span className="text-sm font-medium">Фильтры:</span>
          </div>
          <select
            value={brandSlug}
            onChange={(e) => { setBrandSlug(e.target.value); setPage(0); }}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
          >
            <option value="">Все бренды</option>
            {brands?.map((b: any) => (
              <option key={b.slug} value={b.slug}>{b.name}</option>
            ))}
          </select>
          <select
            value={typeSlug}
            onChange={(e) => { setTypeSlug(e.target.value); setPage(0); }}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
          >
            <option value="">Все типы</option>
            {types?.map((t: any) => (
              <option key={t.slug} value={t.slug}>{t.name}</option>
            ))}
          </select>
          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Поиск модели..."
              className="w-full pl-8 pr-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>
          <span className="text-sm text-gray-500">{total} моделей</span>
        </div>
      </div>

      {/* Models List + Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: Models list */}
        <div className="lg:col-span-1 bg-white rounded-lg border border-gray-200 overflow-hidden max-h-[70vh] overflow-y-auto">
          <div className="p-3 border-b border-gray-100 bg-gray-50 sticky top-0 z-10">
            <h3 className="font-semibold text-sm text-gray-700">Модели ({models.length})</h3>
          </div>
          {Object.entries(grouped).map(([brandName, brandModels]) => (
            <div key={brandName}>
              <div className="px-3 py-1.5 bg-gray-50 text-xs font-semibold text-gray-500 uppercase tracking-wide">
                {brandName}
              </div>
              {brandModels.map((m: any) => (
                <button
                  key={m.slug}
                  onClick={() => setSelectedSlug(m.slug)}
                  className={`w-full text-left px-3 py-2 border-b border-gray-50 text-sm hover:bg-red-50 transition-colors flex items-center gap-2 ${
                    selectedSlug === m.slug ? "bg-red-50 border-l-3 border-l-red-500" : ""
                  }`}
                >
                  <span className="flex-1 truncate">{m.title}</span>
                  {m.isEnriched === "yes" && <CheckCircle2 size={12} className="text-green-500 shrink-0" />}
                  {m.isEnriched === "pending" && <Clock size={12} className="text-amber-500 shrink-0" />}
                  {m.isEnriched === "no" && <XCircle size={12} className="text-gray-300 shrink-0" />}
                </button>
              ))}
            </div>
          ))}
          {/* Pagination */}
          {total > PAGE_SIZE && (
            <div className="p-3 border-t border-gray-100 flex items-center justify-between sticky bottom-0 bg-white">
              <button
                onClick={() => setPage(Math.max(0, page - 1))}
                disabled={page === 0}
                className="px-3 py-1 text-sm border border-gray-200 rounded-lg disabled:opacity-50 hover:bg-gray-50"
              >
                Назад
              </button>
              <span className="text-xs text-gray-500">Стр. {page + 1} из {Math.ceil(total / PAGE_SIZE)}</span>
              <button
                onClick={() => setPage(page + 1)}
                disabled={(page + 1) * PAGE_SIZE >= total}
                className="px-3 py-1 text-sm border border-gray-200 rounded-lg disabled:opacity-50 hover:bg-gray-50"
              >
                Вперёд
              </button>
            </div>
          )}
        </div>

        {/* Right: Model Detail */}
        <div className="lg:col-span-2">
          {!selectedSlug ? (
            <div className="bg-white rounded-lg border border-gray-200 p-8 text-center text-gray-400">
              <Truck size={48} className="mx-auto mb-3 opacity-30" />
              <p>Выберите модель для просмотра деталей</p>
            </div>
          ) : !modelDetail ? (
            <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
              <div className="w-8 h-8 border-2 border-red-500 border-t-transparent rounded-full animate-spin mx-auto" />
            </div>
          ) : (
            <div className="space-y-4">
              {/* Header */}
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs px-2 py-0.5 bg-gray-100 rounded-full text-gray-600">{modelDetail.model.typeName}</span>
                      <span className="text-xs px-2 py-0.5 bg-gray-100 rounded-full text-gray-600">{modelDetail.model.brandName}</span>
                      {modelDetail.model.isEnriched === "yes" && (
                        <span className="text-xs px-2 py-0.5 bg-green-100 rounded-full text-green-700 flex items-center gap-1">
                          <CheckCircle2 size={10} /> Обогащено
                        </span>
                      )}
                    </div>
                    <h2 className="text-xl font-bold text-gray-900">{modelDetail.model.title}</h2>
                    {modelDetail.model.description && (
                      <p className="text-sm text-gray-500 mt-1">{modelDetail.model.description}</p>
                    )}
                  </div>
                  {modelDetail.model.url && (
                    <a href={modelDetail.model.url} target="_blank" rel="noopener noreferrer"
                      className="text-red-500 hover:text-red-600 shrink-0">
                      <ExternalLink size={18} />
                    </a>
                  )}
                </div>
              </div>

              {/* Specs */}
              {modelDetail.specs.length > 0 && (
                <div className="bg-white rounded-lg border border-gray-200 p-4">
                  <h3 className="font-semibold text-sm text-gray-700 mb-3 flex items-center gap-2">
                    <FileText size={16} className="text-blue-500" />
                    Характеристики ({modelDetail.specs.length})
                  </h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {modelDetail.specs.map((s: any, i: number) => (
                      <div key={i} className="bg-gray-50 rounded-lg p-2">
                        <div className="text-[10px] text-gray-400 uppercase tracking-wide">{s.param}</div>
                        <div className="text-sm font-medium text-gray-800">{s.value || "—"}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Fluids */}
              {modelDetail.fluids.length > 0 && (
                <div className="bg-white rounded-lg border border-gray-200 p-4">
                  <h3 className="font-semibold text-sm text-gray-700 mb-3 flex items-center gap-2">
                    <Droplets size={16} className="text-blue-500" />
                    Жидкости ({modelDetail.fluids.length})
                  </h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {modelDetail.fluids.map((f: any, i: number) => (
                      <div key={i} className="bg-blue-50 rounded-lg p-2">
                        <div className="text-[10px] text-blue-400 uppercase tracking-wide">{f.fluidType}</div>
                        <div className="text-sm font-bold text-blue-800">{f.value || "—"}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Oil Specs */}
              {modelDetail.oilSpecs.length > 0 && (
                <div className="bg-white rounded-lg border border-gray-200 p-4">
                  <h3 className="font-semibold text-sm text-gray-700 mb-3 flex items-center gap-2">
                    <Beaker size={16} className="text-purple-500" />
                    Допуски {modelDetail.model.brandName} ({modelDetail.oilSpecs.length})
                  </h3>
                  <div className="space-y-2">
                    {modelDetail.oilSpecs.map((s: any, i: number) => (
                      <div key={i} className="bg-gray-50 rounded-lg p-3">
                        <div className="font-medium text-sm text-gray-700 capitalize mb-1">{s.fluidType.replace(/_/g, " ")}</div>
                        {s.oemSpec && <div className="text-xs text-gray-500 mb-1"><span className="font-medium">OEM:</span> {s.oemSpec.substring(0, 200)}{s.oemSpec.length > 200 ? "..." : ""}</div>}
                        {s.viscosity && <div className="text-xs text-gray-500 mb-1"><span className="font-medium">Вязкость:</span> {s.viscosity.substring(0, 150)}...</div>}
                        {s.apiAce && <div className="text-xs text-gray-500"><span className="font-medium">API/ACEA:</span> {s.apiAce.substring(0, 150)}...</div>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
