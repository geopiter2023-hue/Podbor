import { useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Bot, Search, CheckCircle2, XCircle, Clock, Play,
  Filter, RefreshCw, ChevronDown, ChevronRight,
  BarChart3, AlertTriangle
} from "lucide-react";

export default function HeavyEquipmentEnrichView() {
  const [brandSlug, setBrandSlug] = useState("");
  const [typeSlug, setTypeSlug] = useState("");
  const [selectedSlugs, setSelectedSlugs] = useState<Set<string>>(new Set());
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 100;

  const utils = trpc.useUtils();
  const { data: stats } = trpc.heavyEquipment.stats.useQuery();
  const { data: types } = trpc.heavyEquipment.listTypes.useQuery();
  const { data: brands } = trpc.heavyEquipment.listBrands.useQuery();

  const { data: modelsData, isLoading } = trpc.heavyEquipment.listModels.useQuery(
    {
      brandSlug: brandSlug || undefined,
      typeSlug: typeSlug || undefined,
      enrichedOnly: false,
      limit: PAGE_SIZE,
      offset: page * PAGE_SIZE,
    }
  );

  const { data: needEnrichment } = trpc.heavyEquipment.needEnrichment.useQuery();

  const queueMutation = trpc.heavyEquipment.queueForEnrichment.useMutation({
    onSuccess: () => {
      utils.heavyEquipment.listModels.invalidate();
      utils.heavyEquipment.stats.invalidate();
      utils.heavyEquipment.needEnrichment.invalidate();
      setSelectedSlugs(new Set());
    },
  });

  const updateMutation = trpc.heavyEquipment.updateEnrichment.useMutation({
    onSuccess: () => {
      utils.heavyEquipment.listModels.invalidate();
      utils.heavyEquipment.stats.invalidate();
    },
  });

  const models = modelsData?.models || [];
  const total = modelsData?.total || 0;

  // Group by enrichment status
  const enriched = models.filter((m: any) => m.isEnriched === "yes");
  const pending = models.filter((m: any) => m.isEnriched === "pending");
  const notEnriched = models.filter((m: any) => m.isEnriched === "no");

  const toggleSelect = (slug: string) => {
    const next = new Set(selectedSlugs);
    if (next.has(slug)) next.delete(slug);
    else next.add(slug);
    setSelectedSlugs(next);
  };

  const selectAll = () => {
    const notEnrichedSlugs = notEnriched.map((m: any) => m.slug);
    const allSelected = notEnrichedSlugs.every((s: string) => selectedSlugs.has(s));
    if (allSelected) {
      setSelectedSlugs(new Set());
    } else {
      setSelectedSlugs(new Set(notEnrichedSlugs));
    }
  };

  return (
    <div className="space-y-4">
      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="text-2xl font-bold text-gray-900">{stats.models}</div>
            <div className="text-xs text-gray-500">Всего моделей</div>
          </div>
          <div className="bg-green-50 rounded-lg border border-green-200 p-4">
            <div className="text-2xl font-bold text-green-700">{stats.enriched}</div>
            <div className="text-xs text-green-600">Обогащено</div>
          </div>
          <div className="bg-amber-50 rounded-lg border border-amber-200 p-4">
            <div className="text-2xl font-bold text-amber-700">
              {stats.models - stats.enriched}
            </div>
            <div className="text-xs text-amber-600">Требуют обогащения</div>
          </div>
          <div className="bg-blue-50 rounded-lg border border-blue-200 p-4">
            <div className="text-2xl font-bold text-blue-700">
              {stats.models > 0 ? Math.round((stats.enriched / stats.models) * 100) : 0}%
            </div>
            <div className="text-xs text-blue-600">Прогресс</div>
          </div>
        </div>
      )}

      {/* Progress bar */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-700">Прогресс обогащения</span>
          <span className="text-sm text-gray-500">
            {stats?.enriched || 0} / {stats?.models || 0}
          </span>
        </div>
        <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-green-500 rounded-full transition-all"
            style={{ width: `${stats?.models ? (stats.enriched / stats.models) * 100 : 0}%` }}
          />
        </div>
      </div>

      {/* Actions */}
      <div className="bg-white rounded-lg border border-gray-200 p-4 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <Filter size={16} className="text-gray-400" />
          <select
            value={brandSlug}
            onChange={(e) => { setBrandSlug(e.target.value); setPage(0); }}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
          >
            <option value="">Все бренды</option>
            {brands?.map((b: any) => (
              <option key={b.slug} value={b.slug}>{b.name}</option>
            ))}
          </select>
          <select
            value={typeSlug}
            onChange={(e) => { setTypeSlug(e.target.value); setPage(0); }}
            className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
          >
            <option value="">Все типы</option>
            {types?.map((t: any) => (
              <option key={t.slug} value={t.slug}>{t.name}</option>
            ))}
          </select>
        </div>

        {selectedSlugs.size > 0 && (
          <button
            onClick={() => queueMutation.mutate({ slugs: Array.from(selectedSlugs) })}
            disabled={queueMutation.isPending}
            className="flex items-center gap-2 px-4 py-1.5 bg-red-500 text-white rounded-lg text-sm font-medium hover:bg-red-600 disabled:opacity-50"
          >
            <Bot size={16} />
            {queueMutation.isPending ? "Отправка..." : `В очередь (${selectedSlugs.size})`}
          </button>
        )}

        <button
          onClick={selectAll}
          className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm hover:bg-gray-50"
        >
          Выбрать все н/о
        </button>

        <span className="text-sm text-gray-500 ml-auto">
          {total} моделей на странице
        </span>
      </div>

      {/* Models table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 sticky top-0 z-10">
              <tr>
                <th className="px-3 py-2 text-left w-8">
                  <input
                    type="checkbox"
                    onChange={selectAll}
                    checked={notEnriched.length > 0 && notEnriched.every((m: any) => selectedSlugs.has(m.slug))}
                    className="rounded"
                  />
                </th>
                <th className="px-3 py-2 text-left font-medium text-gray-600">Модель</th>
                <th className="px-3 py-2 text-left font-medium text-gray-600">Бренд</th>
                <th className="px-3 py-2 text-left font-medium text-gray-600">Тип</th>
                <th className="px-3 py-2 text-center font-medium text-gray-600">Статус</th>
                <th className="px-3 py-2 text-center font-medium text-gray-600">Спеков</th>
                <th className="px-3 py-2 text-center font-medium text-gray-600">Жидк.</th>
                <th className="px-3 py-2 text-left font-medium text-gray-600">Источник</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={8} className="p-8 text-center text-gray-400">Загрузка...</td></tr>
              ) : models.length === 0 ? (
                <tr><td colSpan={8} className="p-8 text-center text-gray-400">Нет моделей</td></tr>
              ) : (
                models.map((m: any) => (
                  <tr key={m.slug} className="border-b border-gray-50 hover:bg-gray-50">
                    <td className="px-3 py-2">
                      {m.isEnriched === "no" && (
                        <input
                          type="checkbox"
                          checked={selectedSlugs.has(m.slug)}
                          onChange={() => toggleSelect(m.slug)}
                          className="rounded"
                        />
                      )}
                    </td>
                    <td className="px-3 py-2 font-medium text-gray-900">{m.title}</td>
                    <td className="px-3 py-2 text-gray-600">{m.brandName}</td>
                    <td className="px-3 py-2 text-gray-500 text-xs">{m.typeName}</td>
                    <td className="px-3 py-2 text-center">
                      {m.isEnriched === "yes" && (
                        <span className="inline-flex items-center gap-1 text-xs text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
                          <CheckCircle2 size={10} /> Да
                        </span>
                      )}
                      {m.isEnriched === "pending" && (
                        <span className="inline-flex items-center gap-1 text-xs text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
                          <Clock size={10} /> Очередь
                        </span>
                      )}
                      {m.isEnriched === "no" && (
                        <span className="inline-flex items-center gap-1 text-xs text-gray-400 bg-gray-50 px-2 py-0.5 rounded-full">
                          <XCircle size={10} /> Нет
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-center text-gray-600">{m.nOfficialSpecs}</td>
                    <td className="px-3 py-2 text-center text-gray-600">{m.nFluids}</td>
                    <td className="px-3 py-2 text-xs text-gray-500">
                      {m.sourceType || "—"}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {total > PAGE_SIZE && (
          <div className="p-3 border-t border-gray-100 flex items-center justify-between">
            <button
              onClick={() => setPage(Math.max(0, page - 1))}
              disabled={page === 0}
              className="px-3 py-1 text-sm border border-gray-200 rounded-lg disabled:opacity-50 hover:bg-gray-50"
            >
              Назад
            </button>
            <span className="text-xs text-gray-500">Стр. {page + 1} из {Math.ceil(total / PAGE_SIZE)}</span>
            <button
              onClick={() => setPage(page + 1)}
              disabled={(page + 1) * PAGE_SIZE >= total}
              className="px-3 py-1 text-sm border border-gray-200 rounded-lg disabled:opacity-50 hover:bg-gray-50"
            >
              Вперёд
            </button>
          </div>
        )}
      </div>

      {/* Need enrichment quick list */}
      {needEnrichment && needEnrichment.length > 0 && (
        <div className="bg-amber-50 rounded-lg border border-amber-200 p-4">
          <h3 className="font-semibold text-sm text-amber-800 mb-2 flex items-center gap-2">
            <AlertTriangle size={16} />
            Требуют обогащения ({needEnrichment.length})
          </h3>
          <div className="text-xs text-amber-700">
            Первые 10: {needEnrichment.slice(0, 10).map((m: any) => m.title).join(", ")}
            {needEnrichment.length > 10 ? ` и ещё ${needEnrichment.length - 10}...` : ""}
          </div>
        </div>
      )}
    </div>
  );
}
