/**
 * Seed Heavy Equipment data from excapedia Excel files
 * Run: npx tsx api/seed-heavy-equipment.ts
 */

import { createConnection } from "mysql2/promise";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import { readFileSync } from "fs";
import xlsx from "xlsx";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load .env
const envPath = join(__dirname, "..", ".env");
try {
  const env = readFileSync(envPath, "utf-8");
  for (const line of env.split("\n")) {
    const [key, ...rest] = line.split("=");
    if (key && rest.length > 0 && !key.startsWith("#")) {
      process.env[key.trim()] = rest.join("=").trim();
    }
  }
} catch { /* ignore */ }

const DB_URL = process.env.DATABASE_URL;
if (!DB_URL) {
  console.error("DATABASE_URL not set");
  process.exit(1);
}

async function seed() {
  const conn = await createConnection({ uri: DB_URL });
  console.log("Connected to DB");

  // 1. Create tables if not exist
  console.log("\n1. Creating tables...");
  await conn.execute(`
    CREATE TABLE IF NOT EXISTS heavyEquipmentTypes (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      slug VARCHAR(255) NOT NULL UNIQUE,
      sortOrder INT DEFAULT 0,
      isActive ENUM('active','inactive') DEFAULT 'active' NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    )
  `);
  await conn.execute(`
    CREATE TABLE IF NOT EXISTS heavyEquipmentBrands (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      slug VARCHAR(255) NOT NULL UNIQUE,
      logoUrl VARCHAR(500),
      sortOrder INT DEFAULT 0,
      isActive ENUM('active','inactive') DEFAULT 'active' NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    )
  `);
  await conn.execute(`
    CREATE TABLE IF NOT EXISTS heavyEquipmentModels (
      id INT AUTO_INCREMENT PRIMARY KEY,
      slug VARCHAR(255) NOT NULL UNIQUE,
      title VARCHAR(500) NOT NULL,
      brandSlug VARCHAR(255) NOT NULL,
      brandName VARCHAR(255) NOT NULL,
      typeSlug VARCHAR(255) NOT NULL,
      typeName VARCHAR(255) NOT NULL,
      description TEXT,
      url VARCHAR(500),
      photoUrl VARCHAR(500),
      isEnriched ENUM('yes','no','pending') DEFAULT 'no' NOT NULL,
      sourceType VARCHAR(50),
      sourceUrl VARCHAR(500),
      nOfficialSpecs INT DEFAULT 0,
      nFluids INT DEFAULT 0,
      enrichNotes TEXT,
      lastCheckedAt TIMESTAMP NULL,
      lastFilledAt TIMESTAMP NULL,
      checkedBy VARCHAR(255),
      filledBy VARCHAR(100),
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
      INDEX (brandSlug),
      INDEX (typeSlug),
      INDEX (isEnriched),
      INDEX (slug)
    )
  `);
  await conn.execute(`
    CREATE TABLE IF NOT EXISTS heavyEquipmentSpecs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      modelSlug VARCHAR(255) NOT NULL,
      param VARCHAR(255) NOT NULL,
      value VARCHAR(500),
      sourceType VARCHAR(50),
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
      INDEX (modelSlug),
      INDEX (param)
    )
  `);
  await conn.execute(`
    CREATE TABLE IF NOT EXISTS heavyEquipmentFluids (
      id INT AUTO_INCREMENT PRIMARY KEY,
      modelSlug VARCHAR(255) NOT NULL,
      modelTitle VARCHAR(500),
      fluidType VARCHAR(100) NOT NULL,
      value VARCHAR(100),
      sourceType VARCHAR(50),
      sourceUrl VARCHAR(500),
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
      INDEX (modelSlug),
      INDEX (fluidType)
    )
  `);
  await conn.execute(`
    CREATE TABLE IF NOT EXISTS heavyEquipmentOilSpecs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      brandSlug VARCHAR(255) NOT NULL,
      brandName VARCHAR(255) NOT NULL,
      fluidType VARCHAR(100) NOT NULL,
      oemSpec TEXT,
      viscosity TEXT,
      apiAce TEXT,
      changeInterval TEXT,
      sources TEXT,
      notes TEXT,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
      UNIQUE KEY (brandSlug, fluidType),
      INDEX (brandSlug),
      INDEX (fluidType)
    )
  `);
  console.log("Tables OK");

  // 2. Import Types
  console.log("\n2. Importing Types...");
  const enrichedBook = xlsx.readFile(join(__dirname, "../upload/excapedia_enriched.xlsx"));
  const typesSheet = enrichedBook.Sheets["Сводка по типам"];
  const typesData = xlsx.utils.sheet_to_json(typesSheet);

  // Delete existing types
  await conn.execute("DELETE FROM heavyEquipmentTypes");
  for (const row of typesData as any[]) {
    const name = row["type_ru"];
    if (!name) continue;
    const slug = name.toLowerCase()
      .replace(/[^a-z0-9а-я\s]/gi, "")
      .replace(/\s+/g, "-")
      .substring(0, 60);
    await conn.execute(
      "INSERT INTO heavyEquipmentTypes (name, slug) VALUES (?, ?)",
      [name, slug]
    );
  }
  const [typesCount] = await conn.execute("SELECT COUNT(*) as c FROM heavyEquipmentTypes");
  console.log(`  Imported ${(typesCount as any)[0].c} types`);

  // 3. Import Models
  console.log("\n3. Importing Models...");
  const modelsSheet = enrichedBook.Sheets["Модели"];
  const modelsData = xlsx.utils.sheet_to_json(modelsSheet);

  // Delete existing
  await conn.execute("DELETE FROM heavyEquipmentModels");
  await conn.execute("DELETE FROM heavyEquipmentBrands");

  // Collect unique brands
  const brandSet = new Map<string, string>(); // slug -> name
  for (const row of modelsData as any[]) {
    const brandSlug = (row["brands"] || "").toString().trim();
    if (!brandSlug) continue;
    const brandName = brandSlug.replace(/_/g, " ").replace(/\b\w/g, (c: string) => c.toUpperCase());
    if (!brandSet.has(brandSlug)) brandSet.set(brandSlug, brandName);
  }

  // Insert brands
  for (const [slug, name] of brandSet) {
    await conn.execute(
      "INSERT INTO heavyEquipmentBrands (name, slug) VALUES (?, ?)",
      [name, slug]
    );
  }
  console.log(`  Imported ${brandSet.size} brands`);

  // Insert models in batches
  const BATCH = 200;
  let inserted = 0;
  for (let i = 0; i < modelsData.length; i += BATCH) {
    const batch = (modelsData as any[]).slice(i, i + BATCH);
    const values: any[] = [];
    const placeholders: string[] = [];

    for (const row of batch) {
      const slug = (row["slug"] || "").toString().trim();
      const title = (row["title"] || "").toString().trim();
      const brandSlug = (row["brands"] || "").toString().trim();
      const typeName = (row["type_ru"] || "").toString().trim();
      const description = (row["description"] || "").toString().trim() || null;
      const url = (row["url"] || "").toString().trim() || null;
      const photoUrl = (row["photos"] || "").toString().trim() || null;
      const enriched = row["enriched"] === "да" ? "yes" : "no";
      const sourceType = (row["source_type"] || "").toString().trim() || null;
      const sourceUrl = (row["source_url"] || "").toString().trim() || null;
      const nOfficialSpecs = parseInt(row["n_official_specs"]) || 0;
      const nFluids = parseInt(row["n_fluids"]) || 0;
      const enrichNotes = (row["enrich_notes"] || "").toString().trim() || null;

      if (!slug || !title) continue;

      const typeSlug = typeName.toLowerCase()
        .replace(/[^a-z0-9а-я\s]/gi, "")
        .replace(/\s+/g, "-")
        .substring(0, 60);
      const brandName = brandSlug.replace(/_/g, " ").replace(/\b\w/g, (c: string) => c.toUpperCase());

      values.push(slug, title, brandSlug, brandName, typeSlug, typeName, description, url, photoUrl, enriched, sourceType, sourceUrl, nOfficialSpecs, nFluids, enrichNotes);
      placeholders.push("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    }

    if (placeholders.length > 0) {
      const sql = `INSERT INTO heavyEquipmentModels
        (slug, title, brandSlug, brandName, typeSlug, typeName, description, url, photoUrl, isEnriched, sourceType, sourceUrl, nOfficialSpecs, nFluids, enrichNotes)
        VALUES ${placeholders.join(", ")}`;
      await conn.execute(sql, values);
      inserted += placeholders.length;
    }
  }
  console.log(`  Imported ${inserted} models`);

  // 4. Import Specs
  console.log("\n4. Importing Specs...");
  const specsSheet = enrichedBook.Sheets["Офиц_характеристики"];
  const specsData = xlsx.utils.sheet_to_json(specsSheet);
  await conn.execute("DELETE FROM heavyEquipmentSpecs");

  for (let i = 0; i < specsData.length; i += BATCH) {
    const batch = (specsData as any[]).slice(i, i + BATCH);
    const values: any[] = [];
    const placeholders: string[] = [];

    for (const row of batch) {
      const slug = (row["slug"] || "").toString().trim();
      const param = (row["param"] || "").toString().trim();
      const value = (row["value"] || "").toString().trim() || null;
      const sourceType = (row["source_type"] || "").toString().trim() || null;
      if (!slug || !param) continue;
      values.push(slug, param, value, sourceType);
      placeholders.push("(?, ?, ?, ?)");
    }

    if (placeholders.length > 0) {
      await conn.execute(
        `INSERT INTO heavyEquipmentSpecs (modelSlug, param, value, sourceType) VALUES ${placeholders.join(", ")}`,
        values
      );
    }
  }
  const [specsCount] = await conn.execute("SELECT COUNT(*) as c FROM heavyEquipmentSpecs");
  console.log(`  Imported ${(specsCount as any)[0].c} specs`);

  // 5. Import Fluids
  console.log("\n5. Importing Fluids...");
  const fluidsSheet = enrichedBook.Sheets["Жидкости_и_допуски"];
  const fluidsData = xlsx.utils.sheet_to_json(fluidsSheet);
  await conn.execute("DELETE FROM heavyEquipmentFluids");

  for (let i = 0; i < fluidsData.length; i += BATCH) {
    const batch = (fluidsData as any[]).slice(i, i + BATCH);
    const values: any[] = [];
    const placeholders: string[] = [];

    for (const row of batch) {
      const slug = (row["slug"] || "").toString().trim();
      const title = (row["title"] || "").toString().trim() || null;
      const fluid = (row["fluid"] || "").toString().trim();
      const value = (row["value"] || "").toString().trim() || null;
      const sourceType = (row["source_type"] || "").toString().trim() || null;
      const sourceUrl = (row["source_url"] || "").toString().trim() || null;
      if (!slug || !fluid) continue;
      values.push(slug, title, fluid, value, sourceType, sourceUrl);
      placeholders.push("(?, ?, ?, ?, ?, ?)");
    }

    if (placeholders.length > 0) {
      await conn.execute(
        `INSERT INTO heavyEquipmentFluids (modelSlug, modelTitle, fluidType, value, sourceType, sourceUrl) VALUES ${placeholders.join(", ")}`,
        values
      );
    }
  }
  const [fluidsCount] = await conn.execute("SELECT COUNT(*) as c FROM heavyEquipmentFluids");
  console.log(`  Imported ${(fluidsCount as any)[0].c} fluids`);

  // 6. Import Oil Specs (brand-level)
  console.log("\n6. Importing Oil Specs...");
  const oilBook = xlsx.readFile(join(__dirname, "../upload/excapedia_oil_selection.xlsx"));
  const oilSheet = oilBook.Sheets["Допуски по брендам"];
  const oilData = xlsx.utils.sheet_to_json(oilSheet);
  await conn.execute("DELETE FROM heavyEquipmentOilSpecs");

  const fluidTypes = ["engine_oil", "hydraulic", "coolant", "transmission", "axle"];
  let oilInserted = 0;

  for (const row of oilData as any[]) {
    const brandSlug = (row["brand"] || "").toString().trim();
    if (!brandSlug) continue;
    const brandName = brandSlug.replace(/_/g, " ").replace(/\b\w/g, (c: string) => c.toUpperCase());

    for (const ft of fluidTypes) {
      const spec = (row[ft] || "").toString().trim() || null;
      if (!spec) continue;

      // Parse structured data from text
      const oemMatch = spec.match(/oem_spec:\s*([^;]+)/);
      const viscMatch = spec.match(/viscosity:\s*([^;]+)/);
      const apiMatch = spec.match(/api_acea:\s*([^;]+)/);
      const intervalMatch = spec.match(/change_interval:\s*([^;]+)/);

      await conn.execute(
        `INSERT INTO heavyEquipmentOilSpecs (brandSlug, brandName, fluidType, oemSpec, viscosity, apiAce, changeInterval, sources, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         oemSpec=VALUES(oemSpec), viscosity=VALUES(viscosity), apiAce=VALUES(apiAce), changeInterval=VALUES(changeInterval), sources=VALUES(sources), notes=VALUES(notes)`,
        [
          brandSlug, brandName, ft,
          oemMatch ? oemMatch[1].trim() : null,
          viscMatch ? viscMatch[1].trim() : null,
          apiMatch ? apiMatch[1].trim() : null,
          intervalMatch ? intervalMatch[1].trim() : null,
          null,
          spec.substring(0, 500),
        ]
      );
      oilInserted++;
    }
  }
  console.log(`  Imported ${oilInserted} oil specs`);

  await conn.end();
  console.log("\n=== DONE ===");
  console.log(`Types: ${(typesCount as any)[0].c}`);
  console.log(`Brands: ${brandSet.size}`);
  console.log(`Models: ${inserted}`);
  console.log(`Specs: ${(specsCount as any)[0].c}`);
  console.log(`Fluids: ${(fluidsCount as any)[0].c}`);
  console.log(`Oil specs: ${oilInserted}`);
}

seed().catch(console.error);
