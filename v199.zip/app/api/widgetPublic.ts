/**
 * ═══════════════════════════════════════════════════════════
 *  PUBLIC WIDGET REST API v1
 *  For external platforms — CORS-enabled, API key auth
 * ═══════════════════════════════════════════════════════════
 * 
 *  Endpoints:
 *  GET  /api/widget/v1/brands?key=API_KEY
 *  GET  /api/widget/v1/models?key=API_KEY&makeId=N
 *  GET  /api/widget/v1/modifications?key=API_KEY&makeId=N&modelId=N
 *  GET  /api/widget/v1/result?key=API_KEY&makeId=N&modelId=N&modificationId=N
 *  GET  /api/widget/v1/validate?key=API_KEY
 * 
 *  Headers (optional but recommended):
 *  Origin: https://your-domain.com
 */

import { Hono } from "hono";
import { getDb } from "./queries/connection";
import { eq, sql, asc } from "drizzle-orm";
import { brands, models, modifications, mapping, oils, products, productAssignments, companies } from "@db/schema";

const app = new Hono();

// ─── Telegram notification helper ───
async function notifyTelegram(message: string) {
  try {
    const db = getDb();
    const [{ token }] = await db.select({ token: sql<string>`value` })
      .from(sql`systemSettings`)
      .where(sql`key = 'telegram_bot_token'`)
      .limit(1);
    const [{ chatId }] = await db.select({ chatId: sql<string>`value` })
      .from(sql`systemSettings`)
      .where(sql`key = 'telegram_chat_id'`)
      .limit(1);
    if (!token || !chatId) return;
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "HTML",
      }),
    });
  } catch {
    // Silently fail — notification is non-critical
  }
}

// ─── API Key generator ───
function generateApiKey(): string {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let key = "op_"; // oilpodbor prefix
  for (let i = 0; i < 32; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return key;
}

// ─── CORS — allow all widget origins ───
app.use("*", async (c, next) => {
  c.header("Access-Control-Allow-Origin", c.req.header("Origin") || "*");
  c.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  c.header("Access-Control-Allow-Headers", "Content-Type, x-api-key");
  c.header("Access-Control-Allow-Credentials", "true");
  if (c.req.method === "OPTIONS") return c.text("", 204);
  await next();
});

// ─── Helpers ───
function getApiKey(c: any): string | null {
  return c.req.query("key") || c.req.header("x-api-key") || null;
}

function extractDomain(url: string): string | null {
  try { return new URL(url).hostname; } catch { return null; }
}

function isDomainAllowed(allowed: unknown, request: string): boolean {
  const domains = Array.isArray(allowed) ? allowed : [];
  if (domains.length === 0) return false;
  const req = request.toLowerCase().trim();
  return domains.some((d: string) => {
    const dom = d.toLowerCase().trim();
    return dom === req || req.endsWith(`.${dom}`);
  });
}

async function validateKey(c: any) {
  const key = getApiKey(c);
  if (!key) return { error: "Missing API key. Use ?key=YOUR_KEY", status: 401 };

  const db = getDb();
  const [company] = await db.select().from(companies).where(eq(companies.apiKey, key)).limit(1);
  if (!company) return { error: "Invalid API key", status: 401 };
  if (company.isActive !== "active") return { error: "Account suspended", status: 403 };

  const origin = c.req.header("Origin") || c.req.header("Referer") || "";
  const domain = origin ? extractDomain(origin) : null;
  if (!domain || !isDomainAllowed(company.allowedDomains, domain)) {
    return { error: `Domain not allowed: ${domain || "unknown"}`, status: 403 };
  }

  return { company, domain, key, status: 200 };
}

function json(c: any, data: any, status = 200) {
  return c.json({ success: status === 200, ...data }, status as any);
}

// ─── 1. Validate key ───
app.get("/validate", async (c) => {
  const v = await validateKey(c);
  if (v.error) return json(c, { error: v.error }, v.status);
  return json(c, {
    valid: true,
    company: { id: v.company!.id, name: v.company!.name },
    domain: v.domain,
  });
});

// ─── 1b. Public Registration ───
app.post("/register", async (c) => {
  try {
    const body = await c.req.json();
    const { name, email, domain, website } = body || {};

    // Validate
    if (!name || typeof name !== "string" || name.trim().length < 2) {
      return json(c, { error: "Company name is required (min 2 characters)" }, 400);
    }
    if (!email || typeof email !== "string" || !email.includes("@")) {
      return json(c, { error: "Valid email is required" }, 400);
    }
    if (!domain || typeof domain !== "string" || domain.trim().length < 3) {
      return json(c, { error: "Domain is required (e.g. example.com)" }, 400);
    }

    // Clean inputs
    const cleanName = name.trim();
    const cleanEmail = email.trim().toLowerCase();
    let cleanDomain = domain.trim().toLowerCase();
    // Remove protocol if present
    cleanDomain = cleanDomain.replace(/^https?:\/\//, "").replace(/\/+$/, "");
    const cleanSlug = cleanDomain.replace(/[^a-z0-9]/g, "-").substring(0, 60);

    const db = getDb();

    // Check if company with this domain/email already exists
    const existing = await db.select({ id: companies.id, apiKey: companies.apiKey })
      .from(companies)
      .where(sql`${companies.slug} = ${cleanSlug} OR ${companies.contactEmail} = ${cleanEmail}`)
      .limit(1);

    if (existing.length > 0) {
      // Return existing key instead of error — user already registered
      return json(c, {
        success: true,
        message: "Account already exists. Here is your existing API key.",
        apiKey: existing[0].apiKey,
        domain: cleanDomain,
      });
    }

    // Generate API key
    const apiKey = generateApiKey();

    // Create company
    await db.insert(companies).values({
      name: cleanName,
      slug: cleanSlug,
      apiKey,
      contactEmail: cleanEmail,
      website: website ? website.trim() : null,
      allowedDomains: JSON.stringify([cleanDomain]),
      isActive: "active",
    });

    // Send Telegram notification
    await notifyTelegram(
      `<b>🆕 Новый партнёр Widget API</b>\n\n` +
      `<b>Компания:</b> ${cleanName}\n` +
      `<b>Email:</b> ${cleanEmail}\n` +
      `<b>Домен:</b> ${cleanDomain}\n` +
      `<b>Ключ:</b> <code>${apiKey}</code>\n\n` +
      `<i>Автоматически активирован</i>`
    );

    return json(c, {
      success: true,
      message: "Registration successful! Your API key has been generated.",
      apiKey,
      domain: cleanDomain,
    });
  } catch (err: any) {
    console.error("[Widget Register] Error:", err);
    return json(c, { error: "Registration failed. Please try again later." }, 500);
  }
});

// ─── 2. Brands ───
app.get("/brands", async (c) => {
  const v = await validateKey(c);
  if (v.error) return json(c, { error: v.error }, v.status);

  const db = getDb();
  const rows = await db
    .selectDistinct({ id: mapping.newMakeId, name: brands.name })
    .from(brands)
    .innerJoin(mapping, sql`${brands.id} = ${mapping.makeId}`)
    .orderBy(brands.name);

  return json(c, { brands: rows.map((r) => ({ id: Number(r.id), name: r.name })) });
});

// ─── 3. Models ───
app.get("/models", async (c) => {
  const v = await validateKey(c);
  if (v.error) return json(c, { error: v.error }, v.status);

  const makeId = Number(c.req.query("makeId"));
  if (!makeId) return json(c, { error: "Missing makeId" }, 400);

  const db = getDb();
  const rows = await db
    .selectDistinct({
      modelId: mapping.newModelId,
      modelName: models.modelName,
      yearFrom: models.yearFrom,
      yearTo: models.yearTo,
    })
    .from(models)
    .innerJoin(mapping, sql`${models.modelId} = ${mapping.modelId} AND ${models.makeId} = ${mapping.makeId}`)
    .where(sql`${mapping.newMakeId} = ${makeId}`)
    .orderBy(models.modelName);

  return json(c, {
    models: rows.map((r) => ({
      id: Number(r.modelId),
      name: r.modelName,
      yearFrom: r.yearFrom,
      yearTo: r.yearTo,
    })),
  });
});

// ─── 4. Modifications ───
app.get("/modifications", async (c) => {
  const v = await validateKey(c);
  if (v.error) return json(c, { error: v.error }, v.status);

  const makeId = Number(c.req.query("makeId"));
  const modelId = Number(c.req.query("modelId"));
  if (!makeId || !modelId) return json(c, { error: "Missing makeId or modelId" }, 400);

  const db = getDb();
  const rows = await db
    .selectDistinct({
      id: mapping.newTypeId,
      name: modifications.name,
      engineCode: modifications.engineCode,
      fuel: modifications.fuel,
      horsePower: modifications.horsePower,
      engineCapacity: modifications.engineCapacity,
      startDate: modifications.startDate,
      endDate: modifications.endDate,
    })
    .from(modifications)
    .innerJoin(
      mapping,
      sql`${modifications.id} = ${mapping.typeId} AND ${modifications.makeId} = ${mapping.makeId} AND ${modifications.modelId} = ${mapping.modelId}`
    )
    .where(sql`${mapping.newMakeId} = ${makeId} AND ${mapping.newModelId} = ${modelId}`)
    .orderBy(modifications.name);

  return json(c, {
    modifications: rows.map((r) => ({
      id: Number(r.id),
      name: r.name,
      engineCode: r.engineCode,
      fuel: r.fuel,
      horsePower: r.horsePower,
      engineCapacity: r.engineCapacity,
      yearFrom: r.startDate,
      yearTo: r.endDate,
    })),
  });
});

// ─── 5. Result — oils + products ───
app.get("/result", async (c) => {
  const v = await validateKey(c);
  if (v.error) return json(c, { error: v.error }, v.status);

  const makeId = Number(c.req.query("makeId"));
  const modelId = Number(c.req.query("modelId"));
  const modificationId = Number(c.req.query("modificationId"));
  if (!makeId || !modelId || !modificationId) {
    return json(c, { error: "Missing makeId/modelId/modificationId" }, 400);
  }

  const db = getDb();

  // Resolve mapping
  const mappingRows = await db
    .select({ origMakeId: mapping.makeId, origModelId: mapping.modelId, origTypeId: mapping.typeId })
    .from(mapping)
    .where(sql`${mapping.newMakeId} = ${makeId} AND ${mapping.newModelId} = ${modelId} AND ${mapping.newTypeId} = ${modificationId}`)
    .limit(1);

  if (mappingRows.length === 0) return json(c, { oils: [], products: [] });

  const { origMakeId, origModelId, origTypeId } = mappingRows[0];

  // Get catalog oils
  const catalogOils = await db
    .select({
      id: oils.id,
      name: oils.originalName,
      artNumber: oils.artNumber,
      volume: oils.volume,
      comment: oils.commentName,
    })
    .from(oils)
    .where(sql`${oils.makeId} = ${origMakeId} AND ${oils.modelId} = ${origModelId} AND ${oils.modificationId} = CAST(${origTypeId} AS SIGNED)`)
    .orderBy(asc(oils.orderPosition));

  // Get company products
  const companyProducts = await db
    .select({
      id: products.id,
      name: products.name,
      sku: products.sku,
      brand: products.brand,
      price: products.price,
      volume: products.volume,
      specs: products.specs,
      imageUrl: products.imageUrl,
      isRecommended: productAssignments.isRecommended,
    })
    .from(productAssignments)
    .innerJoin(products, eq(productAssignments.productId, products.id))
    .where(sql`${productAssignments.companyId} = ${v.company!.id} AND ${productAssignments.makeId} = ${origMakeId} AND ${productAssignments.modelId} = ${origModelId} AND ${productAssignments.modificationId} = ${origTypeId}`)
    .orderBy(sql`${productAssignments.isRecommended} DESC`);

  // Car info
  const [carInfo] = await db
    .select({ makeName: brands.name, modelName: models.modelName, modificationName: modifications.name })
    .from(modifications)
    .leftJoin(brands, sql`${brands.id} = ${origMakeId}`)
    .leftJoin(models, sql`${models.makeId} = ${origMakeId} AND ${models.modelId} = ${origModelId}`)
    .where(sql`${modifications.id} = ${origTypeId} AND ${modifications.makeId} = ${origMakeId} AND ${modifications.modelId} = ${origModelId}`)
    .limit(1);

  return json(c, {
    car: {
      make: carInfo?.makeName || "",
      model: carInfo?.modelName || "",
      modification: carInfo?.modificationName || "",
    },
    oils: catalogOils,
    products: companyProducts,
  });
});

// ─── 404 catch-all ───
app.all("/*", (c) => json(c, { error: "Not found. Valid endpoints: /validate, /brands, /models, /modifications, /result" }, 404));

export default app;
