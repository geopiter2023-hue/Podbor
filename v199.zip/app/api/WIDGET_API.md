# OILPODBOR — Public Widget REST API v1

## Базовый URL
```
https://oilpodbor.ru/api/widget/v1
```

## Аутентификация
Все запросы требуют API-ключ. Передайте его через:
- Query параметр: `?key=YOUR_API_KEY`
- Или заголовок: `x-api-key: YOUR_API_KEY`

## CORS
API поддерживает кросс-доменные запросы (CORS). Домен проверяется по списку разрешённых в настройках компании.

---

## Endpoints

### 0. Регистрация (получение API ключа)
```http
POST /api/widget/v1/register
Content-Type: application/json

{
  "name": "Your Company Name",
  "email": "you@company.com",
  "domain": "example.com",
  "website": "https://example.com"
}
```

**Параметры:**
| Параметр | Тип | Обязательный | Описание |
|----------|-----|--------------|----------|
| name | string | Да | Название компании/проекта (мин. 2 символа) |
| email | string | Да | Email для связи |
| domain | string | Да | Домен, на котором будет работать виджет |
| website | string | Нет | Полный URL сайта |

**Ответ (успех):**
```json
{
  "success": true,
  "message": "Registration successful! Your API key has been generated.",
  "apiKey": "op_aBcDeFgHiJkLmNoPqRsTuVwXyZ...",
  "domain": "example.com"
}
```

**Ответ (если домен/email уже зарегистрирован):**
```json
{
  "success": true,
  "message": "Account already exists. Here is your existing API key.",
  "apiKey": "op_aBcDeFgHiJkLmNoPqRsTuVwXyZ...",
  "domain": "example.com"
}
```

**Ответ (ошибка):**
```json
{
  "success": false,
  "error": "Company name is required (min 2 characters)"
}
```

**Альтернатива — веб-форма:**
Откройте `https://oilpodbor.ru/#/partner` для регистрации через браузер.

---

### 1. Проверка ключа
```http
GET /api/widget/v1/validate?key=YOUR_API_KEY
```

**Ответ (успех):**
```json
{
  "success": true,
  "valid": true,
  "company": {
    "id": 1,
    "name": "Your Company"
  },
  "domain": "your-site.com"
}
```

**Ответ (ошибка):**
```json
{
  "success": false,
  "error": "Invalid API key"
}
```

---

### 2. Список марок
```http
GET /api/widget/v1/brands?key=YOUR_API_KEY
```

**Ответ:**
```json
{
  "success": true,
  "brands": [
    { "id": 329, "name": "BMW" },
    { "id": 1320, "name": "Audi" },
    { "id": 1604, "name": "Toyota" }
  ]
}
```

---

### 3. Модели по марке
```http
GET /api/widget/v1/models?key=YOUR_API_KEY&makeId=329
```

**Параметры:**
| Параметр | Тип | Описание |
|----------|-----|----------|
| makeId | number | ID марки из /brands |

**Ответ:**
```json
{
  "success": true,
  "models": [
    {
      "id": 4137,
      "name": "X5",
      "yearFrom": 2000,
      "yearTo": 2026
    }
  ]
}
```

---

### 4. Модификации
```http
GET /api/widget/v1/modifications?key=YOUR_API_KEY&makeId=329&modelId=4137
```

**Параметры:**
| Параметр | Тип | Описание |
|----------|-----|----------|
| makeId | number | ID марки |
| modelId | number | ID модели |

**Ответ:**
```json
{
  "success": true,
  "modifications": [
    {
      "id": 67298,
      "name": "xDrive40i 3.0",
      "engineCode": "B58",
      "fuel": "Бензин",
      "horsePower": 340,
      "engineCapacity": 2998,
      "yearFrom": 2018,
      "yearTo": 2026
    }
  ]
}
```

---

### 5. Результат подбора
```http
GET /api/widget/v1/result?key=YOUR_API_KEY&makeId=329&modelId=4137&modificationId=67298
```

**Параметры:**
| Параметр | Тип | Описание |
|----------|-----|----------|
| makeId | number | ID марки |
| modelId | number | ID модели |
| modificationId | number | ID модификации |

**Ответ:**
```json
{
  "success": true,
  "car": {
    "make": "BMW",
    "model": "X5",
    "modification": "xDrive40i 3.0"
  },
  "oils": [
    {
      "id": 1,
      "name": "Моторное масло",
      "artNumber": "LL-01",
      "volume": "6.5",
      "comment": "SAE 5W-30"
    }
  ],
  "products": [
    {
      "id": 1,
      "name": "LUKOIL Genesis",
      "sku": "GEN-5W30-4L",
      "brand": "LUKOIL",
      "price": 4500,
      "volume": "4L",
      "specs": "API SN/CF, ACEA A3/B4",
      "imageUrl": "https://...",
      "isRecommended": true
    }
  ]
}
```

---

## Примеры кода

### JavaScript (vanilla)
```javascript
const API_KEY = 'your-api-key';
const BASE = 'https://oilpodbor.ru/api/widget/v1';

async function getBrands() {
  const r = await fetch(`${BASE}/brands?key=${API_KEY}`);
  return r.json();
}

async function getModels(makeId) {
  const r = await fetch(`${BASE}/models?key=${API_KEY}&makeId=${makeId}`);
  return r.json();
}

async function getModifications(makeId, modelId) {
  const r = await fetch(`${BASE}/modifications?key=${API_KEY}&makeId=${makeId}&modelId=${modelId}`);
  return r.json();
}

async function getResult(makeId, modelId, modificationId) {
  const r = await fetch(`${BASE}/result?key=${API_KEY}&makeId=${makeId}&modelId=${modelId}&modificationId=${modificationId}`);
  return r.json();
}
```

### React
```jsx
import { useState, useEffect } from 'react';

const API_KEY = 'your-api-key';
const BASE = 'https://oilpodbor.ru/api/widget/v1';

function OilWidget() {
  const [brands, setBrands] = useState([]);
  
  useEffect(() => {
    fetch(`${BASE}/brands?key=${API_KEY}`)
      .then(r => r.json())
      .then(data => setBrands(data.brands));
  }, []);

  return (
    <div>
      {brands.map(b => (
        <button key={b.id}>{b.name}</button>
      ))}
    </div>
  );
}
```

### PHP
```php
<?php
$apiKey = 'your-api-key';
$base = 'https://oilpodbor.ru/api/widget/v1';

$response = file_get_contents("$base/brands?key=$apiKey");
$data = json_decode($response, true);

foreach ($data['brands'] as $brand) {
    echo $brand['name'] . "\n";
}
?>
```

### Python
```python
import requests

API_KEY = 'your-api-key'
BASE = 'https://oilpodbor.ru/api/widget/v1'

r = requests.get(f'{BASE}/brands', params={'key': API_KEY})
data = r.json()

for brand in data['brands']:
    print(brand['name'])
```

### WordPress (shortcode)
```php
function oilpodbor_widget() {
    $api_key = 'your-api-key';
    ob_start();
    ?>
    <div id="oilpodbor-widget"></div>
    <script>
    (async () => {
        const r = await fetch('https://oilpodbor.ru/api/widget/v1/brands?key=<?php echo $api_key; ?>');
        const data = await r.json();
        document.getElementById('oilpodbor-widget').innerHTML = 
            data.brands.map(b => `<button onclick="selectBrand(${b.id})">${b.name}</button>`).join('');
    })();
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('oilpodbor', 'oilpodbor_widget');
```

---

## Коды ошибок

| Код | Описание |
|-----|----------|
| 200 | Успех |
| 400 | Неверные параметры |
| 401 | Нет API ключа или ключ неверный |
| 403 | Домен не разрешён |
| 404 | Endpoint не найден |
| 500 | Ошибка сервера |

---

## Получить API ключ

### Способ 1 — Автоматическая регистрация (рекомендуется)
1. Откройте `https://oilpodbor.ru/#/partner`
2. Заполните форму (название, email, домен)
3. Получите API-ключ мгновенно

### Способ 2 — Через админку
1. Войдите в админку oilpodbor.ru
2. Перейдите в раздел "Компании / Виджеты"
3. Создайте компанию или используйте существующую
4. Скопируйте API-ключ
5. Настройте разрешённые домены

### Способ 3 — API (для интеграций)
```bash
curl -X POST https://oilpodbor.ru/api/widget/v1/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Your Company",
    "email": "you@company.com",
    "domain": "example.com"
  }'
```
