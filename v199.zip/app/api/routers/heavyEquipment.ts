import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import {
  heavyEquipmentTypes,
  heavyEquipmentBrands,
  heavyEquipmentModels,
  heavyEquipmentSpecs,
  heavyEquipmentFluids,
  heavyEquipmentOilSpecs,
} from "@db/schema";
import { eq, and, sql, like, count } from "drizzle-orm";

export const heavyEquipmentRouter = createRouter({
  // ─── Types ───
  listTypes: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(heavyEquipmentTypes).where(eq(heavyEquipmentTypes.isActive, "active")).orderBy(heavyEquipmentTypes.sortOrder);
  }),

  // ─── Brands ───
  listBrands: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(heavyEquipmentBrands).where(eq(heavyEquipmentBrands.isActive, "active")).orderBy(heavyEquipmentBrands.sortOrder);
  }),

  // ─── Models (with filters) ───
  listModels: publicQuery
    .input(
      z.object({
        brandSlug: z.string().optional(),
        typeSlug: z.string().optional(),
        search: z.string().optional(),
        enrichedOnly: z.boolean().optional(),
        limit: z.number().min(1).max(500).default(100),
        offset: z.number().min(0).default(0),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions: any[] = [];

      if (input?.brandSlug) {
        conditions.push(eq(heavyEquipmentModels.brandSlug, input.brandSlug));
      }
      if (input?.typeSlug) {
        conditions.push(eq(heavyEquipmentModels.typeSlug, input.typeSlug));
      }
      if (input?.enrichedOnly) {
        conditions.push(eq(heavyEquipmentModels.isEnriched, "yes"));
      }

      let query = db.select().from(heavyEquipmentModels);

      if (conditions.length > 0) {
        query = query.where(and(...conditions)) as any;
      }

      const models = await query.limit(input?.limit || 100).offset(input?.offset || 0).orderBy(heavyEquipmentModels.title);

      // Get total count
      let countQuery = db.select({ c: count() }).from(heavyEquipmentModels);
      if (conditions.length > 0) {
        countQuery = countQuery.where(and(...conditions)) as any;
      }
      const [total] = await countQuery;

      return { models, total: total.c };
    }),

  // ─── Single Model with details ───
  getModel: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [model] = await db.select().from(heavyEquipmentModels).where(eq(heavyEquipmentModels.slug, input.slug)).limit(1);
      if (!model) return null;

      // Get specs
      const specs = await db.select().from(heavyEquipmentSpecs).where(eq(heavyEquipmentSpecs.modelSlug, input.slug));

      // Get fluids
      const fluids = await db.select().from(heavyEquipmentFluids).where(eq(heavyEquipmentFluids.modelSlug, input.slug));

      // Get oil specs for this brand
      const oilSpecs = await db.select().from(heavyEquipmentOilSpecs).where(eq(heavyEquipmentOilSpecs.brandSlug, model.brandSlug));

      return { model, specs, fluids, oilSpecs };
    }),

  // ─── Model Specs ───
  getSpecs: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(heavyEquipmentSpecs).where(eq(heavyEquipmentSpecs.modelSlug, input.slug));
    }),

  // ─── Model Fluids ───
  getFluids: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(heavyEquipmentFluids).where(eq(heavyEquipmentFluids.modelSlug, input.slug));
    }),

  // ─── Oil Specs by Brand ───
  getOilSpecs: publicQuery
    .input(z.object({ brandSlug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.select().from(heavyEquipmentOilSpecs).where(eq(heavyEquipmentOilSpecs.brandSlug, input.brandSlug));
    }),

  // ─── Stats ───
  stats: publicQuery.query(async () => {
    const db = getDb();
    const [types] = await db.select({ c: count() }).from(heavyEquipmentTypes);
    const [brands] = await db.select({ c: count() }).from(heavyEquipmentBrands);
    const [models] = await db.select({ c: count() }).from(heavyEquipmentModels);
    const [enriched] = await db.select({ c: count() }).from(heavyEquipmentModels).where(eq(heavyEquipmentModels.isEnriched, "yes"));
    const [specs] = await db.select({ c: count() }).from(heavyEquipmentSpecs);
    const [fluids] = await db.select({ c: count() }).from(heavyEquipmentFluids);
    const [oilSpecs] = await db.select({ c: count() }).from(heavyEquipmentOilSpecs);

    return {
      types: types.c,
      brands: brands.c,
      models: models.c,
      enriched: enriched.c,
      specs: specs.c,
      fluids: fluids.c,
      oilSpecs: oilSpecs.c,
    };
  }),

  // ─── Admin: Update enrichment status ───
  updateEnrichment: adminQuery
    .input(z.object({
      slug: z.string(),
      isEnriched: z.enum(["yes", "no", "pending"]),
      enrichNotes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(heavyEquipmentModels)
        .set({
          isEnriched: input.isEnriched,
          enrichNotes: input.enrichNotes || null,
          lastFilledAt: input.isEnriched === "yes" ? new Date() : undefined,
        })
        .where(eq(heavyEquipmentModels.slug, input.slug));
      return { success: true };
    }),

  // ─── Admin: Run enrichment (mark pending) ───
  queueForEnrichment: adminQuery
    .input(z.object({
      slugs: z.array(z.string()),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      for (const slug of input.slugs) {
        await db.update(heavyEquipmentModels)
          .set({ isEnriched: "pending" })
          .where(eq(heavyEquipmentModels.slug, slug));
      }
      return { success: true, count: input.slugs.length };
    }),

  // ─── Admin: Add/Update Oil Spec ───
  updateOilSpec: adminQuery
    .input(z.object({
      brandSlug: z.string(),
      fluidType: z.string(),
      oemSpec: z.string().optional(),
      viscosity: z.string().optional(),
      apiAce: z.string().optional(),
      changeInterval: z.string().optional(),
      sources: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(heavyEquipmentOilSpecs)
        .values(input)
        .onDuplicateKeyUpdate({
          set: {
            oemSpec: input.oemSpec,
            viscosity: input.viscosity,
            apiAce: input.apiAce,
            changeInterval: input.changeInterval,
            sources: input.sources,
            notes: input.notes,
          },
        });
      return { success: true };
    }),

  // ─── Admin: Models needing enrichment ───
  needEnrichment: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(heavyEquipmentModels)
      .where(eq(heavyEquipmentModels.isEnriched, "no"))
      .limit(200)
      .orderBy(heavyEquipmentModels.title);
  }),
});
